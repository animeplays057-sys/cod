from pydantic_settings import BaseSettings
from functools import lru_cache
from typing import Optional


class Settings(BaseSettings):
    # Supabase
    supabase_url: str
    supabase_service_key: str
    supabase_anon_key: str

    # Meta / Instagram
    meta_app_id: str
    meta_app_secret: str
    meta_webhook_verify_token: str
    instagram_redirect_uri: str

    # Instagram App ID & Secret (DIFFERENT from Meta App ID!)
    # Found in: App Dashboard > Instagram > API setup with Instagram login
    #           > Set up Instagram business login > Business login settings
    instagram_app_id: Optional[str] = None      # Instagram-specific App ID
    instagram_app_secret: Optional[str] = None  # Instagram-specific App Secret

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # Security
    secret_key: str
    fernet_key: str

    # App
    frontend_url: str = "http://localhost:5173"
    environment: str = "development"

    # Sentry (optional)
    sentry_dsn: Optional[str] = None

    class Config:
        env_file = ".env"
        extra = "ignore"


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
