from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from config import settings
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)
logger = logging.getLogger(__name__)

# Sentry (optional)
if settings.sentry_dsn:
    import sentry_sdk
    sentry_sdk.init(dsn=settings.sentry_dsn, traces_sample_rate=0.2)

# Create FastAPI app
app = FastAPI(
    title="InstaFlow API",
    description="Instagram DM Automation Platform — by codverify.tech",
    version="1.0.0",
    docs_url="/docs" if settings.environment != "production" else None,
    redoc_url=None
)

# CORS — Allow Cloudflare Pages frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        settings.frontend_url,
        "http://localhost:5173",
        "http://localhost:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register all routers
from routes.auth import router as auth_router
from routes.admin import router as admin_router
from routes.instagram import router as instagram_router
from routes.webhook import router as webhook_router
from routes.automations import router as automations_router
from routes.subscribers import router as subscribers_router
from routes.analytics import router as analytics_router

app.include_router(auth_router)
app.include_router(admin_router)
app.include_router(instagram_router)
app.include_router(webhook_router)
app.include_router(automations_router)
app.include_router(subscribers_router)
app.include_router(analytics_router)


@app.get("/health")
async def health_check():
    """Health check endpoint for AWS load balancer."""
    return {"status": "healthy", "service": "instaflow-api"}


@app.on_event("startup")
async def startup():
    logger.info("🚀 InstaFlow API started")
    logger.info(f"   Environment: {settings.environment}")
    logger.info(f"   Frontend: {settings.frontend_url}")


@app.on_event("shutdown")
async def shutdown():
    logger.info("🔴 InstaFlow API shutting down")
