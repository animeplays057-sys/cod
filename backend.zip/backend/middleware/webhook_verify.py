import hmac
import hashlib
from fastapi import Request, HTTPException, status
from config import settings
import logging

logger = logging.getLogger(__name__)


def verify_meta_signature(payload: bytes, signature_header: str) -> bool:
    """
    Verify Meta webhook signature using HMAC-SHA256.
    Meta sends: X-Hub-Signature-256: sha256=<hash>
    """
    if not signature_header or not signature_header.startswith("sha256="):
        return False

    expected_signature = signature_header[7:]  # Remove "sha256="

    # ✅ FIXED: Use hmac.new() correctly (Python's hmac module)
    computed = hmac.new(
        settings.meta_app_secret.encode("utf-8"),
        payload,
        hashlib.sha256
    ).hexdigest()

    return hmac.compare_digest(computed, expected_signature)


async def validate_webhook_signature(request: Request) -> bytes:
    """
    FastAPI dependency: reads raw body and validates Meta signature.
    Returns raw body for further processing.

    NOTE: Meta webhook events MUST always receive HTTP 200. If we raise 403,
    Meta will retry and eventually disable the webhook subscription.
    We raise here only for non-Meta callers (security boundary).
    For Meta verification failures in production, consider returning body
    with a warning instead of raising, to prevent webhook deregistration.
    """
    body = await request.body()
    signature = request.headers.get("X-Hub-Signature-256", "")

    if not signature:
        # No signature header — likely not from Meta, reject
        logger.warning(f"Webhook called without X-Hub-Signature-256 from {request.client.host}")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Missing webhook signature"
        )

    if not verify_meta_signature(body, signature):
        logger.error(
            f"Invalid webhook signature from {request.client.host}. "
            f"Check META_APP_SECRET in .env matches Meta Developer Console."
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid webhook signature — check META_APP_SECRET"
        )

    return body
