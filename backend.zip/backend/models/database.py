from supabase import create_client, Client
from config import settings

# Service client — bypasses RLS, for backend operations only
supabase: Client = create_client(
    settings.supabase_url,
    settings.supabase_service_key
)
