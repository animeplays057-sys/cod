from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum


# ============================================================
# Enums
# ============================================================
class TriggerType(str, Enum):
    COMMENT_KEYWORD = "comment_keyword"
    ANY_COMMENT = "any_comment"
    STORY_MENTION = "story_mention"
    STORY_REPLY = "story_reply"
    DM_KEYWORD = "dm_keyword"
    REF_URL = "ref_url"


class KeywordMatch(str, Enum):
    EXACT = "exact"
    CONTAINS = "contains"
    STARTS_WITH = "starts_with"
    ANY = "any"


class PostFilter(str, Enum):
    ALL_POSTS = "all_posts"
    SPECIFIC_POST = "specific_post"
    REELS_ONLY = "reels_only"


class DripStatus(str, Enum):
    PENDING = "pending"
    SENT = "sent"
    CANCELLED = "cancelled"
    FAILED = "failed"


# ============================================================
# Auth
# ============================================================
class LoginRequest(BaseModel):
    email: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: str
    role: str
    email: str
    full_name: Optional[str] = None
    is_active: bool = True


# ============================================================
# Admin — User Management
# ============================================================
class CreateUserRequest(BaseModel):
    email: str
    full_name: str
    password: str
    role: str = "user"


class UpdateUserRequest(BaseModel):
    full_name: Optional[str] = None
    is_active: Optional[bool] = None
    role: Optional[str] = None


class UserResponse(BaseModel):
    id: str
    email: str
    full_name: Optional[str]
    role: str
    is_active: bool
    created_at: datetime
    last_login: Optional[datetime]


# ============================================================
# Instagram Accounts
# ============================================================
class InstagramAccountResponse(BaseModel):
    id: str
    ig_user_id: str
    username: str
    name: Optional[str]
    profile_pic_url: Optional[str]
    fb_page_id: Optional[str]
    fb_page_name: Optional[str]
    is_active: bool
    webhook_subscribed: bool
    connected_at: datetime
    token_expires_at: Optional[datetime]


# ============================================================
# Automations
# ============================================================
class CreateAutomationRequest(BaseModel):
    ig_account_id: str
    name: str
    description: Optional[str] = None
    trigger_type: TriggerType
    trigger_keyword: Optional[str] = None
    keyword_match: Optional[KeywordMatch] = KeywordMatch.CONTAINS
    post_filter: PostFilter = PostFilter.ALL_POSTS
    specific_post_id: Optional[str] = None
    also_reply_comment: bool = False
    comment_reply_text: Optional[str] = None
    flow_json: Dict[str, Any] = Field(default={"nodes": [], "edges": []})


class UpdateAutomationRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    trigger_type: Optional[TriggerType] = None
    trigger_keyword: Optional[str] = None
    keyword_match: Optional[KeywordMatch] = None
    post_filter: Optional[PostFilter] = None
    specific_post_id: Optional[str] = None
    also_reply_comment: Optional[bool] = None
    comment_reply_text: Optional[str] = None
    flow_json: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None


class AutomationResponse(BaseModel):
    id: str
    ig_account_id: str
    name: str
    description: Optional[str]
    is_active: bool
    trigger_type: str
    trigger_keyword: Optional[str]
    keyword_match: Optional[str]
    post_filter: str
    specific_post_id: Optional[str]
    also_reply_comment: bool
    comment_reply_text: Optional[str]
    flow_json: Dict[str, Any]
    total_triggered: int
    total_dm_sent: int
    created_at: datetime
    updated_at: datetime


# ============================================================
# Subscribers
# ============================================================
class UpdateSubscriberRequest(BaseModel):
    tags: Optional[List[str]] = None
    custom_fields: Optional[Dict[str, Any]] = None
    opted_out: Optional[bool] = None


class SubscriberResponse(BaseModel):
    id: str
    ig_account_id: str
    ig_user_id: str
    username: Optional[str]
    name: Optional[str]
    profile_pic_url: Optional[str]
    first_seen_at: datetime
    last_interaction_at: datetime
    tags: List[str]
    custom_fields: Dict[str, Any]
    opted_out: bool
    opted_out_at: Optional[datetime]


# ============================================================
# Analytics
# ============================================================
class DashboardStats(BaseModel):
    total_automations: int
    active_automations: int
    total_subscribers: int
    dms_sent_today: int
    dms_sent_this_week: int
    dms_sent_this_month: int
    opted_out_total: int


# ============================================================
# Webhook (internal use)
# ============================================================
class WebhookEvent(BaseModel):
    event_type: str  # "comment" | "message" | "story_mention"
    ig_account_id: str  # Our DB id
    ig_user_id: str  # The person who triggered (commenter/DM sender)
    username: Optional[str]
    text: Optional[str]
    post_id: Optional[str]
    comment_id: Optional[str]
    timestamp: datetime


# ============================================================
# Generic
# ============================================================
class SuccessResponse(BaseModel):
    success: bool = True
    message: str


class ErrorResponse(BaseModel):
    success: bool = False
    error: str
    detail: Optional[str] = None
