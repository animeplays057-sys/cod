from fastapi import APIRouter, HTTPException, Depends, status
from models.database import supabase
from models.schemas import (
    CreateUserRequest, UpdateUserRequest, UserResponse, SuccessResponse
)
from middleware.auth_middleware import require_admin
import logging

router = APIRouter(prefix="/admin", tags=["admin"])
logger = logging.getLogger(__name__)


@router.get("/users", response_model=list[UserResponse])
async def list_users(admin=Depends(require_admin)):
    """Get all platform users (admin only)."""
    result = supabase.table("profiles")\
        .select("*")\
        .order("created_at", desc=True)\
        .execute()
    return result.data or []


@router.post("/users", response_model=UserResponse, status_code=201)
async def create_user(body: CreateUserRequest, admin=Depends(require_admin)):
    """
    Admin creates a new user account.
    Sends a confirmation email via Supabase.
    """
    try:
        # Create auth user via Supabase Admin API
        auth_response = supabase.auth.admin.create_user({
            "email": body.email,
            "password": body.password,
            "email_confirm": True,  # Auto-confirm so they can login immediately
        })

        if not auth_response.user:
            raise HTTPException(status_code=400, detail="Failed to create auth user in Supabase")

        user_id = str(auth_response.user.id)

        # ✅ FIXED: Use upsert() instead of update()
        # The DB trigger auto-creates a minimal profile row (id + email only).
        # If trigger hasn't run yet OR trigger failed, update() silently returns 0 rows.
        # upsert() safely handles both cases.
        supabase.table("profiles").upsert({
            "id": user_id,
            "email": body.email,
            "full_name": body.full_name,
            "role": body.role,
            "created_by": admin["id"],
            "is_active": True
        }, on_conflict="id").execute()

        # Return updated profile
        profile = supabase.table("profiles")\
            .select("*")\
            .eq("id", user_id)\
            .single()\
            .execute()

        if not profile.data:
            raise HTTPException(status_code=500, detail="User created but profile not found. Check DB trigger.")

        return profile.data

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Create user error: {e}")
        raise HTTPException(status_code=400, detail=f"Failed to create user: {str(e)}")


@router.patch("/users/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: str,
    body: UpdateUserRequest,
    admin=Depends(require_admin)
):
    """Update user profile (admin only)."""
    update_data = body.model_dump(exclude_none=True)
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields to update")

    result = supabase.table("profiles")\
        .update(update_data)\
        .eq("id", user_id)\
        .execute()

    if not result.data:
        raise HTTPException(status_code=404, detail="User not found")

    return result.data[0]


@router.delete("/users/{user_id}", response_model=SuccessResponse)
async def deactivate_user(user_id: str, admin=Depends(require_admin)):
    """Deactivate a user (soft delete — sets is_active=false)."""
    supabase.table("profiles")\
        .update({"is_active": False})\
        .eq("id", user_id)\
        .execute()
    return SuccessResponse(message="User deactivated")


@router.get("/stats")
async def platform_stats(admin=Depends(require_admin)):
    """Platform-wide stats for admin dashboard."""
    users = supabase.table("profiles").select("id", count="exact").execute()
    ig_accounts = supabase.table("instagram_accounts").select("id", count="exact").execute()
    automations = supabase.table("automations").select("id", count="exact").eq("is_active", True).execute()
    dms_today = supabase.table("automation_logs")\
        .select("id", count="exact")\
        .eq("dm_sent", True)\
        .gte("sent_at", "now() - interval '24 hours'")\
        .execute()

    return {
        "total_users": users.count,
        "total_ig_accounts": ig_accounts.count,
        "active_automations": automations.count,
        "dms_sent_today": dms_today.count,
    }
