from fastapi import APIRouter, Depends
from models.database import supabase
from middleware.auth_middleware import get_current_user
from datetime import datetime, timezone, timedelta

router = APIRouter(prefix="/analytics", tags=["analytics"])


@router.get("/dashboard")
async def get_dashboard_stats(current_user=Depends(get_current_user)):
    """Main analytics stats for the user dashboard."""
    user_id = current_user["id"]
    now = datetime.now(timezone.utc)

    # Get user's IG account IDs
    accounts = supabase.table("instagram_accounts")\
        .select("id")\
        .eq("user_id", user_id)\
        .execute()
    account_ids = [a["id"] for a in (accounts.data or [])]

    if not account_ids:
        return _empty_stats()

    # Automations
    autos = supabase.table("automations")\
        .select("id, is_active", count="exact")\
        .eq("user_id", user_id)\
        .execute()
    total_auto = autos.count or 0
    active_auto = sum(1 for a in (autos.data or []) if a["is_active"])

    # Subscribers
    subs = supabase.table("subscribers")\
        .select("id, opted_out", count="exact")\
        .in_("ig_account_id", account_ids)\
        .execute()
    total_subs = subs.count or 0
    opted_out = sum(1 for s in (subs.data or []) if s["opted_out"])

    # DMs sent
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    week_start = (now - timedelta(days=7)).isoformat()
    month_start = (now - timedelta(days=30)).isoformat()

    logs_month = supabase.table("automation_logs")\
        .select("sent_at, dm_sent")\
        .in_("ig_account_id", account_ids)\
        .eq("dm_sent", True)\
        .gte("sent_at", month_start)\
        .execute()

    logs = logs_month.data or []
    dms_today = sum(1 for l in logs if l["sent_at"] >= today_start)
    dms_week = sum(1 for l in logs if l["sent_at"] >= week_start)
    dms_month = len(logs)

    return {
        "total_automations": total_auto,
        "active_automations": active_auto,
        "total_subscribers": total_subs,
        "opted_out_total": opted_out,
        "dms_sent_today": dms_today,
        "dms_sent_this_week": dms_week,
        "dms_sent_this_month": dms_month,
    }


@router.get("/automations/{automation_id}")
async def get_automation_analytics(
    automation_id: str,
    current_user=Depends(get_current_user)
):
    """Per-automation analytics."""
    auto = supabase.table("automations")\
        .select("*")\
        .eq("id", automation_id)\
        .eq("user_id", current_user["id"])\
        .single()\
        .execute()

    if not auto.data:
        return {}

    logs = supabase.table("automation_logs")\
        .select("dm_sent, sent_at")\
        .eq("automation_id", automation_id)\
        .order("sent_at", desc=True)\
        .limit(500)\
        .execute()

    data = logs.data or []
    total = len(data)
    sent = sum(1 for l in data if l["dm_sent"])
    failed = total - sent

    return {
        "automation_id": automation_id,
        "name": auto.data["name"],
        "total_triggered": auto.data["total_triggered"],
        "total_dm_sent": auto.data["total_dm_sent"],
        "success_rate": round((sent / total * 100) if total > 0 else 0, 1),
        "recent_logs": data[:20]
    }


def _empty_stats():
    return {
        "total_automations": 0,
        "active_automations": 0,
        "total_subscribers": 0,
        "opted_out_total": 0,
        "dms_sent_today": 0,
        "dms_sent_this_week": 0,
        "dms_sent_this_month": 0,
    }
