from fastapi import APIRouter, HTTPException, status
from models.database import supabase
from models.schemas import LoginRequest, TokenResponse, SuccessResponse
from datetime import datetime, timezone
import logging

router = APIRouter(prefix="/auth", tags=["auth"])
logger = logging.getLogger(__name__)


@router.post("/login", response_model=TokenResponse)
async def login(request: LoginRequest):
    """Login with email and password. Returns Supabase JWT."""
    try:
        response = supabase.auth.sign_in_with_password({
            "email": request.email,
            "password": request.password
        })

        if not response.user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password"
            )

        # Check if user is active
        profile = supabase.table("profiles")\
            .select("role, is_active, id, email, full_name")\
            .eq("id", response.user.id)\
            .single()\
            .execute()

        if not profile.data:
            raise HTTPException(status_code=401, detail="Profile not found")

        if not profile.data.get("is_active", True):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Your account has been deactivated. Contact admin."
            )

        # ✅ FIXED: Use proper Python datetime — "now()" string was being stored literally!
        supabase.table("profiles").update(
            {"last_login": datetime.now(timezone.utc).isoformat()}
        ).eq("id", response.user.id).execute()

        return TokenResponse(
            access_token=response.session.access_token,
            user_id=str(response.user.id),
            role=profile.data.get("role", "user"),
            email=profile.data.get("email", request.email),
            full_name=profile.data.get("full_name"),
            is_active=profile.data.get("is_active", True)
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Login error: {e}")
        raise HTTPException(status_code=401, detail="Login failed")


@router.post("/logout", response_model=SuccessResponse)
async def logout():
    """Sign out (client should discard JWT token)."""
    return SuccessResponse(message="Logged out successfully")
