from fastapi import APIRouter, HTTPException, Depends
from models.database import supabase
from models.schemas import (
    CreateAutomationRequest, UpdateAutomationRequest,
    AutomationResponse, SuccessResponse
)
from middleware.auth_middleware import get_current_user
from services.content_filter import check_message_safety
import logging

router = APIRouter(prefix="/automations", tags=["automations"])
logger = logging.getLogger(__name__)


def _extract_messages_from_flow(flow_json: dict) -> list[str]:
    """Extract all message texts from flow_json for safety validation."""
    messages = []
    for node in flow_json.get("nodes", []):
        if node.get("type") == "messageNode":
            msg = node.get("data", {}).get("message", "")
            if msg:
                messages.append(msg)
    return messages


@router.get("/", response_model=list[AutomationResponse])
async def list_automations(
    ig_account_id: str = None,
    current_user=Depends(get_current_user)
):
    query = supabase.table("automations")\
        .select("*")\
        .eq("user_id", current_user["id"])\
        .order("created_at", desc=True)

    if ig_account_id:
        query = query.eq("ig_account_id", ig_account_id)

    result = query.execute()
    return result.data or []


@router.post("/", response_model=AutomationResponse, status_code=201)
async def create_automation(
    body: CreateAutomationRequest,
    current_user=Depends(get_current_user)
):
    # Verify IG account belongs to this user
    account = supabase.table("instagram_accounts")\
        .select("id")\
        .eq("id", body.ig_account_id)\
        .eq("user_id", current_user["id"])\
        .single()\
        .execute()

    if not account.data:
        raise HTTPException(status_code=404, detail="Instagram account not found")

    # Safety check on all messages in the flow
    for msg in _extract_messages_from_flow(body.flow_json):
        is_safe, reason = check_message_safety(msg)
        if not is_safe:
            raise HTTPException(
                status_code=400,
                detail=f"Message failed safety check: {reason}"
            )

    result = supabase.table("automations").insert({
        "user_id": current_user["id"],
        "ig_account_id": body.ig_account_id,
        "name": body.name,
        "description": body.description,
        "trigger_type": body.trigger_type,
        "trigger_keyword": body.trigger_keyword,
        "keyword_match": body.keyword_match,
        "post_filter": body.post_filter,
        "specific_post_id": body.specific_post_id,
        "also_reply_comment": body.also_reply_comment,
        "comment_reply_text": body.comment_reply_text,
        "flow_json": body.flow_json,
        "is_active": False
    }).execute()

    return result.data[0]


@router.get("/{automation_id}", response_model=AutomationResponse)
async def get_automation(automation_id: str, current_user=Depends(get_current_user)):
    result = supabase.table("automations")\
        .select("*")\
        .eq("id", automation_id)\
        .eq("user_id", current_user["id"])\
        .single()\
        .execute()

    if not result.data:
        raise HTTPException(status_code=404, detail="Automation not found")
    return result.data


@router.patch("/{automation_id}", response_model=AutomationResponse)
async def update_automation(
    automation_id: str,
    body: UpdateAutomationRequest,
    current_user=Depends(get_current_user)
):
    update_data = body.model_dump(exclude_none=True)
    if not update_data:
        raise HTTPException(status_code=400, detail="Nothing to update")

    # Safety check if flow_json is being updated
    if "flow_json" in update_data:
        for msg in _extract_messages_from_flow(update_data["flow_json"]):
            is_safe, reason = check_message_safety(msg)
            if not is_safe:
                raise HTTPException(status_code=400, detail=f"Message failed safety check: {reason}")

    result = supabase.table("automations")\
        .update(update_data)\
        .eq("id", automation_id)\
        .eq("user_id", current_user["id"])\
        .execute()

    if not result.data:
        raise HTTPException(status_code=404, detail="Automation not found")
    return result.data[0]


@router.post("/{automation_id}/activate", response_model=SuccessResponse)
async def activate_automation(automation_id: str, current_user=Depends(get_current_user)):
    result = supabase.table("automations")\
        .update({"is_active": True})\
        .eq("id", automation_id)\
        .eq("user_id", current_user["id"])\
        .execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Automation not found")
    return SuccessResponse(message="Automation activated")


@router.post("/{automation_id}/deactivate", response_model=SuccessResponse)
async def deactivate_automation(automation_id: str, current_user=Depends(get_current_user)):
    supabase.table("automations")\
        .update({"is_active": False})\
        .eq("id", automation_id)\
        .eq("user_id", current_user["id"])\
        .execute()
    return SuccessResponse(message="Automation deactivated")


@router.delete("/{automation_id}", response_model=SuccessResponse)
async def delete_automation(automation_id: str, current_user=Depends(get_current_user)):
    supabase.table("automations")\
        .delete()\
        .eq("id", automation_id)\
        .eq("user_id", current_user["id"])\
        .execute()
    return SuccessResponse(message="Automation deleted")


@router.get("/{automation_id}/logs")
async def get_automation_logs(
    automation_id: str,
    limit: int = 50,
    current_user=Depends(get_current_user)
):
    result = supabase.table("automation_logs")\
        .select("*")\
        .eq("automation_id", automation_id)\
        .order("sent_at", desc=True)\
        .limit(limit)\
        .execute()
    return result.data or []
