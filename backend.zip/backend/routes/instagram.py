from fastapi import APIRouter, HTTPException, Depends, Request
from fastapi.responses import RedirectResponse
from models.database import supabase
from models.schemas import InstagramAccountResponse, SuccessResponse
from middleware.auth_middleware import get_current_user
from services.instagram_api import (
    exchange_code_for_token, get_ig_user_info, subscribe_to_webhooks
)
from services.token_manager import encrypt_token, is_token_expiring_soon
from services.rate_limiter import get_current_usage
from config import settings
from datetime import datetime, timezone, timedelta
import logging

router = APIRouter(prefix="/instagram", tags=["instagram"])
logger = logging.getLogger(__name__)

# ✅ CORRECT: Instagram API with Instagram Login
# Users log in with Instagram credentials directly — NO Facebook account needed!
# This is the same flow ManyChat uses.
# Ref: https://developers.facebook.com/docs/instagram-platform/instagram-api-with-instagram-login/business-login
OAUTH_URL = (
    "https://www.instagram.com/oauth/authorize"
    "?client_id={app_id}"
    "&redirect_uri={redirect_uri}"
    "&scope=instagram_business_basic,instagram_business_manage_messages,instagram_business_manage_comments,instagram_business_content_publish"
    "&response_type=code"
    "&state={state}"
    "&enable_fb_login=0"
)


@router.get("/connect")
async def initiate_connect(current_user=Depends(get_current_user)):
    """Redirect user to Instagram OAuth page."""
    # Use Instagram App ID (different from Meta App ID!)
    # Found in: App Dashboard > Instagram > API setup with Instagram login > Business login settings
    url = OAUTH_URL.format(
        app_id=settings.instagram_app_id,  # Instagram-specific App ID
        redirect_uri=settings.instagram_redirect_uri,
        state=current_user["id"]
    )
    return {"oauth_url": url}


@router.get("/callback")
async def oauth_callback(code: str, state: str):
    """
    Instagram OAuth callback.
    Exchanges code for token, saves account to DB.
    State = user_id.
    """
    try:
        # Exchange code for long-lived token
        token_data = await exchange_code_for_token(code, settings.instagram_redirect_uri)
        if not token_data:
            raise HTTPException(status_code=400, detail="Failed to get Instagram token")

        access_token = token_data["access_token"]
        ig_user_id = token_data.get("ig_user_id")
        expires_in = token_data.get("expires_in", 5184000)  # 60 days

        # ✅ FIXED: Validate ig_user_id — null hone pe silent DB failure hoti thi
        if not ig_user_id:
            logger.error(f"OAuth callback: ig_user_id missing from token response: {token_data}")
            raise HTTPException(status_code=400, detail="Could not get Instagram user ID from Meta. Ensure account is Business/Creator type linked to a Facebook Page.")

        # Get IG user info
        ig_info = await get_ig_user_info(access_token)

        # Check if account already connected
        existing = supabase.table("instagram_accounts")\
            .select("id")\
            .eq("ig_user_id", str(ig_user_id))\
            .execute()

        expires_at = (datetime.now(timezone.utc) + timedelta(seconds=expires_in)).isoformat()
        encrypted = encrypt_token(access_token)

        if existing.data:
            # Update existing connection
            supabase.table("instagram_accounts").update({
                "access_token": encrypted,
                "token_expires_at": expires_at,
                "username": ig_info.get("username", ""),
                "name": ig_info.get("name", ""),
                "profile_pic_url": ig_info.get("profile_picture_url", ""),
                "is_active": True
            }).eq("ig_user_id", str(ig_user_id)).execute()
        else:
            # Create new account record
            supabase.table("instagram_accounts").insert({
                "user_id": state,
                "ig_user_id": str(ig_user_id),
                "username": ig_info.get("username", ""),
                "name": ig_info.get("name", ""),
                "profile_pic_url": ig_info.get("profile_picture_url", ""),
                "access_token": encrypted,
                "token_expires_at": expires_at,
                "is_active": True,
                "webhook_subscribed": False
            }).execute()

        # Subscribe to webhooks
        await subscribe_to_webhooks(str(ig_user_id), encrypted)

        # Redirect to frontend success page
        return RedirectResponse(
            url=f"{settings.frontend_url}/connect-success",
            status_code=302
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"OAuth callback error: {e}")
        return RedirectResponse(
            url=f"{settings.frontend_url}/connect-error",
            status_code=302
        )


@router.get("/accounts", response_model=list[InstagramAccountResponse])
async def get_my_accounts(current_user=Depends(get_current_user)):
    """Get all Instagram accounts connected by the current user."""
    result = supabase.table("instagram_accounts")\
        .select("*")\
        .eq("user_id", current_user["id"])\
        .eq("is_active", True)\
        .execute()
    return result.data or []


@router.delete("/accounts/{account_id}", response_model=SuccessResponse)
async def disconnect_account(
    account_id: str,
    current_user=Depends(get_current_user)
):
    """Disconnect an Instagram account."""
    supabase.table("instagram_accounts").update({
        "is_active": False
    }).eq("id", account_id).eq("user_id", current_user["id"]).execute()
    return SuccessResponse(message="Instagram account disconnected")


@router.get("/accounts/{account_id}/rate-limit")
async def get_rate_limit_status(
    account_id: str,
    current_user=Depends(get_current_user)
):
    """Get current API rate limit usage for an IG account."""
    return get_current_usage(account_id)
