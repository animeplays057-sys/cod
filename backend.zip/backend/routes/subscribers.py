from fastapi import APIRouter, HTTPException, Depends
from models.database import supabase
from models.schemas import UpdateSubscriberRequest, SubscriberResponse, SuccessResponse
from middleware.auth_middleware import get_current_user
import logging

router = APIRouter(prefix="/subscribers", tags=["subscribers"])
logger = logging.getLogger(__name__)


@router.get("/", response_model=list[SubscriberResponse])
async def list_subscribers(
    ig_account_id: str,
    tag: str = None,
    opted_out: bool = None,
    search: str = None,
    limit: int = 100,
    offset: int = 0,
    current_user=Depends(get_current_user)
):
    # Verify IG account belongs to user
    account = supabase.table("instagram_accounts")\
        .select("id")\
        .eq("id", ig_account_id)\
        .eq("user_id", current_user["id"])\
        .single()\
        .execute()
    if not account.data:
        raise HTTPException(status_code=404, detail="Instagram account not found")

    query = supabase.table("subscribers")\
        .select("*")\
        .eq("ig_account_id", ig_account_id)\
        .order("last_interaction_at", desc=True)\
        .limit(limit)\
        .offset(offset)

    if opted_out is not None:
        query = query.eq("opted_out", opted_out)

    if search:
        query = query.or_(f"username.ilike.%{search}%,name.ilike.%{search}%")

    result = query.execute()
    return result.data or []


# ✅ FIXED: export/csv route MUST be defined BEFORE /{subscriber_id}
# FastAPI matches routes top-to-bottom — 'export' was being matched as a
# subscriber_id UUID parameter, causing 422 validation errors.
@router.get("/export/csv")
async def export_subscribers_csv(
    ig_account_id: str,
    current_user=Depends(get_current_user)
):
    """Export subscribers as CSV."""
    from fastapi.responses import StreamingResponse
    import csv
    import io

    result = supabase.table("subscribers")\
        .select("*")\
        .eq("ig_account_id", ig_account_id)\
        .execute()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Username", "Name", "IG User ID", "Tags", "First Seen", "Last Interaction", "Opted Out"])

    for sub in (result.data or []):
        writer.writerow([
            sub.get("username", ""),
            sub.get("name", ""),
            sub.get("ig_user_id", ""),
            ",".join(sub.get("tags", [])),
            sub.get("first_seen_at", ""),
            sub.get("last_interaction_at", ""),
            sub.get("opted_out", False)
        ])

    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=subscribers.csv"}
    )


@router.get("/{subscriber_id}", response_model=SubscriberResponse)
async def get_subscriber(subscriber_id: str, current_user=Depends(get_current_user)):
    result = supabase.table("subscribers")\
        .select("*, instagram_accounts!inner(user_id)")\
        .eq("id", subscriber_id)\
        .single()\
        .execute()

    if not result.data or result.data["instagram_accounts"]["user_id"] != current_user["id"]:
        raise HTTPException(status_code=404, detail="Subscriber not found")
    return result.data


@router.patch("/{subscriber_id}", response_model=SubscriberResponse)
async def update_subscriber(
    subscriber_id: str,
    body: UpdateSubscriberRequest,
    current_user=Depends(get_current_user)
):
    update_data = body.model_dump(exclude_none=True)
    if not update_data:
        raise HTTPException(status_code=400, detail="Nothing to update")

    result = supabase.table("subscribers")\
        .update(update_data)\
        .eq("id", subscriber_id)\
        .execute()

    if not result.data:
        raise HTTPException(status_code=404, detail="Subscriber not found")
    return result.data[0]


@router.post("/{subscriber_id}/tags", response_model=SuccessResponse)
async def add_tags(
    subscriber_id: str,
    tags: list[str],
    current_user=Depends(get_current_user)
):
    from services.subscriber_service import add_tags_to_subscriber
    add_tags_to_subscriber(subscriber_id, tags)
    return SuccessResponse(message=f"Tags added: {tags}")


@router.delete("/{subscriber_id}/tags/{tag}", response_model=SuccessResponse)
async def remove_tag(
    subscriber_id: str,
    tag: str,
    current_user=Depends(get_current_user)
):
    existing = supabase.table("subscribers").select("tags").eq("id", subscriber_id).single().execute()
    if existing.data:
        updated_tags = [t for t in existing.data.get("tags", []) if t != tag]
        supabase.table("subscribers").update({"tags": updated_tags}).eq("id", subscriber_id).execute()
    return SuccessResponse(message=f"Tag '{tag}' removed")
