import json
import logging
from fastapi import APIRouter, Request, Response, HTTPException, Depends, Query
from models.database import supabase
from middleware.webhook_verify import validate_webhook_signature
from services.automation_engine import process_webhook_event
from config import settings
from datetime import datetime, timezone

router = APIRouter(prefix="/webhook", tags=["webhook"])
logger = logging.getLogger(__name__)


@router.get("/meta")
async def webhook_verify(
    hub_mode: str = Query(None, alias="hub.mode"),
    hub_verify_token: str = Query(None, alias="hub.verify_token"),
    hub_challenge: str = Query(None, alias="hub.challenge")
):
    """
    Meta Webhook Verification (GET request from Meta).
    Meta sends hub.mode, hub.verify_token, hub.challenge as query params.
    Must return hub.challenge when verify token matches.
    """
    if (
        hub_mode == "subscribe"
        and hub_verify_token == settings.meta_webhook_verify_token
        and hub_challenge
    ):
        logger.info("Webhook verification successful")
        return Response(content=hub_challenge, media_type="text/plain")

    logger.warning(f"Webhook verification failed. Mode={hub_mode}, Token={hub_verify_token}")
    raise HTTPException(status_code=403, detail="Verification failed")


@router.post("/meta")
async def receive_webhook(
    request: Request,
    raw_body: bytes = Depends(validate_webhook_signature)
):
    """
    Meta Webhook Event Receiver.
    CRITICAL: Must respond with 200 within 5 seconds.
    All processing is async via Celery.
    """
    try:
        payload = json.loads(raw_body)
        logger.debug(f"Webhook received: {json.dumps(payload)[:200]}")

        # Process asynchronously to meet 5-second response requirement
        entries = payload.get("entry", [])
        for entry in entries:
            changes = entry.get("changes", [])
            for change in changes:
                field = change.get("field", "")
                value = change.get("value", {})

                # Find which IG account this is for
                ig_user_id = _extract_ig_user_id(value, entry)
                if not ig_user_id:
                    continue

                # Look up our DB account by IG user ID
                account = supabase.table("instagram_accounts")\
                    .select("id, access_token")\
                    .eq("ig_user_id", str(ig_user_id))\
                    .eq("is_active", True)\
                    .single()\
                    .execute()

                if not account.data:
                    logger.debug(f"No active account found for IG user {ig_user_id}")
                    continue

                ig_db_id = account.data["id"]
                encrypted_token = account.data["access_token"]

                # Route based on event field type
                if field == "comments":
                    await _handle_comment_event(value, ig_db_id, encrypted_token)
                elif field == "messages":
                    await _handle_message_event(value, ig_db_id, encrypted_token)
                elif field == "mentions":
                    await _handle_story_mention(value, ig_db_id, encrypted_token)

        # Must return 200 quickly
        return Response(content="EVENT_RECEIVED", status_code=200)

    except json.JSONDecodeError:
        logger.error("Invalid JSON in webhook payload")
        return Response(content="OK", status_code=200)  # Still return 200
    except Exception as e:
        logger.error(f"Webhook processing error: {e}")
        return Response(content="OK", status_code=200)  # Still return 200


def _extract_ig_user_id(value: dict, entry: dict) -> str | None:
    """Extract the IG business account ID from a webhook event."""
    # Comments: value.media.id belongs to IG account
    recipient = value.get("recipient_id") or value.get("id")
    if recipient:
        return str(recipient)

    # Try from entry
    entry_id = entry.get("id")
    return str(entry_id) if entry_id else None


async def _handle_comment_event(value: dict, ig_db_id: str, encrypted_token: str):
    """Handle a new comment on a post/reel."""
    comment_text = value.get("text", "")
    commenter = value.get("from", {})
    comment_id = value.get("id", "")
    post_id = value.get("media", {}).get("id", "")
    is_reel = value.get("media", {}).get("media_type", "") == "VIDEO"

    if not commenter:
        return

    await process_webhook_event(
        ig_db_account_id=ig_db_id,
        ig_account_encrypted_token=encrypted_token,
        event_type="comment",
        ig_user_id=str(commenter.get("id", "")),
        username=commenter.get("username"),
        text=comment_text,
        post_id=post_id,
        comment_id=comment_id
    )


async def _handle_message_event(value: dict, ig_db_id: str, encrypted_token: str):
    """Handle an incoming DM."""
    messaging = value.get("messaging", [])
    for msg_event in messaging:
        sender = msg_event.get("sender", {})
        message = msg_event.get("message", {})
        text = message.get("text", "")

        if not text or not sender:
            continue

        # Skip messages sent BY the business account (echo)
        if msg_event.get("recipient", {}).get("id") == sender.get("id"):
            continue

        await process_webhook_event(
            ig_db_account_id=ig_db_id,
            ig_account_encrypted_token=encrypted_token,
            event_type="message",
            ig_user_id=str(sender.get("id", "")),
            username=sender.get("username"),
            text=text,
            post_id=None,
            comment_id=None
        )


async def _handle_story_mention(value: dict, ig_db_id: str, encrypted_token: str):
    """Handle a story mention event."""
    mentioner = value.get("from", {})
    mentioned_in = value.get("media", {})

    if not mentioner:
        return

    await process_webhook_event(
        ig_db_account_id=ig_db_id,
        ig_account_encrypted_token=encrypted_token,
        event_type="story_mention",
        ig_user_id=str(mentioner.get("id", "")),
        username=mentioner.get("username"),
        text="",  # Story mentions have no text
        post_id=mentioned_in.get("id"),
        comment_id=None
    )
