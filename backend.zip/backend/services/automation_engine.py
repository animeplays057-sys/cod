from models.database import supabase
from services.content_filter import keyword_matches, matches_opt_out
from services.subscriber_service import (
    get_or_create_subscriber, is_within_24hr_window, mark_subscriber_opted_out
)
from services.rate_limiter import check_duplicate_trigger, is_opted_out_cached
import logging
from typing import Optional
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


async def find_matching_automations(
    ig_account_id: str,  # Our DB UUID
    event_type: str,     # "comment" | "message" | "story_mention" | "story_reply"
    text: str,
    post_id: Optional[str] = None
) -> list:
    """
    Find all active automations that match this event.
    Returns list of matching automation dicts.
    """
    # Load all active automations for this IG account
    result = supabase.table("automations")\
        .select("*")\
        .eq("ig_account_id", ig_account_id)\
        .eq("is_active", True)\
        .execute()

    if not result.data:
        return []

    matched = []
    for automation in result.data:
        if _does_automation_match(automation, event_type, text, post_id):
            matched.append(automation)

    return matched


def _does_automation_match(
    automation: dict,
    event_type: str,
    text: str,
    post_id: Optional[str]
) -> bool:
    """Check if a single automation matches the incoming event."""

    trigger_type = automation["trigger_type"]
    trigger_map = {
        "comment_keyword": ["comment"],
        "any_comment": ["comment"],
        "story_mention": ["story_mention"],
        "story_reply": ["story_reply"],
        "dm_keyword": ["message"],
        "ref_url": ["message"],
    }

    # Check event type matches trigger type
    allowed_events = trigger_map.get(trigger_type, [])
    if event_type not in allowed_events:
        return False

    # Check keyword match
    if trigger_type in ("comment_keyword", "dm_keyword"):
        keyword = automation.get("trigger_keyword", "")
        match_type = automation.get("keyword_match", "contains")
        if not keyword_matches(text, keyword, match_type):
            return False

    # Check post filter for comment triggers
    if event_type == "comment" and trigger_type in ("comment_keyword", "any_comment"):
        post_filter = automation.get("post_filter", "all_posts")
        if post_filter == "specific_post":
            if automation.get("specific_post_id") != post_id:
                return False
        # "reels_only" filter handled by webhook (reel posts have is_reel=True in Meta events)

    return True


async def process_webhook_event(
    ig_db_account_id: str,  # Our DB UUID for the IG account
    ig_account_encrypted_token: str,
    event_type: str,
    ig_user_id: str,
    username: Optional[str],
    text: str,
    post_id: Optional[str] = None,
    comment_id: Optional[str] = None
) -> dict:
    """
    Main entry point for processing a webhook event.
    1. Check opt-out
    2. Get/create subscriber
    3. Check 24hr window
    4. Find matching automations
    5. Queue DM jobs
    Returns summary of what happened.
    """
    summary = {
        "event_type": event_type,
        "ig_user_id": ig_user_id,
        "automations_matched": 0,
        "dms_queued": 0,
        "skipped_reasons": []
    }

    # Check opt-out keyword (user sending STOP)
    if matches_opt_out(text):
        mark_subscriber_opted_out(ig_db_account_id, ig_user_id)
        summary["skipped_reasons"].append("user_opted_out")
        return summary

    # Get or create subscriber (also updates last_interaction_at)
    subscriber = await get_or_create_subscriber(
        ig_account_id=ig_db_account_id,
        ig_user_id=ig_user_id,
        username=username
    )

    # Check if subscriber is opted out
    if subscriber.get("opted_out"):
        summary["skipped_reasons"].append("subscriber_opted_out")
        return summary

    # Find matching automations
    matched_automations = await find_matching_automations(
        ig_account_id=ig_db_account_id,
        event_type=event_type,
        text=text,
        post_id=post_id
    )

    summary["automations_matched"] = len(matched_automations)

    for automation in matched_automations:
        automation_id = automation["id"]

        # Check for duplicate (same trigger already processed)
        if comment_id:
            is_dup = check_duplicate_trigger(automation_id, comment_id)
            if is_dup:
                summary["skipped_reasons"].append(f"duplicate:{automation_id}")
                continue

        # Check 24hr messaging window
        if not is_within_24hr_window(subscriber["last_interaction_at"]):
            summary["skipped_reasons"].append(f"24hr_window_expired:{automation_id}")
            continue

        # Queue DM job
        _queue_dm_job(
            automation=automation,
            subscriber=subscriber,
            ig_account_id=ig_db_account_id,
            encrypted_token=ig_account_encrypted_token,
            trigger_data={
                "event_type": event_type,
                "text": text,
                "post_id": post_id,
                "comment_id": comment_id,
                "username": username
            }
        )

        summary["dms_queued"] += 1

    return summary


def _queue_dm_job(
    automation: dict,
    subscriber: dict,
    ig_account_id: str,
    encrypted_token: str,
    trigger_data: dict
):
    """Enqueue the DM job to Celery."""
    from workers.dm_worker import execute_flow_task
    execute_flow_task.apply_async(
        args=[
            automation["id"],
            automation["flow_json"],
            subscriber["id"],
            ig_account_id,
            encrypted_token,
            subscriber["ig_user_id"],
            trigger_data,
            automation.get("also_reply_comment", False),
            automation.get("comment_reply_text"),
            trigger_data.get("comment_id")
        ],
        queue="dm_queue"
    )
    logger.info(
        f"Queued DM job: automation={automation['id']}, "
        f"subscriber={subscriber['ig_user_id']}"
    )
