import re
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# Patterns that violate Meta policies or suggest spam
BLOCKED_PATTERNS = [
    r'\b(buy now|limited offer|click here|earn money fast|make money)\b',
    r'\b(casino|gambling|poker|bet now|crypto pump)\b',
    r'(?i)(adult|xxx|18\+|nsfw)',
    r'(\+?1?\s*\(?\d{3}\)?[\s\-]\d{3}[\s\-]\d{4})',  # phone numbers
    r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',  # email harvesting
    r'(follow\s+for\s+follow|f4f|l4l)',  # engagement bait
]

# Compiled regexes for speed
_compiled_patterns = [re.compile(p, re.IGNORECASE) for p in BLOCKED_PATTERNS]

# Hard message length limit (Instagram DM max is ~1000 chars, we enforce 800)
MAX_MESSAGE_LENGTH = 800


def check_message_safety(message: str) -> tuple[bool, Optional[str]]:
    """
    Check if a DM message is safe to send.
    Returns (is_safe: bool, reason: Optional[str])
    """
    if not message or not message.strip():
        return False, "Message cannot be empty"

    if len(message) > MAX_MESSAGE_LENGTH:
        return False, f"Message too long ({len(message)} chars, max {MAX_MESSAGE_LENGTH})"

    for pattern in _compiled_patterns:
        if pattern.search(message):
            return False, f"Message contains blocked content: '{pattern.pattern[:30]}'"

    return True, None


def sanitize_message(message: str) -> str:
    """Basic message sanitization — strip leading/trailing whitespace."""
    return message.strip()


def matches_opt_out(text: str) -> bool:
    """
    Check if incoming message text is an opt-out keyword.
    Users who send these should be marked as opted_out.
    """
    opt_out_keywords = {
        "stop", "unsubscribe", "unsub", "cancel", "quit",
        "end", "block", "nahi", "band karo", "mat bhejo"
    }
    cleaned = text.strip().lower()
    return cleaned in opt_out_keywords


def keyword_matches(message: str, keyword: str, match_type: str) -> bool:
    """
    Check if an incoming message/comment matches an automation keyword.
    match_type: 'exact' | 'contains' | 'starts_with' | 'any'
    """
    if match_type == "any" or not keyword:
        return True

    msg_lower = message.lower().strip()
    kw_lower = keyword.lower().strip()

    if match_type == "exact":
        return msg_lower == kw_lower
    elif match_type == "contains":
        return kw_lower in msg_lower
    elif match_type == "starts_with":
        return msg_lower.startswith(kw_lower)

    return False
