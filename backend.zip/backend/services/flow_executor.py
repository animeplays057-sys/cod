"""
Flow Executor — Walks through the React Flow JSON node graph and executes each node.

Flow JSON format:
{
  "nodes": [
    {"id": "start", "type": "startNode", "data": {}},
    {"id": "msg_1", "type": "messageNode", "data": {"message": "Hey {{name}}!", "messageType": "text"}},
    {"id": "delay_1", "type": "delayNode", "data": {"delay_minutes": 60}},
    {"id": "cond_1", "type": "conditionNode", "data": {"field": "tags", "operator": "contains", "value": "vip"}},
    {"id": "action_1", "type": "actionNode", "data": {"action_type": "add_tag", "tag": "converted"}},
    {"id": "rand_1", "type": "randomizerNode", "data": {"branches": [{"percent": 50, "node_id": "msg_a"}, {"percent": 50, "node_id": "msg_b"}]}},
  ],
  "edges": [
    {"id": "e1", "source": "start", "target": "msg_1"},
    {"id": "e2", "source": "msg_1", "target": "delay_1"},
    ...
  ]
}
"""

import random
import logging
from datetime import datetime, timezone, timedelta
from services.instagram_api import send_instagram_dm, InstagramAPIError
from services.subscriber_service import add_tags_to_subscriber, set_custom_field
from models.database import supabase

logger = logging.getLogger(__name__)


class FlowExecutor:
    def __init__(
        self,
        automation_id: str,
        flow_json: dict,
        subscriber_id: str,
        ig_account_id: str,
        encrypted_token: str,
        recipient_ig_user_id: str,
        trigger_data: dict
    ):
        self.automation_id = automation_id
        self.subscriber = self._load_subscriber(subscriber_id)
        self.subscriber_id = subscriber_id
        self.ig_account_id = ig_account_id
        self.encrypted_token = encrypted_token
        self.recipient_ig_user_id = recipient_ig_user_id
        self.trigger_data = trigger_data

        # Build node and edge maps for fast lookup
        nodes = flow_json.get("nodes", [])
        edges = flow_json.get("edges", [])
        self.node_map = {n["id"]: n for n in nodes}
        # edge_map: source_id -> [target_id, ...]
        self.edge_map: dict[str, list] = {}
        for edge in edges:
            src = edge["source"]
            self.edge_map.setdefault(src, [])
            self.edge_map[src].append({
                "target": edge["target"],
                "label": edge.get("label", "")  # "yes"/"no" for conditions
            })

    def _load_subscriber(self, subscriber_id: str) -> dict:
        result = supabase.table("subscribers")\
            .select("*")\
            .eq("id", subscriber_id)\
            .single()\
            .execute()
        return result.data or {}

    def _replace_template_vars(self, text: str) -> str:
        """Replace {{name}}, {{username}}, {{first_name}} in message text."""
        name = self.subscriber.get("name", "") or ""
        username = self.subscriber.get("username", "") or ""
        first_name = name.split()[0] if name else username

        return text\
            .replace("{{name}}", name)\
            .replace("{{username}}", username or "friend")\
            .replace("{{first_name}}", first_name or "friend")

    async def run(self) -> list[dict]:
        """
        Execute the flow starting from 'start' node.
        Returns list of execution log entries.
        """
        logs = []
        start_node = self.node_map.get("start")
        if not start_node:
            logger.error(f"No start node in flow for automation {self.automation_id}")
            return logs

        await self._execute_node("start", logs, depth=0)
        return logs

    async def _execute_node(self, node_id: str, logs: list, depth: int = 0):
        """Recursively execute a node and its successors."""
        if depth > 20:  # Prevent infinite loops
            logger.warning(f"Max depth reached in flow {self.automation_id}")
            return

        node = self.node_map.get(node_id)
        if not node:
            return

        node_type = node.get("type", "")
        data = node.get("data", {})
        next_nodes = self.edge_map.get(node_id, [])

        # ── Start Node ──────────────────────────────────────
        if node_type == "startNode":
            logs.append({"node": node_id, "type": "start", "status": "ok"})
            for edge in next_nodes:
                await self._execute_node(edge["target"], logs, depth + 1)

        # ── Message Node ─────────────────────────────────────
        elif node_type == "messageNode":
            message = self._replace_template_vars(data.get("message", ""))
            try:
                await send_instagram_dm(
                    ig_account_id=self.ig_account_id,
                    encrypted_token=self.encrypted_token,
                    recipient_ig_user_id=self.recipient_ig_user_id,
                    message_text=message
                )
                logs.append({"node": node_id, "type": "message", "status": "sent", "message": message[:50]})
                self._log_to_db(node_id, message, dm_sent=True)

                for edge in next_nodes:
                    await self._execute_node(edge["target"], logs, depth + 1)

            except InstagramAPIError as e:
                logs.append({"node": node_id, "type": "message", "status": "error", "error": str(e)})
                self._log_to_db(node_id, message, dm_sent=False, error=str(e))
                if e.is_rate_limited:
                    raise  # Re-raise so Celery can retry

        # ── Delay Node ───────────────────────────────────────
        elif node_type == "delayNode":
            delay_minutes = data.get("delay_minutes", 0)
            if delay_minutes > 0:
                # Schedule continuation via drip queue
                scheduled_at = datetime.now(timezone.utc) + timedelta(minutes=delay_minutes)
                for edge in next_nodes:
                    supabase.table("drip_queue").insert({
                        "automation_id": self.automation_id,
                        "subscriber_id": self.subscriber_id,
                        "ig_account_id": self.ig_account_id,
                        "current_node_id": edge["target"],
                        "scheduled_at": scheduled_at.isoformat(),
                        "status": "pending"
                    }).execute()
                logs.append({"node": node_id, "type": "delay", "status": "scheduled", "minutes": delay_minutes})
                return  # Stop here — drip worker will continue
            else:
                for edge in next_nodes:
                    await self._execute_node(edge["target"], logs, depth + 1)

        # ── Condition Node ───────────────────────────────────
        elif node_type == "conditionNode":
            result = self._evaluate_condition(data)
            logs.append({"node": node_id, "type": "condition", "result": result})
            for edge in next_nodes:
                if (result and edge["label"] == "yes") or (not result and edge["label"] == "no"):
                    await self._execute_node(edge["target"], logs, depth + 1)

        # ── Action Node ──────────────────────────────────────
        elif node_type == "actionNode":
            await self._execute_action(node_id, data, logs)
            for edge in next_nodes:
                await self._execute_node(edge["target"], logs, depth + 1)

        # ── Randomizer Node ──────────────────────────────────
        elif node_type == "randomizerNode":
            branches = data.get("branches", [])
            chosen = self._pick_random_branch(branches)
            logs.append({"node": node_id, "type": "randomizer", "chosen": chosen})
            if chosen:
                await self._execute_node(chosen, logs, depth + 1)

        # ── Unsubscribe Node ─────────────────────────────────
        elif node_type == "unsubscribeNode":
            from services.subscriber_service import mark_subscriber_opted_out
            mark_subscriber_opted_out(self.ig_account_id, self.recipient_ig_user_id)
            logs.append({"node": node_id, "type": "unsubscribe", "status": "ok"})

    def _evaluate_condition(self, data: dict) -> bool:
        """Evaluate a condition node."""
        field = data.get("field", "")
        operator = data.get("operator", "contains")
        value = data.get("value", "")

        subscriber_value = None
        if field == "tags":
            subscriber_value = self.subscriber.get("tags", [])
        elif field.startswith("custom."):
            key = field[7:]
            subscriber_value = self.subscriber.get("custom_fields", {}).get(key)
        else:
            subscriber_value = self.subscriber.get(field)

        if operator == "contains" and isinstance(subscriber_value, list):
            return value in subscriber_value
        elif operator == "equals":
            return str(subscriber_value) == str(value)
        elif operator == "not_equals":
            return str(subscriber_value) != str(value)
        elif operator == "exists":
            return subscriber_value is not None

        return False

    def _pick_random_branch(self, branches: list) -> str | None:
        """Pick a branch based on percentage weights."""
        if not branches:
            return None
        rand = random.uniform(0, 100)
        cumulative = 0
        for branch in branches:
            cumulative += branch.get("percent", 0)
            if rand <= cumulative:
                return branch.get("node_id")
        return branches[-1].get("node_id")

    async def _execute_action(self, node_id: str, data: dict, logs: list):
        """Execute an action node (add tag, set field, etc.)."""
        action_type = data.get("action_type", "")

        if action_type == "add_tag":
            tag = data.get("tag", "")
            if tag:
                add_tags_to_subscriber(self.subscriber_id, [tag])
                logs.append({"node": node_id, "type": "action", "action": "add_tag", "tag": tag})

        elif action_type == "remove_tag":
            tag = data.get("tag", "")
            if tag:
                current = self.subscriber.get("tags", [])
                updated = [t for t in current if t != tag]
                supabase.table("subscribers").update({"tags": updated})\
                    .eq("id", self.subscriber_id).execute()
                logs.append({"node": node_id, "type": "action", "action": "remove_tag", "tag": tag})

        elif action_type == "set_field":
            field = data.get("field", "")
            value = data.get("value", "")
            if field:
                set_custom_field(self.subscriber_id, field, value)
                logs.append({"node": node_id, "type": "action", "action": "set_field", "field": field})

        elif action_type == "notify_admin":
            # Could send email/Slack notification to admin
            logs.append({"node": node_id, "type": "action", "action": "notify_admin", "status": "ok"})

    def _log_to_db(
        self, node_id: str, message: str, dm_sent: bool, error: str = None
    ):
        """Save execution result to automation_logs table."""
        supabase.table("automation_logs").insert({
            "automation_id": self.automation_id,
            "ig_account_id": self.ig_account_id,
            "subscriber_id": self.subscriber_id,
            "trigger_type": self.trigger_data.get("event_type", ""),
            "trigger_data": self.trigger_data,
            "dm_sent": dm_sent,
            "dm_message": message,
            "dm_node_id": node_id,
            "error": error
        }).execute()

        if dm_sent:
            supabase.rpc(
                "increment_dm_sent",
                {"automation_uuid": self.automation_id}
            ).execute()
