import httpx
from services.token_manager import decrypt_token
from services.rate_limiter import can_make_api_call
import logging
from typing import Optional

logger = logging.getLogger(__name__)

GRAPH_API_BASE = "https://graph.facebook.com/v19.0"


class InstagramAPIError(Exception):
    def __init__(self, message: str, code: int = 0, is_rate_limited: bool = False):
        self.message = message
        self.code = code
        self.is_rate_limited = is_rate_limited
        super().__init__(message)


async def send_instagram_dm(
    ig_account_id: str,
    encrypted_token: str,
    recipient_ig_user_id: str,
    message_text: str
) -> dict:
    """
    Send a Direct Message via Meta Graph API.
    Enforces rate limiting before each call.
    Returns API response dict.
    Raises InstagramAPIError on failure.
    """
    # Rate limit check
    can_proceed, remaining = can_make_api_call(ig_account_id)
    if not can_proceed:
        raise InstagramAPIError(
            "Rate limit reached (180/hour). Message queued for next window.",
            code=429,
            is_rate_limited=True
        )

    token = decrypt_token(encrypted_token)

    payload = {
        "recipient": {"id": recipient_ig_user_id},
        "message": {"text": message_text},
        "messaging_type": "RESPONSE"
    }

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            f"{GRAPH_API_BASE}/me/messages",
            params={"access_token": token},
            json=payload
        )

    data = resp.json()

    if resp.status_code == 429:
        raise InstagramAPIError(
            "Meta API rate limit hit",
            code=429,
            is_rate_limited=True
        )

    if resp.status_code != 200 or "error" in data:
        error = data.get("error", {})
        raise InstagramAPIError(
            error.get("message", "Unknown Meta API error"),
            code=error.get("code", resp.status_code)
        )

    logger.info(
        f"DM sent: IG account={ig_account_id}, "
        f"recipient={recipient_ig_user_id}, "
        f"rate_remaining={remaining}"
    )
    return data


async def reply_to_comment(
    ig_account_id: str,
    encrypted_token: str,
    comment_id: str,
    reply_text: str
) -> dict:
    """Reply publicly to an Instagram comment."""
    can_proceed, _ = can_make_api_call(ig_account_id)
    if not can_proceed:
        raise InstagramAPIError("Rate limit reached", code=429, is_rate_limited=True)

    token = decrypt_token(encrypted_token)

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            f"{GRAPH_API_BASE}/{comment_id}/replies",
            params={"access_token": token},
            json={"message": reply_text}
        )

    data = resp.json()
    if resp.status_code != 200 or "error" in data:
        error = data.get("error", {})
        raise InstagramAPIError(
            error.get("message", "Comment reply failed"),
            code=error.get("code", resp.status_code)
        )

    return data


async def subscribe_to_webhooks(
    ig_user_id: str,
    encrypted_token: str,
    fields: list = None
) -> bool:
    """Subscribe IG account to webhook events."""
    if fields is None:
        fields = ["comments", "messages", "story_insights"]

    token = decrypt_token(encrypted_token)

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            f"{GRAPH_API_BASE}/{ig_user_id}/subscribed_apps",
            params={"access_token": token},
            json={"subscribed_fields": fields}
        )

    data = resp.json()
    return data.get("success", False)


async def get_ig_user_info(access_token: str) -> dict:
    """Get Instagram account info using access token."""
    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.get(
            f"{GRAPH_API_BASE}/me",
            params={
                "fields": "id,username,name,profile_picture_url,followers_count",
                "access_token": access_token
            }
        )
    return resp.json()


async def exchange_code_for_token(code: str, redirect_uri: str) -> Optional[dict]:
    """
    Exchange OAuth authorization code for a long-lived Instagram access token.

    Uses Instagram API with Instagram Login flow (no Facebook required).
    Ref: https://developers.facebook.com/docs/instagram-platform/instagram-api-with-instagram-login/business-login

    Endpoints:
      Step 1: POST https://api.instagram.com/oauth/access_token  → short-lived token
      Step 2: GET  https://graph.instagram.com/access_token      → long-lived token (60 days)
    """
    from config import settings

    # Use Instagram App ID/Secret (NOT the Meta App ID)
    # These are found in: App Dashboard > Instagram > API setup with Instagram login
    # > Set up Instagram business login > Business login settings
    ig_app_id = settings.instagram_app_id or settings.meta_app_id
    ig_app_secret = settings.instagram_app_secret or settings.meta_app_secret

    async with httpx.AsyncClient(timeout=30.0) as client:
        # Step 1: Exchange authorization code for short-lived Instagram User token
        resp = await client.post(
            "https://api.instagram.com/oauth/access_token",
            data={
                "client_id": ig_app_id,
                "client_secret": ig_app_secret,
                "grant_type": "authorization_code",
                "redirect_uri": redirect_uri,
                "code": code
            }
        )
        short_lived_raw = resp.json()
        logger.info(f"Short-lived token response keys: {list(short_lived_raw.keys())}")

        # Response format per docs:
        # {"data": [{"access_token": "...", "user_id": "...", "permissions": "..."}]}
        # OR flat: {"access_token": "...", "user_id": "..."}
        if "data" in short_lived_raw and isinstance(short_lived_raw["data"], list):
            short_lived = short_lived_raw["data"][0]
        else:
            short_lived = short_lived_raw

        if "access_token" not in short_lived:
            logger.error(f"OAuth code exchange failed: {short_lived_raw}")
            return None

        short_token = short_lived["access_token"]
        ig_user_id = str(short_lived.get("user_id", ""))

        if not ig_user_id:
            logger.error(f"ig_user_id missing from token response: {short_lived_raw}")
            return None

        # Step 2: Exchange short-lived for long-lived token (valid 60 days)
        resp2 = await client.get(
            "https://graph.instagram.com/access_token",
            params={
                "grant_type": "ig_exchange_token",
                "client_secret": ig_app_secret,
                "access_token": short_token
            }
        )
        long_lived = resp2.json()
        logger.info(f"Long-lived token response keys: {list(long_lived.keys())}")

    if "access_token" not in long_lived:
        logger.error(f"Long-lived token exchange failed: {long_lived}")
        return None

    return {
        "access_token": long_lived["access_token"],
        "expires_in": long_lived.get("expires_in", 5184000),
        "ig_user_id": ig_user_id
    }

