import redis
from config import settings
from datetime import datetime, timezone, timedelta
import logging

logger = logging.getLogger(__name__)

# Redis connection pool
redis_client = redis.from_url(
    settings.redis_url,
    decode_responses=True,
    max_connections=20
)

# Max safe calls per hour (buffer below Meta's 200 limit)
MAX_CALLS_PER_HOUR = 180
WINDOW_SECONDS = 3600


def can_make_api_call(ig_account_id: str) -> tuple[bool, int]:
    """
    Check if an IG account can make another API call.
    Returns (can_proceed: bool, calls_remaining: int)
    Uses Redis sliding window counter.
    """
    key = f"rate:{ig_account_id}"
    try:
        pipe = redis_client.pipeline()
        pipe.incr(key)
        pipe.expire(key, WINDOW_SECONDS)
        results = pipe.execute()
        current_count = results[0]

        if current_count > MAX_CALLS_PER_HOUR:
            remaining = 0
            # Log rate limit hit
            logger.warning(
                f"Rate limit reached for IG account {ig_account_id}: "
                f"{current_count}/{MAX_CALLS_PER_HOUR} calls this hour"
            )
            # Decrement since we over-counted
            redis_client.decr(key)
            return False, remaining
        else:
            remaining = MAX_CALLS_PER_HOUR - current_count
            return True, remaining

    except Exception as e:
        logger.error(f"Rate limiter Redis error: {e}")
        # Fail open — allow call if Redis is down
        return True, MAX_CALLS_PER_HOUR


def get_current_usage(ig_account_id: str) -> dict:
    """Get current rate limit usage for an IG account."""
    key = f"rate:{ig_account_id}"
    try:
        calls = int(redis_client.get(key) or 0)
        ttl = redis_client.ttl(key)
        return {
            "calls_used": calls,
            "calls_remaining": max(0, MAX_CALLS_PER_HOUR - calls),
            "limit": MAX_CALLS_PER_HOUR,
            "window_resets_in_seconds": ttl if ttl > 0 else WINDOW_SECONDS,
            "percentage_used": round((calls / MAX_CALLS_PER_HOUR) * 100, 1)
        }
    except Exception as e:
        logger.error(f"Rate usage check error: {e}")
        return {"calls_used": 0, "calls_remaining": MAX_CALLS_PER_HOUR, "limit": MAX_CALLS_PER_HOUR}


def check_duplicate_trigger(
    automation_id: str,
    comment_id: str,
    ttl_seconds: int = 86400
) -> bool:
    """
    Check if this exact trigger (automation + comment) was already processed.
    Returns True if it's a DUPLICATE (already processed).
    Stores key for 24 hours.
    """
    key = f"dup:{automation_id}:{comment_id}"
    try:
        # SET NX — set only if not exists (atomic)
        result = redis_client.set(key, "1", ex=ttl_seconds, nx=True)
        # result is True if key was set (new), None if already existed (duplicate)
        return result is None  # True = duplicate, False = new
    except Exception as e:
        logger.error(f"Duplicate check error: {e}")
        return False  # Fail open — process it


def mark_opted_out(ig_account_id: str, subscriber_ig_user_id: str) -> None:
    """Cache opt-out status in Redis for fast lookup."""
    key = f"optout:{ig_account_id}:{subscriber_ig_user_id}"
    redis_client.set(key, "1", ex=7 * 86400)  # 7 day cache


def is_opted_out_cached(ig_account_id: str, subscriber_ig_user_id: str) -> bool:
    """Fast Redis check for opted-out status."""
    key = f"optout:{ig_account_id}:{subscriber_ig_user_id}"
    return redis_client.exists(key) == 1
