from models.database import supabase
from datetime import datetime, timezone, timedelta
import logging

logger = logging.getLogger(__name__)

OPT_OUT_KEYWORDS = {"stop", "unsubscribe", "unsub", "cancel", "quit", "end", "nahi", "band karo"}


async def get_or_create_subscriber(
    ig_account_id: str,
    ig_user_id: str,
    username: str = None,
    name: str = None,
    profile_pic_url: str = None
) -> dict:
    """
    Get existing subscriber or create new one.
    Always updates last_interaction_at for 24hr window tracking.
    """
    now = datetime.now(timezone.utc).isoformat()

    # Check if subscriber exists
    existing = supabase.table("subscribers")\
        .select("*")\
        .eq("ig_account_id", ig_account_id)\
        .eq("ig_user_id", ig_user_id)\
        .execute()

    if existing.data:
        subscriber = existing.data[0]
        # Update last_interaction_at (resets 24hr window)
        update_data = {"last_interaction_at": now}
        if username:
            update_data["username"] = username
        if name:
            update_data["name"] = name

        supabase.table("subscribers")\
            .update(update_data)\
            .eq("id", subscriber["id"])\
            .execute()

        subscriber["last_interaction_at"] = now
        return subscriber

    # Create new subscriber
    insert_data = {
        "ig_account_id": ig_account_id,
        "ig_user_id": ig_user_id,
        "username": username,
        "name": name,
        "profile_pic_url": profile_pic_url,
        "first_seen_at": now,
        "last_interaction_at": now,
        "tags": [],
        "custom_fields": {},
        "opted_out": False
    }

    result = supabase.table("subscribers").insert(insert_data).execute()
    return result.data[0]


def is_within_24hr_window(last_interaction_at: str) -> bool:
    """
    Check if subscriber's last interaction was within 24 hours.
    CRITICAL: Meta requires this check before sending any automated DM.
    """
    if not last_interaction_at:
        return False

    last = datetime.fromisoformat(last_interaction_at.replace("Z", "+00:00"))
    diff = datetime.now(timezone.utc) - last
    return diff <= timedelta(hours=24)


def mark_subscriber_opted_out(ig_account_id: str, ig_user_id: str) -> None:
    """Mark subscriber as opted out and cancel all pending drip messages."""
    now = datetime.now(timezone.utc).isoformat()

    # Find subscriber
    result = supabase.table("subscribers")\
        .select("id")\
        .eq("ig_account_id", ig_account_id)\
        .eq("ig_user_id", ig_user_id)\
        .execute()

    if not result.data:
        return

    subscriber_id = result.data[0]["id"]

    # Mark opted out
    supabase.table("subscribers").update({
        "opted_out": True,
        "opted_out_at": now
    }).eq("id", subscriber_id).execute()

    # Cancel all pending drip queue entries
    supabase.table("drip_queue").update({
        "status": "cancelled"
    }).eq("subscriber_id", subscriber_id)\
      .eq("status", "pending")\
      .execute()

    logger.info(f"Subscriber {ig_user_id} opted out from {ig_account_id}")


def add_tags_to_subscriber(subscriber_id: str, tags: list) -> None:
    """Add tags to a subscriber (merge, no duplicates)."""
    existing = supabase.table("subscribers")\
        .select("tags")\
        .eq("id", subscriber_id)\
        .single()\
        .execute()

    if existing.data:
        current_tags = existing.data.get("tags", [])
        merged = list(set(current_tags + tags))
        supabase.table("subscribers")\
            .update({"tags": merged})\
            .eq("id", subscriber_id)\
            .execute()


def set_custom_field(subscriber_id: str, field: str, value) -> None:
    """Set a custom field on subscriber."""
    existing = supabase.table("subscribers")\
        .select("custom_fields")\
        .eq("id", subscriber_id)\
        .single()\
        .execute()

    if existing.data:
        fields = existing.data.get("custom_fields", {})
        fields[field] = value
        supabase.table("subscribers")\
            .update({"custom_fields": fields})\
            .eq("id", subscriber_id)\
            .execute()
