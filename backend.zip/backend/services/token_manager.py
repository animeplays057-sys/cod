from cryptography.fernet import Fernet
from config import settings
from models.database import supabase
from datetime import datetime, timezone, timedelta
import httpx
import logging

logger = logging.getLogger(__name__)
_fernet = Fernet(settings.fernet_key.encode())


def encrypt_token(token: str) -> str:
    """Encrypt Instagram access token before storing in DB."""
    return _fernet.encrypt(token.encode()).decode()


def decrypt_token(encrypted_token: str) -> str:
    """Decrypt Instagram access token retrieved from DB."""
    return _fernet.decrypt(encrypted_token.encode()).decode()


async def refresh_long_lived_token(ig_account_id: str) -> bool:
    """
    Refresh Instagram Long-Lived Access Token.
    Tokens last 60 days and must be refreshed before expiry.
    Returns True if refreshed successfully.
    """
    try:
        # Get account from DB
        result = supabase.table("instagram_accounts")\
            .select("*")\
            .eq("id", ig_account_id)\
            .single()\
            .execute()

        if not result.data:
            logger.error(f"IG account not found: {ig_account_id}")
            return False

        account = result.data
        current_token = decrypt_token(account["access_token"])

        # Refresh via Meta API
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                "https://graph.instagram.com/refresh_access_token",
                params={
                    "grant_type": "ig_refresh_token",
                    "access_token": current_token
                }
            )
            data = resp.json()

        if "access_token" not in data:
            logger.error(f"Token refresh failed for {ig_account_id}: {data}")
            return False

        new_token = data["access_token"]
        expires_in = data.get("expires_in", 5184000)  # 60 days default
        new_expiry = datetime.now(timezone.utc) + timedelta(seconds=expires_in)

        # Update in DB (encrypted)
        supabase.table("instagram_accounts").update({
            "access_token": encrypt_token(new_token),
            "token_expires_at": new_expiry.isoformat()
        }).eq("id", ig_account_id).execute()

        logger.info(f"Token refreshed for IG account {ig_account_id}")
        return True

    except Exception as e:
        logger.error(f"Token refresh error for {ig_account_id}: {e}")
        return False


def is_token_expiring_soon(expires_at: str, days_threshold: int = 10) -> bool:
    """Check if token expires within threshold days."""
    if not expires_at:
        return True
    expiry = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
    threshold = datetime.now(timezone.utc) + timedelta(days=days_threshold)
    return expiry <= threshold
