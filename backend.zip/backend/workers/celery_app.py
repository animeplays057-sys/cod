from celery import Celery
from config import settings

celery_app = Celery(
    "instaflow",
    broker=settings.redis_url,
    backend=settings.redis_url,
    include=[
        "workers.dm_worker",
        "workers.drip_worker",
        "workers.token_refresh_worker"
    ]
)

celery_app.conf.update(
    # Task routing — separate queues for different priorities
    task_routes={
        "workers.dm_worker.execute_flow_task": {"queue": "dm_queue"},
        "workers.drip_worker.process_drip_queue": {"queue": "drip_queue"},
        "workers.token_refresh_worker.refresh_expiring_tokens": {"queue": "default"},
    },

    # Retry settings
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],

    # Result expiry
    result_expires=3600,

    # Beat schedule (periodic tasks)
    beat_schedule={
        # Check drip queue every minute
        "process-drip-queue": {
            "task": "workers.drip_worker.process_drip_queue",
            "schedule": 60.0,  # every 60 seconds
        },
        # Refresh expiring tokens daily at 3 AM
        "refresh-expiring-tokens": {
            "task": "workers.token_refresh_worker.refresh_expiring_tokens",
            "schedule": 86400.0,  # every 24 hours
        },
    },

    timezone="UTC",
)
