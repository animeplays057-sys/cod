import asyncio
import logging
from workers.celery_app import celery_app
from services.flow_executor import FlowExecutor
from services.instagram_api import reply_to_comment, InstagramAPIError
from models.database import supabase

logger = logging.getLogger(__name__)


@celery_app.task(
    bind=True,
    max_retries=5,
    queue="dm_queue",
    name="workers.dm_worker.execute_flow_task"
)
def execute_flow_task(
    self,
    automation_id: str,
    flow_json: dict,
    subscriber_id: str,
    ig_account_id: str,
    encrypted_token: str,
    recipient_ig_user_id: str,
    trigger_data: dict,
    also_reply_comment: bool = False,
    comment_reply_text: str = None,
    comment_id: str = None
):
    """
    Main Celery task: Execute an automation flow and send DMs.
    Uses exponential backoff on rate limit errors (Meta policy).
    """
    try:
        # If also_reply_comment is set, publicly reply to the comment first
        if also_reply_comment and comment_id and comment_reply_text:
            try:
                asyncio.run(
                    reply_to_comment(
                        ig_account_id=ig_account_id,
                        encrypted_token=encrypted_token,
                        comment_id=comment_id,
                        reply_text=comment_reply_text
                    )
                )
            except InstagramAPIError as e:
                logger.warning(f"Comment reply failed (non-critical): {e}")

        # Execute the flow
        executor = FlowExecutor(
            automation_id=automation_id,
            flow_json=flow_json,
            subscriber_id=subscriber_id,
            ig_account_id=ig_account_id,
            encrypted_token=encrypted_token,
            recipient_ig_user_id=recipient_ig_user_id,
            trigger_data=trigger_data
        )
        logs = asyncio.run(executor.run())

        # Update automation triggered count (increment via DB)
        supabase.rpc("increment_automation_triggered", {"automation_uuid": automation_id}).execute()

        logger.info(f"Flow executed: automation={automation_id}, logs={len(logs)} steps")
        return {"status": "success", "steps": len(logs)}

    except InstagramAPIError as e:
        if e.is_rate_limited:
            # Exponential backoff: 1min, 2min, 4min, 8min, 16min
            wait = 60 * (2 ** self.request.retries)
            logger.warning(
                f"Rate limited on automation {automation_id}. "
                f"Retry {self.request.retries + 1}/5 in {wait}s"
            )
            raise self.retry(exc=e, countdown=wait)
        else:
            logger.error(f"Instagram API error on automation {automation_id}: {e}")
            raise

    except Exception as e:
        logger.error(f"Unexpected error in dm_worker for automation {automation_id}: {e}")
        # Retry with backoff for transient errors
        wait = 30 * (2 ** self.request.retries)
        raise self.retry(exc=e, countdown=wait, max_retries=3)
