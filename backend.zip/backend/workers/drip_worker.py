import asyncio
import logging
from datetime import datetime, timezone
from workers.celery_app import celery_app
from models.database import supabase
from services.flow_executor import FlowExecutor

logger = logging.getLogger(__name__)


@celery_app.task(name="workers.drip_worker.process_drip_queue")
def process_drip_queue():
    """
    Called every 60 seconds by Celery Beat.
    Picks up pending drip queue entries that are due and executes them.
    """
    now = datetime.now(timezone.utc).isoformat()

    # Get all pending entries that are due
    result = supabase.table("drip_queue")\
        .select("*, automations(*), instagram_accounts(access_token)")\
        .eq("status", "pending")\
        .lte("scheduled_at", now)\
        .limit(50)\
        .execute()

    if not result.data:
        return {"processed": 0}

    processed = 0
    for entry in result.data:
        try:
            _process_drip_entry(entry)
            processed += 1
        except Exception as e:
            logger.error(f"Drip entry {entry['id']} failed: {e}")
            supabase.table("drip_queue").update({
                "status": "failed",
                "retry_count": entry.get("retry_count", 0) + 1
            }).eq("id", entry["id"]).execute()

    logger.info(f"Drip queue: processed {processed} entries")
    return {"processed": processed}


def _process_drip_entry(entry: dict):
    """Process a single drip queue entry."""
    # Mark as sent to prevent double-processing
    supabase.table("drip_queue").update({"status": "sent"})\
        .eq("id", entry["id"])\
        .execute()

    # Get automation flow
    automation = entry.get("automations", {})
    ig_account = entry.get("instagram_accounts", {})
    flow_json = automation.get("flow_json", {"nodes": [], "edges": []})
    encrypted_token = ig_account.get("access_token", "")

    # Get subscriber info
    subscriber_result = supabase.table("subscribers")\
        .select("*")\
        .eq("id", entry["subscriber_id"])\
        .single()\
        .execute()

    if not subscriber_result.data:
        return

    subscriber = subscriber_result.data

    # Check opted_out before sending drip
    if subscriber.get("opted_out"):
        logger.info(f"Drip entry {entry['id']} skipped — subscriber opted out")
        return

    # Check 24hr window
    from services.subscriber_service import is_within_24hr_window
    if not is_within_24hr_window(subscriber["last_interaction_at"]):
        logger.info(f"Drip entry {entry['id']} skipped — 24hr window expired")
        return

    # Execute from the specific node — inject a fake start-like edge
    # We create a minimal subflow starting from current_node_id
    # by temporarily making that node the entry point
    entry_node_id = entry["current_node_id"]

    # Create a proxy flow with a fake 'start' that connects directly to entry_node_id
    proxy_flow = {
        "nodes": flow_json.get("nodes", []) + [
            {"id": "drip_start", "type": "startNode", "data": {}}
        ],
        "edges": flow_json.get("edges", []) + [
            {"id": "drip_edge", "source": "drip_start", "target": entry_node_id}
        ]
    }
    # Override the start node ID for this execution
    proxy_flow["nodes"] = [
        n if n["id"] != "start" else {"id": "start_disabled", "type": "startNode", "data": {}}
        for n in proxy_flow["nodes"]
    ]
    # Rename drip_start as start
    proxy_flow["nodes"] = [
        n if n["id"] != "drip_start" else {**n, "id": "start"}
        for n in proxy_flow["nodes"]
    ]
    proxy_flow["edges"] = [
        e if e["id"] != "drip_edge" else {**e, "source": "start"}
        for e in proxy_flow["edges"]
    ]

    executor = FlowExecutor(
        automation_id=entry["automation_id"],
        flow_json=proxy_flow,
        subscriber_id=entry["subscriber_id"],
        ig_account_id=entry["ig_account_id"],
        encrypted_token=encrypted_token,
        recipient_ig_user_id=subscriber["ig_user_id"],
        trigger_data={"event_type": "drip"}
    )
    asyncio.run(executor.run())
