import asyncio
import logging
from workers.celery_app import celery_app
from models.database import supabase
from services.token_manager import refresh_long_lived_token, is_token_expiring_soon

logger = logging.getLogger(__name__)


@celery_app.task(name="workers.token_refresh_worker.refresh_expiring_tokens")
def refresh_expiring_tokens():
    """
    Runs daily via Celery Beat.
    Finds IG accounts whose tokens expire within 10 days and refreshes them.
    """
    result = supabase.table("instagram_accounts")\
        .select("id, username, token_expires_at")\
        .eq("is_active", True)\
        .execute()

    if not result.data:
        return {"checked": 0, "refreshed": 0}

    refreshed = 0
    for account in result.data:
        expires_at = account.get("token_expires_at")
        if is_token_expiring_soon(expires_at, days_threshold=10):
            logger.info(f"Refreshing token for IG account: {account['username']}")
            success = asyncio.run(refresh_long_lived_token(account["id"]))
            if success:
                refreshed += 1
            else:
                logger.error(f"Failed to refresh token for {account['username']}")

    logger.info(f"Token refresh: checked={len(result.data)}, refreshed={refreshed}")
    return {"checked": len(result.data), "refreshed": refreshed}
