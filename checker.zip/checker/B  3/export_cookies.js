// ========================================
// CC Checker — Cookie Exporter
// 
// Instructions:
// 1. Login to WooCommerce site in browser
// 2. Go to /my-account/add-payment-method/
// 3. Press F12 → Console tab
// 4. Paste this ENTIRE script and press Enter
// 5. Copy the output and send to bot via /b3addpair
// ========================================

(function() {
    var cookies = {};
    document.cookie.split(';').forEach(function(c) {
        var parts = c.trim().split('=');
        var key = parts[0];
        var val = parts.slice(1).join('=');
        if (key) cookies[key] = val;
    });
    
    var output = 'cookies = {\n';
    Object.keys(cookies).forEach(function(k) {
        output += "    '" + k + "': '" + cookies[k].replace(/'/g, "\\'") + "',\n";
    });
    output += '}';
    
    console.log('=== COPY EVERYTHING BELOW ===');
    console.log(output);
    console.log('=== END ===');
    console.log('Total cookies:', Object.keys(cookies).length);
    
    // Also try to copy to clipboard
    try {
        navigator.clipboard.writeText(output).then(function() {
            console.log('Copied to clipboard!');
        });
    } catch(e) {
        console.log('Manual copy needed');
    }
})();
