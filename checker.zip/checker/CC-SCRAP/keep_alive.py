import os
from flask import Flask
from threading import Thread

app = Flask('')

@app.route('/')
def home():
    return "✅ Elite Scrapper Bot is Online!"

@app.route('/health')
def health():
    return {"status": "running", "bot": "CC-SCRAP"}, 200

def run():
    # Render apna PORT env var deta hai — use karo
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port)

def live():
    t = Thread(target=run)
    t.daemon = True
    t.start()