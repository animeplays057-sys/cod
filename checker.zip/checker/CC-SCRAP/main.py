import requests
import random
import time
import json
import string
import os
import datetime
from faker import Faker
from keep_alive import live

fake = Faker()

# ============================================================
# CARD PREFIXES — Sirf Shopify-supported networks
# (Mir, RuPay, Troy, Maestro, UnionPay etc. = BRAND_NOT_SUPPORTED)
# ============================================================
CARD_PREFIXES = {
    # ── VISA (Most approved) ────────────────────────────────
    'Visa':                ['4026', '4175', '4508', '4844', '4913', '4917',
                            '4111', '4222', '4532', '4539', '4556', '4916',
                            '4929', '4485', '4716'],

    'Visa Debit':          ['4462', '4563', '4971', '4917', '4508'],

    'Visa Electron':       ['4026', '4508', '4844', '4913', '4917'],

    'Visa Platinum':       ['4147', '4148', '4149', '4150'],

    'Visa Signature':      ['4151', '4152', '4153', '4154'],

    'Visa Infinite':       ['4155', '4156', '4157', '4158'],

    'Visa Corporate':      ['4485', '4532', '4929'],

    'Visa Gift':           ['4003', '4005', '4217', '4500'],

    'Visa Prepaid':        ['4027', '4600', '4601', '4602'],

    # ── VISA EXTENDED (Custom BINs) ─────────────────────────
    'Visa Extended':       ['437378', '417896', '422708', '409403', '426429',
                            '465902', '465901', '465943', '407156', '407170',
                            '489504', '476175', '434769', '411773', '400180',
                            '434076', '403703', '429226', '403706', '420468',
                            '407468', '483313'],

    # ── MASTERCARD ─────────────────────────────────────────
    'Mastercard':          ['51', '52', '53', '54', '55',
                            '2221', '2222', '2223', '2224', '2225',
                            '2226', '2300', '2400', '2500', '2600',
                            '2700', '2710', '2720'],

    'Mastercard Debit':    ['5256', '5273', '5274', '5275'],

    'Mastercard Platinum': ['5410', '5411', '5412'],

    'Mastercard World':    ['5406', '5407', '5408', '5409'],

    'Mastercard Black':    ['5440', '5441', '5442'],

    'Mastercard Corporate':['5413', '5414', '5415', '5416'],

    'Mastercard Prepaid':  ['5100', '5101', '5102', '5103', '5104'],

    # ── MASTERCARD EXTENDED (Custom BINs) ───────────────────
    'Mastercard Extended': ['533621', '546325', '515462', '525843', '521845',
                            '531107', '523971', '528093', '526731', '535256',
                            '535965', '522094', '528944', '538190', '536350',
                            '529750', '524028'],

    # ── AMERICAN EXPRESS ────────────────────────────────────
    'American Express':    ['34', '37'],

    'Amex Corporate':      ['3714', '3782', '3787'],

    # ── DISCOVER ────────────────────────────────────────────
    'Discover':            ['6011', '6221', '6222', '6223', '6224', '6225',
                            '6226', '6227', '6228', '6229', '644', '645',
                            '646', '647', '648', '649', '65'],

    # ── JCB ─────────────────────────────────────────────────
    'JCB':                 ['3528', '3529', '3530', '3531', '3532', '3533',
                            '3534', '3535', '3536', '3537', '3538', '3539',
                            '3540', '3550', '3560', '3570', '3580', '3589'],

    # ── DINERS CLUB ─────────────────────────────────────────
    'Diners Club':         ['300', '301', '302', '303', '304', '305',
                            '3095', '36', '38', '39'],

    'Diners Club US':      ['54', '55'],
}

# Card length map (default = 16)
CARD_LENGTHS = {
    'American Express':  15,
    'Amex Corporate':    15,
    'Diners Club':       14,
}

# BIN Cache — same BIN dobara API call nahi karega
BIN_CACHE = {}


# ============================================================
# CARD GENERATION
# ============================================================
def generate_card_number(card_type):
    if card_type not in CARD_PREFIXES:
        card_type = random.choice(list(CARD_PREFIXES.keys()))

    prefix = random.choice(CARD_PREFIXES[card_type])
    length = CARD_LENGTHS.get(card_type, 16)

    body   = prefix + ''.join([str(random.randint(0, 9)) for _ in range(length - len(prefix) - 1)])
    digits = [int(d) for d in body]
    for i in range(len(digits) - 2, -1, -2):
        digits[i] *= 2
        if digits[i] > 9:
            digits[i] -= 9

    total_sum   = sum(digits)
    check_digit = (10 - (total_sum % 10)) % 10
    return body + str(check_digit), card_type


def luhn_algorithm(card_number):
    digits = [int(d) for d in card_number]
    for i in range(len(digits) - 2, -1, -2):
        digits[i] *= 2
        if digits[i] > 9:
            digits[i] -= 9
    return sum(digits) % 10 == 0


def generate_card_details():
    card_number, card_type = generate_card_number(random.choice(list(CARD_PREFIXES.keys())))

    # Future expiry only — 2026 to 2033 (year never expired)
    month = str(random.randint(1, 12)).zfill(2)
    year  = str(random.randint(26, 33)).zfill(2)

    if card_type in ('American Express', 'Amex Corporate'):
        cvv = str(random.randint(1000, 9999)).zfill(4)
    else:
        cvv = str(random.randint(100, 999)).zfill(3)

    return f"{card_number}|{month}|{year}|{cvv}", card_type


# ============================================================
# BIN LOOKUP
# ============================================================
def fetch_bin_info(BIN, card_type):
    bin_prefix = BIN[:6]

    if bin_prefix in BIN_CACHE:
        return BIN_CACHE[bin_prefix]

    try:
        response = requests.get(f"https://bins.antipublic.cc/bins/{bin_prefix}", timeout=3)
        if response.status_code == 200 and response.json().get('brand'):
            req    = response.json()
            result = {
                'brand':        req.get('brand', card_type).upper(),
                'country':      req.get('country', 'US'),
                'country_name': req.get('country_name', 'United States'),
                'country_flag': req.get('country_flag', '🇺🇸'),
                'bank':         req.get('bank', 'Unknown Bank'),
                'level':        req.get('level', 'Standard'),
                'typea':        req.get('type', 'Credit'),
            }
            BIN_CACHE[bin_prefix] = result
            return result
    except Exception:
        pass

    default = {
        'brand': card_type, 'country': 'US', 'country_name': 'United States',
        'country_flag': '🇺🇸', 'bank': 'Unknown Bank', 'level': 'Standard', 'typea': 'Credit'
    }
    BIN_CACHE[bin_prefix] = default
    return default


# ============================================================
# TELEGRAM HELPERS
# ============================================================
def telegram_send(telegram_api, chat_id, text, reply_markup=None):
    """Message bhejo — message_id return karta hai (edit ke liye)"""
    data = {'chat_id': chat_id, 'text': text, 'parse_mode': 'HTML'}
    if reply_markup:
        data['reply_markup'] = json.dumps(reply_markup)
    try:
        r = requests.post(f'{telegram_api}/sendMessage', data=data, timeout=10)
        if r.status_code == 200:
            return r.json().get('result', {}).get('message_id')
    except Exception as e:
        print(f"⚠️ Send fail: {e}")
    return None


def telegram_edit(telegram_api, chat_id, message_id, text):
    """Ek message ko edit karo — progress auto-update"""
    if not message_id:
        return
    try:
        requests.post(
            f'{telegram_api}/editMessageText',
            data={'chat_id': chat_id, 'message_id': message_id,
                  'text': text, 'parse_mode': 'HTML'},
            timeout=10
        )
    except Exception:
        pass


# ============================================================
# BULK GENERATOR + SENDER
# ============================================================
def send_bulk():
    # ── Bot Config ─────────────────────────────────────────
    bot_token    = os.environ.get('BOT_TOKEN', '8758269594:AAEUreeuyk97XfXNs8JTl00oDoQX4rvU57M')
    chat_id      = int(os.environ.get('CHAT_ID', '2034253345'))
    telegram_api = f'https://api.telegram.org/bot{bot_token}'
    max_retries  = 3

    # ── Settings ───────────────────────────────────────────
    TOTAL_CARDS  = 2000
    MIN_CARDS    = 500
    SKIP_BIN_API = True    # True = BIN API skip — FAST mode (no API delay)

    print(f"🚀 Bulk generation shuru... Target: {TOTAL_CARDS} cards")

    # ── Single progress message — edit hota rahega ─────────
    progress_msg_id = telegram_send(
        telegram_api, chat_id,
        f"😊 <b>SMILE DUMPS</b> 😊\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"📊 <b>Progress:</b> 0/{TOTAL_CARDS}\n"
        f"⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜ 0%\n"
        f"⏳ Generating cards..."
    )
    print(f"📬 Progress msg ID: {progress_msg_id}")

    # ── Phase 1: Generation ────────────────────────────────
    all_cards     = []
    country_stats = {}
    type_stats    = {}
    generated     = 0

    while generated < TOTAL_CARDS:
        card_details, card_type = generate_card_details()
        card_number = card_details.split('|')[0]

        if not luhn_algorithm(card_number):
            continue

        BIN  = card_number[:6]
        if SKIP_BIN_API:
            info = {
                'brand': card_type, 'country': 'US', 'country_name': 'United States',
                'country_flag': '🇺🇸', 'bank': 'Generated Bank', 'level': 'Standard', 'typea': 'Credit'
            }
        else:
            info = fetch_bin_info(BIN, card_type)

        month, year, cvv = card_details.split('|')[1], card_details.split('|')[2], card_details.split('|')[3]
        full_name = fake.name()

        country_key = f"{info['country_name']} {info['country_flag']}"
        country_stats[country_key] = country_stats.get(country_key, 0) + 1

        type_key = f"{info['brand']}-{info['typea']}-{info['level']}"
        type_stats[type_key] = type_stats.get(type_key, 0) + 1

        line = (
            f"{card_details} | {info['brand']} | {info['typea']} | {info['level']} | "
            f"{info['bank']} | {info['country_name']} {info['country_flag']} | Name: {full_name}"
        )
        all_cards.append(line)
        generated += 1

        # Har 200 cards pe progress message EDIT karo (naya nahi)
        if generated % 200 == 0:
            pct    = int((generated / TOTAL_CARDS) * 100)
            filled = pct // 10
            bar    = '🟩' * filled + '⬜' * (10 - filled)
            print(f"  ✅ {generated}/{TOTAL_CARDS} cards generated...")
            telegram_edit(
                telegram_api, chat_id, progress_msg_id,
                f"😊 <b>SMILE DUMPS</b> 😊\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"📊 <b>Progress:</b> {generated}/{TOTAL_CARDS}\n"
                f"{bar} {pct}%\n"
                f"⏳ Generating cards..."
            )

    total_valid = len(all_cards)
    print(f"\n✅ Generation complete! Total: {total_valid} cards")

    # Final progress update
    telegram_edit(
        telegram_api, chat_id, progress_msg_id,
        f"😊 <b>SMILE DUMPS</b> 😊\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"📊 <b>Progress:</b> {total_valid}/{TOTAL_CARDS}\n"
        f"🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩 100%\n"
        f"📦 Preparing file to send..."
    )

    if total_valid < MIN_CARDS:
        print(f"❌ Sirf {total_valid} cards bane — minimum {MIN_CARDS} chahiye. Abort!")
        return

    # ── Phase 2: TXT File ──────────────────────────────────
    timestamp    = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    txt_filename = f"SMILE_DUMPS_{timestamp}.txt"

    header_lines = [
        "╔" + "═"*62 + "╗",
        "║  😊  SMILE DUMPS  --  FRESH CC DUMP                           ║",
        f"║  🕒 Generated : {datetime.datetime.now().strftime('%d %b %Y  %H:%M:%S')}             ║",
        f"║  📦 Total Cards: {total_valid:<6}                                  ║",
        f"║  👨\u200d💻 Developer : @yoursmileyt                              ║",
        "╚" + "═"*62 + "╝",
        "",
        "┌─ 🌍 COUNTRY BREAKDOWN " + "─"*42 + "┐",
    ]
    for country, count in sorted(country_stats.items(), key=lambda x: -x[1]):
        header_lines.append(f"│  {country:<40} → {count:>5} cards  │")

    header_lines += [
        "└" + "─"*62 + "┘",
        "",
        "┌─ 💳 CARD TYPE BREAKDOWN " + "─"*40 + "┐",
    ]
    for ctype, count in sorted(type_stats.items(), key=lambda x: -x[1]):
        header_lines.append(f"│  {ctype:<45} → {count:>5} cards  │")

    header_lines += [
        "└" + "─"*62 + "┘",
        "",
        "═" * 64,
        " FORMAT: CC|MM|YY|CVV | BRAND | TYPE | LEVEL | BANK | COUNTRY",
        "═" * 64,
        "",
    ]

    with open(txt_filename, 'w', encoding='utf-8') as f:
        f.write('\n'.join(header_lines) + '\n')
        f.write('\n'.join(all_cards) + '\n')

    print(f"📄 File saved: {txt_filename} ({os.path.getsize(txt_filename)//1024} KB)")

    # ── Phase 3: Caption ───────────────────────────────────
    top_countries = sorted(country_stats.items(), key=lambda x: -x[1])[:8]
    country_lines = "\n".join([f"  {n} → <b>{c}</b>" for n, c in top_countries])

    top_types = sorted(type_stats.items(), key=lambda x: -x[1])[:8]
    type_lines = "\n".join([f"  <code>{t}</code> → <b>{c}</b>" for t, c in top_types])

    caption = (
        f"😊 <b>SMILE DUMPS</b> 😊\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📦 <b>Total Cards :</b> <code>{total_valid}</code>\n"
        f"🕒 <b>Generated   :</b> <code>{datetime.datetime.now().strftime('%d %b %Y  %H:%M')}</code>\n"
        f"👨\u200d💻 <b>Developer   :</b> @yoursmileyt\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🌍 <b>TOP COUNTRIES</b>\n{country_lines}\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"💳 <b>TOP CARD TYPES</b>\n{type_lines}\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"✂️ Reply <code>split</code> → get 500/500 chunks"
    )

    reply_markup = {
        "inline_keyboard": [[
            {"text": "😊 @yoursmileyt", "url": "https://t.me/yoursmileyt"}
        ]]
    }

    # ── Phase 4: Send Document ─────────────────────────────
    print("\n📤 Telegram pe bhej raha hoon...")
    retry_count = 0
    sent        = False

    while retry_count < max_retries and not sent:
        try:
            with open(txt_filename, 'rb') as doc:
                resp = requests.post(
                    f'{telegram_api}/sendDocument',
                    files={'document': (txt_filename, doc, 'text/plain')},
                    data={'chat_id': chat_id, 'caption': caption,
                          'parse_mode': 'HTML', 'reply_markup': json.dumps(reply_markup)},
                    timeout=60
                )
            if resp.status_code == 200:
                print("✅ SUCCESS! Bulk file Telegram pe bhej diya!")
                sent = True
            elif resp.status_code == 429:
                wait = resp.json().get('parameters', {}).get('retry_after', 15)
                print(f"⚠️ Rate limit! {wait}s wait...")
                time.sleep(wait)
                retry_count += 1
            else:
                print(f"❌ Error: {resp.status_code} — {resp.text}")
                retry_count += 1
                time.sleep(3)
        except Exception as e:
            print(f"❌ Exception: {e}")
            retry_count += 1
            time.sleep(3)

    if not sent:
        print(f"❌ File send nahi hui {max_retries} tries ke baad.")
    else:
        # Thumbnail photo bhi bhejo
        try:
            with open("attached_assets/IMG_20250709_153403_228_1752056794715.jpg", 'rb') as photo:
                requests.post(
                    f'{telegram_api}/sendPhoto',
                    files={'photo': photo},
                    data={
                        'chat_id': chat_id,
                        'caption': (
                            f"😊 <b>SMILE DUMPS</b>\n"
                            f"━━━━━━━━━━━━━━━━━━━━━━━━\n"
                            f"⬆️ File mein <b>{total_valid}</b> fresh cards!\n"
                            f"✂️ Reply <code>split</code> → 500/500 chunks\n"
                            f"👨\u200d💻 @yoursmileyt"
                        ),
                        'parse_mode': 'HTML'
                    },
                    timeout=30
                )
            print("📸 Thumbnail bhi bhej diya!")
        except Exception as e:
            print(f"⚠️ Thumbnail fail: {e}")

    # Progress message ko "Done" pe update karo
    telegram_edit(
        telegram_api, chat_id, progress_msg_id,
        f"✅ <b>BATCH COMPLETE!</b>\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"📦 <b>{total_valid}</b> cards sent!\n"
        f"🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩 100%\n"
        f"😊 @yoursmileyt — Next batch in 60s..."
    )


# ============================================================
# INFINITE LOOP
# ============================================================
def bulk_loop():
    run_count = 0
    while True:
        run_count += 1
        print(f"\n{'='*50}")
        print(f"🔄 RUN #{run_count} shuru...")
        print(f"{'='*50}")
        try:
            send_bulk()
        except Exception as e:
            print(f"❌ Run #{run_count} error: {e}")

        COOLDOWN = 60
        print(f"\n⏳ Next run {COOLDOWN}s mein...")
        time.sleep(COOLDOWN)


# ============================================================
# SPLIT COMMAND — File reply karke "split" likho
# ============================================================
def handle_split(update, bot_token):
    telegram_api = f'https://api.telegram.org/bot{bot_token}'
    msg          = update.get('message', {})
    reply        = msg.get('reply_to_message', {})
    doc          = reply.get('document')
    chat_id      = msg.get('chat', {}).get('id')

    if not doc:
        requests.post(f'{telegram_api}/sendMessage',
            data={'chat_id': chat_id,
                  'text': '⚠️ Kisi .txt file ko reply karke <code>split</code> likho!',
                  'parse_mode': 'HTML'})
        return

    file_id   = doc['file_id']
    file_name = doc.get('file_name', 'cards.txt')

    # File download
    file_resp = requests.get(f'{telegram_api}/getFile',
                              params={'file_id': file_id}, timeout=10)
    file_path = file_resp.json()['result']['file_path']
    content   = requests.get(
        f'https://api.telegram.org/file/bot{bot_token}/{file_path}', timeout=30
    ).text

    # Sirf card lines lo (header skip)
    lines = [
        l for l in content.splitlines()
        if '|' in l and l.strip()
        and not l.startswith('═')
        and not l.startswith('─')
        and not l.startswith('FORMAT')
        and not l.startswith('   ')
    ]

    if not lines:
        requests.post(f'{telegram_api}/sendMessage',
            data={'chat_id': chat_id, 'text': '❌ File mein valid card lines nahi mili!'})
        return

    CHUNK        = 500
    total_chunks = (len(lines) + CHUNK - 1) // CHUNK

    requests.post(f'{telegram_api}/sendMessage',
        data={
            'chat_id': chat_id,
            'text':    f"✂️ Splitting <b>{len(lines)}</b> cards into <b>{total_chunks}</b> files of {CHUNK} each...",
            'parse_mode': 'HTML'
        })

    for i in range(0, len(lines), CHUNK):
        chunk_lines   = lines[i:i + CHUNK]
        chunk_num     = (i // CHUNK) + 1
        chunk_fname   = f"SPLIT_PART{chunk_num:02d}_{file_name}"
        chunk_content = (
            f"PART {chunk_num}/{total_chunks} — {len(chunk_lines)} cards\n"
            + "=" * 60 + "\n"
            + "\n".join(chunk_lines)
        )
        requests.post(
            f'{telegram_api}/sendDocument',
            files={'document': (chunk_fname, chunk_content.encode('utf-8'), 'text/plain')},
            data={
                'chat_id':    chat_id,
                'caption':    f"📂 <b>Part {chunk_num}/{total_chunks}</b> — {len(chunk_lines)} cards",
                'parse_mode': 'HTML'
            },
            timeout=30
        )
        time.sleep(1)

    print(f"✂️ Split done: {total_chunks} files bheje!")


def poll_commands():
    bot_token    = os.environ.get('BOT_TOKEN', '8758269594:AAEUreeuyk97XfXNs8JTl00oDoQX4rvU57M')
    telegram_api = f'https://api.telegram.org/bot{bot_token}'
    offset       = 0

    print("📡 Command polling shuru... 'split' command ke liye ready")
    while True:
        try:
            resp    = requests.get(
                f'{telegram_api}/getUpdates',
                params={'offset': offset, 'timeout': 20, 'allowed_updates': ['message']},
                timeout=25
            )
            updates = resp.json().get('result', [])
            for upd in updates:
                offset = upd['update_id'] + 1
                msg    = upd.get('message', {})
                text   = msg.get('text', '').strip().lower()
                if text == 'split' and msg.get('reply_to_message', {}).get('document'):
                    print("✂️ Split command received!")
                    handle_split(upd, bot_token)
        except Exception as e:
            print(f"⚠️ Polling error: {e}")
            time.sleep(5)


# ============================================================
# ENTRY POINT
# ============================================================
if __name__ == '__main__':
    from threading import Thread

    live()  # Flask (Render ke liye)

    Thread(target=bulk_loop, daemon=True).start()
    print("🤖 Bulk loop started!")

    poll_thread = Thread(target=poll_commands, daemon=True)
    poll_thread.start()
    print("📡 Split command listener started!")

    poll_thread.join()