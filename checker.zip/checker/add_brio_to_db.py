"""
Directly add brio4life.com to DB as a working Shopify gate
using the real scan flow from shopify_site_scanner.py
"""
import asyncio
import sys
import json
sys.path.insert(0, '.')
import database.db as db
from shopify_site_scanner import scan_site

async def main():
    await db.init_db()
    
    # Check what's already there
    existing = await db.get_active_shopify_gates(limit=50)
    print(f"Existing gates: {len(existing)}")
    
    # Scan brio4life.com
    print("\nScanning https://www.brio4life.com ...")
    import asyncio
    semaphore = asyncio.Semaphore(1)
    result = await scan_site("https://www.brio4life.com", semaphore)
    
    print(f"Status:  {result['status']}")
    print(f"Reason:  {result['reason']}")
    print(f"Variant: {result['variant_id']}")
    print(f"Price:   ${result['price']} {result['currency']}")
    print(f"Handle:  {result.get('scan_data', {}).get('delivery_handle', 'NONE')}")
    
    if result["status"] == "WORKING":
        gate_id = await db.add_shopify_gate(
            base_url=result["url"],
            variant_id=result["variant_id"],
            price=result["price"],
            product_title=result["product_title"],
            shop_domain=result["shop_domain"],
            shop_id=result["shop_id"],
            currency=result["currency"],
            checkout_type=result["checkout_type"],
            added_by=0,
            scan_data=result.get("scan_data", {}),
        )
        print(f"\n✅ Added to DB as gate #{gate_id}")
    else:
        print(f"\n❌ Scan failed — manually adding with known values...")
        # Add manually with known working values from our testing
        scan_data = {
            "delivery_handle": "",  # Will be fetched dynamically by gate
            "payment_method_id": "dc2c83c064fc75ebc5dfa2b5bee4f873",
            "vault_ok": True,
            "has_pci_vault": True,
        }
        gate_id = await db.add_shopify_gate(
            base_url="https://www.brio4life.com",
            variant_id=41675869487181,
            price="6.95",
            product_title="RAZE Shaver",
            shop_domain="brio4life.myshopify.com",
            shop_id="",
            currency="USD",
            checkout_type="one_page",
            added_by=0,
            scan_data=scan_data,
        )
        print(f"✅ Manually added as gate #{gate_id}")
    
    # Verify
    gates = await db.get_active_shopify_gates(limit=50)
    print(f"\nTotal gates now: {len(gates)}")
    for g in gates:
        sd = g.get("scan_data", {})
        if isinstance(sd, str):
            try: sd = json.loads(sd)
            except: sd = {}
        dh = sd.get("delivery_handle", "")
        print(f"  #{g['id']} | {g['base_url']} | variant:{g['variant_id']} | ${g['price']} | handle:{dh[:40] if dh else 'DYNAMIC'}")

asyncio.run(main())
