import re, json

with open('shopify_checkout_store_dftba_com.html', 'r', encoding='utf-8', errors='ignore') as f:
    html = f.read()

print('=== CHECKOUT URL PATTERNS ===')
urls = re.findall(r'https?://[a-zA-Z0-9\-\.]+(?:shopify|shopifycs|shopifysvc|shop\.app)[a-zA-Z0-9/\-_\.?=&%]*', html)
for u in sorted(set(urls))[:30]:
    print(' ', u[:120])

print()
print('=== GRAPHQL / API ENDPOINTS ===')
gql = re.findall(r'["\']/((?:api|internal|checkouts?|wallets)[a-zA-Z0-9/_\-\.?=&]*)["\']', html)
for g in sorted(set(gql))[:30]:
    print(' ', g)

print()
print('=== PAYMENT KEYWORDS ===')
for kw in ['payment_session', 'paymentSession', 'sessionToken', 'session_token',
           'checkoutToken', 'checkout_token', 'one_time_token', 'payment_method',
           'deposit.shopify', 'shopifycs.com', 'elb.deposit', 'vault']:
    m = re.search(kw + r'.{0,80}', html, re.I)
    if m:
        print('  ' + kw + ':', m.group(0)[:100])

print()
print('=== SHOPIFY WINDOW VARS ===')
cfgs = re.findall(r'window\.[A-Za-z_]+\s*=\s*\{[^{}]{10,300}\}', html)
for c in cfgs[:8]:
    print(c[:300])
    print()

print()
print('=== SCRIPT SRC PAYMENT ===')
srcs = re.findall(r'src=["\']([^"\']+(?:payment|checkout|stripe|shopify)[^"\']+)["\']', html, re.I)
for s in sorted(set(srcs))[:15]:
    print(' ', s[:120])

print()
print('=== FETCH/XHR CALLS ===')
fetches = re.findall(r'fetch\s*\(\s*["\']([^"\']+)["\']', html)
for f2 in sorted(set(fetches))[:20]:
    print(' ', f2[:120])

print()
print('=== FORM ACTIONS ===')
actions = re.findall(r'action=["\']([^"\']+)["\']', html)
for a in sorted(set(actions))[:10]:
    print(' ', a[:100])
