import re, json, html as html_module

with open('shopify_checkout_store_dftba_com.html', 'r', encoding='utf-8', errors='ignore') as f:
    raw = f.read()

# Decode all HTML entities
html = html_module.unescape(raw)

print('=== SESSION TOKEN (clean) ===')
m = re.search(r'name="serialized-sessionToken"\s+content="([^"]{20,})"', raw)
if m:
    tok = html_module.unescape(m.group(1)).strip('"')
    print(tok)

print()
print('=== ALL SERIALIZED META TAGS ===')
metas = re.findall(r'name="(serialized-[^"]+)"\s+content="([^"]{1,800})"', raw)
for name, val in metas:
    decoded = html_module.unescape(val)
    if decoded.startswith('"') and decoded.endswith('"'):
        decoded = decoded[1:-1]
    try:
        j = json.loads(decoded)
        print(f'[{name}]')
        print(json.dumps(j, indent=2)[:600])
    except:
        print(f'[{name}] = {decoded[:200]}')
    print()

print()
print('=== PAYMENT METHOD IDENTIFIER ===')
m = re.search(r'paymentMethodIdentifier[^}]{0,200}', html)
if m: print(m.group(0)[:300])

print()
print('=== CHECKOUT SESSION IDENTIFIER ===')
m = re.search(r'checkoutSessionIdentifier[^}]{0,100}', html)
if m: print(m.group(0)[:200])

print()
print('=== GRAPHQL QUERY HINTS ===')
for kw in ['submitForCompletion', 'SubmitForCompletion', 'checkoutComplete',
           'CartSubmitForCompletion', 'attemptToken', 'SubmitAlreadyAccepted',
           'paymentProcessing']:
    m = re.search(kw + r'.{0,100}', html, re.I)
    if m:
        print(kw + ':', m.group(0)[:150])
        print()
