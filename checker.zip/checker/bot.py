"""
bot.py — Main entry point for CC Checker Pro Bot
"""
import asyncio
import logging
import os
import sys
from datetime import datetime

# ── Python 3.10+ / 3.14 Event Loop Compatibility Fix ──────────────────────────
# pyrogram 2.0.106 calls asyncio.get_event_loop() at import time in sync.py.
# In Python 3.10+, this raises RuntimeError when no event loop exists yet.
# We must create and set a loop BEFORE importing pyrogram.
try:
    asyncio.get_event_loop()
except RuntimeError:
    asyncio.set_event_loop(asyncio.new_event_loop())

from pyrogram import Client
from aiohttp import web

import config
import database.db as db
from handlers.commands import register_commands
from handlers.checker import register_checker
from handlers.generator import register_generator
from handlers.admin import register_admin
from handlers.scanner import register_scanner
from handlers.proxy_handler import register_proxy_handler, auto_proxy_health_check
from handlers.shopify_handler import register_shopify_handler
from handlers.b3_handler import register_b3

# ── Logging Setup ─────────────────────────────────────────────────────────────
# Render: stdout only, no DEBUG spam (fills log buffer fast)
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

# Ensure stdout supports UTF-8 (prevents UnicodeEncodeError with emojis on Windows console)
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

# Noisy third-party loggers — suppress to WARNING
for _noisy in ("pyrogram", "aiohttp", "asyncio", "urllib3"):
    logging.getLogger(_noisy).setLevel(logging.WARNING)

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    stream=sys.stdout,  # Render captures stdout
)
logger = logging.getLogger("CC-Checker")

# Optional rotating file log (local dev only, ignored on Render)
if os.getenv("LOG_TO_FILE", "false").lower() == "true":
    from logging.handlers import RotatingFileHandler
    _fh = RotatingFileHandler("logs.txt", maxBytes=5_000_000, backupCount=3, encoding="utf-8")
    _fh.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
    logging.getLogger().addHandler(_fh)





# ── Validation ────────────────────────────────────────────────────────────────
def _validate_config():
    errors = []
    if not config.BOT_TOKEN:
        errors.append("BOT_TOKEN is not set")
    if not config.API_ID or config.API_ID == 0:
        errors.append("API_ID is not set")
    if not config.API_HASH:
        errors.append("API_HASH is not set")
    if errors:
        for e in errors:
            logger.error(f"Config Error: {e}")
        raise SystemExit("Fix config errors above and restart.")


# ── Health Check Server ────────────────────────────────────────────────────────
# Render Web Service requires at least one open port.
# This lightweight aiohttp server satisfies that without any extra dependency.
async def _health_handler(request: web.Request) -> web.Response:
    uptime = ""
    if config.START_TIME:
        delta = datetime.now() - config.START_TIME
        hours, rem = divmod(int(delta.total_seconds()), 3600)
        uptime = f"{hours}h {rem // 60}m"
    return web.json_response({
        "status": "ok",
        "bot": config.BOT_NAME,
        "version": config.BOT_VERSION,
        "uptime": uptime,
    })


async def _start_health_server() -> web.AppRunner:
    app = web.Application()
    app.router.add_get("/", _health_handler)
    app.router.add_get("/health", _health_handler)
    runner = web.AppRunner(app)
    await runner.setup()
    port = int(os.environ.get("PORT", 10000))
    site = web.TCPSite(runner, "0.0.0.0", port)
    await site.start()
    logger.info(f"✅ Health server listening on port {port}")
    return runner


# ── Bot Runner ────────────────────────────────────────────────────────────────
async def run_bot():
    _validate_config()

    await db.init_db()
    logger.info("Database initialized")



    # ── Ensure brio4life.com is always in DB as guaranteed working store ───────
    # brio4life is confirmed working and used as DEFAULT_STORE fallback.
    # Add to DB if not present so mass check can also use it.
    try:
        existing = await db._db.fetchone(
            "SELECT id FROM shopify_gates WHERE base_url=?",
            ("https://www.brio4life.com",)
        )
        if not existing:
            await db._db.execute(
                """INSERT OR IGNORE INTO shopify_gates
                   (base_url, shop_domain, variant_id, product_title, price, currency,
                    checkout_type, is_active, scan_data)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                ("https://www.brio4life.com", "brio4life.com", 41675869487181,
                 "Brio Guaranteed", "6.95", "USD", "one-page", 1,
                 '{"payment_method_id":"dc2c83c064fc75ebc5dfa2b5bee4f873"}')
            )
            logger.info("Startup: Added brio4life.com to DB as guaranteed working store")
    except Exception as _be:
        logger.warning(f"Startup brio4life ensure skipped: {_be}")


    # Load proxy pool into memory
    from core.proxy_manager import refresh_proxy_pool
    await refresh_proxy_pool()

    config.START_TIME = datetime.now()

    app = Client(
        name="cc_checker_bot",
        bot_token=config.BOT_TOKEN,
        api_id=config.API_ID,
        api_hash=config.API_HASH,
    )

    register_commands(app)
    register_checker(app)
    register_generator(app)
    register_admin(app)
    register_scanner(app)
    register_proxy_handler(app)
    register_shopify_handler(app)
    register_b3(app)

    logger.info(f"Starting {config.BOT_NAME} v{config.BOT_VERSION}")
    logger.info(f"Stripe keys loaded: {len(config.STRIPE_KEYS)}")
    logger.info(f"Owner IDs: {config.OWNER_IDS}")

    async with app:
        # Auto-register commands in BotFather on startup
        try:
            from handlers.commands import BOT_COMMANDS
            await app.set_bot_commands(BOT_COMMANDS)
            logger.info(f"✅ BotFather commands set ({len(BOT_COMMANDS)} commands)")
        except Exception as e:
            logger.warning(f"Failed to set bot commands: {e}")

        logger.info("Bot is running! Press Ctrl+C to stop.")
        # Start background auto-proxy health check (every 30 min)
        asyncio.ensure_future(auto_proxy_health_check(app))
        await asyncio.Event().wait()



# ── Entry Point ───────────────────────────────────────────────────────────────
async def main():
    runner = await _start_health_server()
    try:
        await run_bot()
    finally:
        await runner.cleanup()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user.")
