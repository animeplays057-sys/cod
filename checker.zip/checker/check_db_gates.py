import asyncio
import json
import sys
sys.path.insert(0, '.')
import database.db as db

async def main():
    await db.init_db()
    
    # Check existing shopify gates
    gates = await db.get_active_shopify_gates(limit=50)
    print(f"Total Shopify gates in DB: {len(gates)}")
    for g in gates:
        sd = g.get("scan_data", {})
        if isinstance(sd, str):
            try: sd = json.loads(sd)
            except: sd = {}
        dh = sd.get("delivery_handle", "")
        print(f"  ID:{g['id']} | {g['base_url']} | variant:{g['variant_id']} | price:${g['price']} | handle:{dh[:30] if dh else 'NONE'}")
    
    print()

asyncio.run(main())
