"""See exactly what the form POST returns."""
import asyncio, re, html as html_mod
import aiohttp
from aiohttp import ClientTimeout, CookieJar

H = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0.0.0 Safari/537.36"}

def em(html_txt, name):
    m = re.search(r'name=["\']serialized-'+re.escape(name)+r'["\'][^>]+content=["\']([^"\']{3,500})["\']', html_txt)
    if not m: return None
    val = html_mod.unescape(m.group(1)).strip()
    return val[1:-1] if (val.startswith('"') and val.endswith('"')) else val or None

async def main():
    base = "https://store.dftba.com"
    jar = CookieJar(unsafe=True)
    async with aiohttp.ClientSession(
        connector=aiohttp.TCPConnector(ssl=False, force_close=True),
        cookie_jar=jar, timeout=ClientTimeout(total=25)
    ) as s:
        await s.post(base+"/cart/add.js", data="id=42551911350347&quantity=1",
            headers={**H,"Content-Type":"application/x-www-form-urlencoded","Accept":"application/json","X-Requested-With":"XMLHttpRequest"},ssl=False)
        async with s.get(base+"/checkout",
            headers={**H,"Accept":"text/html,*/*","Referer":base+"/cart"},
            ssl=False, allow_redirects=True, max_redirects=15) as r:
            co_url = str(r.url)
            co_html = await r.text(errors="ignore")
        sess_tok = em(co_html, "sessionToken")
        
        async with s.post("https://checkout.pci.shopifyinc.com/sessions",
            json={"credit_card":{"number":"4111111111111111","name":"John Doe","month":12,"year":2026,"verification_value":"123"}},
            headers={"Authorization":f'Bearer "{sess_tok}"',"Content-Type":"application/json","Accept":"application/json",
                     "Origin":"https://checkout.pci.shopifyinc.com","User-Agent":H["User-Agent"]},
            ssl=False) as r:
            pid = (await r.json(content_type=None)).get("id","")
        
        # Build cart to get checkout URL
        ep = f"{base}/api/2024-01/graphql.json"
        gql_h = {**H,"Accept":"application/json","Content-Type":"application/json"}
        
        async with s.post(ep, json={"query":"""mutation cartCreate($input: CartInput!) {
  cartCreate(input: $input) { cart { id checkoutUrl } userErrors { message } }
}""","variables":{"input":{"lines":[{"merchandiseId":"gid://shopify/ProductVariant/42551911350347","quantity":1}]}}},
                headers=gql_h, ssl=False) as r:
            d = await r.json(content_type=None)
        cart = (d.get("data") or {}).get("cartCreate",{}).get("cart",{})
        cart_checkout_url = cart.get("checkoutUrl","")
        
        print(f"vault_id: {pid}")
        print(f"form_post_url: {cart_checkout_url[:80]}")
        
        # Form POST to cart checkout URL
        form = {
            "checkout[billing_address][first_name]": "John",
            "checkout[billing_address][last_name]": "Doe",
            "checkout[billing_address][address1]": "123 Main St",
            "checkout[billing_address][city]": "Los Angeles",
            "checkout[billing_address][province]": "CA",
            "checkout[billing_address][country]": "US",
            "checkout[billing_address][zip]": "90001",
            "checkout[credit_card][vault]": pid,
            "checkout[payment_gateway]": "shopify_payments",
            "s": pid,
        }
        async with s.post(cart_checkout_url, data=form,
            headers={**H,"Content-Type":"application/x-www-form-urlencoded","Accept":"text/html,*/*","Referer":cart_checkout_url},
            ssl=False, allow_redirects=True, max_redirects=10) as r:
            resp = await r.text(errors="ignore")
            final = str(r.url)
            print(f"\nForm POST result: [{r.status}] -> {final[:100]}")
            # Show ALL meaningful content
            # Look for key indicators
            for kw in ["thank", "order", "declined", "error", "invalid", "payment", "checkout"]:
                if kw in final.lower() or kw in resp[:2000].lower():
                    idx = resp.lower().find(kw)
                    if idx >= 0:
                        print(f"Found '{kw}': {resp[max(0,idx-50):idx+100]}")
            print(f"\nFirst 500 chars: {resp[:500]}")

asyncio.run(main())
