"""
check_site.py — B3 site compatibility checker
Usage: python check_site.py https://example.com
"""
import sys
import requests
import urllib3
urllib3.disable_warnings()

def check_site(url):
    url = url.rstrip("/")
    print(f"\n🔍 Checking: {url}\n")

    try:
        r = requests.get(
            f"{url}/my-account/add-payment-method/",
            timeout=15,
            verify=False,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/137.0.0.0 Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
            },
            allow_redirects=True,
        )
    except Exception as e:
        print(f"❌ Connection failed: {e}")
        return

    headers = r.headers

    # ── Cloudflare Detection ────────────────────────────
    cf_ray     = headers.get("cf-ray", "")
    cf_server  = "cloudflare" in headers.get("server", "").lower()
    cf_cache   = "cloudflare" in headers.get("cf-cache-status", "").lower()

    is_cloudflare = bool(cf_ray or cf_server or cf_cache)

    # ── JS Challenge / Bot block ────────────────────────
    is_blocked = (
        "just a moment" in r.text.lower() or
        "enable javascript" in r.text.lower() or
        "cf-browser-verification" in r.text.lower() or
        "checking your browser" in r.text.lower()
    )

    # ── Braintree Detection ─────────────────────────────
    has_braintree = (
        "wc_braintree_client_token" in r.text or
        "braintree-api.com" in r.text or
        "braintreegateway.com" in r.text or
        "wc_braintree" in r.text
    )

    # ── WooCommerce Detection ───────────────────────────
    has_woo = (
        "woocommerce" in r.text.lower() or
        "wc-add-payment-method" in r.text or
        "wp-content" in r.text
    )

    # ── Login Required ──────────────────────────────────
    redirected_to_login = "my-account/login" in r.url or "wp-login" in r.url
    needs_login = redirected_to_login or ("log in" in r.text.lower() and not has_braintree)

    # ── Print Results ───────────────────────────────────
    print(f"{'🔴 CLOUDFLARE DETECTED' if is_cloudflare else '✅ No Cloudflare'}")
    if cf_ray:
        print(f"   CF-Ray: {cf_ray}")

    print(f"{'🔴 JS CHALLENGE / BOT BLOCK' if is_blocked else '✅ No JS challenge'}")
    print(f"{'✅ Braintree Found' if has_braintree else '❌ Braintree NOT found'}")
    print(f"{'✅ WooCommerce Found' if has_woo else '❌ WooCommerce NOT found'}")
    print(f"{'⚠️  Login required (expected — create account first)' if needs_login else '✅ Page accessible'}")
    print(f"\nHTTP Status: {r.status_code}")
    print(f"Server: {headers.get('server', 'unknown')}")
    print(f"Final URL: {r.url}")

    print("\n" + "="*50)
    if is_cloudflare and is_blocked:
        print("❌ RESULT: NOT COMPATIBLE — Cloudflare JS challenge will block bot")
    elif is_cloudflare and not is_blocked:
        print("⚠️  RESULT: RISKY — Cloudflare present but no JS challenge (may work)")
    elif not is_cloudflare and has_braintree:
        print("✅ RESULT: COMPATIBLE — No Cloudflare + Braintree confirmed!")
    elif not is_cloudflare and needs_login:
        print("✅ RESULT: LIKELY COMPATIBLE — No Cloudflare, create account & get cookies")
    elif not has_woo:
        print("❌ RESULT: NOT WOOCOMMERCE — Wrong site type")
    else:
        print("⚠️  RESULT: UNKNOWN — Check manually")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python check_site.py https://example.com")
        sys.exit(1)
    check_site(sys.argv[1])
