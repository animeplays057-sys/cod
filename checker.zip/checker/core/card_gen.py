"""
core/card_gen.py — Credit card number generator from BIN
Uses Luhn algorithm to generate valid card numbers.
"""
import random
from core.validator import luhn_check


def _luhn_complete(partial: str) -> str:
    """Add Luhn check digit to a partial number."""
    digits = [int(d) for d in partial]
    # Double every second digit from right (index -1 is the check digit placeholder)
    total = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 0:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    check = (10 - (total % 10)) % 10
    return partial + str(check)


def generate_from_bin(
    bin6: str,
    month: str = "xx",
    year: str = "xxxx",
    cvv: str = "xxx",
    count: int = 10,
) -> list[str]:
    """
    Generate valid CC numbers from a BIN.

    Args:
        bin6: 6-digit BIN prefix
        month: month or 'xx' for random
        year: year or 'xxxx' for random
        cvv: CVV or 'xxx' for random
        count: how many cards to generate
    """
    cards = []
    bin6 = bin6[:6]

    # Determine card length (most are 16)
    if bin6[:2] in ["34", "37"]:
        length = 15  # Amex
    elif bin6[:4] == "6011":
        length = 16
    else:
        length = 16

    for _ in range(count):
        # Generate random digits to fill up to (length - 1) digits
        remaining = length - len(bin6) - 1
        middle = "".join([str(random.randint(0, 9)) for _ in range(remaining)])
        partial = bin6 + middle
        number = _luhn_complete(partial)

        # Generate month
        if month.lower() in ["xx", "x"]:
            m = str(random.randint(1, 12)).zfill(2)
        else:
            m = month.zfill(2)

        # Generate year
        if year.lower() in ["xxxx", "xx"]:
            y = str(random.randint(2025, 2029))
        else:
            y = year if len(year) == 4 else f"20{year}"

        # Generate CVV
        cvv_len = 4 if bin6[:2] in ["34", "37"] else 3
        if cvv.lower() in ["xxx", "xxxx", "x"]:
            c = "".join([str(random.randint(0, 9)) for _ in range(cvv_len)])
        else:
            c = cvv

        cards.append(f"{number}|{m}|{y}|{c}")

    return cards
