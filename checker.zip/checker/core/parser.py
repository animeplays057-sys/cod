"""
core/parser.py — CC string parser supporting all common formats
Supports:
  4111111111111111|12|2026|123
  4111111111111111/12/2026/123
  4111111111111111:12:2026:123
  4111 1111 1111 1111 12 26 123
"""
import re
from dataclasses import dataclass
from typing import Optional


@dataclass
class CardData:
    number: str
    month: str
    year: str
    cvv: str

    @property
    def bin(self) -> str:
        return self.number[:6]

    @property
    def last4(self) -> str:
        return self.number[-4:]

    @property
    def masked(self) -> str:
        return f"{self.bin}{'*' * (len(self.number) - 10)}{self.last4}"

    def __str__(self) -> str:
        return f"{self.number}|{self.month}|{self.year}|{self.cvv}"


# Regex: captures card|mm|yy(yy)|cvv with any separator
_CC_PATTERN = re.compile(
    r"(\d{13,19})"             # card number
    r"[\s|/:,]+"
    r"(\d{1,2})"               # month
    r"[\s|/:,]+"
    r"(\d{2,4})"               # year
    r"[\s|/:,]+"
    r"(\d{3,4})"               # cvv
)


def parse_cc(text: str) -> Optional[CardData]:
    """Parse a CC string into CardData. Returns None if invalid format."""
    text = text.strip().replace(" ", "|")
    m = _CC_PATTERN.search(text)
    if not m:
        return None

    number, month, year, cvv = m.group(1), m.group(2), m.group(3), m.group(4)

    # Normalize month: '3' → '03'
    month = month.zfill(2)

    # Normalize year: '26' → '2026'
    if len(year) == 2:
        year = f"20{year}"

    return CardData(number=number, month=month, year=year, cvv=cvv)


def parse_mass(text: str) -> list[CardData]:
    """Parse multiple CC strings from multi-line text."""
    cards = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        card = parse_cc(line)
        if card:
            cards.append(card)
    return cards
