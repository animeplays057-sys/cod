"""
core/proxy_manager.py — Proxy Pool Manager

Features:
- Proxy rotation (round-robin, fastest first)
- Test proxy via ipify.org (checks real IP change)
- aiohttp connector builder with proxy auth
- Auto-mark dead proxies on repeated failures

Formats supported:
  host:port
  host:port:user:pass
  socks5://host:port:user:pass
  http://user:pass@host:port
"""
import asyncio
import time
import logging
import itertools
from typing import Optional

import aiohttp
from aiohttp import ClientTimeout
from aiohttp_socks import ProxyConnector

logger = logging.getLogger("CC-Checker.Proxy")

TEST_URL     = "https://api.ipify.org?format=json"
TEST_TIMEOUT = ClientTimeout(total=12)

# Round-robin state
_proxy_cycle = None
_proxy_list: list[dict] = []


def _build_proxy_url(proxy: dict) -> str:
    """Build proxy URL string from dict."""
    protocol = proxy.get("protocol", "http")
    host     = proxy["host"]
    port     = proxy["port"]
    user     = proxy.get("username", "")
    pwd      = proxy.get("password", "")

    if user and pwd:
        return f"{protocol}://{user}:{pwd}@{host}:{port}"
    return f"{protocol}://{host}:{port}"


def parse_proxy_string(proxy_str: str) -> Optional[dict]:
    """
    Parse proxy from ALL common string formats:

      user:pass@host:port                  ← instantproxies style ✅
      host:port                            ← simple ✅
      host:port:user:pass                  ← legacy ✅
      http://user:pass@host:port           ← URL style ✅
      socks5://user:pass@host:port         ← SOCKS5 ✅
      socks5://host:port                   ← SOCKS5 no auth ✅
    """
    proxy_str = proxy_str.strip()
    if not proxy_str:
        return None

    protocol = "http"

    # ── URL-style (has "://") ─────────────────────────────────────────────────
    if "://" in proxy_str:
        proto_part, remainder = proxy_str.split("://", 1)
        protocol = proto_part.lower()

        # Handle host:port:user:pass format within URL scheme (no @ but has 3+ colons)
        if remainder.count(":") >= 3 and "@" not in remainder:
            parts = remainder.split(":")
            # parts[0]=host, parts[1]=port, parts[2]=user, parts[3]=pass
            remainder = f"{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}"
            if len(parts) > 4:
                remainder += ":" + ":".join(parts[4:])

        if "@" in remainder:
            creds, hostport = remainder.rsplit("@", 1)
            user, pwd = (creds.split(":", 1) + [""])[:2] if ":" in creds else (creds, "")
        else:
            user, pwd = "", ""
            hostport = remainder

        if ":" not in hostport:
            return None
        host, port_str = hostport.rsplit(":", 1)

    # ── user:pass@host:port (NO "://" — instantproxies format) ───────────────
    elif "@" in proxy_str:
        creds_part, host_part = proxy_str.rsplit("@", 1)
        # creds_part = "user:pass"
        if ":" in creds_part:
            user, pwd = creds_part.split(":", 1)
        else:
            user, pwd = creds_part, ""
        # host_part = "host:port"
        if ":" not in host_part:
            return None
        host, port_str = host_part.rsplit(":", 1)

    # ── Plain formats: host:port or host:port:user:pass ───────────────────────
    else:
        parts = proxy_str.split(":")
        if len(parts) == 2:
            host, port_str = parts
            user, pwd = "", ""
        elif len(parts) >= 4:
            host = parts[0]
            port_str = parts[1]
            user = parts[2]
            pwd = parts[3]
        elif len(parts) == 3:
            host, port_str, user = parts
            pwd = ""
        else:
            return None

    # ── Validate ──────────────────────────────────────────────────────────────
    try:
        port = int(port_str.strip())
    except (ValueError, AttributeError):
        return None

    host = host.strip()
    if not host or not (1 <= port <= 65535):
        return None

    return {
        "host":     host,
        "port":     port,
        "username": (user or "").strip(),
        "password": (pwd or "").strip(),
        "protocol": protocol,
    }



async def test_proxy(proxy: dict) -> tuple[bool, int]:
    """
    Test if proxy works by fetching ipify.org.
    Returns (is_working, latency_ms).
    """
    proxy_url = _build_proxy_url(proxy)
    protocol  = proxy.get("protocol", "http")

    start = time.monotonic()
    try:
        if "socks" in protocol:
            connector = ProxyConnector.from_url(proxy_url, ssl=False)
        else:
            connector = aiohttp.TCPConnector(ssl=False)

        async with aiohttp.ClientSession(connector=connector) as session:
            kwargs = {}
            if "http" in protocol and "socks" not in protocol:
                kwargs["proxy"] = proxy_url

            async with session.get(
                TEST_URL,
                timeout=TEST_TIMEOUT,
                **kwargs
            ) as r:
                if r.status == 200:
                    latency = int((time.monotonic() - start) * 1000)
                    return True, latency

    except Exception as e:
        logger.debug(f"Proxy test failed {proxy['host']}:{proxy['port']}: {e}")

    return False, 9999


def get_connector(proxy: dict) -> aiohttp.BaseConnector:
    """
    Build aiohttp connector for the given proxy.
    """
    proxy_url = _build_proxy_url(proxy)
    protocol  = proxy.get("protocol", "http")

    if "socks" in protocol:
        return ProxyConnector.from_url(proxy_url, ssl=False, limit=10)
    else:
        return aiohttp.TCPConnector(ssl=False, limit=10)


def get_proxy_kwargs(proxy: dict) -> dict:
    """
    Return extra kwargs to pass to aiohttp session.get()/post() for HTTP proxies.
    For SOCKS proxies, the connector handles routing (no extra kwargs needed).
    """
    protocol = proxy.get("protocol", "http")
    if "socks" in protocol:
        return {}
    return {"proxy": _build_proxy_url(proxy)}


async def refresh_proxy_pool():
    """Reload working proxies from DB into memory cache."""
    global _proxy_cycle, _proxy_list
    import database.db as db
    _proxy_list = await db.get_working_proxies()
    if _proxy_list:
        _proxy_cycle = itertools.cycle(_proxy_list)
        logger.info(f"Proxy pool loaded: {len(_proxy_list)} proxies")
    else:
        _proxy_cycle = None
        logger.info("No working proxies in pool")


def get_next_proxy() -> Optional[dict]:
    """Get next proxy from round-robin pool. Returns None if no proxies."""
    global _proxy_cycle
    if not _proxy_cycle:
        return None
    try:
        return next(_proxy_cycle)
    except StopIteration:
        return None


async def add_and_test_proxy(
    proxy_str: str,
    added_by: int = 0,
) -> tuple[bool, str, dict | None]:
    """
    Parse, test, and add proxy to DB.
    Returns (success, message, proxy_dict).
    """
    import database.db as db

    proxy = parse_proxy_string(proxy_str)
    if not proxy:
        return False, "❌ Invalid proxy format", None

    # Test the proxy
    logger.info(f"Testing proxy {proxy['host']}:{proxy['port']}...")
    working, latency = await test_proxy(proxy)

    if not working:
        return False, f"❌ Proxy dead — `{proxy['host']}:{proxy['port']}` timeout/refused", None

    # Save to DB
    pid = await db.add_proxy(
        host=proxy["host"],
        port=proxy["port"],
        username=proxy.get("username", ""),
        password=proxy.get("password", ""),
        protocol=proxy.get("protocol", "http"),
        latency_ms=latency,
        added_by=added_by,
    )
    await refresh_proxy_pool()

    msg = (
        f"✅ Proxy added!\n"
        f"🌐 `{proxy['host']}:{proxy['port']}`\n"
        f"🔌 Protocol: `{proxy['protocol']}`\n"
        f"⚡ Latency: `{latency}ms`\n"
        f"🆔 ID: `{pid}`"
    )
    return True, msg, proxy


def get_random_proxy() -> Optional[str]:
    """Get next proxy from round-robin pool formatted as a URL string."""
    proxy = get_next_proxy()
    if not proxy:
        return None
    return _build_proxy_url(proxy)

