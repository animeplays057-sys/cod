"""
core/queue_manager.py — Async check queue with rate limiting and concurrency control
"""
import asyncio
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Callable, Awaitable

from gateways.base import GatewayResult, CCStatus
from gateways.router import route_and_check
from core.parser import CardData
from core.validator import validate_card
import config


@dataclass
class CheckJob:
    card: CardData
    user_id: int
    callback: Callable[[GatewayResult], Awaitable[None]]


class RateLimiter:
    """Token bucket rate limiter per user."""

    def __init__(self, limit: int, window: int = 60):
        self.limit = limit
        self.window = window
        self._user_times: dict[int, deque] = defaultdict(deque)

    def is_allowed(self, user_id: int) -> tuple[bool, int]:
        """Returns (allowed, seconds_to_wait)."""
        now = time.monotonic()
        q = self._user_times[user_id]
        # Remove old entries
        while q and now - q[0] > self.window:
            q.popleft()

        if len(q) >= self.limit:
            wait = int(self.window - (now - q[0])) + 1
            return False, wait

        q.append(now)
        return True, 0


class CheckQueue:
    """Global async queue for CC checks."""

    def __init__(self):
        self._queue: asyncio.Queue[CheckJob] = asyncio.Queue()
        self._semaphore = asyncio.Semaphore(config.MAX_CONCURRENT)
        self._rate_limiter = RateLimiter(config.RATE_LIMIT)
        self._stats = {"total": 0, "live": 0, "dead": 0, "errors": 0}
        self._running = False

    async def add(self, card: CardData, user_id: int, callback) -> tuple[bool, str]:
        """Add a card to the check queue. Returns (success, error_message)."""
        # Rate limit check
        allowed, wait = self._rate_limiter.is_allowed(user_id)
        if not allowed:
            return False, f"⏳ Rate limit hit! Wait {wait}s before next check."

        # Basic validation before queuing
        valid, reason = validate_card(card.number, card.month, card.year, card.cvv)
        if not valid:
            result = GatewayResult(
                status=CCStatus.INVALID,
                gateway="Validator",
                message=reason,
                raw_code="local_validation",
            )
            await callback(result)
            return True, ""

        job = CheckJob(card=card, user_id=user_id, callback=callback)
        await self._queue.put(job)
        return True, ""

    async def start(self):
        """Start the worker loop."""
        self._running = True
        while self._running:
            try:
                job = await asyncio.wait_for(self._queue.get(), timeout=1.0)
                asyncio.create_task(self._process(job))
            except asyncio.TimeoutError:
                continue
            except Exception:
                continue

    async def _process(self, job: CheckJob):
        """Process a single CC check job."""
        async with self._semaphore:
            try:
                result = await route_and_check(job.card)
                self._stats["total"] += 1
                if result.is_live:
                    self._stats["live"] += 1
                elif result.status == CCStatus.ERROR:
                    self._stats["errors"] += 1
                else:
                    self._stats["dead"] += 1

                await job.callback(result)
            except Exception as e:
                self._stats["errors"] += 1
                error_result = GatewayResult(
                    status=CCStatus.ERROR,
                    gateway="Queue",
                    message=f"Processing error: {e}",
                    raw_code="queue_error",
                )
                try:
                    await job.callback(error_result)
                except Exception:
                    pass
            finally:
                self._queue.task_done()

    def get_stats(self) -> dict:
        return dict(self._stats)

    def stop(self):
        self._running = False


# Global instance
check_queue = CheckQueue()
