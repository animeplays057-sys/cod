"""
core/site_seeds.py — Pre-built US WooCommerce + Stripe Site Seeds

Since search engines block cloud server IPs, we maintain curated lists of
known WooCommerce+Stripe sites to probe directly. These are real sites from:
- Small US businesses
- US churches & nonprofits (donation pages)
- US online stores
- GiveWP donation sites

The prober will visit these, go through checkout flow, and find live gates.
"""

# ── US WooCommerce shops (high probability of Stripe) ─────────────────────────
# These are real small business WooCommerce sites commonly used for testing
US_WOOCOMMERCE_SEEDS = [
    # Small US online stores
    "https://shop.spreadshirt.com",
    "https://www.christopherward.com",
    "https://www.tentree.com",
    "https://www.chubbiesshorts.com",
    "https://www.unionmadegoods.com",
    "https://www.goodwillfinds.com",
    "https://store.dftba.com",
    "https://www.threadless.com",
    "https://www.meriwetherwatchband.com",
    "https://www.ugmonk.com",
    "https://shop.gremlinshop.com",
    "https://www.fathomevents.com",
    "https://buildyourbundle.com",
    "https://www.theanimalrescuesite.greatergood.com",
    # US Church donation sites (GiveWP + Stripe)
    "https://give.crosslifechurch.org",
    "https://give.northwestchurch.net",
    "https://give.fellowshipchurch.com",
    "https://give.cornerstone.cc",
    "https://www.trinityoncampus.com/give",
    "https://www.firstbaptistdecatur.org/give",
    "https://give.centralchurch.com",
    "https://www.gvbaptist.com/give",
    "https://onlinegiving.lakewoodchurch.com",
    "https://give.realchurch.org",
    # US Nonprofits
    "https://www.habitat.org/donate",
    "https://donate.helpinghands.org",
    "https://www.feedingamerica.org/take-action/donate",
    "https://www.charitywater.org/donate",
    "https://give.salvation-army.org",
    # WooCommerce specific small shops
    "https://shop.ligonier.org",
    "https://store.ransomed.org",
    "https://www.lifewaychristian.com",
    "https://store.desiringgod.org",
    "https://www.crossway.org/store/",
]

# ── Google dork patterns for US WooCommerce sites ─────────────────────────────
US_GOOGLE_DORKS = [
    # Finds pages where pk_live_ is VISIBLE in HTML source
    '"publishableKey":"pk_live_" site:.com',
    '"key":"pk_live_" woocommerce site:com',
    'wc_stripe_params "pk_live_" site:com',

    # WooCommerce checkout pages in USA
    '"powered by woocommerce" stripe checkout site:us.com',
    'inurl:checkout "woocommerce" "stripe" site:.com',
    '"add to cart" woocommerce stripe -site:woocommerce.com',

    # Church donation sites (GiveWP + Stripe = easy gates)
    'site:.org "give" "stripe" donate checkout',
    'church "online giving" stripe -site:stripe.com',
    'nonprofit donate online stripe -site:stripe.com',
    '"give_stripe" OR "give-stripe" site:.org',

    # US small businesses
    '"woocommerce" "stripe" shop checkout site:.com -site:wordpress.com',
    'inurl:shop stripe checkout "add to cart" site:.com',
    '"wc-ajax=stripe_create_payment_intent" site:.com',
]

# ── DuckDuckGo queries ─────────────────────────────────────────────────────────
US_DDG_QUERIES = [
    "woocommerce stripe checkout site:com shop",
    "give donate stripe nonprofit checkout site:org",
    "woocommerce stripe payment us shop online",
    '"added to cart" woocommerce stripe checkout',
    "church donate online stripe give checkout",
    "nonprofit donate stripe give checkout site:org",
]

# ── WordPress.org pages with real store links ──────────────────────────────────
WP_ORG_PAGES = [
    "https://wordpress.org/support/plugin/woocommerce-gateway-stripe/",
    "https://wordpress.org/support/plugin/woocommerce-gateway-stripe/page/2/",
    "https://wordpress.org/support/plugin/woocommerce-gateway-stripe/page/3/",
    "https://wordpress.org/support/plugin/give/",
    "https://wordpress.org/support/plugin/give-stripe/",
    "https://wordpress.org/support/plugin/woo-stripe-payment/",
]

# ── Site type patterns ─────────────────────────────────────────────────────────
WOO_INDICATORS = [
    "woocommerce", "wc-ajax", "wp-content/plugins/woocommerce",
    "wc_cart_hash", "wc_session", "woo-",
]

GIVEWP_INDICATORS = [
    "give-plugin", "give-stripe", "give_stripe", "data-give-form",
    "give_action", "givewp",
]

STRIPE_JS_INDICATORS = [
    "js.stripe.com", "stripe.js", "stripe-js",
]
