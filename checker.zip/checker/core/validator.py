"""
core/validator.py — Luhn algorithm + card validation
"""
from datetime import datetime


def luhn_check(number: str) -> bool:
    """Validate card number using Luhn algorithm."""
    digits = [int(d) for d in number if d.isdigit()]
    if len(digits) < 13:
        return False
    total = 0
    reverse = digits[::-1]
    for i, d in enumerate(reverse):
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def validate_expiry(month: str, year: str) -> tuple[bool, str]:
    """Check if card is expired. Returns (valid, reason)."""
    try:
        m, y = int(month), int(year)
        exp = datetime(y, m, 1)
        now = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        if exp < now:
            return False, "Card Expired"
        return True, ""
    except (ValueError, OverflowError):
        return False, "Invalid Expiry"


def detect_card_brand(number: str) -> str:
    """Detect card network from BIN."""
    n = number.replace(" ", "")
    if n.startswith("4"):
        return "Visa"
    elif n[:2] in [str(i) for i in range(51, 56)] or n[:4] in ["2221", "2720"]:
        return "Mastercard"
    elif n[:2] in ["34", "37"]:
        return "Amex"
    elif n[:4] in ["6011", "6221", "6440", "6450", "6500"]:
        return "Discover"
    elif n[:4] in ["3528", "3589"] or n[:2] == "35":
        return "JCB"
    elif n[:4] == "6304" or n[:2] in ["36", "38"]:
        return "Diners"
    elif n[:4] in ["6759", "6761", "6762", "6763"]:
        return "Maestro"
    elif n[:4] in ["6304"]:
        return "Solo"
    return "Unknown"


def validate_card(number: str, month: str, year: str, cvv: str) -> tuple[bool, str]:
    """Full card validation. Returns (valid, error_message)."""
    # Length check
    clean = number.replace(" ", "")
    if not clean.isdigit() or len(clean) < 13 or len(clean) > 19:
        return False, "Invalid card number length"

    # Luhn
    if not luhn_check(clean):
        return False, "Failed Luhn check (invalid card number)"

    # Expiry
    valid, reason = validate_expiry(month, year)
    if not valid:
        return False, reason

    # CVV length
    brand = detect_card_brand(clean)
    expected_cvv_len = 4 if brand == "Amex" else 3
    if not cvv.isdigit() or len(cvv) not in [3, 4]:
        return False, "Invalid CVV"

    return True, ""
