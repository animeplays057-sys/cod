"""
database/db.py — SQLite/Turso database manager

Local run: Uses SQLite file (database/checker.db)
Render/Cloud: Uses Turso (libsql) cloud database if TURSO_URL + TURSO_TOKEN set

Turso FREE tier:
  - 500MB storage
  - Unlimited reads
  - Data persists across deploys!

Setup:
  1. turso.tech pe free account banao
  2. Database create karo
  3. TURSO_URL aur TURSO_TOKEN .env mein daalo
"""
import json
import logging
import os
from typing import Optional
import config

logger = logging.getLogger("CC-Checker.DB")

# ── Detect DB mode ─────────────────────────────────────────────────────────────
_raw_turso_url  = os.getenv("TURSO_URL", "")
TURSO_TOKEN     = os.getenv("TURSO_TOKEN", "")

# libsql:// → https:// (aiohttp needs https for HTTP API calls)
if _raw_turso_url.startswith("libsql://"):
    TURSO_URL = "https://" + _raw_turso_url[len("libsql://"):]
elif _raw_turso_url.startswith("http"):
    TURSO_URL = _raw_turso_url
else:
    TURSO_URL = ""

USE_TURSO = bool(TURSO_URL and TURSO_TOKEN)

if USE_TURSO:
    logger.info("Using Turso cloud database")
else:
    logger.info(f"Using local SQLite: {config.DB_PATH}")


# ── CREATE TABLES SQL ──────────────────────────────────────────────────────────
INIT_SQL = """
CREATE TABLE IF NOT EXISTS users (
    user_id     INTEGER PRIMARY KEY,
    username    TEXT,
    first_name  TEXT,
    checks_today INTEGER DEFAULT 0,
    total_checks INTEGER DEFAULT 0,
    joined_at   TEXT DEFAULT CURRENT_TIMESTAMP,
    last_active TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS checks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER,
    card_number TEXT,
    card_bin    TEXT,
    status      TEXT,
    gateway     TEXT,
    is_vbv      INTEGER DEFAULT 0,
    message     TEXT,
    checked_at  TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bin_cache (
    bin       TEXT PRIMARY KEY,
    data      TEXT,
    cached_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS scraped_gates (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    domain          TEXT NOT NULL,
    pk_key          TEXT NOT NULL,
    endpoint        TEXT NOT NULL,
    method          TEXT DEFAULT 'POST',
    intent_type     TEXT DEFAULT 'payment_intent',
    payload_template TEXT DEFAULT '{}',
    is_active       INTEGER DEFAULT 1,
    success_count   INTEGER DEFAULT 0,
    fail_count      INTEGER DEFAULT 0,
    added_by        INTEGER DEFAULT 0,
    added_at        TEXT DEFAULT CURRENT_TIMESTAMP,
    last_checked    TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(domain, endpoint)
);

CREATE TABLE IF NOT EXISTS proxies (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    host        TEXT NOT NULL,
    port        INTEGER NOT NULL,
    username    TEXT DEFAULT '',
    password    TEXT DEFAULT '',
    protocol    TEXT DEFAULT 'http',
    is_active   INTEGER DEFAULT 1,
    is_working  INTEGER DEFAULT 1,
    latency_ms  INTEGER DEFAULT 9999,
    fail_count  INTEGER DEFAULT 0,
    added_by    INTEGER DEFAULT 0,
    added_at    TEXT DEFAULT CURRENT_TIMESTAMP,
    last_tested TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(host, port)
);

CREATE TABLE IF NOT EXISTS shopify_gates (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    base_url        TEXT NOT NULL UNIQUE,
    shop_domain     TEXT DEFAULT '',
    shop_id         TEXT DEFAULT '',
    variant_id      INTEGER NOT NULL,
    product_title   TEXT DEFAULT '',
    price           TEXT NOT NULL,
    currency        TEXT DEFAULT 'USD',
    checkout_type   TEXT DEFAULT 'one-page',
    is_active       INTEGER DEFAULT 1,
    success_count   INTEGER DEFAULT 0,
    fail_count      INTEGER DEFAULT 0,
    added_by        INTEGER DEFAULT 0,
    added_at        TEXT DEFAULT CURRENT_TIMESTAMP,
    last_checked    TEXT DEFAULT CURRENT_TIMESTAMP,
    scan_data       TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS b3_config (
    id          INTEGER PRIMARY KEY DEFAULT 1,
    site_url    TEXT NOT NULL DEFAULT '',
    updated_at  TEXT DEFAULT CURRENT_TIMESTAMP,
    total_checked INTEGER DEFAULT 0,
    total_live    INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS b3_cookies (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    pair_id     TEXT NOT NULL,
    cookie1     TEXT NOT NULL,
    cookie2     TEXT NOT NULL,
    is_active   INTEGER DEFAULT 1,
    added_at    TEXT DEFAULT CURRENT_TIMESTAMP,
    last_used   TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(pair_id)
);
"""


# ── Connection helper ──────────────────────────────────────────────────────────
class _DB:
    """Unified DB connection — works with both SQLite and Turso."""
    _session = None

    async def _get_session(self):
        import aiohttp
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                connector=aiohttp.TCPConnector(ssl=False, limit=30, ttl_dns_cache=300),
                timeout=aiohttp.ClientTimeout(total=10)
            )
        return self._session

    async def execute(self, sql: str, params: tuple = ()):
        """Execute a single statement."""
        if USE_TURSO:
            return await self._turso_exec(sql, params)
        else:
            return await self._sqlite_exec(sql, params)

    async def executemany(self, sql: str, params_list: list):
        for p in params_list:
            await self.execute(sql, p)

    async def fetchone(self, sql: str, params: tuple = ()) -> Optional[tuple]:
        if USE_TURSO:
            rows = await self._turso_query(sql, params)
            return rows[0] if rows else None
        else:
            return await self._sqlite_fetchone(sql, params)

    async def fetchall(self, sql: str, params: tuple = ()) -> list:
        if USE_TURSO:
            return await self._turso_query(sql, params)
        else:
            return await self._sqlite_fetchall(sql, params)

    # ── Turso (libsql HTTP API) ────────────────────────────────────────────────
    async def _turso_exec(self, sql: str, params: tuple = ()):
        url = f"{TURSO_URL}/v2/pipeline"
        headers = {
            "Authorization": f"Bearer {TURSO_TOKEN}",
            "Content-Type": "application/json",
        }
        stmt = {"type": "execute", "stmt": {"sql": sql, "args": [{"type": "text", "value": str(p)} for p in params]}}
        payload = {"requests": [stmt, {"type": "close"}]}
        session = await self._get_session()
        async with session.post(url, json=payload, headers=headers) as r:
            return await r.json()

    async def _turso_query(self, sql: str, params: tuple = ()) -> list:
        url = f"{TURSO_URL}/v2/pipeline"
        headers = {
            "Authorization": f"Bearer {TURSO_TOKEN}",
            "Content-Type": "application/json",
        }
        stmt = {"type": "execute", "stmt": {"sql": sql, "args": [{"type": "text", "value": str(p)} for p in params]}}
        payload = {"requests": [stmt, {"type": "close"}]}
        session = await self._get_session()
        async with session.post(url, json=payload, headers=headers) as r:
            data = await r.json()
        try:
            result = data["results"][0]["response"]["result"]
            cols = [c["name"] for c in result["cols"]]
            rows = []
            for row in result["rows"]:
                rows.append(tuple(v.get("value") for v in row))
            return rows
        except Exception as e:
            logger.debug(f"Turso query error: {e} | data={data}")
            return []

    # ── SQLite (local) ─────────────────────────────────────────────────────────
    async def _sqlite_exec(self, sql: str, params: tuple = ()):
        import aiosqlite
        async with aiosqlite.connect(config.DB_PATH) as db:
            await db.execute(sql, params)
            await db.commit()

    async def _sqlite_fetchone(self, sql: str, params: tuple = ()) -> Optional[tuple]:
        import aiosqlite
        async with aiosqlite.connect(config.DB_PATH) as db:
            async with db.execute(sql, params) as cur:
                return await cur.fetchone()

    async def _sqlite_fetchall(self, sql: str, params: tuple = ()) -> list:
        import aiosqlite
        async with aiosqlite.connect(config.DB_PATH) as db:
            async with db.execute(sql, params) as cur:
                return await cur.fetchall()


_db = _DB()


# ── Init ───────────────────────────────────────────────────────────────────────
async def init_db():
    """Create all tables on first run."""
    if not USE_TURSO:
        import os as _os
        _os.makedirs(_os.path.dirname(config.DB_PATH), exist_ok=True)

    for stmt in INIT_SQL.strip().split(";"):
        stmt = stmt.strip()
        if stmt:
            try:
                await _db.execute(stmt)
            except Exception as e:
                logger.debug(f"Init SQL skipped: {e}")


# ── User functions ─────────────────────────────────────────────────────────────

async def upsert_user(user_id: int, username: str, first_name: str):
    await _db.execute("""
        INSERT INTO users (user_id, username, first_name)
        VALUES (?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            username=excluded.username,
            first_name=excluded.first_name,
            last_active=CURRENT_TIMESTAMP
    """, (user_id, username, first_name))


async def increment_check_count(user_id: int):
    await _db.execute("""
        UPDATE users SET
            checks_today = checks_today + 1,
            total_checks = total_checks + 1,
            last_active = CURRENT_TIMESTAMP
        WHERE user_id = ?
    """, (user_id,))


async def log_check(user_id: int, card_number: str, card_bin: str,
                    status: str, gateway: str, is_vbv: bool, message: str):
    await _db.execute("""
        INSERT INTO checks (user_id, card_number, card_bin, status, gateway, is_vbv, message)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (user_id, card_number[-4:], card_bin, status, gateway, int(is_vbv), message))


async def get_user_stats(user_id: int) -> dict:
    row = await _db.fetchone(
        "SELECT checks_today, total_checks, joined_at FROM users WHERE user_id = ?",
        (user_id,)
    )
    if row:
        return {"today": row[0], "total": row[1], "joined": row[2]}
    return {"today": 0, "total": 0, "joined": "Unknown"}


async def get_global_stats() -> dict:
    r1 = await _db.fetchone("SELECT COUNT(*) FROM users")
    r2 = await _db.fetchone("SELECT COUNT(*) FROM checks")
    r3 = await _db.fetchone("SELECT COUNT(*) FROM checks WHERE status IN ('CHARGED','LIVE_VBV','LIVE_3DS')")
    r4 = await _db.fetchone("SELECT COUNT(*) FROM checks WHERE status = 'DEAD'")
    return {
        "users":        int(r1[0]) if r1 else 0,
        "total_checks": int(r2[0]) if r2 else 0,
        "live":         int(r3[0]) if r3 else 0,
        "dead":         int(r4[0]) if r4 else 0,
    }


# ── Scraped Gates CRUD ─────────────────────────────────────────────────────────

async def add_gate(
    domain: str,
    pk_key: str,
    endpoint: str,
    method: str = "POST",
    intent_type: str = "payment_intent",
    payload_template: dict = None,
    added_by: int = 0,
) -> int:
    """Add or update a scraped gate. Returns gate ID."""
    payload_json = json.dumps(payload_template or {})
    await _db.execute("""
        INSERT INTO scraped_gates (domain, pk_key, endpoint, method, intent_type, payload_template, added_by)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(domain, endpoint) DO UPDATE SET
            pk_key=excluded.pk_key,
            method=excluded.method,
            intent_type=excluded.intent_type,
            payload_template=excluded.payload_template,
            is_active=1,
            last_checked=CURRENT_TIMESTAMP
    """, (domain, pk_key, endpoint, method, intent_type, payload_json, added_by))
    row = await _db.fetchone(
        "SELECT id FROM scraped_gates WHERE domain=? AND endpoint=?", (domain, endpoint)
    )
    return int(row[0]) if row else 0


async def get_active_gates() -> list[dict]:
    """Get all active scraped gates ordered by success rate."""
    rows = await _db.fetchall("""
        SELECT id, domain, pk_key, endpoint, method, intent_type, payload_template,
               success_count, fail_count, added_at
        FROM scraped_gates
        WHERE is_active = 1
        ORDER BY success_count DESC, added_at DESC
    """)
    gates = []
    for row in rows:
        try:
            pt = json.loads(row[6] or "{}")
        except Exception:
            pt = {}
        gates.append({
            "id":               int(row[0]),
            "domain":           row[1],
            "pk_key":           row[2],
            "endpoint":         row[3],
            "method":           row[4],
            "intent_type":      row[5],
            "payload_template": pt,
            "success_count":    int(row[7] or 0),
            "fail_count":       int(row[8] or 0),
            "added_at":         row[9],
        })
    return gates


async def get_all_gates_count() -> int:
    row = await _db.fetchone("SELECT COUNT(*) FROM scraped_gates WHERE is_active=1")
    return int(row[0]) if row else 0


async def update_gate_stats(gate_id: int, success: bool):
    col = "success_count" if success else "fail_count"
    await _db.execute(f"""
        UPDATE scraped_gates SET {col} = {col} + 1, last_checked = CURRENT_TIMESTAMP
        WHERE id = ?
    """, (gate_id,))


async def disable_gate(gate_id: int):
    await _db.execute("UPDATE scraped_gates SET is_active=0 WHERE id=?", (gate_id,))


async def clear_all_gates():
    await _db.execute("DELETE FROM scraped_gates")


# ── Proxy CRUD ─────────────────────────────────────────────────────────────────

async def add_proxy(
    host: str, port: int,
    username: str = "", password: str = "",
    protocol: str = "http",
    latency_ms: int = 9999,
    added_by: int = 0,
) -> int:
    """Add or update a proxy. Returns proxy ID."""
    await _db.execute("""
        INSERT INTO proxies (host, port, username, password, protocol, latency_ms, added_by)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(host, port) DO UPDATE SET
            username=excluded.username,
            password=excluded.password,
            protocol=excluded.protocol,
            latency_ms=excluded.latency_ms,
            is_active=1,
            is_working=1,
            last_tested=CURRENT_TIMESTAMP
    """, (host, port, username, password, protocol, latency_ms, added_by))
    row = await _db.fetchone("SELECT id FROM proxies WHERE host=? AND port=?", (host, port))
    return int(row[0]) if row else 0


async def get_working_proxies() -> list[dict]:
    """Get all working proxies sorted by latency."""
    rows = await _db.fetchall("""
        SELECT id, host, port, username, password, protocol, latency_ms, added_at
        FROM proxies
        WHERE is_active=1 AND is_working=1
        ORDER BY latency_ms ASC
    """)
    proxies = []
    for row in rows:
        proxies.append({
            "id":       int(row[0]),
            "host":     row[1],
            "port":     int(row[2]),
            "username": row[3] or "",
            "password": row[4] or "",
            "protocol": row[5] or "http",
            "latency":  int(row[6] or 9999),
            "added_at": row[7],
        })
    return proxies


async def get_all_proxies() -> list[dict]:
    """Get all proxies (including dead ones)."""
    rows = await _db.fetchall("""
        SELECT id, host, port, username, password, protocol,
               is_active, is_working, latency_ms, fail_count, added_at, last_tested
        FROM proxies ORDER BY latency_ms ASC
    """)
    proxies = []
    for row in rows:
        proxies.append({
            "id":         int(row[0]),
            "host":       row[1],
            "port":       int(row[2]),
            "username":   row[3] or "",
            "password":   row[4] or "",
            "protocol":   row[5] or "http",
            "is_active":  bool(row[6]),
            "is_working": bool(row[7]),
            "latency":    int(row[8] or 9999),
            "fail_count": int(row[9] or 0),
            "added_at":   row[10],
            "last_tested": row[11],
        })
    return proxies


async def get_proxy_by_id(proxy_id: int) -> dict | None:
    """Get a single proxy by ID."""
    row = await _db.fetchone("""
        SELECT id, host, port, username, password, protocol,
               is_active, is_working, latency_ms, fail_count
        FROM proxies WHERE id=?
    """, (proxy_id,))
    if not row:
        return None
    return {
        "id":         int(row[0]),
        "host":       row[1],
        "port":       int(row[2]),
        "username":   row[3] or "",
        "password":   row[4] or "",
        "protocol":   row[5] or "http",
        "is_active":  bool(row[6]),
        "is_working": bool(row[7]),
        "latency":    int(row[8] or 9999),
        "fail_count": int(row[9] or 0),
    }


async def update_proxy_result(proxy_id: int, working: bool, latency_ms: int = 9999):
    """Update proxy test result."""
    if working:
        await _db.execute("""
            UPDATE proxies SET is_working=1, latency_ms=?, fail_count=0,
                               last_tested=CURRENT_TIMESTAMP
            WHERE id=?
        """, (latency_ms, proxy_id))
    else:
        await _db.execute("""
            UPDATE proxies SET is_working=0, fail_count=fail_count+1,
                               last_tested=CURRENT_TIMESTAMP
            WHERE id=?
        """, (proxy_id,))


async def delete_proxy(proxy_id: int):
    await _db.execute("DELETE FROM proxies WHERE id=?", (proxy_id,))


async def clear_dead_proxies():
    await _db.execute("DELETE FROM proxies WHERE is_working=0")


async def get_proxies_count() -> dict:
    total = await _db.fetchone("SELECT COUNT(*) FROM proxies WHERE is_active=1")
    working = await _db.fetchone("SELECT COUNT(*) FROM proxies WHERE is_active=1 AND is_working=1")
    return {
        "total":   int(total[0]) if total else 0,
        "working": int(working[0]) if working else 0,
    }


# ── Shopify Gates CRUD ─────────────────────────────────────────────────────────

async def add_shopify_gate(
    base_url: str,
    variant_id: int,
    price: str,
    product_title: str = "",
    shop_domain: str = "",
    shop_id: str = "",
    currency: str = "USD",
    checkout_type: str = "one-page",
    added_by: int = 0,
    scan_data: dict = None,
) -> int:
    """Add or update a Shopify gate. Returns gate ID."""
    scan_json = json.dumps(scan_data or {})
    await _db.execute("""
        INSERT INTO shopify_gates
            (base_url, shop_domain, shop_id, variant_id, product_title,
             price, currency, checkout_type, added_by, scan_data)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(base_url) DO UPDATE SET
            shop_domain=excluded.shop_domain,
            shop_id=excluded.shop_id,
            variant_id=excluded.variant_id,
            product_title=excluded.product_title,
            price=excluded.price,
            currency=excluded.currency,
            checkout_type=excluded.checkout_type,
            is_active=1,
            scan_data=excluded.scan_data,
            last_checked=CURRENT_TIMESTAMP
    """, (base_url, shop_domain, shop_id, variant_id, product_title,
           price, currency, checkout_type, added_by, scan_json))
    row = await _db.fetchone("SELECT id FROM shopify_gates WHERE base_url=?", (base_url,))
    return int(row[0]) if row else 0


async def get_active_shopify_gates(limit: int = 50) -> list[dict]:
    """Get active Shopify gates ordered by success rate."""
    rows = await _db.fetchall("""
        SELECT id, base_url, shop_domain, variant_id, product_title,
               price, currency, checkout_type, success_count, fail_count,
               added_by, added_at, last_checked, scan_data
        FROM shopify_gates
        WHERE is_active=1
        ORDER BY success_count DESC, added_at DESC
        LIMIT ?
    """, (limit,))
    gates = []
    for r in rows:
        # Parse scan_data JSON
        raw_sd = r[13]
        try:
            import json as _json
            sd = _json.loads(raw_sd) if raw_sd else {}
        except Exception:
            sd = {}
        gates.append({
            "id":            int(r[0]),
            "base_url":      r[1],
            "shop_domain":   r[2] or "",
            "variant_id":    int(r[3]),
            "product_title": r[4] or "",
            "price":         r[5],
            "currency":      r[6] or "USD",
            "checkout_type": r[7] or "one-page",
            "success_count": int(r[8] or 0),
            "fail_count":    int(r[9] or 0),
            "added_by":      int(r[10] or 0),
            "added_at":      r[11],
            "last_checked":  r[12],
            "scan_data":     sd,
        })
    return gates



async def get_shopify_gates_count() -> dict:
    total   = await _db.fetchone("SELECT COUNT(*) FROM shopify_gates WHERE is_active=1")
    return {"total": int(total[0]) if total else 0}


async def update_shopify_gate_stats(gate_id: int, success: bool):
    """
    Update Shopify gate success/fail stats.
    
    IMPORTANT: Only call this for CARD-LEVEL results (declined/approved),
    NOT for infra errors (no_delivery, throttled, cart_error, etc.).
    Auto-disable threshold is HIGH (500) to prevent concurrent workers
    from killing good stores during mass checks.
    """
    if success:
        await _db.execute("""
            UPDATE shopify_gates
            SET success_count=success_count+1, fail_count=0, last_checked=CURRENT_TIMESTAMP
            WHERE id=?
        """, (gate_id,))
    else:
        # Increment fail_count
        await _db.execute("""
            UPDATE shopify_gates
            SET fail_count=fail_count+1, last_checked=CURRENT_TIMESTAMP
            WHERE id=?
        """, (gate_id,))
        # Auto-disable only after MANY consecutive card-level failures
        # High threshold (500) prevents concurrent workers from disabling stores
        # during mass checks due to temporary Shopify rate-limiting
        row = await _db.fetchone("SELECT success_count, fail_count, base_url, is_active FROM shopify_gates WHERE id=?", (gate_id,))
        if row:
            success_count, fail_count, base_url, is_active = int(row[0] or 0), int(row[1] or 0), row[2], int(row[3] or 0)
            if fail_count >= 500 and is_active == 1:
                await _db.execute("UPDATE shopify_gates SET is_active=0 WHERE id=?", (gate_id,))
                logger.info(f"🚫 Disabled dead Shopify gate {base_url} (ID: {gate_id}) due to {fail_count} consecutive card-level failures.")


async def disable_shopify_gate(gate_id: int):
    await _db.execute("UPDATE shopify_gates SET is_active=0 WHERE id=?", (gate_id,))


async def delete_shopify_gate(base_url: str):
    await _db.execute("DELETE FROM shopify_gates WHERE base_url=?", (base_url,))


# ── B3 WooCommerce Braintree Gate ──────────────────────────────────────────────

async def b3_set_site(site_url: str):
    """Set or update the B3 target site URL."""
    await _db.execute("""
        INSERT INTO b3_config (id, site_url, updated_at)
        VALUES (1, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(id) DO UPDATE SET
            site_url=excluded.site_url,
            updated_at=CURRENT_TIMESTAMP
    """, (site_url.rstrip("/"),))


async def b3_get_config() -> dict | None:
    """Get current B3 config."""
    row = await _db.fetchone(
        "SELECT site_url, updated_at, total_checked, total_live FROM b3_config WHERE id=1"
    )
    if not row:
        return None
    return {
        "site_url":      row[0],
        "updated_at":    row[1],
        "total_checked": int(row[2] or 0),
        "total_live":    int(row[3] or 0),
    }


async def b3_add_cookie_pair(pair_id: str, cookie1: str, cookie2: str):
    """Add or replace a cookie pair."""
    await _db.execute("""
        INSERT INTO b3_cookies (pair_id, cookie1, cookie2, added_at, last_used)
        VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ON CONFLICT(pair_id) DO UPDATE SET
            cookie1=excluded.cookie1,
            cookie2=excluded.cookie2,
            is_active=1,
            added_at=CURRENT_TIMESTAMP
    """, (pair_id, cookie1, cookie2))


async def b3_get_active_pairs() -> list[dict]:
    """Get all active cookie pairs."""
    rows = await _db.fetchall(
        "SELECT id, pair_id, cookie1, cookie2, added_at, last_used FROM b3_cookies WHERE is_active=1"
    )
    return [
        {
            "id":       r[0],
            "pair_id":  r[1],
            "cookie1":  r[2],
            "cookie2":  r[3],
            "added_at": r[4],
            "last_used": r[5],
        }
        for r in rows
    ]


async def b3_delete_pair(pair_id: str):
    """Delete a cookie pair by pair_id."""
    await _db.execute("DELETE FROM b3_cookies WHERE pair_id=?", (pair_id,))


async def b3_mark_pair_used(pair_id: str):
    """Update last_used timestamp for a pair."""
    await _db.execute(
        "UPDATE b3_cookies SET last_used=CURRENT_TIMESTAMP WHERE pair_id=?",
        (pair_id,)
    )


async def b3_increment_stats(live: bool):
    """Track checked/live counts."""
    await _db.execute("""
        UPDATE b3_config SET
            total_checked = total_checked + 1,
            total_live    = total_live + ?
        WHERE id = 1
    """, (1 if live else 0,))


async def b3_is_configured() -> bool:
    """True if B3 has a site URL + at least one active cookie pair."""
    cfg = await b3_get_config()
    if not cfg or not cfg.get("site_url"):
        return False
    pairs = await b3_get_active_pairs()
    return len(pairs) > 0
