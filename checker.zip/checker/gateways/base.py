"""
gateways/base.py — Base result dataclass for all gateways
"""
from dataclasses import dataclass, field
from enum import Enum


class CCStatus(str, Enum):
    CHARGED        = "CHARGED"          # ✅ Live, non-VBV, auth success
    LIVE_VBV       = "LIVE_VBV"         # 🔐 Live, VBV/3DS required
    LIVE_3DS       = "LIVE_3DS"         # 🔐 Live, 3DS required (same as VBV)
    INSUFFICIENT   = "INSUFFICIENT"     # ⚠️  Live but insufficient funds
    DEAD           = "DEAD"             # ❌ Declined/invalid
    EXPIRED        = "EXPIRED"          # ❌ Expired card
    INVALID        = "INVALID"          # ❌ Invalid card number
    DO_NOT_HONOR   = "DO_NOT_HONOR"     # 🚫 Bank blocked
    PICKUP         = "PICKUP"           # 🚫 Card reported lost/stolen
    ERROR          = "ERROR"            # ❓ Gateway/network error


STATUS_EMOJI = {
    CCStatus.CHARGED:       "✅",
    CCStatus.LIVE_VBV:      "🔐",
    CCStatus.LIVE_3DS:      "🔐",
    CCStatus.INSUFFICIENT:  "⚠️",
    CCStatus.DO_NOT_HONOR:  "🔥",
    CCStatus.PICKUP:        "🔥",
    CCStatus.EXPIRED:       "🔥",
    CCStatus.DEAD:          "❌",
    CCStatus.INVALID:       "❌",
    CCStatus.ERROR:         "❓",
}

STATUS_LABEL = {
    CCStatus.CHARGED:       "LIVE ✅ CHARGED",
    CCStatus.LIVE_VBV:      "LIVE 🔐 VBV",
    CCStatus.LIVE_3DS:      "LIVE 🔐 3DS",
    CCStatus.INSUFFICIENT:  "LIVE ⚠️ NSF",
    CCStatus.DO_NOT_HONOR:  "LIVE 🔥 DO NOT HONOR",
    CCStatus.PICKUP:        "LIVE 🔥 STOLEN/LOST",
    CCStatus.EXPIRED:       "LIVE 🔥 EXPIRED",
    CCStatus.DEAD:          "DEAD ❌",
    CCStatus.INVALID:       "DEAD ❌ INVALID",
    CCStatus.ERROR:         "ERROR ❓",
}

# Friendly label per gate result type (shown in bot messages)
GATE_RESULT_LABEL = {
    "Shopify":       {CCStatus.CHARGED: "✅ Order Placed — Card Live!"},
    "Authorize.net": {CCStatus.CHARGED: "✅ Approved — Auth Success"},
    "Square":        {CCStatus.CHARGED: "✅ Square Approved — Card Live!"},
    "Stripe":        {CCStatus.CHARGED: "✅ Charged — Non-VBV Live"},
    "Braintree":     {CCStatus.CHARGED: "✅ Auth Approved — Card Live"},
    "Razorpay":      {CCStatus.CHARGED: "✅ Payment Auth — Card Live (INR)"},
}

# Is this card "alive" (usable)?
# Any bank response = card exists in bank system = LIVE
# DEAD = truly invalid number (vault rejection) or no bank response at all
LIVE_STATUSES = {
    CCStatus.CHARGED,
    CCStatus.LIVE_VBV,
    CCStatus.LIVE_3DS,
    CCStatus.INSUFFICIENT,
    CCStatus.DO_NOT_HONOR,   # Bank responded = card exists
    CCStatus.PICKUP,         # Bank responded = card exists (stolen/lost)
    CCStatus.EXPIRED,        # Bank responded = card exists but expired
}


@dataclass
class GatewayResult:
    status: CCStatus
    gateway: str
    message: str                        # human-readable response
    raw_code: str = ""                  # raw decline/error code
    is_vbv: bool = False                # VBV / 3DS required
    is_non_vbv: bool = False            # Non-VBV confirmed
    charge_amount: float = 0.0          # amount charged (usually 0)
    extra: dict = field(default_factory=dict)

    @property
    def is_live(self) -> bool:
        return self.status in LIVE_STATUSES

    @property
    def emoji(self) -> str:
        return STATUS_EMOJI.get(self.status, "❓")

    @property
    def label(self) -> str:
        return STATUS_LABEL.get(self.status, str(self.status))
