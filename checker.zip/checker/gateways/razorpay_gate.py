"""
gateways/razorpay_gate.py — Razorpay CC Checker (Checkout Ajax Flow)

Flow:
  1. Create Razorpay Order (server key: KEY_ID + KEY_SECRET)
  2. Submit card via /v1/payments/create/ajax (public key only: KEY_ID)
     This is the same endpoint Razorpay's Checkout.js uses internally.
  3. Parse bank response -> LIVE / DEAD / VBV / INSUFFICIENT

Amount Strategy (fraud detection bypass):
  149/199/249/299/399/499 INR randomly rotated.
  Real merchants charge these — no ML suspicion.

Proxy Support:
  Pass proxy dict to check_razorpay() for IP rotation.
  International card checking needs non-Indian proxy IPs.

IMPORTANT — Razorpay Dashboard settings needed:
  Settings > Checkout > International Payments -> ENABLE
  Without this, all non-Indian cards will return
  'International cards are not supported'
"""

import asyncio
import random
import time
import base64
import json
import aiohttp
from aiohttp import ClientTimeout

try:
    from aiohttp_socks import ProxyConnector
    _SOCKS_AVAILABLE = True
except ImportError:
    _SOCKS_AVAILABLE = False

from gateways.base import GatewayResult, CCStatus
from core.parser import CardData
import config

TIMEOUT = ClientTimeout(total=20)
RAZORPAY_API      = "https://api.razorpay.com/v1"
RAZORPAY_AJAX_URL = "https://api.razorpay.com/v1/payments/create/ajax"

# Realistic INR amounts in paise (1 INR = 100 paise)
REALISTIC_AMOUNTS_PAISE = [
    14900,   # 149 INR
    19900,   # 199 INR
    24900,   # 249 INR
    29900,   # 299 INR
    39900,   # 399 INR
    49900,   # 499 INR
]

# Fake but realistic Indian names (avoid "Card Holder" pattern)
FAKE_NAMES = [
    "Rahul Sharma", "Priya Singh", "Amit Kumar", "Sneha Patel",
    "Vikram Gupta", "Pooja Mehta", "Rajesh Verma", "Anita Joshi",
    "Suresh Nair",  "Deepa Iyer",  "Mohit Agarwal", "Kavita Rao",
]

# Razorpay error reason -> CCStatus
RAZORPAY_REASON_MAP = {
    "card_declined":                       CCStatus.DEAD,
    "do_not_honor":                        CCStatus.DO_NOT_HONOR,
    "insufficient_funds":                  CCStatus.INSUFFICIENT,
    "lost_card":                           CCStatus.PICKUP,
    "stolen_card":                         CCStatus.PICKUP,
    "expired_card":                        CCStatus.EXPIRED,
    "incorrect_cvc":                       CCStatus.CHARGED,   # card exists = LIVE
    "invalid_cvc":                         CCStatus.CHARGED,   # card exists = LIVE
    "incorrect_number":                    CCStatus.INVALID,
    "invalid_number":                      CCStatus.INVALID,
    "card_number_invalid":                 CCStatus.INVALID,   # Razorpay actual code
    "invalid_expiry_month":                CCStatus.EXPIRED,
    "invalid_expiry_year":                 CCStatus.EXPIRED,
    "expiry_invalid":                      CCStatus.EXPIRED,   # Razorpay actual code
    "incorrect_card_details":              CCStatus.DEAD,      # GATEWAY_ERROR reason
    "card_not_supported":                  CCStatus.DEAD,
    "card_velocity_exceeded":              CCStatus.DO_NOT_HONOR,
    "withdrawal_count_limit_exceeded":     CCStatus.DO_NOT_HONOR,
    "not_permitted":                       CCStatus.DO_NOT_HONOR,
    "security_violation":                  CCStatus.DEAD,
    "transaction_not_permitted":           CCStatus.DO_NOT_HONOR,
    "restricted_card":                     CCStatus.DO_NOT_HONOR,
    "authentication_required":             CCStatus.LIVE_VBV,
    "3ds_required":                        CCStatus.LIVE_VBV,
    "acs_required":                        CCStatus.LIVE_VBV,
    "enrollment_required":                 CCStatus.LIVE_VBV,
}

VBV_KEYWORDS = [
    "3d secure", "3ds", "authentication required", "otp",
    "verified by visa", "mastercard securecode", "enrolled",
    "step up", "challenge", "frictionless",
]

INT_KEYWORDS = [
    "international cards are not supported",
    "international card",
    "international payments",
    "not supported",
]


def _server_auth() -> str:
    """Basic auth with KEY_ID + KEY_SECRET (for order creation)."""
    if not config.RAZORPAY_KEY_ID or not config.RAZORPAY_KEY_SECRET:
        raise ValueError("Razorpay credentials not configured in .env")
    creds = f"{config.RAZORPAY_KEY_ID}:{config.RAZORPAY_KEY_SECRET}"
    return "Basic " + base64.b64encode(creds.encode()).decode()


def _pub_auth() -> str:
    """Basic auth with KEY_ID only (for checkout/payment submission)."""
    if not config.RAZORPAY_KEY_ID:
        raise ValueError("RAZORPAY_KEY_ID not configured")
    creds = f"{config.RAZORPAY_KEY_ID}:"
    return "Basic " + base64.b64encode(creds.encode()).decode()


def _pick_amount() -> int:
    return random.choice(REALISTIC_AMOUNTS_PAISE)


def _fake_name() -> str:
    return random.choice(FAKE_NAMES)


def _random_email() -> str:
    names = ["user", "raj", "amit", "priya", "test", "mail", "inbox"]
    domains = ["gmail.com", "yahoo.com", "hotmail.com", "outlook.com"]
    return f"{random.choice(names)}{random.randint(100, 9999)}@{random.choice(domains)}"


def _random_phone() -> str:
    # Indian mobile format
    prefixes = ["9", "8", "7", "6"]
    return f"+91{random.choice(prefixes)}{random.randint(100000000, 999999999)}"


def _detect_vbv(text: str) -> bool:
    t = text.lower()
    return any(kw in t for kw in VBV_KEYWORDS)


def _detect_international(text: str) -> bool:
    t = text.lower()
    return any(kw in t for kw in INT_KEYWORDS)


def _parse_error(resp: dict, amount_inr: int, http_status: int = 0) -> GatewayResult:
    """Parse Razorpay error dict into GatewayResult."""
    err  = resp.get("error", {})
    code = err.get("code", "UNKNOWN")
    desc = err.get("description") or ""
    reason = err.get("reason") or ""
    step   = err.get("step") or ""
    meta   = err.get("metadata") or {}

    # HTTP 500 with empty description = server-side rejection (unsupported card type)
    if http_status == 500 and not desc and not reason:
        return GatewayResult(
            status=CCStatus.DEAD,
            gateway="Razorpay",
            message=f"Declined | Card Not Supported (RuPay/Unsupported BIN) | INR {amount_inr}",
            raw_code="card_not_supported",
            extra={"meta": str(meta), "http": 500},
        )

    # Fill default desc if still empty
    if not desc:
        desc = reason or code or "Declined"

    # International card blocked by account settings
    if _detect_international(desc):
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="Razorpay",
            message=(
                f"International Cards Disabled in Razorpay Account!\n"
                f"Enable: Dashboard -> Settings -> Checkout -> International Payments"
            ),
            raw_code="international_disabled",
            extra={"desc": desc, "meta": str(meta)},
        )

    # VBV/3DS detection from message
    if _detect_vbv(desc) or _detect_vbv(reason):
        return GatewayResult(
            status=CCStatus.LIVE_VBV,
            gateway="Razorpay",
            message=f"3DS/VBV Required | INR {amount_inr} | Card LIVE",
            raw_code=reason or code,
            is_vbv=True,
            extra={"desc": desc, "meta": str(meta)},
        )

    # Step-based VBV
    if step in ("payment_authentication", "payment_authorization") and "3ds" in desc.lower():
        return GatewayResult(
            status=CCStatus.LIVE_VBV,
            gateway="Razorpay",
            message=f"3DS Auth Required | INR {amount_inr} | Card LIVE",
            raw_code=reason or code,
            is_vbv=True,
        )

    # Reason-based mapping
    if reason in RAZORPAY_REASON_MAP:
        status = RAZORPAY_REASON_MAP[reason]
        msg_prefix = {
            CCStatus.CHARGED:       f"Card LIVE (CVV mismatch ok) | INR {amount_inr}",
            CCStatus.INSUFFICIENT:  f"Insufficient Funds | INR {amount_inr} | Card LIVE",
            CCStatus.EXPIRED:       f"Expired Card | {desc}",
            CCStatus.INVALID:       f"Invalid Card Number | {desc}",
            CCStatus.DEAD:          f"Declined | {desc} [{reason}]",
            CCStatus.DO_NOT_HONOR:  f"Do Not Honor | {desc}",
            CCStatus.PICKUP:        f"Lost/Stolen | {desc}",
        }.get(status, f"{desc} [{reason}]")

        return GatewayResult(
            status=status,
            gateway="Razorpay",
            message=msg_prefix,
            raw_code=reason,
            is_vbv=(status == CCStatus.LIVE_VBV),
            is_non_vbv=(status == CCStatus.CHARGED),
            charge_amount=float(amount_inr) if status == CCStatus.CHARGED else 0.0,
            extra={"step": step, "meta": str(meta)},
        )

    # Code-based fallback
    if "insufficient" in desc.lower():
        return GatewayResult(
            status=CCStatus.INSUFFICIENT,
            gateway="Razorpay",
            message=f"Insufficient Funds | INR {amount_inr} | Card LIVE",
            raw_code=code,
        )
    if "expir" in desc.lower():
        return GatewayResult(
            status=CCStatus.EXPIRED,
            gateway="Razorpay",
            message=f"Expired Card | {desc}",
            raw_code=code,
        )
    if "invalid" in desc.lower() and "number" in desc.lower():
        return GatewayResult(
            status=CCStatus.INVALID,
            gateway="Razorpay",
            message=f"Invalid Card | {desc}",
            raw_code=code,
        )

    # Gateway / Server error — check reason before treating as ERROR
    if code in ("GATEWAY_ERROR", "SERVER_ERROR"):
        # If reason tells us the actual problem, use it (don't return ERROR)
        if reason in RAZORPAY_REASON_MAP:
            status = RAZORPAY_REASON_MAP[reason]
            friendly = {
                CCStatus.DEAD:         f"Declined | {desc} [{reason}]",
                CCStatus.INSUFFICIENT: f"Insufficient Funds | INR {amount_inr} | Card LIVE",
                CCStatus.EXPIRED:      f"Expired Card | {desc}",
                CCStatus.INVALID:      f"Invalid Card | {desc}",
                CCStatus.DO_NOT_HONOR: f"Do Not Honor | {desc}",
                CCStatus.LIVE_VBV:     f"3DS Required | INR {amount_inr} | Card LIVE",
            }.get(status, f"Declined | {desc} [{reason}]")
            return GatewayResult(
                status=status,
                gateway="Razorpay",
                message=friendly,
                raw_code=reason,
                is_vbv=(status == CCStatus.LIVE_VBV),
                extra={"code": code, "step": step},
            )
        # True gateway/network issue with no actionable reason
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="Razorpay",
            message=f"Gateway Error | {desc}",
            raw_code=code,
        )

    if code in ("NETWORK_ERROR", "TIMEOUT"):
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="Razorpay",
            message=f"Network Error | {desc}",
            raw_code=code,
        )


    # Default dead
    return GatewayResult(
        status=CCStatus.DEAD,
        gateway="Razorpay",
        message=f"Declined | {desc} [{code}]",
        raw_code=code,
        extra={"reason": reason, "step": step},
    )


def _build_connector(proxy: dict | None):
    """Build aiohttp connector with optional proxy."""
    if not proxy:
        return None

    protocol = proxy.get("protocol", "http")
    host     = proxy.get("host", "")
    port     = proxy.get("port", 0)
    user     = proxy.get("username", "")
    pwd      = proxy.get("password", "")

    if user and pwd:
        proxy_url = f"{protocol}://{user}:{pwd}@{host}:{port}"
    else:
        proxy_url = f"{protocol}://{host}:{port}"

    if "socks" in protocol and _SOCKS_AVAILABLE:
        return ProxyConnector.from_url(proxy_url, ssl=False, limit=10)
    return None   # HTTP proxy passed via request kwargs


def _build_proxy_kwargs(proxy: dict | None) -> dict:
    """Return proxy kwarg for HTTP proxies."""
    if not proxy:
        return {}
    protocol = proxy.get("protocol", "http")
    if "socks" in protocol:
        return {}   # handled by connector
    host = proxy.get("host", "")
    port = proxy.get("port", 0)
    user = proxy.get("username", "")
    pwd  = proxy.get("password", "")
    if user and pwd:
        return {"proxy": f"{protocol}://{user}:{pwd}@{host}:{port}"}
    return {"proxy": f"{protocol}://{host}:{port}"}


async def _create_order(session: aiohttp.ClientSession, amount_paise: int, proxy_kwargs: dict):
    """Create Razorpay order (server-side, uses KEY_ID + KEY_SECRET)."""
    try:
        async with session.post(
            f"{RAZORPAY_API}/orders",
            json={
                "amount":          amount_paise,
                "currency":        "INR",
                "receipt":         f"rcpt_{int(time.time())}_{random.randint(1000, 9999)}",
                "payment_capture": 1,
            },
            headers={
                "Authorization": _server_auth(),
                "Content-Type":  "application/json",
                "Accept":        "application/json",
            },
            **proxy_kwargs,
        ) as resp:
            data = await resp.json(content_type=None)
            if resp.status == 200 and data.get("id"):
                return data
            return None
    except Exception:
        return None


async def _submit_payment(
    session:      aiohttp.ClientSession,
    order_id:     str,
    amount_paise: int,
    card:         CardData,
    proxy_kwargs: dict,
) -> tuple[int, dict]:
    """
    Submit card payment via Razorpay's checkout ajax endpoint.
    Uses only KEY_ID (public key) — same as browser checkout flow.
    Returns (http_status, response_dict).
    """
    exp_year = card.year[-2:] if len(card.year) == 4 else card.year

    payload = {
        "key_id":              config.RAZORPAY_KEY_ID,
        "order_id":            order_id,
        "amount":              str(amount_paise),
        "currency":            "INR",
        "method":              "card",
        "card[number]":        card.number,
        "card[name]":          _fake_name(),
        "card[expiry_month]":  card.month.zfill(2),
        "card[expiry_year]":   exp_year,
        "card[cvv]":           card.cvv,
        "save":                "0",
        "email":               _random_email(),
        "contact":             _random_phone(),
    }

    headers = {
        "Authorization":  _pub_auth(),
        "Content-Type":   "application/x-www-form-urlencoded",
        "Accept":         "application/json",
        "User-Agent":     (
            "Mozilla/5.0 (Linux; Android 13; Pixel 7 Pro) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Mobile Safari/537.36"
        ),
        "Origin":         "https://checkout.razorpay.com",
        "Referer":        "https://checkout.razorpay.com/",
        "X-Razorpay-TrackId": f"rzp_{int(time.time())}",
    }

    try:
        async with session.post(
            RAZORPAY_AJAX_URL,
            data=payload,
            headers=headers,
            timeout=TIMEOUT,
            **proxy_kwargs,
        ) as resp:
            raw = await resp.text()
            http_status = resp.status
            try:
                data = json.loads(raw)
            except Exception:
                data = {"error": {"code": "PARSE_ERROR", "description": raw[:200]}}
            return http_status, data

    except aiohttp.ClientConnectorError as e:
        return 0, {"error": {"code": "NETWORK_ERROR", "description": f"Connection failed: {e}"}}
    except asyncio.TimeoutError:
        return 0, {"error": {"code": "TIMEOUT", "description": "Request timed out"}}
    except Exception as e:
        return 0, {"error": {"code": "EXCEPTION", "description": str(e)}}



async def check_razorpay(card: CardData, proxy: dict | None = None) -> GatewayResult:
    """
    Main Razorpay CC checker via checkout ajax endpoint.
    Handles: OTP flow (RuPay/Indian cards), 3DS redirect, direct auth, errors.
    """
    if not config.RAZORPAY_KEY_ID or not config.RAZORPAY_KEY_SECRET:
        return GatewayResult(
            status=CCStatus.ERROR, gateway="Razorpay",
            message="Razorpay credentials not configured! Set in .env",
            raw_code="config_error",
        )

    amount_paise = _pick_amount()
    amount_inr   = amount_paise // 100
    connector    = _build_connector(proxy)
    proxy_kwargs = _build_proxy_kwargs(proxy)

    try:
        session_kwargs = {"timeout": TIMEOUT}
        if connector:
            session_kwargs["connector"] = connector

        async with aiohttp.ClientSession(**session_kwargs) as session:

            order = await _create_order(session, amount_paise, proxy_kwargs)
            if not order:
                return GatewayResult(
                    status=CCStatus.ERROR, gateway="Razorpay",
                    message="Failed to create order",
                    raw_code="order_create_failed",
                )

            order_id = order["id"]
            http_status, resp = await _submit_payment(
                session, order_id, amount_paise, card, proxy_kwargs
            )

            # ── Hard error object ────────────────────────────────────────────
            if "error" in resp:
                return _parse_error(resp, amount_inr, http_status=http_status)

            # ── HTTP 500 no error key = unsupported card ─────────────────────
            if http_status == 500:
                return GatewayResult(
                    status=CCStatus.DEAD, gateway="Razorpay",
                    message=f"Declined | Card Not Supported | INR {amount_inr}",
                    raw_code="server_error_500",
                )

            # ── CASE A: OTP flow — RuPay / Indian domestic cards ────────────
            # Response has type="otp" and next=["otp_submit","otp_resend"]
            # This means OTP was sent to cardholder's phone -> card is LIVE VBV
            if resp.get("type") == "otp" or (
                "payment_id" in resp
                and "next" in resp
                and isinstance(resp.get("next"), list)
            ):
                meta      = resp.get("metadata", {})
                pid       = resp.get("payment_id", "")
                network   = (meta.get("network") or "").upper()
                issuer    = meta.get("issuer") or "Unknown"
                card_type = (meta.get("card_type") or "").capitalize()
                last4     = meta.get("last4", "")
                net_label = {
                    "RUPAY": "RuPay", "VISA": "Visa",
                    "MASTERCARD": "Mastercard", "AMEX": "Amex",
                }.get(network, network or "Card")

                return GatewayResult(
                    status=CCStatus.LIVE_VBV, gateway="Razorpay",
                    message=f"OTP Sent | INR {amount_inr} | {net_label} LIVE (VBV)",
                    raw_code="otp_sent", is_vbv=True,
                    extra={
                        "order_id": order_id, "payment_id": pid,
                        "issuer": issuer, "network": network,
                        "card_type": card_type, "last4": last4,
                    },
                )

            # ── CASE B: Standard payment object (id + status) ───────────────
            pid = resp.get("id") or resp.get("razorpay_payment_id") or ""
            if http_status == 200 and pid:
                pay_status  = resp.get("status", "")
                next_action = resp.get("next_action") or resp.get("next")

                if pay_status in ("authorized", "captured"):
                    return GatewayResult(
                        status=CCStatus.CHARGED, gateway="Razorpay",
                        message=f"Authorized | INR {amount_inr} | Non-VBV LIVE",
                        raw_code=pay_status, is_non_vbv=True,
                        charge_amount=float(amount_inr),
                        extra={"order_id": order_id, "payment_id": pid},
                    )
                if pay_status == "created" and next_action:
                    return GatewayResult(
                        status=CCStatus.LIVE_VBV, gateway="Razorpay",
                        message=f"3DS Required | INR {amount_inr} | Card LIVE (VBV)",
                        raw_code="3ds_redirect", is_vbv=True,
                        extra={"order_id": order_id, "payment_id": pid},
                    )
                if pay_status == "created":
                    return GatewayResult(
                        status=CCStatus.LIVE_VBV, gateway="Razorpay",
                        message=f"Auth Pending | INR {amount_inr} | Card possibly LIVE",
                        raw_code="created_no_action", is_vbv=True,
                        extra={"order_id": order_id, "payment_id": pid},
                    )
                if pay_status == "failed":
                    err_desc = resp.get("error_description") or resp.get("error_reason", "Declined")
                    return GatewayResult(
                        status=CCStatus.DEAD, gateway="Razorpay",
                        message=f"Payment Failed | {err_desc} | INR {amount_inr}",
                        raw_code=resp.get("error_code", "failed"),
                        extra={"order_id": order_id, "payment_id": pid},
                    )

            # ── Unknown / unhandled response ─────────────────────────────────
            raw_preview = str(resp)[:150]
            return GatewayResult(
                status=CCStatus.ERROR, gateway="Razorpay",
                message=f"Unknown response [HTTP {http_status}] | {raw_preview}",
                raw_code=f"http_{http_status}",
                extra={"order_id": order_id},
            )

    except ValueError as e:
        return GatewayResult(status=CCStatus.ERROR, gateway="Razorpay",
                             message=str(e), raw_code="config_error")
    except Exception as e:
        return GatewayResult(status=CCStatus.ERROR, gateway="Razorpay",
                             message=f"Exception: {type(e).__name__}: {e}",
                             raw_code="exception")
