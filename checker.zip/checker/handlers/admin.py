"""
handlers/admin.py — Admin-only commands (/broadcast, /addkey, /userlist)
"""
from pyrogram import Client, filters, enums
from pyrogram.types import Message
import config
import database.db as db
from utils.error_handler import notify_owner_on_error



def owner_only(func):
    """Decorator to restrict commands to bot owner."""
    async def wrapper(client, msg: Message):
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("❌ Owner only command.", parse_mode=enums.ParseMode.MARKDOWN)
            return
        await func(client, msg)
    return wrapper


def register_admin(app: Client):

    @app.on_message(filters.command("addkey"))
    @owner_only
    @notify_owner_on_error
    async def addkey_cmd(client: Client, msg: Message):
        """Add a new Stripe key at runtime."""
        parts = msg.text.strip().split()
        if len(parts) < 2:
            await msg.reply("Usage: `/addkey sk_live_...`", parse_mode=enums.ParseMode.MARKDOWN)
            return
        key = parts[1]
        if not key.startswith("sk_"):
            await msg.reply("❌ Invalid Stripe key format.", parse_mode=enums.ParseMode.MARKDOWN)
            return
        if key not in config.STRIPE_KEYS:
            config.STRIPE_KEYS.append(key)
            await msg.reply(
                f"✅ Key added! Total keys: `{len(config.STRIPE_KEYS)}`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
        else:
            await msg.reply("⚠️ Key already exists.", parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("removekey"))
    @owner_only
    @notify_owner_on_error
    async def removekey_cmd(client: Client, msg: Message):
        """Remove a Stripe key at runtime."""
        parts = msg.text.strip().split()
        if len(parts) < 2:
            await msg.reply("Usage: `/removekey sk_live_...`", parse_mode=enums.ParseMode.MARKDOWN)
            return
        key = parts[1]
        if key in config.STRIPE_KEYS:
            config.STRIPE_KEYS.remove(key)
            await msg.reply(
                f"✅ Key removed. Remaining: `{len(config.STRIPE_KEYS)}`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
        else:
            await msg.reply("❌ Key not found.", parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("keys"))
    @owner_only
    @notify_owner_on_error
    async def keys_cmd(client: Client, msg: Message):
        """List loaded Stripe keys (masked)."""
        if not config.STRIPE_KEYS:
            await msg.reply("❌ No keys loaded.", parse_mode=enums.ParseMode.MARKDOWN)
            return
        masked = [f"`{k[:8]}...{k[-4:]}`" for k in config.STRIPE_KEYS]
        text = f"🔑 **Stripe Keys ({len(config.STRIPE_KEYS)}):**\n" + "\n".join(masked)
        await msg.reply(text, parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("gstats"))
    @owner_only
    @notify_owner_on_error
    async def gstats_cmd(client: Client, msg: Message):
        """Global bot stats."""
        stats = await db.get_global_stats()
        text = (
            f"📊 **Global Stats**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"👥 Users: `{stats['users']}`\n"
            f"🔢 Total Checks: `{stats['total_checks']}`\n"
            f"✅ Live: `{stats['live']}`\n"
            f"❌ Dead: `{stats['dead']}`\n"
        )
        await msg.reply(text, parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("setgate"))
    @owner_only
    @notify_owner_on_error
    async def setgate_cmd(client: Client, msg: Message):
        """
        Set gate priority order at runtime.
        Usage: /setgate shopify,stripe,authnet
        Available gates: shopify, authnet, square, stripe, braintree
        """
        VALID_GATES = {"shopify", "authnet", "square", "stripe", "braintree"}
        parts = msg.text.strip().split(maxsplit=1)
        if len(parts) < 2:
            current = ",".join(config.GATE_PRIORITY)
            await msg.reply(
                f"📋 **Gate Priority Manager**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"**Current order:** `{current}`\n\n"
                f"**Usage:** `/setgate shopify,authnet,stripe`\n\n"
                f"**Available gates:**\n"
                f"• `shopify` — No key needed\n"
                f"• `authnet` — Authorize.net\n"
                f"• `square` — Square\n"
                f"• `stripe` — Stripe\n"
                f"• `braintree` — Braintree",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        raw = parts[1].strip().lower()
        new_gates = [g.strip() for g in raw.split(",") if g.strip()]

        # Validate
        invalid = [g for g in new_gates if g not in VALID_GATES]
        if invalid:
            await msg.reply(
                f"❌ Invalid gates: `{', '.join(invalid)}`\n"
                f"Valid options: `shopify, authnet, square, stripe, braintree`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        if not new_gates:
            await msg.reply("❌ Must provide at least one gate.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        # Apply new priority
        config.GATE_PRIORITY = new_gates
        await msg.reply(
            f"✅ **Gate priority updated!**\n"
            f"New order: `{' → '.join(new_gates)}`",
            parse_mode=enums.ParseMode.MARKDOWN
        )

    @app.on_message(filters.command("gateon"))
    @owner_only
    @notify_owner_on_error
    async def gateon_cmd(client: Client, msg: Message):
        """Enable a specific gate (move to front of priority)."""
        parts = msg.text.strip().split()
        if len(parts) < 2:
            await msg.reply("Usage: `/gateon shopify`", parse_mode=enums.ParseMode.MARKDOWN)
            return
        gate = parts[1].lower()
        if gate not in {"shopify", "authnet", "square", "stripe", "braintree"}:
            await msg.reply("❌ Unknown gate.", parse_mode=enums.ParseMode.MARKDOWN)
            return
        if gate not in config.GATE_PRIORITY:
            config.GATE_PRIORITY.insert(0, gate)
        else:
            config.GATE_PRIORITY.remove(gate)
            config.GATE_PRIORITY.insert(0, gate)
        await msg.reply(
            f"✅ `{gate}` moved to **first priority**!\n"
            f"Order: `{' → '.join(config.GATE_PRIORITY)}`",
            parse_mode=enums.ParseMode.MARKDOWN
        )

    @app.on_message(filters.command("gateoff"))
    @owner_only
    @notify_owner_on_error
    async def gateoff_cmd(client: Client, msg: Message):
        """Disable a specific gate (remove from priority)."""
        parts = msg.text.strip().split()
        if len(parts) < 2:
            await msg.reply("Usage: `/gateoff stripe`", parse_mode=enums.ParseMode.MARKDOWN)
            return
        gate = parts[1].lower()
        if gate == "shopify":
            await msg.reply("❌ Cannot disable Shopify gate (it's the base gate).", parse_mode=enums.ParseMode.MARKDOWN)
            return
        if gate in config.GATE_PRIORITY:
            config.GATE_PRIORITY.remove(gate)
            await msg.reply(
                f"✅ `{gate}` **disabled**!\n"
                f"Active: `{' → '.join(config.GATE_PRIORITY)}`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
        else:
            await msg.reply(f"⚠️ `{gate}` was not in priority list.", parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("setworkers"))
    @owner_only
    @notify_owner_on_error
    async def setworkers_cmd(client: Client, msg: Message):
        """Set concurrent checking workers count at runtime."""
        parts = msg.text.strip().split()
        if len(parts) < 2:
            await msg.reply(
                f"🛠️ **Worker Configuration**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"• Current Owner Workers: `{config.OWNER_WORKERS}`\n"
                f"• Current Admin Workers: `{config.MAX_CONCURRENT}`\n\n"
                f"**Usage:** `/setworkers <num>` (sets both to `<num>`)\n"
                f"**Example:** `/setworkers 30`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return
            
        try:
            num = int(parts[1])
            if num < 1 or num > 100:
                await msg.reply("❌ Worker count must be between 1 and 100.", parse_mode=enums.ParseMode.MARKDOWN)
                return
        except ValueError:
            await msg.reply("❌ Invalid number.", parse_mode=enums.ParseMode.MARKDOWN)
            return
            
        config.OWNER_WORKERS = num
        config.MAX_CONCURRENT = num
        await msg.reply(
            f"✅ **Workers Updated!**\n\n"
            f"• Owner Workers: `{config.OWNER_WORKERS}`\n"
            f"• Admin Workers: `{config.MAX_CONCURRENT}`",
            parse_mode=enums.ParseMode.MARKDOWN
        )

