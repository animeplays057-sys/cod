from pyrogram import Client, filters, enums
import config
from core.auto_generator import AutoGenerator
from utils.error_handler import notify_owner_on_error

# Global instance of the generator
auto_gen: AutoGenerator | None = None

def _is_admin(user_id: int) -> bool:
    return user_id in config.OWNER_IDS

@notify_owner_on_error
async def cmd_autogen_on(client: Client, message):
    if not _is_admin(message.from_user.id):
        return await message.reply("🚫 **Access Denied!**", parse_mode=enums.ParseMode.MARKDOWN)
        
    global auto_gen
    if not auto_gen:
        auto_gen = AutoGenerator(client)
        
    if auto_gen.start():
        await message.reply("🤖 **Auto-Generator Started!**\n\nI will now silently generate and check cards in the background. I'll send you a message if I hit a LIVE or CHARGED card.")
    else:
        await message.reply("⚠️ Auto-Generator is already running!")

@notify_owner_on_error
async def cmd_autogen_off(client: Client, message):
    if not _is_admin(message.from_user.id):
        return await message.reply("🚫 **Access Denied!**", parse_mode=enums.ParseMode.MARKDOWN)
        
    global auto_gen
    if auto_gen and auto_gen.stop():
        await message.reply("🛑 **Auto-Generator Stopped!**")
    else:
        await message.reply("⚠️ Auto-Generator is not currently running.")

@notify_owner_on_error
async def cmd_autogen_status(client: Client, message):
    if not _is_admin(message.from_user.id):
        return await message.reply("🚫 **Access Denied!**", parse_mode=enums.ParseMode.MARKDOWN)
        
    global auto_gen
    if not auto_gen:
        return await message.reply("⚠️ Auto-Generator has never been started.")
        
    state = "🟢 RUNNING" if auto_gen.is_running else "🔴 STOPPED"
    s = auto_gen.stats
    
    text = (
        f"🤖 **Auto-Generator Status: {state}**\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"🔢 **Cards Generated:** `{s['generated']}`\n"
        f"🔍 **Cards Checked:** `{s['checked']}`\n\n"
        f"✅ **LIVE/CHARGED:** `{s['live']}`\n"
        f"❌ **DEAD:** `{s['dead']}`\n"
        f"⚠️ **ERRORS:** `{s['error']}`"
    )
    await message.reply(text)

def register_autogen_handler(app: Client):
    app.on_message(filters.command("autogen_on"))(cmd_autogen_on)
    app.on_message(filters.command("autogen_off"))(cmd_autogen_off)
    app.on_message(filters.command("autogen_status"))(cmd_autogen_status)
