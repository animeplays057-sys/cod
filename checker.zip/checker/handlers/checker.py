"""
handlers/checker.py — /chk, /mchk handlers

/chk   — Single CC check via active gateway (set by GATE_PRIORITY in .env)
/mchk  — Mass check (.txt file) with concurrent workers

Owner has NO limits:
  - Unlimited cards per batch
  - Max concurrent workers (OWNER_WORKERS)
Regular users: ADMIN only (all other IDs rejected)
"""
import asyncio
import logging
import time
import os
import tempfile

from pyrogram import Client, filters, enums
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from core.parser import parse_cc, parse_mass
from core.bin_lookup import lookup_bin, BinInfo
from gateways.router import route_and_check
from gateways.base import CCStatus, LIVE_STATUSES
from utils.formatter import format_single_result, format_mass_progress, format_mass_complete
import database.db as db
import config
from utils.error_handler import notify_owner_on_error

logger = logging.getLogger("CC-Checker")



_active_checks: dict[tuple, bool] = {}            # (chat_id, session_id) -> bool
_stop_events:   dict[tuple, asyncio.Event] = {}    # (chat_id, session_id) -> Event
_active_tasks:  dict[tuple, list] = {}             # (chat_id, session_id) -> [Task]


def _is_admin(user_id: int) -> bool:
    """Check if user is in OWNER_IDS list."""
    return user_id in config.OWNER_IDS


def _is_owner(user_id: int) -> bool:
    """Check if user is the primary owner (first in OWNER_IDS)."""
    return bool(config.OWNER_IDS) and user_id == config.OWNER_IDS[0]


async def _admin_denied(msg: Message):
    """Reply with access denied message."""
    await msg.reply(
        "🚫 **Access Denied!**\n\n"
        "This bot is private — admin only.\n"
        "Contact the owner for access.",
        parse_mode=enums.ParseMode.MARKDOWN
    )


def _enrich_card_info(bin_info: BinInfo | None, result_extra: dict) -> tuple[str, str, str, str, str]:
    """
    Returns (flag, country, bank, scheme, ctype) by combining BIN lookup
    with Razorpay gateway metadata fallback.
    Works for both /chk and /mchk flows.
    """
    flag    = bin_info.flag_emoji()  if bin_info else "🌐"
    country = bin_info.country_name  if bin_info else "Unknown"
    bank    = bin_info.bank_name     if bin_info else "Unknown"
    ctype   = bin_info.type          if bin_info else "Unknown"
    scheme  = bin_info.scheme        if bin_info else "Unknown"

    # Enrich from Razorpay OTP metadata (network/issuer/card_type)
    extra = result_extra or {}
    gw_network   = (extra.get("network") or "").upper()
    gw_issuer    = extra.get("issuer") or ""
    gw_card_type = (extra.get("card_type") or "").capitalize()

    net_map = {
        "RUPAY": "RuPay", "VISA": "Visa",
        "MASTERCARD": "Mastercard", "AMEX": "Amex",
        "UNIONPAY": "UnionPay", "JCB": "JCB",
    }

    if scheme in ("Unknown", "") and gw_network:
        scheme = net_map.get(gw_network, gw_network.capitalize())
    if ctype in ("Unknown", "") and gw_card_type:
        ctype = gw_card_type
    if bank in ("Unknown", "") and gw_issuer:
        bank = gw_issuer

    return flag, country, bank, scheme, ctype


@notify_owner_on_error
async def stop_mchk_callback(client: Client, cb):
    # callback_data format: stop_mchk_{chat_id}_{session_id}
    parts = cb.data.split("_")
    # parts: ['stop', 'mchk', chat_id, session_id]
    try:
        chat_id    = int(parts[2])
        session_id = parts[3] if len(parts) > 3 else None
    except (IndexError, ValueError):
        await cb.answer("Invalid stop data.", show_alert=True)
        return

    if cb.from_user.id not in config.OWNER_IDS:
        await cb.answer("❌ Owner/Admin only.", show_alert=True)
        return

    if session_id:
        sess_key = (chat_id, session_id)
    else:
        # Fallback: try to find any active session for this chat
        sess_key = next((k for k in _active_tasks if k[0] == chat_id), None)

    if not sess_key:
        await cb.answer("No active check found.", show_alert=True)
        return

    # Mark stopped
    _active_checks[sess_key] = False
    ev = _stop_events.get(sess_key)
    if ev:
        ev.set()

    # Cancel all in-progress tasks for this specific session
    tasks = _active_tasks.get(sess_key, [])
    cancelled = sum(1 for t in tasks if not t.done() and t.cancel())
    logger.info(f"STOP pressed for chat {chat_id} session {session_id} — cancelled {cancelled} running tasks")
    await cb.answer(f"🛑 Stopping... ({cancelled} tasks cancelled). File coming shortly.", show_alert=True)


def register_checker(app: Client):
    @app.on_callback_query(filters.create(lambda _, __, cb: cb.data and cb.data.startswith("stop_mchk_")))
    async def _stop_mchk(client: Client, cb):
        await stop_mchk_callback(client, cb)

    # ── /chk — Single CC Check ─────────────────────────────────────────────────
    @app.on_message(filters.command("chk"))
    @notify_owner_on_error
    async def chk_cmd(client: Client, msg: Message):
        """Single CC check via active gateway (GATE_PRIORITY in .env). ADMIN ONLY."""
        if not _is_admin(msg.from_user.id):
            await _admin_denied(msg); return

        await db.upsert_user(
            msg.from_user.id,
            msg.from_user.username or "",
            msg.from_user.first_name or "",
        )

        text = msg.text.strip()
        cc_text = text[len("/chk"):].strip()
        if not cc_text:
            await msg.reply(
                "❌ **Usage:** `/chk 4111111111111111|12|2026|123`\n\n"
                "💳 **CC Checker**\n"
                "• ✅ `Charged` — Card Live, Non-VBV\n"
                "• 🔐 `Live VBV` — Card live, 3DS/OTP required\n"
                "• ⚠️ `Insufficient` — Card live, no balance\n"
                "• ❌ `Declined` — Dead / invalid",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        card = parse_cc(cc_text)
        if not card:
            await msg.reply(
                "❌ **Invalid card format!**\n"
                "Use: `4111111111111111|12|2026|123`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        wait_msg = await msg.reply(
            f"⏳ **Checking...**\n`{card.number}|{card.month}|{card.year}|{card.cvv}`",
            parse_mode=enums.ParseMode.MARKDOWN
        )

        start = time.monotonic()
        result = await route_and_check(card)
        elapsed = time.monotonic() - start

        bin_info = await lookup_bin(card.bin)
        user_name = msg.from_user.username or msg.from_user.first_name or "user"
        text = format_single_result(card, result, bin_info, elapsed, username=user_name)

        await wait_msg.edit_text(text, parse_mode=enums.ParseMode.MARKDOWN)

        await db.increment_check_count(msg.from_user.id)
        await db.log_check(
            user_id=msg.from_user.id,
            card_number=card.number,
            card_bin=card.bin,
            status=result.status.value,
            gateway=result.gateway,
            is_vbv=result.is_vbv,
            message=result.message,
        )

    # ── /mchk — Mass CC Check ──────────────────────────────────────────────────
    @app.on_message(
        filters.command("mchk") & (filters.document | filters.text)
    )
    @notify_owner_on_error
    async def mchk_cmd(client: Client, msg: Message):
        """
        Mass CC check. ADMIN ONLY.
        Owner: unlimited cards, max workers.
        Usage:
          • Send .txt file with caption /mchk
          • OR reply to a .txt file with /mchk
        """
        if not _is_admin(msg.from_user.id):
            await _admin_denied(msg); return

        await db.upsert_user(
            msg.from_user.id,
            msg.from_user.username or "",
            msg.from_user.first_name or "",
        )

        is_owner = _is_owner(msg.from_user.id)

        # Determine document source: direct upload or reply
        doc_msg = None
        if msg.document:
            doc_msg = msg
        elif msg.reply_to_message and msg.reply_to_message.document:
            doc_msg = msg.reply_to_message
        else:
            await msg.reply(
                "❌ **How to use /mchk:**\n\n"
                "**Method 1:** Send `.txt` file with caption `/mchk`\n"
                "**Method 2:** Reply to a `.txt` file with `/mchk`\n\n"
                "📄 Each line = one card: `4111111111111111|12|2026|123`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        doc = doc_msg.document
        if not (doc.file_name or "").lower().endswith(".txt"):
            await msg.reply("❌ Only `.txt` files supported.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        # File size: owner = 10MB, others = 1MB
        max_size = 10_000_000 if is_owner else 1_000_000
        if doc.file_size > max_size:
            await msg.reply(
                f"❌ File too large. Max **{'10MB' if is_owner else '1MB'}**.",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        wait_msg = await msg.reply("📥 **Downloading file...**", parse_mode=enums.ParseMode.MARKDOWN)

        tmp_path = None
        try:
            tmp_path = await client.download_media(doc)
            with open(tmp_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except Exception as e:
            await wait_msg.edit_text(
                f"❌ Failed to read file: `{e}`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return
        finally:
            if tmp_path and os.path.exists(tmp_path):
                os.remove(tmp_path)

        cards = parse_mass(content)
        if not cards:
            await wait_msg.edit_text(
                "❌ No valid cards found in file.\n"
                "Format: `4111111111111111|12|2026|123`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        total = len(cards)

        # Card limit: owner = unlimited, others = 1000
        if not is_owner and total > 1000:
            await wait_msg.edit_text(
                f"❌ Too many cards (`{total}`). Max **1000** per batch.",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        # Cards per store — configurable via env var (default 5 for Render free tier)
        # Set CARDS_PER_STORE=10 in Render env vars for higher speed on paid plans
        _cps_env = int(os.getenv("CARDS_PER_STORE", "5"))
        CARDS_PER_STORE  = _cps_env if is_owner else min(_cps_env, 3)
        fallback_workers = config.OWNER_WORKERS if is_owner else config.MAX_CONCURRENT


        # ── Unique session key — isolates this check from concurrent ones ──────
        import uuid as _uuid
        session_id = _uuid.uuid4().hex[:8]  # short 8-char ID e.g. "a3f2b1c9"
        sess_key   = (msg.chat.id, session_id)

        _active_checks[sess_key] = True
        stop_event = asyncio.Event()
        _stop_events[sess_key] = stop_event
        # Embed session_id in button so STOP cancels only THIS check
        stop_markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("🛑 STOP CHECKING 🛑", callback_data=f"stop_mchk_{msg.chat.id}_{session_id}")]
        ])

        # ── Load Shopify stores for store-pool architecture ───────────────────
        shopify_stores = []
        use_store_pool = False
        if "shopify" in config.GATE_PRIORITY:
            try:
                from gateways.shopify_gate import _get_stores, check_shopify_on_store, INFRA_ERROR_CODES
                shopify_stores = await _get_stores()
            except Exception:
                shopify_stores = []
            use_store_pool = len(shopify_stores) > 0

        total_concurrent = len(shopify_stores) * CARDS_PER_STORE if use_store_pool else fallback_workers

        await wait_msg.edit_text(
            f"⚡ **Mass Check Started!**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📋 **Total Cards:** `{total}`\n"
            f"🕑 **Gate:** `{', '.join(config.GATE_PRIORITY).upper()}`\n"
            f"🏗️ **Mode:** `{'Store-Pool' if use_store_pool else 'Standard'}` | "
            f"`{len(shopify_stores)} stores × {CARDS_PER_STORE} cards` = `{total_concurrent} parallel`\n"
            f"{'👑 **Owner:** Unlimited' if is_owner else ''}\n"
            f"⏳ Please wait...",
            parse_mode=enums.ParseMode.MARKDOWN,
            reply_markup=stop_markup
        )

        # ── State tracking (use lock for safe concurrent updates) ──────────────
        lock = asyncio.Lock()
        done          = 0
        live_count    = 0
        dead_count    = 0
        vbv_count     = 0
        non_vbv_count = 0
        error_count   = 0
        charged_results: list[dict] = []
        vbv_results:     list[dict] = []
        dead_results:    list[dict] = []
        error_results:   list[dict] = []
        start = time.monotonic()
        last_edit_time = 0.0

        async def _collect_result(card, result, t0):
            """Shared result handler for both store-pool and fallback paths."""
            nonlocal done, live_count, dead_count, vbv_count, non_vbv_count, error_count, last_edit_time

            elapsed = time.monotonic() - t0

            # BIN lookup ONLY for live cards (skip for dead = instant)
            bin_info = None
            if result.is_live:
                bin_info = await lookup_bin(card.bin)

            flag, country, bank, scheme, ctype = _enrich_card_info(bin_info, result.extra)
            full_type = f"{scheme} {ctype}".strip() if scheme and ctype else (scheme or ctype or "Unknown")

            is_live_card = False
            async with lock:
                done += 1
                current_done = done

                item = {
                    "card":     f"{card.number}|{card.month}|{card.year}|{card.cvv}",
                    "gateway":  result.gateway,
                    "response": result.message[:80],
                    "scheme":   full_type,
                    "bank":     bank,
                    "country":  f"{flag} {country}",
                    "time":     f"{elapsed:.2f}s",
                    "amount":   f"${result.charge_amount:.2f}" if getattr(result, "charge_amount", 0) > 0 else "N/A"
                }

                if result.status == CCStatus.ERROR:
                    error_count += 1
                    error_results.append(item)
                elif result.is_live:
                    live_count += 1
                    is_live_card = True
                    if result.status == CCStatus.CHARGED:
                        non_vbv_count += 1
                        item["tag"] = "✅ CHARGED"
                        charged_results.append(item)
                    else:
                        vbv_count += 1
                        if result.status == CCStatus.INSUFFICIENT:
                            item["tag"] = "⚠️ NSF"
                        elif result.status == CCStatus.DO_NOT_HONOR:
                            item["tag"] = "🔥 DECLINED-LIVE"
                        elif result.status == CCStatus.PICKUP:
                            item["tag"] = "🔥 STOLEN-LIVE"
                        elif result.status == CCStatus.EXPIRED:
                            item["tag"] = "🔥 EXPIRED-LIVE"
                        else:
                            item["tag"] = "🔐 VBV"
                        vbv_results.append(item)
                else:
                    dead_count += 1
                    dead_results.append(item)

            # DB log (outside lock)
            await db.log_check(
                user_id=msg.from_user.id,
                card_number=card.number,
                card_bin=card.bin,
                status=result.status.value,
                gateway=result.gateway,
                is_vbv=result.is_vbv,
                message=result.message,
            )

            if is_live_card:
                user_name = msg.from_user.username or msg.from_user.first_name or "user"
                single_text = format_single_result(card, result, bin_info, elapsed, username=user_name)
                single_text = f"🚨 **Instant Live Card (Mass Check)!** 🚨\n\n" + single_text
                try:
                    instant_msg = await client.send_message(
                        chat_id=msg.chat.id,
                        text=single_text,
                        parse_mode=enums.ParseMode.MARKDOWN
                    )
                    await client.pin_chat_message(
                        chat_id=msg.chat.id,
                        message_id=instant_msg.id,
                        disable_notification=False
                    )
                except Exception as e:
                    logger.error(f"Failed to send/pin instant mass result: {e}")

            # Progress update (every 1.0s)
            now = time.monotonic()
            if now - last_edit_time >= 1.0 or current_done == total:
                last_edit_time = now
                async with lock:
                    progress_text = format_mass_progress(
                        current_done, total, live_count, dead_count,
                        vbv_count, non_vbv_count, error_count
                    )
                try:
                    markup = stop_markup if _active_checks.get(sess_key, True) else None
                    await wait_msg.edit_text(progress_text, parse_mode=enums.ParseMode.MARKDOWN, reply_markup=markup)
                except Exception:
                    pass

        if use_store_pool:
            # ── STORE-POOL ARCHITECTURE ──────────────────────────────────────────
            # Each store gets its own worker pool (sem=CARDS_PER_STORE).
            # Cards distributed from shared asyncio.Queue.
            # Infra errors → retry on same/other store, max MAX_RETRIES times.
            # After MAX_RETRIES → count as ERROR so done counter always reaches total.
            MAX_RETRIES   = 3   # max infra retries per card before counting as error
            card_queue    = asyncio.Queue()
            retry_counts: dict = {}  # card_str → retry count
            _disabled_urls: set  = set()  # stores disabled mid-run (avoid re-checking)
            for card in cards:
                await card_queue.put(card)

            all_store_tasks = []
            # Stall detection: track when done counter LAST changed
            # Only exit if done hasn't moved for 90 seconds (real stall)
            _stall_last_done  = [0]
            _stall_last_time  = [time.monotonic()]

            async def store_pool_worker(store: dict):
                """One worker pool per store. Pulls from shared queue, CARDS_PER_STORE at once."""
                store_url   = store.get("base_url", "")
                sem_store   = asyncio.Semaphore(CARDS_PER_STORE)
                inner_tasks = []
                dispatched  = 0

                async def check_card_on_store(card):
                    try:
                        if stop_event.is_set() or not _active_checks.get(sess_key, True):
                            async with lock:
                                nonlocal done
                                done += 1
                            return
                        t0 = time.monotonic()
                        try:
                            result = await check_shopify_on_store(card, store)
                        except asyncio.CancelledError:
                            raise
                        except Exception as ex:
                            from gateways.base import GatewayResult
                            result = GatewayResult(
                                status=CCStatus.ERROR, gateway="Shopify",
                                message=str(ex)[:60], raw_code="cart_exception"
                            )

                        # Infra error handling — retry up to MAX_RETRIES times
                        if result.status == CCStatus.ERROR and result.raw_code in INFRA_ERROR_CODES:
                            # Track consecutive failures → auto-disable bad stores
                            try:
                                from gateways.shopify_gate import _track_infra_fail as _tif
                                await _tif(store, result.raw_code)
                            except Exception:
                                pass
                            # If store got auto-disabled, add to local blacklist
                            if store.get("is_active", 1) == 0:
                                _disabled_urls.add(store_url)

                            card_key = f"{card.number}"
                            retries  = retry_counts.get(card_key, 0)
                            if retries < MAX_RETRIES:
                                retry_counts[card_key] = retries + 1
                                await card_queue.put(card)
                            else:
                                await _collect_result(card, result, t0)
                            return

                        await _collect_result(card, result, t0)
                    finally:
                        sem_store.release()

                while True:
                    if stop_event.is_set() or not _active_checks.get(sess_key, True):
                        break

                    # Exit immediately if this store was disabled (DB auto-disable or local blacklist)
                    if store_url in _disabled_urls:
                        logger.info(f"Store {store_url} disabled mid-run — worker exiting")
                        break

                    # Stall guard: exit if done counter hasn't moved in 90 seconds
                    async with lock:
                        _curr_done = done
                    if _curr_done != _stall_last_done[0]:
                        _stall_last_done[0] = _curr_done
                        _stall_last_time[0]  = time.monotonic()
                    elif time.monotonic() - _stall_last_time[0] > 90:
                        logger.warning(f"Store-pool stall: done={_curr_done}/{total} unchanged for 90s — exiting")
                        break

                    # Acquire semaphore first to check store capacity before pulling card from queue
                    await sem_store.acquire()

                    # Try to get a card
                    card = None
                    try:
                        card = card_queue.get_nowait()
                    except asyncio.QueueEmpty:
                        pass

                    if card is None:
                        sem_store.release()
                        async with lock:
                            current_done = done
                        if current_done >= total:
                            break
                        await asyncio.sleep(0.05)
                        continue

                    task = asyncio.ensure_future(check_card_on_store(card))
                    inner_tasks.append(task)
                    dispatched += 1

                    # Periodically purge completed tasks to prevent memory growth
                    if dispatched % 20 == 0:
                        inner_tasks = [t for t in inner_tasks if not t.done()]

                # Wait for this store's remaining in-flight tasks
                if inner_tasks:
                    await asyncio.gather(*[t for t in inner_tasks if not t.done()],
                                         return_exceptions=True)

            # Launch all store pools simultaneously
            for store in shopify_stores:
                t = asyncio.ensure_future(store_pool_worker(store))
                all_store_tasks.append(t)
            _active_tasks[sess_key] = list(all_store_tasks)

            try:
                await asyncio.gather(*all_store_tasks, return_exceptions=True)
            except asyncio.CancelledError:
                for t in all_store_tasks:
                    t.cancel()
                raise

        else:
            # ── FALLBACK: Standard semaphore approach for non-Shopify gates ──────
            sem = asyncio.Semaphore(fallback_workers)

            async def check_one(card):
                nonlocal last_edit_time
                if stop_event.is_set() or not _active_checks.get(sess_key, True):
                    return
                async with sem:
                    if stop_event.is_set() or not _active_checks.get(sess_key, True):
                        return
                    t0 = time.monotonic()
                    result = await route_and_check(card)
                    await _collect_result(card, result, t0)

            all_tasks = [asyncio.ensure_future(check_one(card)) for card in cards]
            _active_tasks[sess_key] = all_tasks
            await asyncio.gather(*all_tasks, return_exceptions=True)


        was_stopped = not _active_checks.pop(sess_key, True)
        _stop_events.pop(sess_key, None)
        _active_tasks.pop(sess_key, None)  # cleanup
        elapsed = time.monotonic() - start
        await db.increment_check_count(msg.from_user.id)

        # Construct live cards list for progress formatter
        live_lines = []
        for r in charged_results:
            live_lines.append(f"{r['card']} [✅ LIVE] {r['scheme']} | {r['bank']} | {r['country']} | {r['response']} | {r['time']}")
        for r in vbv_results:
            live_lines.append(f"{r['card']} [🔐 VBV] {r['scheme']} | {r['bank']} | {r['country']} | {r['response']} | {r['time']}")

        # ── Final Summary ───────────────────────────────────────────────────────
        if was_stopped:
            final_text = (
                f"🛑 **Mass Check Stopped by User!**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"📊 **Progress:** `{done}/{total}`\n"
                f"✅ **Charged:** `{non_vbv_count}`\n"
                f"🔐 **VBV:** `{vbv_count}`\n"
                f"❌ **Dead:** `{dead_count}`\n"
                f"❓ **Error:** `{error_count}`\n"
                f"⏱️ **Time:** `{elapsed:.1f}s`"
            )
        else:
            final_text = format_mass_complete(
                total=total,
                live=live_count,
                dead=dead_count,
                vbv=vbv_count,
                non_vbv=non_vbv_count,
                errors=error_count,
                elapsed=elapsed,
                live_cards=live_lines,
            )
        await wait_msg.edit_text(final_text, parse_mode=enums.ParseMode.MARKDOWN)

        # ── Send results as .txt file ────────────────────────────────────────
        lines = [
            "=" * 60,
            "⚡ CC CHECKER PRO — MASS CHECK RESULTS" + (" (STOPPED BY USER)" if was_stopped else ""),
            f"📋 Total Checked: {done}/{total} | ✅ Charged: {non_vbv_count} | 🔐 VBV: {vbv_count} | ❌ Dead: {dead_count} | ❓ Error: {error_count}",
            f"⚡ Mode: {'Store-Pool' if use_store_pool else 'Standard'} | Parallel: {total_concurrent} | ⏱️ Time: {elapsed:.1f}s",
            "=" * 60,
            "",
        ]

        if charged_results:
            lines.append(f"✅ CHARGE APPROVED ({len(charged_results)} cards)")
            lines.append("-" * 60)
            for r in charged_results:
                lines.append(f"{r['card']} | Status: {r['tag']} | Amount: {r['amount']} | Gate: {r['gateway']} | Response: {r['response']} | Info: {r['scheme']} | Bank: {r['bank']} | Country: {r['country']} | Time: {r['time']}")
            lines.append("")

        if vbv_results:
            lines.append(f"🔐 VBV / OTP REQUIRED ({len(vbv_results)} cards)")
            lines.append("-" * 60)
            for r in vbv_results:
                lines.append(f"{r['card']} | Status: {r['tag']} | Amount: {r['amount']} | Gate: {r['gateway']} | Response: {r['response']} | Info: {r['scheme']} | Bank: {r['bank']} | Country: {r['country']} | Time: {r['time']}")
            lines.append("")

        if dead_results:
            lines.append(f"❌ DEAD / DECLINED ({len(dead_results)} cards)")
            lines.append("-" * 60)
            for r in dead_results:
                lines.append(f"{r['card']} | Amount: {r['amount']} | Gate: {r['gateway']} | Response: {r['response']} | Info: {r['scheme']} | Bank: {r['bank']} | Country: {r['country']} | Time: {r['time']}")
            lines.append("")

        if error_results:
            lines.append(f"❓ ERRORS ({len(error_results)} cards)")
            lines.append("-" * 60)
            for r in error_results:
                lines.append(f"{r['card']} | Amount: {r['amount']} | Gate: {r['gateway']} | Response: {r['response']} | Time: {r['time']}")
            lines.append("")

        results_text = "\n".join(lines)
        tmp_file = tempfile.NamedTemporaryFile(
            mode="w", suffix="_mass_results.txt",
            delete=False, encoding="utf-8"
        )
        tmp_file.write(results_text)
        tmp_file.close()

        try:
            caption = (
                f"⚡ **Mass Check Results" + (" (Stopped)" if was_stopped else "") + "**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"✅ **Charged:** `{non_vbv_count}`\n"
                f"🔐 **VBV:** `{vbv_count}`\n"
                f"❌ **Dead:** `{dead_count}`\n"
                f"📋 **Checked:** `{done}/{total}` | ⏱️ `{elapsed:.1f}s`"
            )
            file_name_txt = f"mass_results_stopped_{done}of{total}.txt" if was_stopped else f"mass_results_{total}cards.txt"
            await client.send_document(
                msg.chat.id,
                tmp_file.name,
                caption=caption,
                parse_mode=enums.ParseMode.MARKDOWN,
                file_name=file_name_txt,
            )
        finally:
            os.unlink(tmp_file.name)
