"""
handlers/commands.py — /start, /help, /stats, /gates, /id, /setcmds
All commands: ADMIN ONLY (except /start which shows access denied to non-admins)
"""
from pyrogram import Client, filters, enums
from pyrogram.types import Message, BotCommand
from datetime import datetime, timezone
import config
import database.db as db
from utils.formatter import format_bin_info
from core.bin_lookup import lookup_bin
from utils.error_handler import notify_owner_on_error



def _is_admin(user_id: int) -> bool:
    return user_id in config.OWNER_IDS


async def _admin_denied(msg: Message):
    await msg.reply(
        "🚫 **Access Denied!**\n\n"
        "This bot is **private** — admin only.\n"
        "Contact the owner for access.",
        parse_mode=enums.ParseMode.MARKDOWN
    )


START_TEXT = """
⚡ **CC Checker Pro** — Private Admin Bot

━━━━━━━━━━━━━━━━━━━━━━
💳 **CC Checker (2-Stage Pipeline):**
• `/chk <cc>` — Single card check
• `/mchk` — Mass check (.txt file)
  ↳ Stage 1: B3 Braintree (filter dead)
  ↳ Stage 2: Shopify/Razorpay (charge live cards)

━━━━━━━━━━━━━━━━━━━━━━
🛒 **Shopify Gate:**
• `/addshopify <url>` — Add Shopify store as gate
• `/shopifygates` — List saved Shopify gates
• `/scshopify <url>` — Scan only (don't save)
• `/rmshopify <id>` — Remove a gate (admin)

━━━━━━━━━━━━━━━━━━━━━━
🔵 **B3 Braintree Gate (Standalone):**
• `/b3chk <cc>` — B3-only single check
• `/b3mchk` — B3-only mass check
• `/b3status` — Gate status & stats
• `/b3site <url>` — Set WooCommerce site
• `/b3addpair` — Add cookie pair
• `/b3pairs` — List cookie pairs
• `/b3delpair <id>` — Delete pair

━━━━━━━━━━━━━━━━━━━━━━
🎯 **Gate Scanner:**
• `/gscan <url>` — Scan Stripe gate
• `/mgscan` — Mass scan (.txt)
• `/mygates` — View Stripe gates

━━━━━━━━━━━━━━━━━━━━━━
🛠️ **Tools:**
• `/gen <bin>` — Generate cards from BIN
• `/bin <bin>` — BIN info lookup
• `/gates` — Gateway status
• `/stats` — Your stats
"""

HELP_TEXT = """
📖 **CC Checker Pro — Full Command List**

━━━━━━━━━━━━━━━━━━━━━━
🔁 **CC CHECKER (2-STAGE PIPELINE):**
`/chk 4111|12|2026|123` — Single card check
  → Stage 1: B3 Braintree (WooCommerce cookies)
  → Dead cards stop here (Razorpay skipped!)
  → Live cards → Stage 2: Razorpay (INR charge)

`/mchk` — Mass check (.txt file)
  → Same 2-stage pipeline for every card
  → Live cards .txt file sent at end

━━━━━━━━━━━━━━━━━━━━━━
🔵 **B3 BRAINTREE GATE (STANDALONE):**
`/b3chk 4111|12|2026|123` — B3-only check
  → No Razorpay, no charge
  → Uses WooCommerce cookies

`/b3mchk` — B3-only mass check (.txt)
  → Only B3 Braintree, no Razorpay
  → 3 workers (WooCommerce rate limit)

**B3 Configuration:**
`/b3status` — Gate status, stats, hit rate
`/b3site <url>` — Set WooCommerce site URL
`/b3addpair` — Add cookie pair (guided flow)
`/b3pairs` — List all cookie pairs
`/b3delpair <id>` — Remove a cookie pair

━━━━━━━━━━━━━━━━━━━━━━
🎯 **GATE SCANNER:**
`/gscan https://example.com` — Scan for Stripe gate
`/mgscan` — Mass scan (upload .txt)
`/mygates` — View scraped Stripe gates
`/delgate <id>` — Delete a Stripe gate

━━━━━━━━━━━━━━━━━━━━━━
🛠️ **TOOLS:**
`/setworkers <num>` — Set checking workers count (owner only)
`/gen 414720` — Generate 10 cards
`/gen 414720|xx|2026|xxx` — Fixed year
`/bin 414720` — BIN info lookup
`/stats` — Your check stats
`/gates` — Gateway status panel
`/setcmds` — Register commands in BotFather


━━━━━━━━━━━━━━━━━━━━━━
📊 **Result Codes:**
✅ `LIVE` — Card charged / added!
⚠️ `INSUFFICIENT` — Card LIVE, no balance
🔐 `LIVE VBV` — Card live, 3DS/OTP required
❌ `DEAD` — Declined / invalid
"""

# Full command list for BotFather
BOT_COMMANDS = [
    BotCommand("chk",          "Single CC check (pipeline)"),
    BotCommand("mchk",         "Mass CC check .txt (pipeline)"),
    BotCommand("b3chk",        "B3 Braintree only single check"),
    BotCommand("b3mchk",       "B3 Braintree only mass check .txt"),
    BotCommand("b3status",     "B3 gate status and stats"),
    BotCommand("b3site",       "Set B3 WooCommerce target site"),
    BotCommand("b3addpair",    "Add B3 cookie pair (guided)"),
    BotCommand("b3pairs",      "List B3 cookie pairs"),
    BotCommand("b3delpair",    "Delete B3 cookie pair"),
    BotCommand("addshopify",   "Add Shopify store as payment gate"),
    BotCommand("shopifygates", "List all saved Shopify gates"),
    BotCommand("scshopify",    "Scan Shopify site (no save)"),
    BotCommand("rmshopify",    "Remove a Shopify gate by ID"),
    BotCommand("gscan",        "Scan site for Stripe gate"),
    BotCommand("mgscan",       "Mass scan sites (.txt)"),
    BotCommand("mygates",      "View saved Stripe gates"),
    BotCommand("gen",          "Generate cards from BIN"),
    BotCommand("bin",          "BIN info lookup"),
    BotCommand("gates",        "Gateway status"),
    BotCommand("stats",        "Your check stats"),
    BotCommand("setworkers",   "Set concurrent checking workers count"),
    BotCommand("setcmds",      "Update bot command list"),
    BotCommand("help",         "Full command list"),
]


def register_commands(app: Client):

    @app.on_message(filters.command("start"))
    @notify_owner_on_error
    async def start_cmd(client: Client, msg: Message):
        if not _is_admin(msg.from_user.id):
            await msg.reply(
                "🚫 **Private Bot**\n\n"
                "This bot is admin-only.\n"
                "Contact the owner for access.",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return
        await db.upsert_user(
            msg.from_user.id,
            msg.from_user.username or "",
            msg.from_user.first_name or "",
        )
        await msg.reply(START_TEXT, parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("help"))
    @notify_owner_on_error
    async def help_cmd(client: Client, msg: Message):
        if not _is_admin(msg.from_user.id):
            await _admin_denied(msg); return
        await msg.reply(HELP_TEXT, parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("id"))
    @notify_owner_on_error
    async def id_cmd(client: Client, msg: Message):
        await msg.reply(
            f"👤 **Your Telegram ID:** `{msg.from_user.id}`",
            parse_mode=enums.ParseMode.MARKDOWN
        )

    # /setcmds — Register all commands with BotFather
    @app.on_message(filters.command("setcmds"))
    @notify_owner_on_error
    async def setcmds_cmd(client: Client, msg: Message):
        if not _is_admin(msg.from_user.id):
            await _admin_denied(msg); return
        try:
            await client.set_bot_commands(BOT_COMMANDS)
            await msg.reply(
                f"✅ **Bot commands registered!**\n\n"
                f"**{len(BOT_COMMANDS)} commands** set in BotFather.\n"
                f"Now type `/` in chat to see them all.\n\n"
                f"_Commands update may take ~30 seconds to appear._",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
        except Exception as e:
            await msg.reply(
                f"❌ **Failed to set commands:**\n`{e}`",
                parse_mode=enums.ParseMode.MARKDOWN,
            )

    @app.on_message(filters.command("gates"))
    @notify_owner_on_error
    async def gates_cmd(client: Client, msg: Message):
        if not _is_admin(msg.from_user.id):
            await _admin_denied(msg); return

        from gateways.router import get_active_gates

        scraped_count = await db.get_all_gates_count()
        scraped_status = f"✅ {scraped_count} gates saved" if scraped_count > 0 else "⚠️ None — use /gscan"

        try:
            shopify_data = await db.get_shopify_gates_count()
            shopify_count = shopify_data.get("total", 0)
            shopify_status = f"✅ {shopify_count} stores" if shopify_count > 0 else "⚠️ None — use /addshopify"
        except Exception:
            shopify_status = "⚠️ DB not initialized"

        authnet_status   = "✅ Active" if (config.AUTHNET_LOGIN_ID and config.AUTHNET_LOGIN_ID != "your_api_login_id") else "⚠️ Add AUTHNET_LOGIN_ID"
        square_status    = "✅ Active" if (config.SQUARE_ACCESS_TOKEN and config.SQUARE_ACCESS_TOKEN != "your_square_access_token") else "⚠️ Add SQUARE_ACCESS_TOKEN"
        stripe_status    = f"✅ Active ({len(config.STRIPE_PK_KEYS)} PK keys)" if config.STRIPE_PK_KEYS else "⚠️ Not configured"
        bt_status        = "✅ Active" if (config.BT_MERCHANT_ID and config.BT_MERCHANT_ID != "your_merchant_id") else "⚠️ Not configured"

        active_gates = get_active_gates()

        text = (
            f"🔗 **Payment Gateways Status**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🛒 **Shopify Payments** — {shopify_status}\n"
            f"   ↳ `/addshopify <url>` to add stores\n"
            f"0. 🎯 **Scraped Stripe** — {scraped_status}\n"
            f"   ↳ `/gscan <url>` to add more\n"
            f"1. 🟣 **Stripe** — {stripe_status}\n"
            f"   ↳ SetupIntent VBV detection\n"
            f"2. 🏦 **Authorize.net** — {authnet_status}\n"
            f"3. 🟦 **Square** — {square_status}\n"
            f"4. 🔵 **Braintree** — {bt_status}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📋 **Priority:** `{'→'.join(config.GATE_PRIORITY)}`\n"
            f"⚡ **Configured:** `{len(active_gates)}`\n"
            f"🛡️ **VBV Detection:** Active\n"
            f"🔄 **Auto-Failover:** Enabled\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💡 `/sh <cc>` — Shopify gate\n"
            f"💡 `/setcmds` — Refresh command list"
        )
        await msg.reply(text, parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("stats"))
    @notify_owner_on_error
    async def stats_cmd(client: Client, msg: Message):
        if not _is_admin(msg.from_user.id):
            await _admin_denied(msg); return
        user_stats = await db.get_user_stats(msg.from_user.id)
        global_stats = await db.get_global_stats()
        text = (
            f"📊 **Your Stats**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🔢 Checks Today: `{user_stats['today']}`\n"
            f"📈 Total Checks: `{user_stats['total']}`\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🌍 **Global Stats**\n"
            f"👥 Users: `{global_stats['users']}`\n"
            f"🔢 Total Checks: `{global_stats['total_checks']}`\n"
            f"✅ Live Found: `{global_stats['live']}`\n"
            f"❌ Dead: `{global_stats['dead']}`"
        )
        await msg.reply(text, parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("bin"))
    @notify_owner_on_error
    async def bin_cmd(client: Client, msg: Message):
        if not _is_admin(msg.from_user.id):
            await _admin_denied(msg); return
        parts = msg.text.split()
        if len(parts) < 2:
            await msg.reply("❌ Usage: `/bin 414720`", parse_mode=enums.ParseMode.MARKDOWN)
            return

        bin6 = parts[1][:6]
        if not bin6.isdigit() or len(bin6) < 6:
            await msg.reply("❌ Invalid BIN. Must be 6 digits.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        wait_msg = await msg.reply("🔍 Looking up BIN...", parse_mode=enums.ParseMode.MARKDOWN)
        info = await lookup_bin(bin6)

        if not info:
            await wait_msg.edit_text(
                f"❌ No info found for BIN `{bin6}`", parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        await wait_msg.edit_text(format_bin_info(info), parse_mode=enums.ParseMode.MARKDOWN)
