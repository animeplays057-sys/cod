"""
handlers/proxy_handler.py - Proxy Management Commands

Commands:
  /addproxy <proxy>     - Add single proxy (test -> save if OK)
  /addproxies           - Mass add from .txt file (up to 500)
  /proxies              - List all proxies
  /checkproxies         - Live test all proxies against Shopify right now
  /testproxy <id>       - Test specific proxy by ID
  /testallproxy         - Test all proxies (owner only)
  /delproxy <id>        - Delete proxy by ID
  /cleardeadproxy       - Delete all dead proxies (owner only)

Proxy formats:
  host:port
  host:port:user:pass
  socks5://host:port
  socks5://user:pass@host:port
  http://user:pass@host:port

Auto health check: every 30 minutes (background task)
"""
import asyncio
import os
import tempfile

from pyrogram import Client, filters, enums
from pyrogram.types import Message

import config
import database.db as db
from utils.error_handler import notify_owner_on_error

from core.proxy_manager import (
    parse_proxy_string, test_proxy, add_and_test_proxy,
    refresh_proxy_pool,
)


def _is_owner(user_id: int) -> bool:
    return user_id in config.OWNER_IDS


def register_proxy_handler(app: Client):

    @app.on_message(filters.command("addproxy"))
    @notify_owner_on_error
    async def addproxy_cmd(client: Client, msg: Message):
        """Add a single proxy."""
        if not _is_owner(msg.from_user.id):
            await msg.reply("🚫 Owner only command.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        text = msg.text.strip()
        proxy_str = text[len("/addproxy"):].strip()
        if not proxy_str:
            await msg.reply(
                "❌ **Usage:**\n"
                "`/addproxy host:port`\n"
                "`/addproxy host:port:user:pass`\n"
                "`/addproxy socks5://user:pass@host:port`\n\n"
                "📌 Bot tests proxy before saving!",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        wait = await msg.reply(
            f"🔍 Testing proxy `{proxy_str[:50]}`...",
            parse_mode=enums.ParseMode.MARKDOWN,
        )
        success, result_msg, _ = await add_and_test_proxy(proxy_str, added_by=msg.from_user.id)
        await wait.edit_text(result_msg, parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("addproxies") & (filters.document | filters.text))
    @notify_owner_on_error
    async def addproxies_cmd(client: Client, msg: Message):
        """Mass add proxies from .txt file."""
        if not _is_owner(msg.from_user.id):
            await msg.reply("🚫 Owner only.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        doc_msg = None
        if msg.document:
            doc_msg = msg
        elif msg.reply_to_message and msg.reply_to_message.document:
            doc_msg = msg.reply_to_message
        else:
            await msg.reply(
                "❌ Send `.txt` file with caption `/addproxies`\n"
                "One proxy per line:\n"
                "```\n"
                "1.2.3.4:8080\n"
                "1.2.3.5:8080:user:pass\n"
                "socks5://1.2.3.6:1080:user:pass\n"
                "```",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        doc = doc_msg.document
        if doc.file_size > 500_000:
            await msg.reply("❌ Max 500KB.")
            return

        wait = await msg.reply("📥 Downloading proxy list...", parse_mode=enums.ParseMode.MARKDOWN)

        tmp_path = None
        try:
            tmp_path = await client.download_media(doc)
            with open(tmp_path, "r", encoding="utf-8", errors="ignore") as f:
                lines = [l.strip() for l in f.readlines() if l.strip()]
        except Exception as e:
            await wait.edit_text(f"❌ Failed: `{e}`", parse_mode=enums.ParseMode.MARKDOWN)
            return
        finally:
            if tmp_path and os.path.exists(tmp_path):
                os.remove(tmp_path)

        if not lines:
            await wait.edit_text("❌ No proxies found in file.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        total = len(lines)
        if total > 500:
            await wait.edit_text(f"Too many ({total}). Max 500 per batch.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        await wait.edit_text(
            f"🔍 **Testing {total} proxies...**\nThis may take a while...",
            parse_mode=enums.ParseMode.MARKDOWN,
        )

        added = 0
        failed = 0
        invalid = 0
        sem = asyncio.Semaphore(20)  # Test 20 at a time for speed

        async def test_one(proxy_str: str):
            nonlocal added, failed, invalid
            async with sem:
                success, _, _ = await add_and_test_proxy(proxy_str, added_by=msg.from_user.id)
                if success:
                    added += 1
                elif parse_proxy_string(proxy_str):
                    failed += 1
                else:
                    invalid += 1

        await asyncio.gather(*[test_one(line) for line in lines])

        await wait.edit_text(
            f"✅ **Proxy Import Complete!**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"✅ **Added (working):** `{added}`\n"
            f"❌ **Dead (timeout):** `{failed}`\n"
            f"⚠️ **Invalid format:** `{invalid}`\n"
            f"📋 **Total:** `{total}`",
            parse_mode=enums.ParseMode.MARKDOWN,
        )

    @app.on_message(filters.command("proxies"))
    @notify_owner_on_error
    async def proxies_cmd(client: Client, msg: Message):
        """List all proxies."""
        if not _is_owner(msg.from_user.id):
            await msg.reply("🚫 Owner only.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        proxies = await db.get_all_proxies()
        if not proxies:
            await msg.reply(
                "📭 No proxies saved.\n\n"
                "Add proxies:\n"
                "`/addproxy host:port:user:pass`\n"
                "or `/addproxies` with .txt file",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        # Build list
        working = [p for p in proxies if p["is_working"]]
        dead    = [p for p in proxies if not p["is_working"]]

        lines = [
            f"🌐 **Proxy Pool** — `{len(working)}/{len(proxies)}` working",
            "━━━━━━━━━━━━━━━━━━━━━━",
        ]

        for p in proxies[:20]:  # Max 20 shown
            status = "✅" if p["is_working"] else "❌"
            auth   = f"`{p['username']}:***`" if p["username"] else "No auth"
            latency = f"`{p['latency']}ms`" if p["latency"] < 9999 else "`timeout`"
            lines.append(
                f"{status} `#{p['id']}` `{p['host']}:{p['port']}` "
                f"[{p['protocol'].upper()}] {latency}"
            )

        if len(proxies) > 20:
            lines.append(f"... +{len(proxies)-20} more")

        lines += [
            "━━━━━━━━━━━━━━━━━━━━━━",
            f"📊 Working: `{len(working)}` | Dead: `{len(dead)}`",
            "💡 `/testallproxy` — retest all",
            "💡 `/cleardeadproxy` — remove dead ones",
        ]
        await msg.reply("\n".join(lines), parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("testproxy"))
    @notify_owner_on_error
    async def testproxy_cmd(client: Client, msg: Message):
        """Test a specific proxy by ID."""
        if not _is_owner(msg.from_user.id):
            await msg.reply("🚫 Owner only.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        parts = msg.text.strip().split()
        if len(parts) < 2:
            await msg.reply("❌ Usage: `/testproxy <id>`", parse_mode=enums.ParseMode.MARKDOWN)
            return

        try:
            pid = int(parts[1])
        except ValueError:
            await msg.reply("❌ Invalid ID.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        proxy = await db.get_proxy_by_id(pid)
        if not proxy:
            await msg.reply(f"❌ Proxy `#{pid}` not found.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        wait = await msg.reply(
            f"🔍 Testing `{proxy['host']}:{proxy['port']}`...",
            parse_mode=enums.ParseMode.MARKDOWN,
        )
        working, latency = await test_proxy(proxy)
        await db.update_proxy_result(pid, working, latency)
        await refresh_proxy_pool()

        if working:
            await wait.edit_text(
                f"✅ **Proxy Working!**\n"
                f"🌐 `{proxy['host']}:{proxy['port']}`\n"
                f"⚡ Latency: `{latency}ms`",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
        else:
            await wait.edit_text(
                f"❌ **Proxy Dead!**\n"
                f"🌐 `{proxy['host']}:{proxy['port']}`\n"
                f"💡 Use `/delproxy {pid}` to remove",
                parse_mode=enums.ParseMode.MARKDOWN,
            )

    @app.on_message(filters.command("testallproxy"))
    @notify_owner_on_error
    async def testallproxy_cmd(client: Client, msg: Message):
        """Test all proxies (owner only)."""
        if not _is_owner(msg.from_user.id):
            await msg.reply("🚫 Owner only.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        proxies = await db.get_all_proxies()
        if not proxies:
            await msg.reply("📭 No proxies to test.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        wait = await msg.reply(
            f"🔍 Testing `{len(proxies)}` proxies...",
            parse_mode=enums.ParseMode.MARKDOWN,
        )

        working_count = 0
        dead_count = 0
        sem = asyncio.Semaphore(10)

        async def test_one(p: dict):
            nonlocal working_count, dead_count
            async with sem:
                ok, latency = await test_proxy(p)
                await db.update_proxy_result(p["id"], ok, latency)
                if ok:
                    working_count += 1
                else:
                    dead_count += 1

        await asyncio.gather(*[test_one(p) for p in proxies])
        await refresh_proxy_pool()

        await wait.edit_text(
            f"✅ **Test Complete!**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"✅ Working: `{working_count}`\n"
            f"❌ Dead: `{dead_count}`\n"
            f"📋 Total: `{len(proxies)}`",
            parse_mode=enums.ParseMode.MARKDOWN,
        )

    @app.on_message(filters.command("delproxy"))
    @notify_owner_on_error
    async def delproxy_cmd(client: Client, msg: Message):
        """Delete proxy by ID."""
        if not _is_owner(msg.from_user.id):
            await msg.reply("🚫 Owner only.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        parts = msg.text.strip().split()
        if len(parts) < 2:
            await msg.reply("❌ Usage: `/delproxy <id>`", parse_mode=enums.ParseMode.MARKDOWN)
            return

        try:
            pid = int(parts[1])
        except ValueError:
            await msg.reply("❌ Invalid ID.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        await db.delete_proxy(pid)
        await refresh_proxy_pool()
        await msg.reply(f"✅ Proxy `#{pid}` deleted.", parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("cleardeadproxy"))
    @notify_owner_on_error
    async def cleardeadproxy_cmd(client: Client, msg: Message):
        """Delete all dead proxies."""
        if not _is_owner(msg.from_user.id):
            await msg.reply("Owner only.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        await db.clear_dead_proxies()
        await refresh_proxy_pool()
        await msg.reply("All dead proxies cleared!", parse_mode=enums.ParseMode.MARKDOWN)

    @app.on_message(filters.command("checkproxies"))
    @notify_owner_on_error
    async def checkproxies_cmd(client: Client, msg: Message):
        """Live test all proxies against Shopify checkout right now."""
        if not _is_owner(msg.from_user.id):
            await msg.reply("Owner only.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        proxies = await db.get_all_proxies()
        if not proxies:
            await msg.reply(
                "No proxies saved.\n\nAdd with /addproxies (send .txt file with caption /addproxies)\n"
                "Format: host:port:user:pass (one per line)",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        wait = await msg.reply(
            f"Testing {len(proxies)} proxies against Shopify...\nThis takes ~15 seconds...",
            parse_mode=enums.ParseMode.MARKDOWN,
        )

        import aiohttp as _aio
        from core.proxy_manager import _build_proxy_url
        TEST_URL = "https://www.brio4life.com/checkout"

        async def _shopify_test(p: dict):
            url = _build_proxy_url(p)
            try:
                conn = _aio.TCPConnector(ssl=False)
                async with _aio.ClientSession(connector=conn) as s:
                    async with s.get(
                        TEST_URL, proxy=url,
                        timeout=_aio.ClientTimeout(total=12),
                        allow_redirects=True, max_redirects=10,
                        headers={"User-Agent": "Mozilla/5.0 Chrome/120"}
                    ) as r:
                        ok = r.status in (200, 302, 301)
                        await db.update_proxy_result(p["id"], ok, 999)
                        return ok, p
            except Exception:
                await db.update_proxy_result(p["id"], False, 9999)
                return False, p

        sem = asyncio.Semaphore(20)
        async def _sem_test(p):
            async with sem:
                return await _shopify_test(p)

        results = await asyncio.gather(*[_sem_test(p) for p in proxies])
        await refresh_proxy_pool()

        live  = [p for ok, p in results if ok]
        dead  = [p for ok, p in results if not ok]

        lines = [
            f"Shopify Proxy Check Complete",
            f"{'='*30}",
            f"LIVE: {len(live)} | DEAD: {len(dead)} | TOTAL: {len(proxies)}",
            f"{'='*30}",
        ]
        if live:
            lines.append("WORKING PROXIES:")
            for p in live:
                user = f"{p['username']}:***@" if p.get('username') else ""
                lines.append(f"  OK  {p['protocol']}://{user}{p['host']}:{p['port']}")
        if dead:
            lines.append("DEAD PROXIES:")
            for p in dead[:5]:
                lines.append(f"  DEAD #{p['id']} {p['host']}:{p['port']}")
            if len(dead) > 5:
                lines.append(f"  ... +{len(dead)-5} more dead")

        lines.append("")
        if not live:
            lines.append("WARNING: No working proxies! Checks will use direct IP.")
            lines.append("Add proxies: /addproxies with .txt file")
        else:
            lines.append(f"Pool refreshed. Using {len(live)} live proxies for checks.")

        await wait.edit_text("\n".join(lines), parse_mode=enums.ParseMode.MARKDOWN)


async def auto_proxy_health_check(client: Client):
    """
    Background task: test all proxies against Shopify every 30 minutes.
    Dead proxies are marked as is_working=0 in DB.
    Pool is refreshed after each check.
    """
    import aiohttp as _aio
    from core.proxy_manager import _build_proxy_url
    logger = __import__('logging').getLogger("CC-Checker.Proxy")
    TEST_URL = "https://www.brio4life.com/checkout"
    INTERVAL = 30 * 60  # 30 minutes

    await asyncio.sleep(60)  # Wait 60s after bot start before first check

    while True:
        try:
            proxies = await db.get_all_proxies()
            if proxies:
                logger.info(f"Auto health check: testing {len(proxies)} proxies...")

                async def _check(p):
                    url = _build_proxy_url(p)
                    try:
                        conn = _aio.TCPConnector(ssl=False)
                        async with _aio.ClientSession(connector=conn) as s:
                            async with s.get(
                                TEST_URL, proxy=url,
                                timeout=_aio.ClientTimeout(total=12),
                                allow_redirects=True, max_redirects=10,
                                headers={"User-Agent": "Mozilla/5.0 Chrome/120"}
                            ) as r:
                                ok = r.status in (200, 302, 301)
                                await db.update_proxy_result(p["id"], ok, 999 if ok else 9999)
                                return ok
                    except Exception:
                        await db.update_proxy_result(p["id"], False, 9999)
                        return False

                sem = asyncio.Semaphore(20)
                async def _sem(p):
                    async with sem:
                        return await _check(p)

                results = await asyncio.gather(*[_sem(p) for p in proxies], return_exceptions=True)
                live = sum(1 for r in results if r is True)
                dead = len(proxies) - live
                await refresh_proxy_pool()
                logger.info(f"Auto health check done: {live} live, {dead} dead")
        except Exception as e:
            logger.warning(f"Auto proxy health check error: {e}")

        await asyncio.sleep(INTERVAL)
