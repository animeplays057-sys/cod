"""
handlers/shopify_handler.py — Bot Commands for Shopify Gate Management

Commands:
  /addshopify <url>     — Scan URL and add as Shopify gate if working
  /shopifygates         — List all saved Shopify gates
  /rmshopify <id>       — Remove a Shopify gate by ID (admin only)
  /scshopify <url>      — Scan only (don't save to DB)
"""
import asyncio
import logging
import re
import os
import sys
import html as html_module
import json
import time

import aiohttp
from aiohttp import ClientTimeout, CookieJar
from pyrogram import Client, filters
from pyrogram import enums

import config
import database.db as db
from utils.error_handler import notify_owner_on_error


logger = logging.getLogger("CC-Checker.ShopifyHandler")

TIMEOUT       = ClientTimeout(total=25)
VAULT_TIMEOUT = ClientTimeout(total=12)

BROWSER_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/125.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,*/*;q=0.9",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate",
    "Connection": "keep-alive",
}

SEP = "━" * 22


def _is_owner(user_id: int) -> bool:
    return user_id in config.OWNER_IDS


def _extract_meta(html: str, name: str) -> str | None:
    m = re.search(
        r'name=["\']' + re.escape(name) + r'["\'][^>]+content=["\']([^"\']{3,})["\']',
        html
    )
    if not m:
        return None
    val = html_module.unescape(m.group(1)).strip()
    if val.startswith('"') and val.endswith('"'):
        val = val[1:-1]
    return val or None


def _pick_best_variant(products: list) -> dict | None:
    """Pick cheapest available variant between $1-$10, else cheapest overall."""
    candidates = []
    for p in products:
        for v in p.get("variants", []):
            if not v.get("available", True):
                continue
            try:
                price = float(v.get("price", 999))
            except Exception:
                continue
            candidates.append({
                "variant_id":    v.get("id"),
                "price":         f"{price:.2f}",
                "price_f":       price,
                "product_title": p.get("title", ""),
                "handle":        p.get("handle", ""),
            })

    if not candidates:
        return None

    preferred = [c for c in candidates if 1.0 <= c["price_f"] <= 10.0]
    if preferred:
        return min(preferred, key=lambda x: x["price_f"])
    return min(candidates, key=lambda x: x["price_f"])


def _extract_unique_id(html: str) -> str:
    """Extract unique_id from Shopify identification JWT in checkout HTML."""
    import base64 as _b64
    jwts = re.findall(r'eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+', html)
    for jwt in jwts:
        try:
            parts = jwt.split(".")
            pad   = parts[1] + "=" * (4 - len(parts[1]) % 4)
            payload = json.loads(_b64.b64decode(pad))
            uid = payload.get("unique_id", "")
            if uid and len(uid) == 32:
                return uid
        except Exception:
            pass
    return ""


async def _scan_shopify_site(url: str) -> dict:
    """Full Shopify site scan with proper delivery handle extraction."""
    import urllib.parse as _urlparse

    base = url.rstrip("/")
    if not base.startswith("http"):
        base = "https://" + base

    result = {
        "url": base, "status": "FAIL", "reason": "",
        "is_shopify": False,
        "shop_domain": "", "shop_id": "", "variant_id": None,
        "product_title": "", "price": "", "currency": "USD",
        "checkout_type": "", "session_token": False, "vault_ok": False,
        "scan_data": {},
    }

    jar  = CookieJar(unsafe=True)
    conn = aiohttp.TCPConnector(ssl=False, limit=3, force_close=True)

    try:
        async with aiohttp.ClientSession(connector=conn, cookie_jar=jar) as s:

            # ── 1. Homepage ───────────────────────────────────────────────
            try:
                async with s.get(base, headers=BROWSER_HEADERS, ssl=False,
                                  timeout=TIMEOUT, allow_redirects=True) as r:
                    hp = await r.text(errors="ignore")
            except Exception as e:
                result["reason"] = f"Homepage error: {str(e)[:40]}"
                return result

            is_shopify = (
                "shopify" in hp.lower()
                or "myshopify.com" in hp.lower()
                or "cdn.shopify.com" in hp.lower()
            )
            if not is_shopify:
                result["reason"] = "Not a Shopify site"
                return result

            result["is_shopify"] = True

            m = re.search(r'["\']([\w\-]+\.myshopify\.com)["\']', hp)
            result["shop_domain"] = m.group(1) if m else ""
            m = re.search(r'["\']?shop(?:Id|_id)["\']?[\s:=]+(\d{5,12})', hp, re.I)
            result["shop_id"] = m.group(1) if m else ""

            # ── 2. Products ───────────────────────────────────────────────
            try:
                async with s.get(
                    base + "/products.json?limit=50",
                    headers={**BROWSER_HEADERS, "Accept": "application/json"},
                    ssl=False, timeout=TIMEOUT,
                ) as r:
                    pj = await r.json(content_type=None)
                products = pj.get("products", [])
            except Exception:
                result["reason"] = "Products API failed"
                return result

            if not products:
                result["reason"] = "No products found"
                return result

            variant = _pick_best_variant(products)
            if not variant:
                result["reason"] = "No available variants"
                return result

            result["variant_id"]    = variant["variant_id"]
            result["product_title"] = variant["product_title"]
            result["price"]         = variant["price"]
            result["scan_data"]["products_count"] = len(products)

            # ── 3. Add to cart ────────────────────────────────────────────
            try:
                async with s.post(
                    base + "/cart/add.js",
                    data=f"id={variant['variant_id']}&quantity=1",
                    headers={
                        **BROWSER_HEADERS,
                        "Content-Type": "application/x-www-form-urlencoded",
                        "Accept": "application/json",
                        "X-Requested-With": "XMLHttpRequest",
                    },
                    ssl=False, timeout=TIMEOUT,
                ) as r:
                    if r.status not in (200, 201):
                        result["reason"] = f"Cart add HTTP {r.status}"
                        return result
            except Exception as e:
                result["reason"] = f"Cart error: {str(e)[:40]}"
                return result

            # ── 4. Checkout page ──────────────────────────────────────────
            try:
                async with s.get(
                    base + "/checkout",
                    headers={**BROWSER_HEADERS, "Referer": base + "/cart"},
                    ssl=False, timeout=TIMEOUT,
                    allow_redirects=True, max_redirects=15,
                ) as r:
                    checkout_url  = str(r.url)
                    checkout_html = await r.text(errors="ignore")
                    if r.status not in (200, 201):
                        result["reason"] = f"Checkout HTTP {r.status}"
                        return result
            except Exception as e:
                result["reason"] = f"Checkout error: {str(e)[:40]}"
                return result

            session_token = _extract_meta(checkout_html, "serialized-sessionToken")
            layout        = _extract_meta(checkout_html, "serialized-checkoutLayout")
            checkout_sess = _extract_meta(checkout_html, "serialized-checkoutSessionIdentifier")
            stripe_pks    = re.findall(r'pk_(?:live|test)_[a-zA-Z0-9]{24,}', checkout_html)

            # Extract checkout_id from URL
            m_coid = re.search(r"/checkouts/cn/([a-zA-Z0-9]+)", checkout_url)
            checkout_id = m_coid.group(1) if m_coid else ""

            # Extract payment_method_id
            m_pmid = re.search(r'paymentMethodIdentifier["\s:=]+["\']([a-f0-9]{32})["\']', checkout_html)
            payment_method_id = m_pmid.group(1) if m_pmid else "dc2c83c064fc75ebc5dfa2b5bee4f873"

            # Extract unique_id from JWT (needed for delivery handle prefix)
            unique_id = _extract_unique_id(checkout_html)

            result["checkout_type"] = layout or "unknown"
            result["scan_data"].update({
                "checkout_url":       checkout_url,
                "checkout_id":        checkout_id,
                "checkout_sess":      checkout_sess,
                "layout":             layout,
                "stripe_pk":          stripe_pks,
                "html_size":          len(checkout_html),
                "payment_method_id":  payment_method_id,
            })

            if not session_token:
                result["reason"] = "No session token (JS-rendered checkout?)"
                return result

            result["session_token"] = True

            # ── 5. PCI Vault test ─────────────────────────────────────────
            try:
                async with s.post(
                    "https://checkout.pci.shopifyinc.com/sessions",
                    json={"credit_card": {"number": "4242424242424242", "name": "Test User",
                                          "month": 12, "year": 2028, "verification_value": "123"}},
                    headers={
                        "Authorization": f'Bearer "{session_token}"',
                        "Content-Type":  "application/json",
                        "Accept":        "application/json",
                        "Origin":        "https://checkout.pci.shopifyinc.com",
                        "Referer":       checkout_url,
                        "User-Agent":    BROWSER_HEADERS["User-Agent"],
                    },
                    ssl=False, timeout=VAULT_TIMEOUT,
                ) as r:
                    vault_status = r.status
                    vault_body   = await r.text(errors="ignore")
            except Exception as e:
                vault_status = 0
                vault_body   = str(e)[:100]

            result["scan_data"]["vault_status"]   = vault_status
            result["scan_data"]["vault_response"] = vault_body[:150]

            try:
                vj = json.loads(vault_body)
                result["vault_ok"] = bool(vj.get("id") or vault_status == 422)
            except Exception:
                result["vault_ok"] = vault_status == 422

            # ── 6. Delivery handle — use SAME checkout cart (cookie) ──────
            # Key fix: cart cookie = checkout_id?key=... -> same session GID
            delivery_handle = ""
            if result["vault_ok"]:
                try:
                    sf_ep  = base + "/api/2024-01/graphql.json"
                    sf_hdr = {**BROWSER_HEADERS, "Accept": "application/json",
                              "Content-Type": "application/json"}

                    # Get cart GID from cookie (same session as checkout)
                    cart_gid = ""
                    try:
                        for cookie in s.cookie_jar:
                            if cookie.key == "cart":
                                val = _urlparse.unquote(cookie.value)
                                if "?key=" in val:
                                    cart_gid = f"gid://shopify/Cart/{val}"
                                    break
                    except Exception:
                        pass

                    if not cart_gid:
                        # Fallback: create new cart
                        async with s.post(sf_ep, json={"query": """mutation cartCreate($input: CartInput!) {
  cartCreate(input: $input) { cart { id } userErrors { message } }
}""", "variables": {"input": {"lines": [{"merchandiseId": f"gid://shopify/ProductVariant/{variant['variant_id']}", "quantity": 1}]}}},
                            headers=sf_hdr, ssl=False, timeout=ClientTimeout(total=10)) as r:
                            cj_r = await r.json(content_type=None)
                        cart_gid = ((cj_r.get("data") or {}).get("cartCreate") or {}).get("cart", {}).get("id", "")

                    if cart_gid:
                        async with s.post(sf_ep, json={"query": """mutation cartBuyerIdentityUpdate($cartId: ID!, $buyerIdentity: CartBuyerIdentityInput!) {
  cartBuyerIdentityUpdate(cartId: $cartId, buyerIdentity: $buyerIdentity) {
    cart { deliveryGroups(first: 3) { nodes { deliveryOptions { handle title } } } }
    userErrors { message }
  }
}""", "variables": {
                            "cartId": cart_gid,
                            "buyerIdentity": {
                                "email": "test@example.com",
                                "countryCode": "US",
                                "deliveryAddressPreferences": [{"deliveryAddress": {
                                    "firstName": "John", "lastName": "Doe",
                                    "address1": "123 Main St", "city": "Hudson",
                                    "province": "WY", "zip": "82515", "country": "US",
                                }}]
                            }
                        }}, headers=sf_hdr, ssl=False, timeout=ClientTimeout(total=12)) as r:
                            dj = await r.json(content_type=None)

                        nodes = (((dj.get("data") or {}).get("cartBuyerIdentityUpdate") or {})
                                 .get("cart", {}).get("deliveryGroups", {}).get("nodes") or [])
                        if nodes:
                            opts = nodes[0].get("deliveryOptions") or []
                            if opts:
                                rate_handle = opts[0].get("handle", "")
                                # Compose full 64-char handle: unique_id-rate_handle
                                if unique_id and rate_handle:
                                    delivery_handle = f"{unique_id}-{rate_handle}"
                                elif rate_handle:
                                    delivery_handle = rate_handle
                except Exception as e:
                    result["scan_data"]["delivery_handle_error"] = str(e)[:80]

            result["scan_data"]["delivery_handle"] = delivery_handle

            # ── Gate quality check ─────────────────────────────────────────
            # Only add store if BOTH vault works AND delivery handle found
            if not result["vault_ok"]:
                result["reason"] = f"PCI Vault failed (status {vault_status}) — Shopify Payments not active"
                return result

            if not delivery_handle:
                result["reason"] = "No US delivery option available — store ships US only to specific regions"
                return result

            # ── 7. Real card gateway test ──────────────────────────────────
            # Test with a known-dead generic card to confirm gateway is live.
            # A live gateway always returns DECLINED or VBV for this card.
            # cart_error / no_payment / exception = store is broken → don't save.
            result["scan_data"]["card_test"] = "pending"
            try:
                from gateways.shopify_gate import check_shopify as _check_shopify, invalidate_stores_cache
                from core.parser import CardData as _CardData
                import database.db as _db

                # Build a minimal store dict as the gate expects
                _store_override = {
                    "base_url":         base,
                    "variant_id":       result["variant_id"],
                    "price":            result["price"],
                    "currency":         result["currency"],
                    "payment_method_id": payment_method_id,
                    "gate_id":          None,  # no DB id yet
                    "scan_data":        result["scan_data"],
                }

                # Generic test card — always declined on a live gateway, never charged
                _test_card = _CardData(
                    number="4242424242424242",
                    month="12",
                    year="2028",
                    cvv="123",
                )

                # Temporarily inject the store into the gate's cache so check_shopify uses it
                from gateways import shopify_gate as _sg
                _old_cache = list(_sg._stores_cache)
                _sg._stores_cache = [_store_override]
                _sg._stores_cache_ts = 1e18  # very far future → won't reload

                try:
                    _test_result = await _check_shopify(_test_card)
                finally:
                    # Restore original cache
                    _sg._stores_cache = _old_cache
                    _sg._stores_cache_ts = 0.0

                gate_status_code = _test_result.raw_code or ""
                gate_msg         = _test_result.message or ""
                result["scan_data"]["card_test"] = f"{gate_status_code} | {gate_msg[:60]}"

                # GOOD responses = gateway is live:
                #   declined / vbv / 3ds / insufficient = card processed and response returned
                GATEWAY_LIVE_CODES = {"declined", "vbv", "3ds", "submit_failed", "insufficient", "stolen_card"}

                if gate_status_code not in GATEWAY_LIVE_CODES:
                    result["reason"] = f"Gateway test failed: {gate_msg[:60]} [{gate_status_code}]"
                    return result

                # If we got here, gateway is live ✅
                result["scan_data"]["gateway_test_shot"] = _test_result.raw_code

            except Exception as _e:
                # If card test itself throws an exception, be conservative and skip store
                result["reason"] = f"Card test exception: {str(_e)[:60]}"
                return result

            result["status"] = "WORKING"
            result["reason"] = (
                f"Shopify Payments | {layout or 'checkout'} | "
                f"${result['price']} {result['currency']} | "
                f"VAULT OK | HANDLE OK | GATEWAY LIVE"
            )

    except asyncio.TimeoutError:
        result["reason"] = "Timeout"
    except Exception as e:
        result["reason"] = f"Error: {str(e)[:60]}"

    return result



# ── /addshopify ────────────────────────────────────────────────────────────────
async def cmd_add_shopify(client: Client, message):
    user_id = message.from_user.id

    parts = message.text.strip().split()
    if len(parts) < 2:
        await message.reply(
            "**Usage:** `/addshopify <url>`\n\n"
            "**Example:** `/addshopify https://store.dftba.com`\n\n"
            "The bot will:\n"
            "1. Scan the site\n"
            "2. Find cheapest product ($1-$10)\n"
            "3. Test cart + checkout + vault\n"
            "4. Save to DB if working",
            parse_mode=enums.ParseMode.MARKDOWN,
        )
        return

    url = parts[1].strip()
    if not url.startswith("http"):
        url = "https://" + url

    msg = await message.reply(
        f"🔍 **Scanning Shopify site...**\n\n"
        f"`{url}`\n\n"
        f"⏳ Testing cart → checkout → vault...",
        parse_mode=enums.ParseMode.MARKDOWN,
    )

    result = await _scan_shopify_site(url)

    if result["status"] != "WORKING":
        await msg.edit_text(
            f"❌ **Scan Failed**\n\n"
            f"`{url}`\n\n"
            f"**Reason:** `{result['reason']}`\n\n"
            f"This site cannot be used as a Shopify gate.",
            parse_mode=enums.ParseMode.MARKDOWN,
        )
        return

    # Save to DB
    gate_id = await db.add_shopify_gate(
        base_url=result["url"],
        variant_id=result["variant_id"],
        price=result["price"],
        product_title=result["product_title"],
        shop_domain=result["shop_domain"],
        shop_id=result["shop_id"],
        currency=result["currency"],
        checkout_type=result["checkout_type"],
        added_by=user_id,
        scan_data=result.get("scan_data", {}),
    )

    sd = result.get("scan_data", {})
    stripe_info = f"\n**Stripe PK:** `{sd['stripe_pk'][0][:30]}...`" if sd.get("stripe_pk") else ""
    vault_info  = "✅ Vault tested OK" if result["vault_ok"] else "⚠️ Vault untested"

    await msg.edit_text(
        f"✅ **Shopify Gate Added!**\n\n"
        f"{SEP}\n"
        f"**Gate ID:** `#{gate_id}`\n"
        f"**URL:** `{result['url']}`\n"
        f"**Shop:** `{result['shop_domain'] or 'unknown'}`\n"
        f"{SEP}\n"
        f"**Product:** `{result['product_title'][:40]}`\n"
        f"**Variant ID:** `{result['variant_id']}`\n"
        f"**Charge Amount:** `${result['price']} {result['currency']}`\n"
        f"**Checkout Type:** `{result['checkout_type']}`\n"
        f"**PCI Vault:** `{vault_info}`\n"
        f"{stripe_info}\n"
        f"{SEP}\n"
        f"Use `/shopifygates` to see all gates.",
        parse_mode=enums.ParseMode.MARKDOWN,
    )


# ── /scshopify (scan only, no save) ───────────────────────────────────────────
async def cmd_scan_shopify(client: Client, message):
    parts = message.text.strip().split()
    if len(parts) < 2:
        await message.reply(
            "**Usage:** `/scshopify <url>`\n\n"
            "Scans site without saving to DB.",
            parse_mode=enums.ParseMode.MARKDOWN,
        )
        return

    url = parts[1].strip()
    if not url.startswith("http"):
        url = "https://" + url

    msg = await message.reply(
        f"🔍 **Scanning (test only)...**\n`{url}`",
        parse_mode=enums.ParseMode.MARKDOWN,
    )

    result = await _scan_shopify_site(url)
    sd     = result.get("scan_data", {})

    if result["status"] == "WORKING":
        stripe_info = f"\n**Stripe PK:** `{sd['stripe_pk'][0][:30]}...`" if sd.get("stripe_pk") else ""
        await msg.edit_text(
            f"✅ **Site is Working!**\n\n"
            f"{SEP}\n"
            f"**URL:** `{url}`\n"
            f"**Shop:** `{result['shop_domain'] or 'unknown'}`\n"
            f"**Shop ID:** `{result['shop_id'] or 'N/A'}`\n"
            f"{SEP}\n"
            f"**Product:** `{result['product_title'][:40]}`\n"
            f"**Variant ID:** `{result['variant_id']}`\n"
            f"**Charge:** `${result['price']} {result['currency']}`\n"
            f"**Checkout:** `{result['checkout_type']}`\n"
            f"**Session Token:** `{'✅ Found' if result['session_token'] else '❌ Not found'}`\n"
            f"**PCI Vault:** `{'✅ OK' if result['vault_ok'] else '⚠️ Untested'}`\n"
            f"**Vault Status:** `{sd.get('vault_status', '?')}`\n"
            f"**Products found:** `{sd.get('products_count', '?')}`\n"
            f"{stripe_info}\n"
            f"{SEP}\n"
            f"Use `/addshopify {url}` to save to DB.",
            parse_mode=enums.ParseMode.MARKDOWN,
        )
    else:
        await msg.edit_text(
            f"❌ **Site Not Working**\n\n"
            f"`{url}`\n\n"
            f"**Reason:** `{result['reason']}`\n\n"
            f"**Is Shopify:** `{result['is_shopify']}`\n"
            f"**Products:** `{sd.get('products_count', '0')}`\n"
            f"**Checkout HTML:** `{sd.get('html_size', '0')} bytes`\n"
            f"**Vault Status:** `{sd.get('vault_status', 'N/A')}`",
            parse_mode=enums.ParseMode.MARKDOWN,
        )


# ── /shopifygates ──────────────────────────────────────────────────────────────
async def cmd_shopify_gates(client: Client, message):
    gates = await db.get_active_shopify_gates(limit=20)
    count = await db.get_shopify_gates_count()

    if not gates:
        await message.reply(
            "📭 **No Shopify gates in DB yet!**\n\n"
            "Use `/addshopify <url>` to add one.\n"
            "Use `/scshopify <url>` to test without saving.",
            parse_mode=enums.ParseMode.MARKDOWN,
        )
        return

    lines = [f"🛒 **Shopify Gates** ({count['total']} total)\n{SEP}"]
    for g in gates[:15]:
        from urllib.parse import urlparse
        domain = urlparse(g["base_url"]).netloc or g["base_url"]
        ratio  = ""
        tot    = g["success_count"] + g["fail_count"]
        if tot > 0:
            pct   = int(g["success_count"] / tot * 100)
            ratio = f" | {pct}% success"
        lines.append(
            f"**#{g['id']}** `{domain}`\n"
            f"  💰 `${g['price']}` | 🏷 `{g['product_title'][:25]}`\n"
            f"  ✅ {g['success_count']} | ❌ {g['fail_count']}{ratio}\n"
        )

    lines.append(f"{SEP}")
    lines.append("**Commands:**")
    lines.append("`/addshopify <url>` — Add new gate")
    lines.append("`/scshopify <url>` — Scan only")
    lines.append("`/rmshopify <id>` — Remove gate (admin)")

    await message.reply(
        "\n".join(lines),
        parse_mode=enums.ParseMode.MARKDOWN,
    )


# ── /rmshopify ─────────────────────────────────────────────────────────────────
async def cmd_rm_shopify(client: Client, message):
    if not _is_owner(message.from_user.id):
        await message.reply("❌ Admin only command.")
        return

    parts = message.text.strip().split()
    if len(parts) < 2:
        await message.reply("Usage: `/rmshopify <gate_id>`", parse_mode=enums.ParseMode.MARKDOWN)
        return

    try:
        gate_id = int(parts[1])
    except ValueError:
        await message.reply("❌ Invalid gate ID. Use a number.")
        return

    await db.disable_shopify_gate(gate_id)
    await message.reply(f"✅ Shopify gate **#{gate_id}** disabled.", parse_mode=enums.ParseMode.MARKDOWN)


# ── /massaddshopify (mass scan & add from .txt file or text list) ────────────────
async def cmd_mass_add_shopify(client: Client, message):
    if not _is_owner(message.from_user.id):
        await message.reply("❌ Owner only command.")
        return

    urls = []
    
    doc_msg = None
    if message.document:
        doc_msg = message
    elif message.reply_to_message and message.reply_to_message.document:
        doc_msg = message.reply_to_message

    if doc_msg:
        doc = doc_msg.document
        if doc.file_size > 500_000:
            await message.reply("❌ Max file size is 500KB.")
            return
        wait = await message.reply("📥 Downloading shopify sites list...", parse_mode=enums.ParseMode.MARKDOWN)
        tmp_path = None
        try:
            tmp_path = await client.download_media(doc)
            with open(tmp_path, "r", encoding="utf-8", errors="ignore") as f:
                lines = [l.strip() for l in f.readlines() if l.strip()]
        except Exception as e:
            await wait.edit_text(f"❌ Failed: `{e}`")
            return
        finally:
            if tmp_path and os.path.exists(tmp_path):
                os.remove(tmp_path)
        
        for line in lines:
            for word in line.split():
                word = word.strip()
                if not word:
                    continue
                if word.startswith("http://") or word.startswith("https://"):
                    urls.append(word)
                elif "." in word and len(word) > 4:
                    urls.append("https://" + word)
    else:
        text = message.text.strip()
        lines = text[len("/massaddshopify"):].strip().split()
        if not lines:
            await message.reply(
                "❌ **Usage:**\n"
                "Reply to a `.txt` file with `/massaddshopify` caption, OR send list of URLs:\n"
                "`/massaddshopify https://site1.com https://site2.com`",
                parse_mode=enums.ParseMode.MARKDOWN,
            )
            return
        for word in lines:
            word = word.strip()
            if not word:
                continue
            if word.startswith("http://") or word.startswith("https://"):
                urls.append(word)
            elif "." in word and len(word) > 4:
                urls.append("https://" + word)

    urls = list(dict.fromkeys(urls))
    if not urls:
        if doc_msg:
            await wait.edit_text("❌ No Shopify URLs found in file.")
        else:
            await message.reply("❌ No valid URLs found.")
        return

    total = len(urls)
    # Workers: 15 concurrent — high enough for speed, low enough to avoid IP bans
    WORKERS = min(15, total)

    status_msg = wait if doc_msg else await message.reply(
        f"🔍 **Mass Shopify Scan Started!**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📋 **Total Sites:** `{total}`\n"
        f"⚙️ **Workers:** `{WORKERS}` (parallel)\n"
        f"🃏 **Validation:** Full card gateway test\n"
        f"⏳ Please wait...",
        parse_mode=enums.ParseMode.MARKDOWN,
    )

    working_count = 0
    failed_count  = 0
    working_list  = []

    sem  = asyncio.Semaphore(WORKERS)
    lock = asyncio.Lock()
    last_edit = 0.0

    async def scan_one(url: str):
        nonlocal working_count, failed_count, last_edit
        async with sem:
            res = await _scan_shopify_site(url)
            async with lock:
                if res["status"] == "WORKING":
                    working_count += 1
                    gate_id = await db.add_shopify_gate(
                        base_url=res["url"],
                        variant_id=res["variant_id"],
                        price=res["price"],
                        product_title=res["product_title"],
                        shop_domain=res["shop_domain"],
                        shop_id=res["shop_id"],
                        currency=res["currency"],
                        checkout_type=res["checkout_type"],
                        added_by=message.from_user.id,
                        scan_data=res.get("scan_data", {}),
                    )
                    # Also refresh the in-memory store cache so new stores are used immediately
                    try:
                        from gateways.shopify_gate import invalidate_stores_cache
                        invalidate_stores_cache()
                    except Exception:
                        pass
                    sd = res.get("scan_data", {})
                    test_info = sd.get("card_test", "")
                    working_list.append(f"#{gate_id} | {res['url']} (${res['price']}) | ✅ {test_info[:30]}")
                else:
                    failed_count += 1

                done = working_count + failed_count
                now  = time.monotonic()
                # Update progress every 2 sites or every 2 seconds
                if done % 2 == 0 or done == total or (now - last_edit >= 2.0):
                    if now - last_edit >= 1.5 or done == total:
                        last_edit = now
                        progress_text = (
                            f"🔍 **Scanning Shopify Sites...**\n"
                            f"━━━━━━━━━━━━━━━━━━━━━━\n"
                            f"⏳ **Progress:** `{done}/{total}`\n"
                            f"✅ **Working (verified):** `{working_count}`\n"
                            f"❌ **Failed/Invalid:** `{failed_count}`"
                        )
                        try:
                            await status_msg.edit_text(progress_text, parse_mode=enums.ParseMode.MARKDOWN)
                        except Exception:
                            pass

    await asyncio.gather(*[scan_one(url) for url in urls])
    
    working_results = "\n".join(working_list) if working_list else "None"
    final_text = (
        f"✅ **Mass Shopify Scan Complete!**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📊 **Summary:**\n"
        f"📋 Total: `{total}`\n"
        f"✅ Working: `{working_count}`\n"
        f"❌ Failed: `{failed_count}`\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🛍️ **Added Gates:**\n"
        f"`{working_results}`"
    )
    await status_msg.edit_text(final_text, parse_mode=enums.ParseMode.MARKDOWN)


# ── Register ───────────────────────────────────────────────────────────────────
def register_shopify_handler(app: Client):
    app.on_message(filters.command("addshopify"))(notify_owner_on_error(cmd_add_shopify))
    app.on_message(filters.command("scshopify"))(notify_owner_on_error(cmd_scan_shopify))
    app.on_message(filters.command("shopifygates"))(notify_owner_on_error(cmd_shopify_gates))
    app.on_message(filters.command("rmshopify"))(notify_owner_on_error(cmd_rm_shopify))
    app.on_message(filters.command("massaddshopify"))(notify_owner_on_error(cmd_mass_add_shopify))
    logger.info("✅ Shopify handler registered")
