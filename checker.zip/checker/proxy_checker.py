"""
proxy_checker.py — Parse proxies.text, test all proxies, save live ones to .env

Supports 3 formats from proxies.text:
  1. host:port:user:pass         (pointtoserver, ip:8081)
  2. user:pass@host:port         (instantproxies)
  3. 3364:y0a3zi1hkcd9@host:port (instantproxies alternate)

Tests by connecting to https://httpbin.org/ip via proxy.
Live proxies are saved to .env PROXY_LIST.
"""
import asyncio
import aiohttp
import re
import sys
from aiohttp import ClientTimeout

TEST_URL     = "https://api.ipify.org?format=json"
TIMEOUT_SEC  = 12
MAX_WORKERS  = 30  # concurrent test workers
PROXY_FILE   = "proxies.text"

def parse_proxy_line(line: str) -> str | None:
    """
    Parse a proxy line into aiohttp-compatible http://user:pass@host:port URL.
    Returns None if line is unrecognizable or non-proxy text.
    """
    line = line.strip()
    if not line or line.startswith("#") or line.startswith("TYPE") or line.startswith("•"):
        return None
    # Skip lines that are just labels
    if re.match(r'^[A-Za-z\s🔼🔸]+$', line):
        return None

    # Format 1: host:port:user:pass
    # e.g. px023004.pointtoserver.com:10780:purevpn0s551451:9dpdlc2nfxgj
    # e.g. 5.42.206.146:8081:MNzcBTC3...:MNzcBTC3...
    m = re.match(r'^([\w.\-]+):(\d+):([^:@]+):([^:@]+)$', line)
    if m:
        host, port, user, pwd = m.groups()
        return f"http://{user}:{pwd}@{host}:{port}"

    # Format 2: user:pass@host:port
    # e.g. 207657:qeyWpB6yZ@66.212.23.107:8800
    # e.g. 3364:y0a3zi1hkcd9@p105.instantproxies.com:8937
    m = re.match(r'^([^@\s]+):([^@\s]+)@([\w.\-]+):(\d+)$', line)
    if m:
        user, pwd, host, port = m.groups()
        return f"http://{user}:{pwd}@{host}:{port}"

    # Format 3: 2906:XANpZWO45A2U@host:port (same as format 2 essentially)
    return None


async def check_proxy(session_cls, proxy_url: str, semaphore: asyncio.Semaphore) -> tuple[str, bool, str]:
    """Test a proxy. Returns (proxy_url, is_live, ip_or_error)."""
    async with semaphore:
        try:
            connector = aiohttp.TCPConnector(ssl=False, force_close=True)
            async with aiohttp.ClientSession(
                connector=connector,
                timeout=ClientTimeout(total=TIMEOUT_SEC)
            ) as s:
                async with s.get(TEST_URL, proxy=proxy_url) as r:
                    if r.status == 200:
                        data = await r.json(content_type=None)
                        ip = data.get("ip", "?")
                        return (proxy_url, True, ip)
                    return (proxy_url, False, f"HTTP {r.status}")
        except asyncio.TimeoutError:
            return (proxy_url, False, "timeout")
        except Exception as e:
            err = str(e)[:40]
            return (proxy_url, False, err)


async def main():
    # 1. Parse
    print(f"Parsing {PROXY_FILE}...")
    with open(PROXY_FILE, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()

    proxies = []
    seen = set()
    skipped = 0
    for line in lines:
        url = parse_proxy_line(line)
        if url and url not in seen:
            seen.add(url)
            proxies.append(url)
        elif not url:
            skipped += 1

    print(f"  Total unique proxies to test: {len(proxies)}")
    print(f"  Skipped non-proxy lines:      {skipped}")
    print(f"  Testing with {MAX_WORKERS} concurrent workers...")
    print(f"  Timeout per proxy: {TIMEOUT_SEC}s\n")

    # 2. Test concurrently
    semaphore = asyncio.Semaphore(MAX_WORKERS)
    tasks = [check_proxy(None, proxy, semaphore) for proxy in proxies]

    live = []
    dead = []
    done = 0
    total = len(tasks)

    results = await asyncio.gather(*tasks)
    for proxy_url, is_live, info in results:
        done += 1
        status = "✅" if is_live else "❌"
        print(f"  [{done:3d}/{total}] {status} {proxy_url[:55]:<55} | {info}")
        if is_live:
            live.append(proxy_url)
        else:
            dead.append(proxy_url)

    # 3. Report
    print(f"\n{'='*60}")
    print(f"  LIVE:  {len(live)}")
    print(f"  DEAD:  {len(dead)}")
    print(f"{'='*60}\n")

    if live:
        print("Live proxies:")
        for p in live:
            print(f"  {p}")

        # 4. Update .env
        proxy_csv = ",".join(live)
        try:
            with open(".env", "r", encoding="utf-8") as f:
                env_content = f.read()

            if re.search(r'^PROXY_LIST\s*=', env_content, re.MULTILINE):
                env_content = re.sub(
                    r'^PROXY_LIST\s*=.*$',
                    f"PROXY_LIST={proxy_csv}",
                    env_content, flags=re.MULTILINE
                )
            else:
                env_content += f"\nPROXY_LIST={proxy_csv}\n"

            with open(".env", "w", encoding="utf-8") as f:
                f.write(env_content)

            print(f"\n✅ .env updated with {len(live)} live proxies!")
        except Exception as e:
            print(f"\n⚠️  Could not update .env: {e}")
            print(f"Manually set in .env:\nPROXY_LIST={proxy_csv}")

        # Save live proxies to file too
        with open("live_proxies.txt", "w") as f:
            for p in live:
                f.write(p + "\n")
        print(f"✅ Saved to live_proxies.txt")
    else:
        print("❌ No live proxies found.")

asyncio.run(main())
