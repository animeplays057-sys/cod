"""
Rescan brio4life.com and force-save delivery_handle properly in DB
"""
import asyncio
import sys
import json
sys.path.insert(0, '.')
import database.db as db
from shopify_site_scanner import scan_site

async def main():
    await db.init_db()
    
    print("Scanning https://www.brio4life.com ...")
    import asyncio as _aio
    semaphore = _aio.Semaphore(1)
    result = await scan_site("https://www.brio4life.com", semaphore)
    
    sd = result.get("scan_data", {})
    print(f"\nStatus:          {result['status']}")
    print(f"Reason:          {result['reason']}")
    print(f"Variant:         {result['variant_id']}")
    print(f"Price:           ${result['price']} {result['currency']}")
    print(f"delivery_handle: {sd.get('delivery_handle', 'NOT FOUND')}")
    print(f"payment_method_id: {sd.get('payment_method_id', 'NOT FOUND')}")
    print(f"scan_data keys:  {list(sd.keys())}")
    print(f"Full scan_data: {json.dumps(sd, indent=2)[:500]}")
    
    if result["status"] == "WORKING":
        gate_id = await db.add_shopify_gate(
            base_url=result["url"],
            variant_id=result["variant_id"],
            price=result["price"],
            product_title=result["product_title"],
            shop_domain=result["shop_domain"],
            shop_id=result["shop_id"],
            currency=result["currency"],
            checkout_type=result["checkout_type"],
            added_by=0,
            scan_data=sd,
        )
        print(f"\n✅ Added/Updated as gate #{gate_id}")
    
    # Verify saved data
    gates = await db.get_active_shopify_gates(limit=5)
    for g in gates:
        gsd = g.get("scan_data", {})
        if isinstance(gsd, str):
            try: gsd = json.loads(gsd)
            except: gsd = {}
        dh = gsd.get("delivery_handle", "")
        pmid = gsd.get("payment_method_id", "")
        print(f"\n--- Gate #{g['id']} ---")
        print(f"URL:     {g['base_url']}")
        print(f"Variant: {g['variant_id']}")
        print(f"Price:   ${g['price']}")
        print(f"Handle:  {dh[:60] if dh else 'EMPTY - will fetch dynamically'}")
        print(f"PM ID:   {pmid[:40] if pmid else 'default'}")

asyncio.run(main())
