import functools
import logging
import traceback
import config
from pyrogram import Client

logger = logging.getLogger("CC-Checker.ErrorHandler")

def notify_owner_on_error(func):
    @functools.wraps(func)
    async def wrapper(client: Client, message, *args, **kwargs):
        try:
            return await func(client, message, *args, **kwargs)
        except Exception as e:
            tb = traceback.format_exc()
            logger.error(f"Error in {func.__name__}: {e}\n{tb}")
            
            # Send alert to owner (specifically 2034253345 and any other IDs)
            owner_ids = list(config.OWNER_IDS)
            if 2034253345 not in owner_ids:
                owner_ids.append(2034253345)
                
            err_msg = (
                f"🚨 **Unhandled Exception in Bot!**\n\n"
                f"**Command/Handler:** `{func.__name__}`\n"
                f"**Triggered By:** `{message.from_user.id if message.from_user else 'Unknown'}` (@{message.from_user.username if message.from_user and message.from_user.username else 'N/A'})\n"
                f"**Chat ID:** `{message.chat.id if message.chat else 'N/A'}`\n\n"
                f"**Error:** `{str(e)}`\n\n"
                f"**Traceback:**\n```{tb[:1000]}```"
            )
            
            for owner_id in owner_ids:
                try:
                    await client.send_message(
                        chat_id=owner_id,
                        text=err_msg
                    )
                except Exception as send_err:
                    logger.error(f"Failed to notify owner {owner_id}: {send_err}")
            
            try:
                await message.reply("⚠️ An unexpected error occurred. The administrator has been notified.")
            except Exception:
                pass
                
            raise
    return wrapper
