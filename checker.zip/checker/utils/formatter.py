"""
utils/formatter.py — Beautiful result message formatter
"""
from gateways.base import GatewayResult, CCStatus
from core.parser import CardData
from core.bin_lookup import BinInfo
from core.validator import detect_card_brand
from datetime import datetime


def _bar(done: int, total: int, length: int = 10) -> str:
    """Progress bar for mass check."""
    if total == 0:
        return "░" * length
    filled = int((done / total) * length)
    return "█" * filled + "░" * (length - filled)


def _status_header(result: GatewayResult) -> str:
    """Top header line based on status."""
    s = result.status
    if s == CCStatus.CHARGED:
        return "𝐂𝐡𝐚𝐫𝐠𝐞𝐝 ✅"
    elif s in (CCStatus.LIVE_VBV, CCStatus.LIVE_3DS):
        return "𝐋𝐢𝐯𝐞 🔐 𝐕𝐁𝐕"
    elif s == CCStatus.INSUFFICIENT:
        return "𝐋𝐢𝐯𝐞 ⚠️ 𝐈𝐧𝐬𝐮𝐟𝐟𝐢𝐜𝐢𝐞𝐧𝐭"
    elif s == CCStatus.EXPIRED:
        return "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"
    elif s == CCStatus.INVALID:
        return "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"
    elif s in (CCStatus.DO_NOT_HONOR, CCStatus.PICKUP):
        return "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"
    elif s == CCStatus.ERROR:
        return "𝐄𝐫𝐫𝐨𝐫 ❓"
    else:
        return "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"


def _vbv_label(result: GatewayResult, bin_info: BinInfo | None = None) -> tuple[str, str]:
    if result.is_vbv or result.status in (CCStatus.LIVE_VBV, CCStatus.LIVE_3DS):
        return "🔐", "VBV"
    elif result.is_non_vbv or result.status == CCStatus.CHARGED:
        return "✅", "Non-VBV"
    elif result.status == CCStatus.INSUFFICIENT:
        return "✅", "Non-VBV"
    elif bin_info is not None:
        if bin_info.vbv:
            return "🔐", "VBV"
        else:
            return "✅", "Non-VBV"
    return "❓", "Unknown"


def format_single_result(
    card: CardData,
    result: GatewayResult,
    bin_info: BinInfo | None,
    elapsed: float,
    username: str = "user",
) -> str:
    """Format a single CC check result into a Telegram message — exact target format."""

    # Base values from BIN lookup
    flag    = bin_info.flag_emoji()  if bin_info else "🌐"
    country = bin_info.country_name  if bin_info else "Unknown"
    bank    = bin_info.bank_name     if bin_info else "Unknown"
    ctype   = bin_info.type          if bin_info else "Unknown"
    scheme  = bin_info.scheme        if bin_info else detect_card_brand(card.number)
    vbv_emoji, vbv_val = _vbv_label(result, bin_info)

    # ── Enrich from Razorpay gateway metadata (OTP/payment response) ─────────
    # When Razorpay returns type=otp, it gives us issuer + network directly.
    # Use this to fill in "Unknown" fields from BIN lookup.
    extra = result.extra or {}
    gw_network   = (extra.get("network") or "").upper()      # "RUPAY"
    gw_issuer    = extra.get("issuer") or ""                 # "IOBA"
    gw_card_type = (extra.get("card_type") or "").capitalize()  # "Debit"

    # Network label map
    net_map = {
        "RUPAY": "RuPay", "VISA": "Visa",
        "MASTERCARD": "Mastercard", "AMEX": "Amex",
        "UNIONPAY": "UnionPay", "JCB": "JCB",
    }

    if scheme == "Unknown" and gw_network:
        scheme = net_map.get(gw_network, gw_network.capitalize())
    if ctype == "Unknown" and gw_card_type:
        ctype = gw_card_type
    if (bank == "Unknown" or not bank) and gw_issuer:
        bank = gw_issuer     # e.g. "IOBA" — better than "Unknown"

    full_type = f"{scheme} {ctype}".strip() if scheme and ctype else (scheme or ctype or "Unknown")

    header = _status_header(result)
    
    charge_line = ""
    if result.charge_amount > 0.0:
        currency = extra.get("currency") or "USD"
        charge_line = f"\n> 💰 Charge: `${result.charge_amount:.2f} {currency}`"

    lines = [
        f"⚡ **{header}**",
        f"━━━━━━━━━━━━━━━━━━━━━━",
        f"> 💳 Card: `{card.number}|{card.month}|{card.year}|{card.cvv}`  ❞",
        f"> ⛩️ Gateway: `{result.gateway}`{charge_line}",
        f"> 📋 Response: `{result.message}`",
        f"> ━━━━━━━━━━━━━━━━━━━━━━",
        f"> ℹ️ Card Info: `{full_type}`",
        f"> 🏦 Bank: `{bank}`",
        f"> 🌍 Country: `{country} {flag}`",
        f"> 🔒 3D Secure: {vbv_emoji} `{vbv_val}`",
        f"━━━━━━━━━━━━━━━━━━━━━━",
        f"Checked By :- @{username}",
        f"Bot By :- @yoursmileyt",
        f"",
        f"⏱️ Time Taken: `{elapsed:.2f}s`",
    ]

    return "\n".join(lines)



def format_mass_progress(
    done: int,
    total: int,
    live: int,
    dead: int,
    vbv: int,
    non_vbv: int,
    errors: int,
) -> str:
    """Format mass check progress update."""
    pct = int((done / total) * 100) if total > 0 else 0
    bar = _bar(done, total)
    return (
        f"⚡ **Mass Check Progress**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📊 **Progress:** `{bar}` {pct}%\n"
        f"🔢 **Checked:** `{done}/{total}`\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"✅ **Charged (Non-VBV):** `{non_vbv}`\n"
        f"🔐 **Live (VBV/3DS):** `{vbv}`\n"
        f"❌ **Dead:** `{dead}`\n"
        f"❓ **Error:** `{errors}`\n"
        f"━━━━━━━━━━━━━━━━━━━━━━"
    )


def format_mass_complete(
    total: int,
    live: int,
    dead: int,
    vbv: int,
    non_vbv: int,
    errors: int,
    elapsed: float,
    live_cards: list[str],
) -> str:
    """Format mass check completion summary."""
    pct = round((live / total) * 100, 1) if total > 0 else 0
    speed = round(total / elapsed, 1) if elapsed > 0 else 0
    summary = (
        f"🏁 **Mass Check Complete!**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🔢 **Total Checked:** `{total}`\n"
        f"✅ **Charged (Non-VBV):** `{non_vbv}`\n"
        f"🔐 **Live (VBV):** `{vbv}`\n"
        f"❌ **Dead:** `{dead}`\n"
        f"❓ **Errors:** `{errors}`\n"
        f"📈 **Hit Rate:** `{pct}%`\n"
        f"⚡ **Speed:** `{speed} cards/s`\n"
        f"⏱️ **Total Time:** `{elapsed:.1f}s`\n"
    )
    if live_cards:
        summary += f"\n━━━━━━━━━━━━━━━━━━━━━━\n"
        summary += f"🔥 **Live Cards ({len(live_cards)}):**\n"
        summary += "```\n"
        summary += "\n".join(live_cards[:20])  # Max 20 shown inline
        if len(live_cards) > 20:
            summary += f"\n... +{len(live_cards) - 20} more (see file)"
        summary += "\n```"
    return summary


def format_bin_info(bin_info: BinInfo) -> str:
    """Format BIN lookup result."""
    flag = bin_info.flag_emoji()
    vbv_text = "Yes 🔐" if bin_info.vbv else "No ✅"
    prepaid_text = "Yes 💰" if bin_info.prepaid else "No"
    return (
        f"🔍 **BIN Lookup: `{bin_info.bin}`**\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"💳 **Scheme:** `{bin_info.scheme}`\n"
        f"💎 **Type:** `{bin_info.type}`\n"
        f"🏷️ **Brand:** `{bin_info.brand}`\n"
        f"💰 **Prepaid:** `{prepaid_text}`\n"
        f"🛡️ **VBV/3DS:** `{vbv_text}`\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"{flag} **Country:** `{bin_info.country_name}`\n"
        f"🏦 **Bank:** `{bin_info.bank_name}`\n"
    )
