from supabase import create_client, Client
from config.settings import settings
from loguru import logger

_client: Client | None = None


def _create_client() -> Client:
    """Create and return a new Supabase client instance."""
    return create_client(settings.SUPABASE_URL, settings.SUPABASE_SERVICE_KEY)


def get_supabase() -> Client:
    global _client
    if _client is None:
        try:
            _client = _create_client()
            logger.info("Supabase client initialized")
        except Exception as e:
            logger.error(f"Supabase connection failed: {e}")
            raise

    # BUG-023 FIX: Health-check the client so stale connections are recovered.
    # A dropped connection would leave _client non-None but broken.
    # We do a lightweight ping; if it fails, we reset and reconnect.
    try:
        _client.table("users").select("id").limit(1).execute()
    except Exception:
        logger.warning("Supabase connection appears stale — reconnecting...")
        _client = None
        try:
            _client = _create_client()
            logger.info("Supabase client reconnected successfully")
        except Exception as e:
            logger.error(f"Supabase reconnection failed: {e}")
            raise

    return _client


def reset_db():
    """Reset DB client — called if connection becomes stale."""
    global _client
    _client = None
    logger.info("Supabase client reset")


def get_db() -> Client:
    return get_supabase()
