from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, HTMLResponse, Response
from fastapi.staticfiles import StaticFiles
import os
from contextlib import asynccontextmanager
from loguru import logger
from slowapi.errors import RateLimitExceeded
import sys

from middleware.cors import add_cors_middleware
from middleware.logging_middleware import LoggingMiddleware
from middleware.rate_limiter import limiter
from services.scheduler import start_scheduler, stop_scheduler

# Configure loguru
logger.remove()
logger.add(sys.stderr, level="INFO", format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level}</level> | {message}")
logger.add("logs/codverify.log", rotation="10 MB", retention="30 days", level="DEBUG")


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 CODVerify API starting up...")
    try:
        start_scheduler()
    except Exception as e:
        logger.warning(f"Scheduler start warning: {e}")
    yield
    logger.info("Shutting down CODVerify API...")
    stop_scheduler()


app = FastAPI(
    title="CODVerify API",
    description="B2B SaaS platform for COD order verification via WhatsApp",
    version="1.0.0",
    lifespan=lifespan,
)

# Middleware
add_cors_middleware(app)
app.add_middleware(LoggingMiddleware)
app.state.limiter = limiter


@app.exception_handler(RateLimitExceeded)
async def rate_limit_handler(request: Request, exc: RateLimitExceeded):
    return JSONResponse(status_code=429, content={"success": False, "message": "Rate limit exceeded. Try again later.", "data": None, "errors": []})


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception: {exc}")
    return JSONResponse(status_code=500, content={"success": False, "message": "Internal server error", "data": None, "errors": [str(exc)]})


# Routes
from routes.auth import router as auth_router
from routes.merchant.dashboard import router as merchant_dashboard_router
from routes.merchant.orders import router as merchant_orders_router
from routes.merchant.stores import router as merchant_stores_router
from routes.merchant.settings import router as merchant_settings_router
from routes.merchant.api_keys import router as merchant_api_keys_router
from routes.merchant.templates import router as merchant_templates_router
from routes.merchant.customers import router as merchant_customers_router
from routes.merchant.billing import router as merchant_billing_router
from routes.merchant.support import router as merchant_support_router
from routes.merchant.notifications import router as merchant_notifications_router
from routes.admin.dashboard import router as admin_dashboard_router
from routes.admin.merchants import router as admin_merchants_router
from routes.admin.orders import router as admin_orders_router, stores_router as admin_stores_router
from routes.admin.billing import router as admin_billing_router
from routes.admin.partners import router as admin_partners_router
from routes.admin.blog import router as admin_blog_router
from routes.admin.support_and_more import router as admin_support_router
from routes.admin.integrations import router as admin_integrations_router
from routes.webhooks.store_webhooks import router as store_webhooks_router
from routes.webhooks.whatsapp_webhooks import router as whatsapp_webhooks_router
from routes.public.public_routes import router as public_router
from routes.admin.contracts import router as admin_contracts_router
from routes.admin.whatsapp_crm import router as admin_whatsapp_crm_router
from routes.merchant.contracts import router as merchant_contracts_router
from routes.worker.dashboard import router as worker_dashboard_router
from routes.worker.orders import router as worker_orders_router
from routes.worker.chat import router as worker_chat_router, public_router as public_chat_router, admin_chat_router
from routes.worker.callbacks import router as worker_callbacks_router
from routes.admin.staff import router as admin_staff_router
from routes.merchant.chatbot import router as merchant_chatbot_router
from routes.public.merchant_chatbot import router as public_merchant_chatbot_router
from routes.worker.merchant_limits import router as worker_merchant_limits_router
from routes.worker.stores import router as worker_stores_router
from routes.worker.orders import active_workers_router as worker_active_workers_router
from routes.admin.jobs import router as admin_jobs_router
from routes.public.jobs import router as public_jobs_router
from routes.admin.webhooks import router as admin_webhooks_router
from routes.merchant.returns import router as merchant_returns_router
from routes.admin.returns import router as admin_returns_router
from routes.worker.returns import router as worker_returns_router
from routes.merchant.topup import router as merchant_topup_router
from routes.admin.reviews import router as admin_reviews_router
from routes.public.help_center import router as public_help_center_router
from routes.merchant.help_center_config import router as merchant_help_center_router
from routes.admin.pricing import router as admin_pricing_router, public_router as public_pricing_router
from routes.complaints import (
    merchant_router as merchant_complaints_router,
    worker_router as worker_complaints_router,
    admin_router as admin_complaints_router,
    public_router as public_complaint_router,
)
from routes.influencer.influencer_auth import router as influencer_auth_router, public_router as influencer_public_router
from routes.influencer.influencer_dashboard import router as influencer_dashboard_router
from routes.influencer.influencer_withdrawals import router as influencer_withdrawals_router
from routes.influencer.influencer_leaderboard import router as influencer_leaderboard_router
from routes.admin.influencers import router as admin_influencers_router
from routes.worker.worker_influencer_leads import router as worker_influencer_leads_router

app.include_router(auth_router)
app.include_router(merchant_dashboard_router)
app.include_router(merchant_orders_router)
app.include_router(merchant_stores_router)
app.include_router(merchant_settings_router)
app.include_router(merchant_api_keys_router)
app.include_router(merchant_templates_router)
app.include_router(merchant_customers_router)
app.include_router(merchant_billing_router)
app.include_router(merchant_support_router)
app.include_router(merchant_notifications_router)
app.include_router(admin_dashboard_router)
app.include_router(admin_merchants_router)
app.include_router(admin_orders_router)
app.include_router(admin_stores_router)
app.include_router(admin_billing_router)
app.include_router(admin_partners_router)
app.include_router(admin_blog_router)
app.include_router(admin_support_router)
app.include_router(admin_integrations_router)
app.include_router(store_webhooks_router)
app.include_router(whatsapp_webhooks_router)
app.include_router(public_router)
app.include_router(admin_contracts_router)
app.include_router(admin_whatsapp_crm_router)
app.include_router(merchant_contracts_router)
app.include_router(worker_dashboard_router)
app.include_router(worker_orders_router)
app.include_router(worker_chat_router)
app.include_router(public_chat_router)
app.include_router(admin_chat_router)
app.include_router(worker_callbacks_router)
app.include_router(admin_staff_router)
app.include_router(merchant_chatbot_router)
app.include_router(public_merchant_chatbot_router)
app.include_router(worker_merchant_limits_router)
app.include_router(worker_stores_router)
app.include_router(worker_active_workers_router)
app.include_router(admin_jobs_router)
app.include_router(public_jobs_router)
app.include_router(admin_webhooks_router)
app.include_router(merchant_returns_router)
app.include_router(admin_returns_router)
app.include_router(worker_returns_router)
app.include_router(merchant_topup_router)
app.include_router(admin_reviews_router)
app.include_router(public_help_center_router)
app.include_router(merchant_help_center_router)
app.include_router(admin_pricing_router)
app.include_router(public_pricing_router)
app.include_router(merchant_complaints_router)
app.include_router(worker_complaints_router)
app.include_router(admin_complaints_router)
app.include_router(public_complaint_router)

# Influencer system
app.include_router(influencer_auth_router)
app.include_router(influencer_public_router)
app.include_router(influencer_dashboard_router)
app.include_router(influencer_withdrawals_router)
app.include_router(influencer_leaderboard_router)
app.include_router(admin_influencers_router)
app.include_router(worker_influencer_leads_router)

# Serve static files (chatbot widget JS, etc.)
_static_dir = os.path.join(os.path.dirname(__file__), "static")
os.makedirs(_static_dir, exist_ok=True)
app.mount("/static", StaticFiles(directory=_static_dir), name="static")


@app.get("/")
async def root():
    return {
        "name": "CODVerify API",
        "version": "1.0.0",
        "description": "B2B SaaS for COD order verification via WhatsApp",
        "docs": "/docs",
        "health": "/health",
    }


@app.get("/health")
async def health():
    status = {"status": "healthy", "service": "codverify-api", "version": "1.0.0"}
    errors = []

    # DB connectivity check
    try:
        from config.database import get_db
        db = get_db()
        db.table("users").select("id").limit(1).execute()
        status["database"] = "ok"
    except Exception as e:
        status["database"] = "error"
        errors.append(f"DB: {str(e)[:80]}")

    # Scheduler check
    try:
        from services.scheduler import scheduler
        status["scheduler"] = "running" if scheduler.running else "stopped"
        if not scheduler.running:
            errors.append("Scheduler is not running")
    except Exception:
        status["scheduler"] = "unknown"

    if errors:
        status["status"] = "degraded"
        status["errors"] = errors
        return JSONResponse(status_code=503, content=status)

    return status


@app.get("/api/v1/stats/public")
async def public_stats():
    """Public stats for homepage — real counts from DB with caching."""
    import time
    cache = getattr(app.state, "_stats_cache", None)
    if cache and time.time() - cache.get("ts", 0) < 300:  # 5-min cache
        return cache["data"]
    try:
        from config.database import get_db
        db = get_db()
        merchants_res = db.table("users").select("id", count="exact").eq("role", "merchant").neq("status", "suspended").execute()
        orders_res = db.table("cod_orders").select("id", count="exact").execute()
        data = {
            "active_brands": merchants_res.count or 0,
            "orders_verified": orders_res.count or 0,
        }
        app.state._stats_cache = {"ts": time.time(), "data": data}
        return data
    except Exception:
        return {"active_brands": 0, "orders_verified": 0}


# ── Chatbot Widget Routes ─────────────────────────────────────────────

@app.get("/chatbot/widget")
async def chatbot_widget(merchant_id: str = "", api_key: str = ""):
    """Serve the chatbot widget HTML page (loaded inside an iframe on merchant's website)."""
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CODVerify Chat</title>
<style>
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #fff; height: 100vh; display: flex; flex-direction: column; overflow: hidden; }}
.chat-header {{ padding: 16px; color: #fff; display: flex; align-items: center; gap: 12px; flex-shrink: 0; }}
.chat-header .avatar {{ width: 36px; height: 36px; border-radius: 50%; background: rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; font-size: 18px; }}
.chat-header .info h3 {{ font-size: 15px; font-weight: 700; }}
.chat-header .info p {{ font-size: 11px; opacity: 0.8; }}
.chat-header .close-btn {{ margin-left: auto; background: none; border: none; color: #fff; font-size: 20px; cursor: pointer; opacity: 0.7; }}
.chat-header .close-btn:hover {{ opacity: 1; }}
.messages {{ flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 8px; }}
.message {{ max-width: 85%; padding: 10px 14px; border-radius: 16px; font-size: 14px; line-height: 1.5; word-wrap: break-word; animation: fadeIn 0.3s ease; }}
@keyframes fadeIn {{ from {{ opacity: 0; transform: translateY(8px); }} to {{ opacity: 1; transform: translateY(0); }} }}
.msg-bot {{ background: #f1f5f9; color: #1e293b; border-bottom-left-radius: 4px; align-self: flex-start; }}
.msg-user {{ background: var(--primary, #6366f1); color: #fff; border-bottom-right-radius: 4px; align-self: flex-end; }}
.msg-system {{ background: #fef3c7; color: #92400e; font-size: 12px; align-self: center; border-radius: 8px; text-align: center; }}
.menu-options {{ display: flex; flex-direction: column; gap: 6px; padding: 8px 16px; }}
.menu-btn {{ background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px 14px; border-radius: 10px; text-align: left; cursor: pointer; font-size: 13px; color: #334155; transition: all 0.2s; }}
.menu-btn:hover {{ background: #eef2ff; border-color: var(--primary, #6366f1); color: var(--primary, #6366f1); }}
.input-area {{ padding: 12px 16px; border-top: 1px solid #e2e8f0; display: flex; gap: 8px; flex-shrink: 0; background: #fff; }}
.input-area input {{ flex: 1; padding: 10px 14px; border: 1px solid #e2e8f0; border-radius: 10px; font-size: 14px; outline: none; }}
.input-area input:focus {{ border-color: var(--primary, #6366f1); }}
.input-area button {{ padding: 10px 16px; border: none; border-radius: 10px; color: #fff; cursor: pointer; font-size: 14px; font-weight: 600; }}
.input-area button:disabled {{ opacity: 0.5; cursor: not-allowed; }}
.typing {{ display: flex; gap: 4px; align-items: center; padding: 10px 14px; align-self: flex-start; }}
.typing span {{ width: 6px; height: 6px; background: #94a3b8; border-radius: 50%; animation: bounce 1.4s infinite; }}
.typing span:nth-child(2) {{ animation-delay: 0.2s; }}
.typing span:nth-child(3) {{ animation-delay: 0.4s; }}
@keyframes bounce {{ 0%,80%,100% {{ transform: scale(0); }} 40% {{ transform: scale(1); }} }}
.offline-form {{ padding: 20px; display: flex; flex-direction: column; gap: 12px; }}
.offline-form input, .offline-form textarea {{ padding: 10px 14px; border: 1px solid #e2e8f0; border-radius: 10px; font-size: 14px; outline: none; font-family: inherit; }}
.offline-form textarea {{ resize: none; height: 80px; }}
.offline-form button {{ padding: 12px; border: none; border-radius: 10px; color: #fff; cursor: pointer; font-size: 14px; font-weight: 600; }}
.powered {{ text-align: center; padding: 6px; font-size: 10px; color: #94a3b8; flex-shrink: 0; }}
.powered a {{ color: #6366f1; text-decoration: none; }}
</style>
</head>
<body>
<div id="app"></div>
<script>
(function() {{
  var API_KEY = "{api_key}";
  var API_BASE = window.location.origin + "/api/v1/merchant-chat";
  var primaryColor = "#6366f1";
  var botName = "Support Bot";
  var welcomeMessage = "Hi! 👋 How can I help you today?";
  var menuOptions = [];
  var sessionId = null;
  var messages = [];
  var isLoading = false;
  var offlineMode = false;

  // Fetch config
  fetch(API_BASE + "/config/" + API_KEY)
    .then(function(r) {{ return r.json(); }})
    .then(function(data) {{
      if (data.success && data.data) {{
        var c = data.data;
        primaryColor = c.primary_color || primaryColor;
        botName = c.bot_name || botName;
        welcomeMessage = c.welcome_message || welcomeMessage;
        menuOptions = c.menu_options || [];
      }}
      render();
    }})
    .catch(function() {{ render(); }});

  function render() {{
    document.documentElement.style.setProperty("--primary", primaryColor);
    var app = document.getElementById("app");
    app.innerHTML = "";
    app.style.cssText = "display:flex;flex-direction:column;height:100vh;";

    // Header
    var header = document.createElement("div");
    header.className = "chat-header";
    header.style.background = primaryColor;
    header.innerHTML = '<div class="avatar">🤖</div><div class="info"><h3>' + botName + '</h3><p>Online</p></div><button class="close-btn" onclick="window.parent.postMessage(\\'codverify-chatbot-close\\', \\'*\\')">&times;</button>';
    app.appendChild(header);

    // Messages area
    var msgArea = document.createElement("div");
    msgArea.className = "messages";
    msgArea.id = "msgArea";
    app.appendChild(msgArea);

    // Welcome message
    addMessage("bot", welcomeMessage);

    // Menu options + Callback button
    if (!sessionId) {{
      var menuDiv = document.createElement("div");
      menuDiv.className = "menu-options";
      menuDiv.id = "menuDiv";
      if (menuOptions.length > 0) {{
        menuOptions.forEach(function(opt) {{
          var btn = document.createElement("button");
          btn.className = "menu-btn";
          btn.textContent = opt.label;
          btn.onclick = function() {{
            if (opt.answer) {{
              addMessage("user", opt.label);
              addMessage("bot", opt.answer);
            }} else {{
              sendMessage(opt.label);
            }}
          }};
          menuDiv.appendChild(btn);
        }});
      }}
      // Always show "Request a Callback" button
      var cbBtn = document.createElement("button");
      cbBtn.className = "menu-btn";
      cbBtn.style.cssText = "background:#fef3c7;border-color:#f59e0b;color:#92400e;font-weight:600;";
      cbBtn.innerHTML = "📞 Request a Callback";
      cbBtn.onclick = function() {{
        var menuDiv = document.getElementById("menuDiv");
        if (menuDiv) menuDiv.remove();
        startCallbackFlow();
      }};
      menuDiv.appendChild(cbBtn);
      app.appendChild(menuDiv);
    }}

    // Input area
    var inputArea = document.createElement("div");
    inputArea.className = "input-area";
    inputArea.innerHTML = '<input type="text" id="chatInput" placeholder="Type a message..." /><button id="sendBtn" style="background:' + primaryColor + '">Send</button>';
    app.appendChild(inputArea);

    // Powered by
    var powered = document.createElement("div");
    powered.className = "powered";
    powered.innerHTML = 'Powered by <a href="https://codverify.tech" target="_blank">CODVerify</a>';
    app.appendChild(powered);

    // Events
    document.getElementById("chatInput").addEventListener("keypress", function(e) {{
      if (e.key === "Enter") sendMessage();
    }});
    document.getElementById("sendBtn").addEventListener("click", function() {{ sendMessage(); }});
  }}

  function addMessage(type, text) {{
    var msgArea = document.getElementById("msgArea");
    if (!msgArea) return;
    var div = document.createElement("div");
    div.className = "message " + (type === "user" ? "msg-user" : type === "system" ? "msg-system" : "msg-bot");
    div.textContent = text;
    msgArea.appendChild(div);
    msgArea.scrollTop = msgArea.scrollHeight;
  }}

  function showTyping() {{
    var msgArea = document.getElementById("msgArea");
    var typing = document.createElement("div");
    typing.className = "typing";
    typing.id = "typingIndicator";
    typing.innerHTML = "<span></span><span></span><span></span>";
    msgArea.appendChild(typing);
    msgArea.scrollTop = msgArea.scrollHeight;
  }}

  function hideTyping() {{
    var el = document.getElementById("typingIndicator");
    if (el) el.remove();
  }}

  function sendMessage(text) {{
    var input = document.getElementById("chatInput");
    var msg = text || (input ? input.value.trim() : "");
    if (!msg || isLoading) return;
    if (input) input.value = "";

    addMessage("user", msg);
    isLoading = true;
    showTyping();

    // Remove menu after first message
    var menuDiv = document.getElementById("menuDiv");
    if (menuDiv) menuDiv.remove();

    if (!sessionId) {{
      // Start new chat
      fetch(API_BASE + "/start", {{
        method: "POST",
        headers: {{ "Content-Type": "application/json" }},
        body: JSON.stringify({{ api_key: API_KEY, message: msg }})
      }})
      .then(function(r) {{ return r.json(); }})
      .then(function(data) {{
        hideTyping();
        isLoading = false;
        if (data.success && data.data) {{
          if (data.data.no_workers_available) {{
            addMessage("system", data.data.offline_message || "No agents available right now.");
            showOfflineForm();
            return;
          }}
          sessionId = data.data.session_id;
          if (data.data.ai_response) addMessage("bot", data.data.ai_response);
          if (data.data.handoff_requested) {{
            addMessage("system", "Connecting you with a support agent...");
            startPolling();
          }}
        }}
      }})
      .catch(function() {{
        hideTyping();
        isLoading = false;
        addMessage("system", "Something went wrong. Please try again.");
      }});
    }} else {{
      // Continue chat
      fetch(API_BASE + "/message/" + sessionId, {{
        method: "POST",
        headers: {{ "Content-Type": "application/json" }},
        body: JSON.stringify({{ api_key: API_KEY, message: msg }})
      }})
      .then(function(r) {{ return r.json(); }})
      .then(function(data) {{
        hideTyping();
        isLoading = false;
        if (data.success && data.data) {{
          if (data.data.ai_response) addMessage("bot", data.data.ai_response);
          if (data.data.handoff_requested) {{
            addMessage("system", "Connecting you with a support agent...");
            startPolling();
          }}
        }}
      }})
      .catch(function() {{
        hideTyping();
        isLoading = false;
        addMessage("system", "Something went wrong. Please try again.");
      }});
    }}
  }}

  var pollInterval = null;
  function startPolling() {{
    if (pollInterval) return;
    var lastCount = 0;
    pollInterval = setInterval(function() {{
      if (!sessionId) return;
      fetch(API_BASE + "/messages/" + sessionId + "?api_key=" + API_KEY)
        .then(function(r) {{ return r.json(); }})
        .then(function(data) {{
          if (!data.success || !data.data) return;
          var msgs = data.data.messages || [];
          // Only show new messages from worker
          if (msgs.length > lastCount) {{
            for (var i = lastCount; i < msgs.length; i++) {{
              var m = msgs[i];
              if (m.sender_type === "worker") addMessage("bot", m.message);
              else if (m.sender_type === "system" && i >= lastCount) addMessage("system", m.message);
            }}
            lastCount = msgs.length;
          }}
          if (data.data.session_status === "closed") {{
            clearInterval(pollInterval);
            pollInterval = null;
            addMessage("system", "Chat ended. Thank you!");
          }}
        }});
    }}, 3000);
  }}

  function showOfflineForm() {{
    var inputArea = document.querySelector(".input-area");
    if (inputArea) inputArea.style.display = "none";

    var msgArea = document.getElementById("msgArea");
    var form = document.createElement("div");
    form.className = "offline-form";
    form.innerHTML = '<input type="text" id="offName" placeholder="Your Name *" />' +
      '<input type="text" id="offPhone" placeholder="Phone Number *" />' +
      '<input type="email" id="offEmail" placeholder="Email (optional)" />' +
      '<textarea id="offReason" placeholder="How can we help?"></textarea>' +
      '<button id="offSubmit" style="background:' + primaryColor + '">Request Callback</button>';
    msgArea.parentNode.insertBefore(form, msgArea.nextSibling);

    document.getElementById("offSubmit").addEventListener("click", function() {{
      var name = document.getElementById("offName").value.trim();
      var phone = document.getElementById("offPhone").value.trim();
      var email = document.getElementById("offEmail").value.trim();
      var reason = document.getElementById("offReason").value.trim();
      if (!name || !phone) {{ alert("Name and phone are required."); return; }}

      fetch(API_BASE + "/offline-callback", {{
        method: "POST",
        headers: {{ "Content-Type": "application/json" }},
        body: JSON.stringify({{ api_key: API_KEY, visitor_name: name, visitor_phone: phone, visitor_email: email, reason: reason }})
      }})
      .then(function(r) {{ return r.json(); }})
      .then(function(data) {{
        form.innerHTML = '<p style="text-align:center;color:#22c55e;font-weight:600;padding:20px;">✅ ' + (data.data?.message || 'We\\'ll call you back soon!') + '</p>';
      }})
      .catch(function() {{
        form.innerHTML = '<p style="text-align:center;color:#ef4444;padding:20px;">Something went wrong. Please try again.</p>';
      }});
    }});
  }}

  // ── Callback Request Flow (conversational — asks one by one) ──
  var callbackData = {{}};
  var callbackStep = 0;
  var inCallbackFlow = false;

  function startCallbackFlow() {{
    inCallbackFlow = true;
    callbackStep = 0;
    callbackData = {{}};
    addMessage("user", "📞 Request a Callback");
    addMessage("bot", "Sure! I\\'d be happy to arrange a callback for you. Let me collect a few details.");
    setTimeout(function() {{
      addMessage("bot", "What is your name?");
    }}, 500);
    // Override input handler for callback flow
    var input = document.getElementById("chatInput");
    var sendBtn = document.getElementById("sendBtn");
    if (input) input.placeholder = "Type your name...";

    // Remove old listeners and add callback-specific ones
    var newInput = input.cloneNode(true);
    input.parentNode.replaceChild(newInput, input);
    var newSendBtn = sendBtn.cloneNode(true);
    sendBtn.parentNode.replaceChild(newSendBtn, sendBtn);

    newInput.addEventListener("keypress", function(e) {{
      if (e.key === "Enter") handleCallbackInput();
    }});
    newSendBtn.addEventListener("click", handleCallbackInput);
  }}

  function handleCallbackInput() {{
    var input = document.getElementById("chatInput");
    var val = input ? input.value.trim() : "";
    if (!val) return;
    input.value = "";

    addMessage("user", val);

    if (callbackStep === 0) {{
      // Name
      callbackData.visitor_name = val;
      callbackStep = 1;
      setTimeout(function() {{
        addMessage("bot", "Thanks " + val + "! What\\'s your phone number?");
        if (input) input.placeholder = "Your phone number...";
      }}, 400);
    }} else if (callbackStep === 1) {{
      // Phone
      callbackData.visitor_phone = val;
      callbackStep = 2;
      setTimeout(function() {{
        addMessage("bot", "Got it! What\\'s your email address? (You can type \\'skip\\' if you don\\'t want to share)");
        if (input) input.placeholder = "Your email or type skip...";
      }}, 400);
    }} else if (callbackStep === 2) {{
      // Email
      if (val.toLowerCase() !== "skip") {{
        callbackData.visitor_email = val;
      }} else {{
        callbackData.visitor_email = "";
      }}
      callbackStep = 3;
      setTimeout(function() {{
        addMessage("bot", "Last question — what\\'s the reason for the callback? What do you need help with?");
        if (input) input.placeholder = "Describe your issue...";
      }}, 400);
    }} else if (callbackStep === 3) {{
      // Reason — submit
      callbackData.reason = val;
      callbackStep = 4;
      inCallbackFlow = false;
      if (input) input.placeholder = "Type a message...";

      addMessage("bot", "Perfect! Submitting your callback request...");

      fetch(API_BASE + "/callback-request", {{
        method: "POST",
        headers: {{ "Content-Type": "application/json" }},
        body: JSON.stringify({{
          api_key: API_KEY,
          visitor_name: callbackData.visitor_name,
          visitor_phone: callbackData.visitor_phone,
          visitor_email: callbackData.visitor_email || "",
          reason: callbackData.reason,
        }})
      }})
      .then(function(r) {{ return r.json(); }})
      .then(function(data) {{
        if (data.success) {{
          addMessage("bot", "✅ Your callback request has been submitted! Our team will call you back shortly. Thank you!");
        }} else {{
          addMessage("bot", "❌ Something went wrong. Please try again or contact support directly.");
        }}
        // Re-attach normal handlers
        reattachNormalHandlers();
      }})
      .catch(function() {{
        addMessage("bot", "❌ Network error. Please try again.");
        reattachNormalHandlers();
      }});
    }}
  }}

  function reattachNormalHandlers() {{
    var input = document.getElementById("chatInput");
    var sendBtn = document.getElementById("sendBtn");
    if (!input || !sendBtn) return;
    var newInput = input.cloneNode(true);
    input.parentNode.replaceChild(newInput, input);
    var newSendBtn = sendBtn.cloneNode(true);
    sendBtn.parentNode.replaceChild(newSendBtn, sendBtn);
    newInput.addEventListener("keypress", function(e) {{
      if (e.key === "Enter") sendMessage();
    }});
    newSendBtn.addEventListener("click", function() {{ sendMessage(); }});
  }}
}})();
</script>
</body>
</html>"""
    return HTMLResponse(content=html)


# NOTE: The chatbot widget JS (`chatbot-widget.js`) is served directly
# via the StaticFiles mount at /static (see line 137 above).
# The file at backend/static/chatbot-widget.js is the canonical widget.


# ── Chatbot Script Loader (fixes 404 for old Shopify script tags) ─────────────
# Old Shopify script tags point to /chatbot/script.js on api.codverify.tech.
# This route looks up the merchant's API key by shop domain and injects
# the new chatbot-widget.js — replacing the old iframe approach.
@app.get("/chatbot/script.js")
async def chatbot_script_loader(request: Request, shop: str = ""):
    """
    Loader script injected by the Shopify plugin into merchant storefronts.
    Looks up merchant API key by shop domain and serves chatbot-widget.js.
    """
    from config.database import get_db

    public_backend = "https://api.codverify.tech"
    api_key = ""

    if shop:
        try:
            db = get_db()
            # Find user by shopify_shop_domain
            user_res = db.table("users").select("id").eq(
                "shopify_shop_domain", shop
            ).limit(1).execute()

            if user_res.data:
                user_id = user_res.data[0]["id"]
                # Get their chatbot API key from merchant_chatbot_config
                ms_res = db.table("merchant_chatbot_config").select(
                    "api_key"
                ).eq("merchant_id", user_id).limit(1).execute()

                if ms_res.data:
                    api_key = ms_res.data[0].get("api_key") or ""
        except Exception as e:
            logger.warning(f"chatbot/script.js lookup failed for shop={shop}: {e}")

    if not api_key:
        # Return empty script — chatbot not configured for this shop
        return Response(
            content="// CODVerify: chatbot not configured for this store.\n",
            media_type="application/javascript",
            headers={"Cache-Control": "no-cache", "Access-Control-Allow-Origin": "*"},
        )

    js_content = f"""(function() {{
  if (window.__codverify_chatbot_loaded) return;
  window.__codverify_chatbot_loaded = true;

  var s = document.createElement('script');
  s.src = {repr(public_backend + '/static/chatbot-widget.js?v=7')};
  s.setAttribute('data-codverify-key', {repr(api_key)});
  s.setAttribute('data-codverify-api', {repr(public_backend)});
  s.async = true;
  document.head.appendChild(s);
}})();
"""
    return Response(
        content=js_content,
        media_type="application/javascript",
        headers={
            "Cache-Control": "public, max-age=300",
            "Access-Control-Allow-Origin": "*",
        },
    )

