from fastapi import Request, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials, APIKeyHeader
from config.security import decode_access_token
from config.database import get_db
from config.settings import settings
from loguru import logger
from functools import wraps
from middleware.contract import VALID_SERVICES as _ALL_VALID_SERVICES

security = HTTPBearer()
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    payload = decode_access_token(token)
    if payload is None:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid token payload")

    db = get_db()
    result = db.table("users").select("*").eq("id", user_id).execute()
    if not result.data:
        raise HTTPException(status_code=401, detail="User not found")

    user = result.data[0]
    if user.get("status") == "suspended":
        raise HTTPException(status_code=403, detail="Account suspended")
    if user.get("status") == "inactive":
        raise HTTPException(status_code=403, detail="Account inactive")

    # Check for impersonation
    if payload.get("impersonating"):
        user["_impersonating"] = True
        user["_admin_id"] = payload.get("admin_id")

    return user


from datetime import datetime, timezone

async def get_current_merchant(user: dict = Depends(get_current_user)):
    if user.get("role") not in ("merchant", "admin"):
        raise HTTPException(status_code=403, detail="Merchant access required")
    if user.get("role") == "admin" and not user.get("_impersonating"):
        raise HTTPException(status_code=403, detail="Merchant access required")

    # ── Admins impersonating bypass contract enforcement ──────────────────
    if user.get("_impersonating"):
        # BUG-018 FIX: Use proper import instead of fragile __import__() dynamic call
        user["contracted_services"] = list(_ALL_VALID_SERVICES)
        user["active_contract"] = None
        return user

    # ── Fetch active/pending contract ─────────────────────────────────────
    db = get_db()
    now_iso = datetime.now(timezone.utc).isoformat()

    contract_res = (
        db.table("contracts")
        .select("id, status, services, end_date, start_date, contract_number, plan_name")
        .eq("user_id", user["id"])
        .in_("status", ["active", "pending"])
        .order("created_at", desc=True)
        .limit(1)
        .execute()
    )

    # ── No contract at all — allow through with empty services ───────────
    # Enforcement happens at route-level via require_service()
    # Contract page, billing, support, notifications always accessible
    if not contract_res.data:
        user["contracted_services"] = []
        user["active_contract"] = None
        user["contract_status"] = "no_contract"
        return user

    contract = contract_res.data[0]

    # ── Contract expired: end_date in the past — auto-expire + allow through
    end_date = contract.get("end_date")
    if end_date and end_date < now_iso and contract["status"] == "active":
        try:
            db.table("contracts").update({"status": "expired"}).eq("id", contract["id"]).execute()
            db.table("users").update({"account_status": "contract_expired"}).eq("id", user["id"]).execute()
        except Exception as e:
            logger.warning(f"Auto-expire failed for contract {contract['id']}: {e}")

        # Allow through — but with empty services so require_service() blocks service routes
        user["contracted_services"] = []
        user["active_contract"] = {**contract, "status": "expired"}
        user["contract_status"] = "expired"
        return user

    # ── Contract still pending (not yet activated) ────────────────────────
    if contract["status"] == "pending":
        user["contracted_services"] = []
        user["active_contract"] = contract
        user["contract_status"] = "pending"
        return user

    # ── Active contract — build canonical services list ──────────────────
    raw_services = contract.get("services") or []

    # ── Human-readable name → canonical key mapping ───────────────────────
    # Admin may type service names in any format. We map ALL variants to
    # canonical keys so require_service() works regardless of what admin typed.
    HUMAN_TO_CANONICAL: dict = {
        # COD Verification & Order Management variants
        "cod_verification": "cod_verification",
        "cod": "cod_verification",
        "cod verify": "cod_verification",
        "sms verification": "cod_verification",
        "sms verify": "cod_verification",
        "call verification": "cod_verification",
        "call verify": "cod_verification",
        "whatsapp verification": "cod_verification",
        "whatsapp verify": "cod_verification",
        "order verification": "cod_verification",
        "cod order verification": "cod_verification",
        "multi-country support": "cod_verification",
        "multi country support": "cod_verification",
        "24x7 monitoring": "cod_verification",
        "24×7 monitoring": "cod_verification",
        "24/7 monitoring": "cod_verification",
        "fraud detection": "cod_verification",
        "ndr management": "cod_verification",
        "ndr": "cod_verification",
        "rto management": "cod_verification",
        # Customer Support variants
        "customer_support": "customer_support",
        "customer support": "customer_support",
        "personal customer support": "customer_support",
        "live chat": "customer_support",
        "chat support": "customer_support",
        "ai chat": "customer_support",
        "chatbot": "customer_support",
        "ai chatbot": "customer_support",
        "support": "customer_support",
        "customer care": "customer_support",
        "customer service": "customer_support",
        # Help Center variants
        "help_center": "help_center",
        "help center": "help_center",
        "help centre": "help_center",
        "knowledge base": "help_center",
        "faq": "help_center",
        # Returns Management variants
        "returns_management": "returns_management",
        "returns management": "returns_management",
        "returns & refunds": "returns_management",
        "returns and refunds": "returns_management",
        "returns": "returns_management",
        "refunds": "returns_management",
        "exchange": "returns_management",
        "return management": "returns_management",
        "reverse logistics": "returns_management",
        # Analytics variants
        "analytics": "analytics",
        "rto analytics": "analytics",
        "advanced analytics": "analytics",
        "reports": "analytics",
        "analytics & reports": "analytics",
        "reporting": "analytics",
        # Chatbot AI variants
        "chatbot_ai": "chatbot_ai",
        "chatbot ai": "chatbot_ai",
        "ai bot": "chatbot_ai",
    }

    # ── Service bundles: parent → children included automatically ─────────
    # If merchant has a parent service, they automatically get all child services.
    # e.g. "Personal Customer Support" → customer_support →
    #      also grants: help_center, chatbot_ai (complaints page)
    SERVICE_BUNDLES: dict = {
        "customer_support": ["help_center", "chatbot_ai", "customer_support"],
        "chatbot_ai":       ["chatbot_ai", "customer_support"],
        "help_center":      ["help_center", "customer_support"],
        "cod_verification": ["cod_verification"],
        "returns_management": ["returns_management"],
        "analytics":        ["analytics"],
    }

    # Step 1: Map raw names → canonical keys
    canonical_services: set = set()
    for s in raw_services:
        if not s:
            continue
        s_lower = s.strip().lower()
        canonical_services.add(s_lower)
        mapped = HUMAN_TO_CANONICAL.get(s_lower)
        if mapped:
            canonical_services.add(mapped)

    # Step 2: Expand bundles — add all child services
    to_expand = list(canonical_services)
    for key in to_expand:
        bundle = SERVICE_BUNDLES.get(key, [])
        canonical_services.update(bundle)

    user["contracted_services"] = list(canonical_services)
    user["active_contract"] = contract

    return user



async def get_current_admin(user: dict = Depends(get_current_user)):
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


async def get_current_worker(user: dict = Depends(get_current_user)):
    if user.get("role") not in ("worker", "admin"):
        raise HTTPException(status_code=403, detail="Worker access required")
    return user


async def get_api_key_user(request: Request, api_key: str = Depends(api_key_header)):
    db = get_db()

    # Method 1: Standard API key auth
    if api_key:
        result = db.table("api_keys").select("*").eq("api_key", api_key).eq("is_active", True).execute()
        if result.data:
            key_data = result.data[0]
            db.table("api_keys").update({
                "last_used_at": "now()",
                "last_used_ip": request.client.host if request.client else None
            }).eq("id", key_data["id"]).execute()

            user_result = db.table("users").select("*").eq("id", key_data["user_id"]).execute()
            if not user_result.data:
                raise HTTPException(status_code=401, detail="User not found")

            user = user_result.data[0]
            if user.get("status") in ("suspended", "inactive"):
                raise HTTPException(status_code=403, detail="Account not active")
            return user

    # Method 2: Internal token + shop_domain (for Shopify plugin forwarding orders)
    internal_token = request.headers.get("X-Internal-Token", "")
    expected_token = getattr(settings, 'INTERNAL_API_TOKEN', "")
    if internal_token and expected_token and internal_token == expected_token:
        shop_domain = request.headers.get("X-Shop-Domain", "")
        if shop_domain:
            # Try 1: Direct user lookup by shopify_shop_domain
            user_result = db.table("users").select("*").eq("shopify_shop_domain", shop_domain).execute()
            if user_result.data:
                user = user_result.data[0]
                if user.get("status") not in ("suspended", "inactive"):
                    return user

            # Try 2: Fallback via stores table (store_url = shop_domain)
            # Note: Don't filter by is_active — after uninstall+reinstall, store may be temporarily inactive
            store_result = db.table("stores").select("user_id").eq("store_url", shop_domain).limit(1).execute()
            if store_result.data:
                user_result = db.table("users").select("*").eq("id", store_result.data[0]["user_id"]).execute()
                if user_result.data:
                    user = user_result.data[0]
                    if user.get("status") not in ("suspended", "inactive"):
                        return user

            logger.warning(f"Webhook auth failed: no user found for shop_domain={shop_domain}")

    raise HTTPException(status_code=401, detail="API key required")
