"""
Contract enforcement middleware.
Provides require_service() dependency that can be added to any merchant route
to enforce that the merchant's active contract includes the required service.
"""
from fastapi import Depends, HTTPException, Request
from middleware.auth import get_current_merchant
from loguru import logger

# ── Canonical service keys ────────────────────────────────────────────────────
# These must match what admin puts in contracts.services[]
VALID_SERVICES = {
    "cod_verification",    # Main COD order verification via WhatsApp
    "customer_support",    # Live chat + AI chatbot widget
    "help_center",         # Help Center widget for merchant's Shopify page
    "returns_management",  # Return/exchange management dashboard
    "analytics",           # Advanced analytics
    "chatbot_ai",          # AI chatbot (subset of customer_support)
}


# ── Service bundles — parent service grants child services automatically ──────
# If a merchant has cod_verification, they can also access returns_management
# because returns are a core part of the COD workflow.
SERVICE_BUNDLES = {
    "cod_verification":  ["cod_verification", "returns_management"],
    "customer_support":  ["customer_support", "help_center", "chatbot_ai"],
    "chatbot_ai":        ["chatbot_ai", "customer_support"],
    "help_center":       ["help_center", "customer_support"],
    "returns_management":["returns_management"],
    "analytics":         ["analytics"],
}


def _expand_services(raw_services: list) -> set:
    """Expand contracted services using bundle inheritance."""
    expanded = set()
    for s in raw_services:
        expanded.add(s.strip().lower())
        for bundle in SERVICE_BUNDLES.get(s.strip().lower(), []):
            expanded.add(bundle)
    return expanded


def require_service(service_key: str):
    """
    FastAPI dependency factory.
    Usage:  user = Depends(require_service("cod_verification"))
    Raises 403 with structured error if:
    - No active contract
    - Contract is expired
    - Required service not in contract

    NOTE: OPTIONS (preflight) requests are always allowed through — they must
    not trigger 401/403 or the browser's CORS check will fail before the actual
    request is even sent.
    """
    if service_key not in VALID_SERVICES:
        raise ValueError(f"Unknown service key: {service_key}")

    async def _checker(request: Request, user: dict = Depends(get_current_merchant)):
        # ── Always pass OPTIONS preflight requests ──────────────────────────
        if request.method == "OPTIONS":
            return user

        contracted_services = user.get("contracted_services", [])

        # Expand using bundles so cod_verification → also grants returns_management
        expanded = _expand_services(contracted_services)

        if not expanded:
            raise HTTPException(
                status_code=403,
                detail={
                    "error": "no_contract",
                    "service": service_key,
                    "message": "You don't have an active contract. Please contact support.",
                }
            )

        if service_key not in expanded:
            raise HTTPException(
                status_code=403,
                detail={
                    "error": "service_not_in_contract",
                    "service": service_key,
                    "message": f"The '{service_key}' service is not included in your contract. Please contact support to upgrade.",
                    "contracted_services": list(expanded),
                }
            )

        return user

    return _checker
