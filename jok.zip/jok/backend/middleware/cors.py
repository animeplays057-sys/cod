from fastapi.middleware.cors import CORSMiddleware
from config.settings import settings


def add_cors_middleware(app):
    """
    Two-layer CORS policy:
    1. Authenticated dashboard/API → strict allowlist + credentials allowed
    2. Public chatbot widget endpoints → any origin allowed, but NO credentials
       (public endpoints don't use cookies or session tokens)
    """
    app.add_middleware(
        CORSMiddleware,
        # Strict: only known frontend + plugin origins can send credentials
        allow_origins=settings.allowed_origins_list,
        # Permissive regex for cross-origin Shopify/WooCommerce widget embeds.
        # IMPORTANT: allow_credentials is False here, so this wildcard is safe
        # (browsers block credentialed wildcard CORS; we don't need credentials
        #  on public chatbot widget API calls — they use API keys in the body).
        allow_origin_regex=r"https://.*",
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "X-Internal-Token",
                       "X-Api-Key", "Accept", "Origin", "X-Requested-With"],
    )
