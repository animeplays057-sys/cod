from fastapi.middleware.cors import CORSMiddleware
from config.settings import settings

# Always include production domains even if .env is misconfigured
_ALWAYS_ALLOWED = [
    "https://codverify.tech",
    "https://www.codverify.tech",
    "http://localhost:5173",
    "http://localhost:3000",
]


def add_cors_middleware(app):
    """
    CORS policy: allow configured origins + always allow production frontend.

    NOTE: allow_origin_regex + allow_credentials=True is a known Starlette bug
    (regex is silently ignored when credentials=True). We use explicit list only.
    """
    origins = list(dict.fromkeys(settings.allowed_origins_list + _ALWAYS_ALLOWED))

    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
