-- ============================================================
-- CODVerify — Influencer Referral System Migration
-- Run this in Supabase SQL Editor (all at once)
-- ============================================================

-- 0. Add 'influencer' to user_role enum (CRITICAL — run this first)
ALTER TYPE user_role ADD VALUE IF NOT EXISTS 'influencer';

-- 1. Add influencer fields to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS referred_by_code text;
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_influencer boolean DEFAULT false;

-- 2. influencer_profiles — one row per influencer account
CREATE TABLE IF NOT EXISTS influencer_profiles (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    ref_code text UNIQUE NOT NULL,
    full_name text,
    social_handle text,        -- e.g. @rohit_ecommerce
    platform text,             -- youtube | instagram | twitter | tiktok | other
    follower_count int DEFAULT 0,
    niche text,                -- ecommerce | dropshipping | general | other
    upi_id text,               -- for Razorpay payout
    bank_account_number text,
    bank_ifsc text,
    bank_account_name text,
    status text DEFAULT 'pending',  -- pending | verified | suspended
    wallet_balance numeric(10,2) DEFAULT 0,
    total_earned numeric(10,2) DEFAULT 0,
    total_leads int DEFAULT 0,
    qualified_leads int DEFAULT 0,
    approved_by uuid REFERENCES users(id),
    approved_at timestamptz,
    rejection_reason text,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- 3. influencer_leads — one row per referred merchant
CREATE TABLE IF NOT EXISTS influencer_leads (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    influencer_id uuid NOT NULL REFERENCES influencer_profiles(id) ON DELETE CASCADE,
    merchant_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    ref_code text NOT NULL,
    status text DEFAULT 'pending',
    -- pending | called | qualified | not_qualified
    called_at timestamptz,
    qualified_at timestamptz,
    reviewed_by uuid REFERENCES users(id),  -- worker/admin who decided
    worker_notes text,
    -- Lead payout
    lead_payout_amount numeric(10,2),
    lead_payout_status text DEFAULT 'pending', -- pending | paid | cancelled
    lead_payout_id uuid,
    -- Subscription payout
    subscription_payout_amount numeric(10,2),
    subscription_payout_status text DEFAULT 'pending',
    subscription_payout_id uuid,
    subscription_at timestamptz,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- 4. influencer_payouts — wallet credit transactions
CREATE TABLE IF NOT EXISTS influencer_payouts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    influencer_id uuid NOT NULL REFERENCES influencer_profiles(id) ON DELETE CASCADE,
    lead_id uuid REFERENCES influencer_leads(id),
    payout_type text NOT NULL,  -- qualified_lead | subscription | manual_credit | withdrawal_refund
    amount numeric(10,2) NOT NULL,
    description text,
    created_at timestamptz DEFAULT now()
);

-- 5. influencer_withdrawals — withdrawal requests
CREATE TABLE IF NOT EXISTS influencer_withdrawals (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    influencer_id uuid NOT NULL REFERENCES influencer_profiles(id) ON DELETE CASCADE,
    amount numeric(10,2) NOT NULL,
    -- Payment method (at time of request)
    upi_id text,
    bank_account_number text,
    bank_ifsc text,
    bank_account_name text,
    payment_method text DEFAULT 'upi',  -- upi | bank
    -- Razorpay payout attempt
    razorpay_payout_id text,
    razorpay_fund_account_id text,
    razorpay_status text,               -- queued | processing | processed | reversed | failed
    razorpay_failure_reason text,
    -- Overall status
    status text DEFAULT 'pending',      -- pending | processing | paid | failed | rejected | manual_paid
    requested_at timestamptz DEFAULT now(),
    processed_at timestamptz,
    processed_by uuid REFERENCES users(id),
    admin_notes text,
    -- Manual fallback
    manual_payment_ref text,            -- UTR/transaction ref if paid manually
    is_manual_fallback boolean DEFAULT false
);

-- 6. influencer_payout_config — admin-configurable payout tiers
CREATE TABLE IF NOT EXISTS influencer_payout_config (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tier_label text,           -- e.g. "Starter (1-10)", "Growth (11-20)"
    tier_min int NOT NULL,
    tier_max int,              -- NULL means unlimited (51+)
    lead_payout numeric(10,2) NOT NULL DEFAULT 50,
    subscription_payout numeric(10,2) NOT NULL DEFAULT 200,
    is_active boolean DEFAULT true,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- 7. Seed default payout tiers
INSERT INTO influencer_payout_config (tier_label, tier_min, tier_max, lead_payout, subscription_payout)
VALUES
    ('Starter (1-10)',    1,  10,   50.00,  200.00),
    ('Growth (11-20)',   11,  20,   75.00,  300.00),
    ('Pro (21-50)',      21,  50,  100.00,  500.00),
    ('Elite (51+)',      51, NULL, 150.00,  750.00)
ON CONFLICT DO NOTHING;

-- 8. Indexes for performance
CREATE INDEX IF NOT EXISTS idx_influencer_profiles_user_id ON influencer_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_influencer_profiles_ref_code ON influencer_profiles(ref_code);
CREATE INDEX IF NOT EXISTS idx_influencer_profiles_status ON influencer_profiles(status);
CREATE INDEX IF NOT EXISTS idx_influencer_leads_influencer_id ON influencer_leads(influencer_id);
CREATE INDEX IF NOT EXISTS idx_influencer_leads_merchant_id ON influencer_leads(merchant_id);
CREATE INDEX IF NOT EXISTS idx_influencer_leads_status ON influencer_leads(status);
CREATE INDEX IF NOT EXISTS idx_influencer_payouts_influencer_id ON influencer_payouts(influencer_id);
CREATE INDEX IF NOT EXISTS idx_influencer_withdrawals_influencer_id ON influencer_withdrawals(influencer_id);
CREATE INDEX IF NOT EXISTS idx_influencer_withdrawals_status ON influencer_withdrawals(status);
CREATE INDEX IF NOT EXISTS idx_users_referred_by_code ON users(referred_by_code);
