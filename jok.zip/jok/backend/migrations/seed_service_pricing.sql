-- ══════════════════════════════════════════════════════════════════════════════
-- CODVerify: CLEAN service_pricing table & re-seed with correct keys
-- Run this in Supabase SQL Editor → New Query
--
-- WHY: Old entries had wrong keys (whatsapp_cod_verification, human_agent_chat,
--      return_whatsapp, etc.) causing DUPLICATE rows in admin dashboard.
--      New keys match frontend SERVICE_META in PricingPage.tsx exactly.
-- ══════════════════════════════════════════════════════════════════════════════

-- Step 1: Create table if not exists
CREATE TABLE IF NOT EXISTS service_pricing (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    service_key     text UNIQUE NOT NULL,
    label           text NOT NULL,
    icon            text DEFAULT '💬',
    amount          numeric(10,2) DEFAULT 0,
    currency        text DEFAULT 'INR',
    notes           text DEFAULT '',
    active          boolean DEFAULT true,
    display_order   int DEFAULT 0,
    created_at      timestamptz DEFAULT now(),
    updated_at      timestamptz DEFAULT now()
);

-- Step 2: DELETE all old/wrong-key entries (fixes duplicates)
DELETE FROM service_pricing WHERE service_key IN (
    'whatsapp_cod_verification',
    'call_not_picked',
    'human_agent_chat',
    'return_whatsapp',
    'delivery_notification',
    'return_new_request_wa',
    'return_merchant_alert_wa',
    'clarification_wa',
    'email_daily_summary'
);

-- Step 3: Upsert correct entries (safe to re-run)
INSERT INTO service_pricing (service_key, label, icon, amount, currency, notes, active, display_order)
VALUES
    -- ── Verification ─────────────────────────────────────────────────
    ('whatsapp_verification',   'WhatsApp COD Verification',          '💬',  0.50,  'INR', 'per message',   true,  1),
    ('call_verification',       'Call Verification',                   '📞',  7.00,  'INR', 'per call',      true,  2),
    ('call_no_answer',          'Call Not Answered / No Response',     '📵',  0.00,  'INR', 'Free',          true,  3),
    -- ── Support ──────────────────────────────────────────────────────
    ('ai_chatbot',              'AI Chatbot',                          '🤖',  0.00,  'INR', 'Unlimited',     true,  4),
    ('human_agent',             'Human Agent Chat',                    '👤',  5.00,  'INR', 'per session',   true,  5),
    -- ── Returns ──────────────────────────────────────────────────────
    ('return_wa_notification',  'Return / Exchange WA Notification',   '🔄',  0.50,  'INR', 'per message',   true,  6),
    ('return_merchant_alert',   'New Return Alert (Merchant)',          '🔔',  0.50,  'INR', 'per message',   true,  7),
    ('return_status_update',    'Return Status Update (Customer)',      '↩️', 0.50,  'INR', 'per message',   true,  8),
    -- ── Delivery ─────────────────────────────────────────────────────
    ('order_shipped',           'Order Shipped Notification',          '🚚',  0.50,  'INR', 'per message',   true,  9),
    ('order_delivered',         'Order Delivered Notification',        '📦',  0.50,  'INR', 'per message',   true, 10),
    -- ── Reports ──────────────────────────────────────────────────────
    ('email_weekly_summary',    'Weekly Email Summary',                '📧',  0.00,  'INR', 'Free',          true, 11)
ON CONFLICT (service_key) DO UPDATE
    SET label         = EXCLUDED.label,
        icon          = EXCLUDED.icon,
        amount        = EXCLUDED.amount,
        currency      = EXCLUDED.currency,
        notes         = EXCLUDED.notes,
        active        = EXCLUDED.active,
        display_order = EXCLUDED.display_order,
        updated_at    = now();

-- Step 4: Verify — should show exactly 11 rows, no duplicates
SELECT service_key, label, amount, notes, active, display_order
FROM service_pricing
ORDER BY display_order;
