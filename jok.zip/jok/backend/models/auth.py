from pydantic import BaseModel, EmailStr, Field
from typing import Optional
from utils.constants import PlanType


class RegisterRequest(BaseModel):
    name: str = Field(..., min_length=2, max_length=255)
    email: EmailStr
    password: str = Field(..., min_length=8)
    phone: Optional[str] = Field(default="", max_length=20)
    company_name: Optional[str] = Field(default="", max_length=255)
    plan_type: PlanType = PlanType.TRIAL
    referred_by_code: Optional[str] = Field(default=None, max_length=30)  # Influencer ref code
    ref_from_link: bool = False  # True if came via referral link (makes field non-editable)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class RefreshRequest(BaseModel):
    refresh_token: str


class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str = Field(..., min_length=8)


class VerifyEmailRequest(BaseModel):
    token: str


class UpdateProfileRequest(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=255)
    phone: Optional[str] = None
    company_name: Optional[str] = None
    company_logo_url: Optional[str] = None
    timezone: Optional[str] = None


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str = Field(..., min_length=8)


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: dict
