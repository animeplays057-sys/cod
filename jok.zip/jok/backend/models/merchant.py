from pydantic import BaseModel, Field
from typing import Optional, List, Any
from utils.constants import StorePlatform, VerificationStatus, TicketPriority


class DashboardStatsRequest(BaseModel):
    pass


class ChartDataRequest(BaseModel):
    period: str = "7d"
    from_date: Optional[str] = None
    to_date: Optional[str] = None


class OrderFilterParams(BaseModel):
    page: int = 1
    limit: int = 20
    status: Optional[str] = None
    search: Optional[str] = None
    date_from: Optional[str] = None
    date_to: Optional[str] = None
    store_id: Optional[str] = None
    sort_by: str = "created_at"
    sort_order: str = "desc"


class ManualOrderUpdate(BaseModel):
    status: str = Field(..., pattern="^(confirmed|cancelled)$")
    note: Optional[str] = None


class ResendVerificationRequest(BaseModel):
    pass


class ConnectStoreRequest(BaseModel):
    platform: StorePlatform
    store_url: str = Field(..., min_length=5)
    store_name: Optional[str] = None
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    access_token: Optional[str] = None


class OrderEditRequest(BaseModel):
    customer_name: Optional[str] = None
    customer_phone: Optional[str] = None
    customer_email: Optional[str] = None
    order_amount: Optional[float] = None
    order_type: Optional[str] = None
    payment_method: Optional[str] = None
    delivery_status: Optional[str] = None
    tracking_number: Optional[str] = None
    tracking_company: Optional[str] = None
    tracking_url: Optional[str] = None
    notes: Optional[str] = None
    tags: Optional[str] = None
    shipping_address_json: Optional[dict] = None


class UpdateStoreRequest(BaseModel):
    store_name: Optional[str] = None
    is_active: Optional[bool] = None


class UpdateSettingsRequest(BaseModel):
    message_delay_seconds: Optional[int] = Field(None, ge=0, le=3600)
    working_hours_enabled: Optional[bool] = None
    working_hours_start: Optional[str] = None
    working_hours_end: Optional[str] = None
    auto_cancel_on_no: Optional[bool] = None
    auto_cancel_on_no_reply: Optional[bool] = None
    no_reply_timeout_hours: Optional[int] = Field(None, ge=1, le=48)
    max_retries: Optional[int] = Field(None, ge=1, le=5)
    retry_interval_hours: Optional[int] = Field(None, ge=1, le=24)
    min_order_amount: Optional[float] = Field(None, ge=0)
    send_delivery_updates: Optional[bool] = None
    notification_email: Optional[str] = None
    notification_on_cancel: Optional[bool] = None
    notification_daily_summary: Optional[bool] = None
    notification_quota_warning: Optional[bool] = None
    webhook_callback_url: Optional[str] = None
    # Message toggles — user controls which messages get sent
    enable_verification_msg: Optional[bool] = None
    enable_thankyou_msg: Optional[bool] = None
    enable_cancel_msg: Optional[bool] = None
    enable_delivery_updates_msg: Optional[bool] = None
    enable_no_reply_reminder: Optional[bool] = None


class ConnectWhatsAppRequest(BaseModel):
    whatsapp_business_id: str
    whatsapp_phone_number_id: str
    whatsapp_access_token: str


class GenerateApiKeyRequest(BaseModel):
    label: str = Field(..., min_length=1, max_length=255)


class CreateTemplateRequest(BaseModel):
    template_name: str = Field(..., min_length=1)
    template_type: str
    template_body: str
    template_header: Optional[str] = None
    template_footer: Optional[str] = None
    template_buttons_json: Optional[Any] = None
    template_language: str = "en"
    variables_json: Optional[Any] = None


class BlacklistRequest(BaseModel):
    phone_number: str
    phone_hash: Optional[str] = None
    reason: Optional[str] = None


class UpgradePlanRequest(BaseModel):
    plan_type: str
    billing_cycle: str = "monthly"


class WalletRechargeRequest(BaseModel):
    amount: float = Field(..., gt=0)


class WalletAddMoneyRequest(BaseModel):
    amount: float = Field(..., gt=0)
    payment_id: Optional[str] = None
    payment_method: str = "razorpay"


class CreateTicketRequest(BaseModel):
    subject: str = Field(..., min_length=3, max_length=500)
    description: str = Field(..., min_length=10)
    priority: TicketPriority = TicketPriority.MEDIUM
    category: Optional[str] = None


class TicketReplyRequest(BaseModel):
    message: str = Field(..., min_length=1)
