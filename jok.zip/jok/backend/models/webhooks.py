from pydantic import BaseModel, Field
from typing import Optional, List, Any


class OrderProduct(BaseModel):
    name: str
    quantity: int = 1
    price: float
    image_url: Optional[str] = None


class ShippingAddress(BaseModel):
    line1: str = ""
    line2: Optional[str] = None
    city: str = ""
    state: str = ""
    pincode: str = ""
    country: str = "India"


class NewOrderWebhook(BaseModel):
    store_order_id: str = Field(..., min_length=1)
    order_number: Optional[str] = None
    customer_name: str = ""
    customer_phone: str = ""
    customer_email: Optional[str] = None
    order_amount: float = Field(..., gt=0)
    currency: str = "INR"
    payment_method: str = "cod"  # cod, prepaid, manual, etc.
    order_type: Optional[str] = None  # auto-detected from payment_method if not set
    products: List[OrderProduct] = []
    shipping_address: Optional[ShippingAddress] = None
    fulfillment_status: str = "unfulfilled"  # unfulfilled, partial, fulfilled
    tags: Optional[str] = None
    notes: Optional[str] = None
    source: str = "shopify"  # shopify, woocommerce, manual
    shop_domain: Optional[str] = None
    tracking_number: Optional[str] = None
    tracking_url: Optional[str] = None
    tracking_company: Optional[str] = None


class DeliveryUpdateWebhook(BaseModel):
    store_order_id: str
    delivery_status: str = Field(..., pattern="^(shipped|in_transit|out_for_delivery|delivered|returned)$")
    tracking_number: Optional[str] = None
    tracking_url: Optional[str] = None
    tracking_company: Optional[str] = None
