from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from typing import Optional
from config.database import get_db
from middleware.auth import get_current_admin
from utils.helpers import success_response, paginate_params, pagination_meta
from models.admin import AdminManualCredit, AdminWalletCredit, AdminUpdatePricing
from services.notification_service import create_notification
from utils.constants import DEFAULT_PER_ORDER_RATE

router = APIRouter(prefix="/api/v1/admin/billing", tags=["Admin Billing"])


# ── Models ────────────────────────────────────────────────────────────────────

class WalletPlanBody(BaseModel):
    label: str = Field(..., min_length=1, max_length=50)
    amount: float = Field(..., gt=0)
    bonus: float = Field(0.0, ge=0)
    currency: str = Field("INR", pattern="^(INR|USD)$")
    is_active: bool = True
    sort_order: int = 0


class SplitPricingBody(BaseModel):
    per_order_rate_inr: float = Field(..., gt=0, description="INR per order (India)")
    per_order_rate_usd: float = Field(..., gt=0, description="USD per order (International)")
    description: Optional[str] = None


# ── Overview ──────────────────────────────────────────────────────────────────

@router.get("/overview")
async def overview(user: dict = Depends(get_current_admin)):
    """Admin billing overview: total revenue, wallet stats, usage."""
    db = get_db()
    from datetime import datetime, timezone

    merchants = db.table("users").select("wallet_balance").eq("role", "merchant").execute()
    total_wallet = sum(float(m.get("wallet_balance", 0) or 0) for m in (merchants.data or []))

    try:
        recharges = db.table("billing_transactions").select("amount,transaction_type").eq("status", "completed").execute()
        recharge_types = {"wallet_recharge", "recharge", "credit", "top_up", "wallet_credit", "wallet_admin_credit"}
        total_revenue = sum(
            float(t.get("amount", 0))
            for t in (recharges.data or [])
            if str(t.get("transaction_type", "")).lower() in recharge_types
               or "recharge" in str(t.get("transaction_type", "")).lower()
               or "credit" in str(t.get("transaction_type", "")).lower()
        )
        if total_revenue == 0:
            total_revenue = sum(float(t.get("amount", 0)) for t in (recharges.data or []))

        today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0).isoformat()
        today_txns = db.table("billing_transactions").select("amount,transaction_type").eq("status", "completed").gte("created_at", today_start).execute()
        today_revenue = sum(float(t.get("amount", 0)) for t in (today_txns.data or []))
    except Exception:
        total_revenue = 0.0
        today_revenue = 0.0
        today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0).isoformat()

    try:
        rate_setting = db.table("admin_settings").select("setting_value").eq("setting_key", "per_order_rate_inr").execute()
        per_order_rate = float(rate_setting.data[0]["setting_value"]) if rate_setting.data else DEFAULT_PER_ORDER_RATE
    except Exception:
        per_order_rate = DEFAULT_PER_ORDER_RATE

    try:
        today_orders = db.table("orders").select("id", count="exact").gte("created_at", today_start).execute()
        today_order_count = today_orders.count or 0
    except Exception:
        today_order_count = 0

    low_balance_threshold = per_order_rate * 50
    low_balance = [m for m in (merchants.data or []) if float(m.get("wallet_balance", 0) or 0) < low_balance_threshold]

    return success_response({
        "total_revenue": total_revenue,
        "today_revenue": today_revenue,
        "total_wallet_balance": total_wallet,
        "per_order_rate_inr": per_order_rate,
        "today_orders": today_order_count,
        "total_merchants": len(merchants.data or []),
        "low_balance_merchants": len(low_balance),
    })


@router.get("/transactions")
async def transactions(page: int = 1, limit: int = 20, merchant_id: str = None, status: str = None, txn_type: str = None, user: dict = Depends(get_current_admin)):
    db = get_db()
    offset, limit = paginate_params(page, limit)
    query = db.table("billing_transactions").select("*, users!inner(name, email, company_name)", count="exact")
    if merchant_id:
        query = query.eq("user_id", merchant_id)
    if status:
        query = query.eq("status", status)
    if txn_type:
        query = query.eq("transaction_type", txn_type)
    result = query.order("created_at", desc=True).range(offset, offset + limit - 1).execute()
    return success_response({"transactions": result.data or [], "pagination": pagination_meta(result.count or 0, page, limit)})


# ── Wallet Credit ─────────────────────────────────────────────────────────────

@router.post("/wallet/credit")
async def credit_wallet(body: AdminWalletCredit, user: dict = Depends(get_current_admin)):
    """Admin credits money to a merchant's wallet."""
    db = get_db()
    merchant = db.table("users").select("wallet_balance, name").eq("id", body.merchant_id).execute()
    if not merchant.data:
        raise HTTPException(status_code=404, detail="Merchant not found")

    m_data = merchant.data[0]
    current = float(m_data.get("wallet_balance", 0) or 0)
    new_balance = current + body.amount

    # Determine currency
    from services.payment_service import get_currency_config
    cur = get_currency_config("IN")
    currency = cur["currency"]
    sym = cur["symbol"]

    db.table("users").update({"wallet_balance": new_balance}).eq("id", body.merchant_id).execute()
    db.table("billing_transactions").insert({
        "user_id": body.merchant_id,
        "amount": body.amount,
        "currency": currency,
        "transaction_type": "wallet_admin_credit",
        "description": body.reason or f"Admin credit by {user.get('name', 'Admin')}",
        "status": "completed",
        "paid_at": "now()",
    }).execute()

    await create_notification(body.merchant_id, "Wallet Credited 💰",
        f"{sym}{body.amount} has been added to your wallet by admin.", "success", "billing", "/dashboard/billing")

    db.table("activity_logs").insert({
        "user_id": user["id"], "action": "wallet_admin_credit",
        "entity_type": "billing", "entity_id": body.merchant_id,
        "details_json": {"amount": body.amount, "currency": currency, "reason": body.reason},
    }).execute()

    return success_response({"new_balance": new_balance}, f"{sym}{body.amount} credited to merchant wallet")


# ── Pricing (Split INR/USD) ───────────────────────────────────────────────────

@router.get("/pricing")
async def get_pricing(user: dict = Depends(get_current_admin)):
    """Get per-order pricing for both INR and USD."""
    db = get_db()
    def _get_rate(key, default):
        r = db.table("admin_settings").select("setting_value").eq("setting_key", key).execute()
        return float(r.data[0]["setting_value"]) if r.data else default

    return success_response({
        "per_order_rate_inr": _get_rate("per_order_rate_inr", DEFAULT_PER_ORDER_RATE),
        "per_order_rate_usd": _get_rate("per_order_rate_usd", round(DEFAULT_PER_ORDER_RATE / 83, 4)),
        # Legacy key — kept for backwards compat
        "per_order_rate": _get_rate("per_order_rate", DEFAULT_PER_ORDER_RATE),
    })


@router.put("/pricing")
async def update_pricing(body: SplitPricingBody, user: dict = Depends(get_current_admin)):
    """Admin sets per-order rates for INR and USD separately."""
    db = get_db()

    def _upsert(key, value, label, group):
        existing = db.table("admin_settings").select("id").eq("setting_key", key).execute()
        if existing.data:
            db.table("admin_settings").update({"setting_value": str(value), "updated_by": user["id"]}).eq("setting_key", key).execute()
        else:
            db.table("admin_settings").insert({"setting_key": key, "setting_value": str(value), "setting_label": label, "setting_group": group, "updated_by": user["id"]}).execute()

    _upsert("per_order_rate_inr", body.per_order_rate_inr, "Per Order Rate (₹ INR)", "billing")
    _upsert("per_order_rate_usd", body.per_order_rate_usd, "Per Order Rate ($ USD)", "billing")
    # Also update legacy key
    _upsert("per_order_rate", body.per_order_rate_inr, "Per Order Verification Rate", "billing")

    db.table("activity_logs").insert({
        "user_id": user["id"], "action": "update_pricing",
        "entity_type": "settings", "entity_id": "per_order_rate",
        "details_json": {"inr": body.per_order_rate_inr, "usd": body.per_order_rate_usd},
    }).execute()

    return success_response({
        "per_order_rate_inr": body.per_order_rate_inr,
        "per_order_rate_usd": body.per_order_rate_usd,
    }, "Pricing updated for INR and USD")


# ── Wallet Recharge Plans (Admin CRUD) ────────────────────────────────────────

@router.get("/wallet-plans")
async def list_wallet_plans(currency: str = None, user: dict = Depends(get_current_admin)):
    """List all wallet top-up plans. Optionally filter by currency (INR/USD)."""
    db = get_db()
    query = db.table("wallet_recharge_plans").select("*").order("currency").order("sort_order")
    if currency:
        query = query.eq("currency", currency.upper())
    result = query.execute()
    return success_response(result.data or [])


@router.post("/wallet-plans")
async def create_wallet_plan(body: WalletPlanBody, user: dict = Depends(get_current_admin)):
    """Create a new wallet top-up plan."""
    db = get_db()
    result = db.table("wallet_recharge_plans").insert({
        "label": body.label,
        "amount": body.amount,
        "bonus": body.bonus,
        "currency": body.currency,
        "is_active": body.is_active,
        "sort_order": body.sort_order,
    }).execute()
    return success_response(result.data[0] if result.data else {}, "Wallet plan created")


@router.put("/wallet-plans/{plan_id}")
async def update_wallet_plan(plan_id: str, body: WalletPlanBody, user: dict = Depends(get_current_admin)):
    """Update an existing wallet top-up plan."""
    db = get_db()
    existing = db.table("wallet_recharge_plans").select("id").eq("id", plan_id).execute()
    if not existing.data:
        raise HTTPException(status_code=404, detail="Wallet plan not found")
    db.table("wallet_recharge_plans").update({
        "label": body.label, "amount": body.amount, "bonus": body.bonus,
        "currency": body.currency, "is_active": body.is_active, "sort_order": body.sort_order,
    }).eq("id", plan_id).execute()
    return success_response(message="Wallet plan updated")


@router.delete("/wallet-plans/{plan_id}")
async def delete_wallet_plan(plan_id: str, user: dict = Depends(get_current_admin)):
    """Delete a wallet top-up plan."""
    db = get_db()
    existing = db.table("wallet_recharge_plans").select("id").eq("id", plan_id).execute()
    if not existing.data:
        raise HTTPException(status_code=404, detail="Wallet plan not found")
    db.table("wallet_recharge_plans").delete().eq("id", plan_id).execute()
    return success_response(message="Wallet plan deleted")


@router.post("/manual-credit")
async def manual_credit(body: AdminManualCredit, user: dict = Depends(get_current_admin)):
    db = get_db()
    # Get merchant currency
    from services.payment_service import get_currency_config
    cur = get_currency_config("IN")
    db.table("billing_transactions").insert({
        "user_id": body.merchant_id, "amount": body.amount, "currency": cur["currency"],
        "transaction_type": body.type, "description": body.description, "status": "completed",
        "paid_at": "now()",
    }).execute()
    return success_response(message=f"Manual {body.type} of {cur['symbol']}{body.amount} processed")


