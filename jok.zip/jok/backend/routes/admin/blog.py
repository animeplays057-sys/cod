from fastapi import APIRouter, Depends, HTTPException
from config.database import get_db
from middleware.auth import get_current_admin
from models.admin import CreateBlogPostRequest, UpdateBlogPostRequest
from utils.helpers import success_response, slugify, calculate_reading_time, paginate_params, pagination_meta
from datetime import datetime, timezone
import asyncio
from utils.seo import ping_indexnow
import os

router = APIRouter(prefix="/api/v1/admin/blog", tags=["Admin Blog"])


@router.get("/posts")
async def list_posts(page: int = 1, limit: int = 20, status: str = None, category: str = None, user: dict = Depends(get_current_admin)):
    db = get_db()
    offset, limit = paginate_params(page, limit)
    query = db.table("blog_posts").select("*", count="exact")
    if status == "published":
        query = query.eq("is_published", True)
    elif status == "draft":
        query = query.eq("is_published", False)
    if category:
        query = query.eq("category", category)
    result = query.order("created_at", desc=True).range(offset, offset + limit - 1).execute()
    return success_response({"posts": result.data or [], "pagination": pagination_meta(result.count or 0, page, limit)})


@router.post("/posts")
async def create_post(body: CreateBlogPostRequest, user: dict = Depends(get_current_admin)):
    db = get_db()
    data = body.model_dump()
    data["slug"] = slugify(body.title)
    data["reading_time_minutes"] = calculate_reading_time(body.content)
    data["author_id"] = user["id"]
    data["author_name"] = user.get("name", "Admin")
    if body.is_published:
        data["published_at"] = datetime.now(timezone.utc).isoformat()
    result = db.table("blog_posts").insert(data).execute()
    
    if body.is_published:
        host_url = os.getenv("FRONTEND_URL", "https://codverify.tech").rstrip("/")
        public_url = f"{host_url}/blog/{data['slug']}"
        asyncio.create_task(ping_indexnow(public_url))
        
    return success_response(result.data[0], "Post created")


@router.put("/posts/{post_id}")
async def update_post(post_id: str, body: UpdateBlogPostRequest, user: dict = Depends(get_current_admin)):
    db = get_db()
    updates = body.model_dump(exclude_unset=True)
    if "content" in updates:
        updates["reading_time_minutes"] = calculate_reading_time(updates["content"])
    if "title" in updates:
        updates["slug"] = slugify(updates["title"])
    if updates.get("is_published"):
        existing = db.table("blog_posts").select("published_at, slug").eq("id", post_id).execute()
        if existing.data and not existing.data[0].get("published_at"):
            updates["published_at"] = datetime.now(timezone.utc).isoformat()
            
            # Ping IndexNow if transitioned to published
            host_url = os.getenv("FRONTEND_URL", "https://codverify.tech").rstrip("/")
            slug_val = updates.get("slug", existing.data[0].get("slug"))
            public_url = f"{host_url}/blog/{slug_val}"
            asyncio.create_task(ping_indexnow(public_url))

    if updates:
        db.table("blog_posts").update(updates).eq("id", post_id).execute()
    return success_response(message="Post updated")


@router.delete("/posts/{post_id}")
async def delete_post(post_id: str, user: dict = Depends(get_current_admin)):
    db = get_db()
    db.table("blog_posts").delete().eq("id", post_id).execute()
    return success_response(message="Post deleted")
