from fastapi import APIRouter, Depends
from datetime import datetime, timezone, timedelta
from config.database import get_db
from middleware.auth import get_current_admin
from utils.helpers import success_response

router = APIRouter(prefix="/api/v1/admin/dashboard", tags=["Admin Dashboard"])


@router.get("/stats")
async def stats(user: dict = Depends(get_current_admin)):
    db = get_db()
    now = datetime.now(timezone.utc)
    today = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    week_ago = (now - timedelta(days=7)).isoformat()
    month_ago = (now - timedelta(days=30)).isoformat()

    merchants = db.table("users").select("status", count="exact").eq("role", "merchant").execute()
    active = sum(1 for m in (merchants.data or []) if m["status"] == "active")
    trial = sum(1 for m in (merchants.data or []) if m["status"] == "trial")
    suspended = sum(1 for m in (merchants.data or []) if m["status"] == "suspended")

    total_orders = db.table("orders").select("id", count="exact").execute()
    today_orders = db.table("orders").select("id, order_type", count="exact").gte("created_at", today).execute()
    month_orders = db.table("orders").select("verification_status", count="exact").gte("created_at", month_ago).execute()

    cod_today = sum(1 for o in (today_orders.data or []) if o.get("order_type") == "cod")
    prepaid_today = sum(1 for o in (today_orders.data or []) if o.get("order_type") == "prepaid")

    confirmed_month = sum(1 for o in (month_orders.data or []) if o.get("verification_status") in ("confirmed", "manual_confirmed"))
    conf_rate = round(confirmed_month / (month_orders.count or 1) * 100, 1)

    subs = db.table("service_subscriptions").select("plan_type, price_monthly").eq("status", "active").execute()
    mrr = sum(float(s.get("price_monthly", 0) or 0) for s in (subs.data or []))
    by_plan = {}
    for s in (subs.data or []):
        by_plan[s["plan_type"]] = by_plan.get(s["plan_type"], 0) + 1

    new_week = db.table("users").select("id", count="exact").eq("role", "merchant").gte("created_at", week_ago).execute()
    new_today = db.table("users").select("id", count="exact").eq("role", "merchant").gte("created_at", today).execute()

    try:
        tickets = db.table("support_tickets").select("id", count="exact").eq("status", "open").execute()
        open_tickets = tickets.count or 0
    except Exception:
        open_tickets = 0

    return success_response({
        "merchants": {"total": merchants.count or 0, "active": active, "trial": trial, "suspended": suspended},
        "orders": {"total": total_orders.count or 0, "today": today_orders.count or 0, "cod_today": cod_today, "prepaid_today": prepaid_today, "this_month": month_orders.count or 0},
        "confirmation_rate": conf_rate,
        "mrr": mrr,
        "subscriptions_by_plan": by_plan,
        "signups": {"today": new_today.count or 0, "this_week": new_week.count or 0},
        "open_tickets": open_tickets,
    })


@router.get("/chart-data")
async def chart_data(period: str = "30d", user: dict = Depends(get_current_admin)):
    db = get_db()
    days = {"7d": 7, "30d": 30, "90d": 90, "12m": 365}.get(period, 30)
    start = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

    orders = db.table("orders").select("created_at, verification_status").gte("created_at", start).execute()
    daily = {}
    for o in (orders.data or []):
        day = o["created_at"][:10]
        if day not in daily:
            daily[day] = {"date": day, "total": 0, "confirmed": 0, "cancelled": 0}
        daily[day]["total"] += 1
        if o.get("verification_status") in ("confirmed", "manual_confirmed"):
            daily[day]["confirmed"] += 1
        elif o.get("verification_status") in ("cancelled", "manual_cancelled"):
            daily[day]["cancelled"] += 1

    return success_response(sorted(daily.values(), key=lambda x: x["date"]))


@router.get("/new-requests")
async def new_requests(user: dict = Depends(get_current_admin)):
    """Get recent merchant signups that haven't been assigned contracts yet (new service requests)."""
    db = get_db()
    # Get merchants who signed up in last 30 days, ordered by newest first
    recent = db.table("users").select(
        "id, name, email, phone, company_name, status, account_status, shopify_shop_domain, created_at"
    ).eq("role", "merchant").order("created_at", desc=True).limit(50).execute()

    requests_list = []
    for u in (recent.data or []):
        # Determine source
        source = "shopify" if u.get("shopify_shop_domain") else "website"
        # Check if they already have a contract
        contract_check = db.table("contracts").select("id, status").eq("user_id", u["id"]).limit(1).execute()
        has_contract = bool(contract_check.data)
        contract_status = contract_check.data[0]["status"] if has_contract else None

        requests_list.append({
            "id": u["id"],
            "name": u.get("name", "Unknown"),
            "email": u.get("email", ""),
            "phone": u.get("phone", ""),
            "company_name": u.get("company_name", ""),
            "source": source,
            "shop_domain": u.get("shopify_shop_domain", ""),
            "status": u.get("status", ""),
            "account_status": u.get("account_status", "pending_activation"),
            "has_contract": has_contract,
            "contract_status": contract_status,
            "created_at": u.get("created_at", ""),
        })

    # Split: pending (no contract) first, then with contract
    pending = [r for r in requests_list if not r["has_contract"]]
    with_contract = [r for r in requests_list if r["has_contract"]]

    return success_response({
        "pending_requests": pending,
        "processed_requests": with_contract,
        "total_pending": len(pending),
        "total_processed": len(with_contract),
    })
