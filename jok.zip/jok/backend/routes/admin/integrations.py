"""
Admin Integrations API — Manage Groq, SMTP, Shopify Apps from Admin Dashboard
All credentials stored in admin_settings / shopify_apps table (encrypted where needed)
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime, timezone
from config.database import get_db
from middleware.auth import get_current_admin
from utils.helpers import success_response
from utils.encryption import encrypt_value, decrypt_value
from services.email_service import _send_email_async, _is_configured as _email_configured
from services.groq_service import test_groq_connection
from services import shopify_app_service

router = APIRouter(prefix="/api/v1/admin/integrations", tags=["Admin Integrations"])


# ─── Models ───────────────────────────────────────────────────────
class GroqConfig(BaseModel):
    api_key: str
    model: str = "llama-3.1-8b-instant"
    temperature: float = Field(0.3, ge=0.0, le=1.0)
    enabled: bool = True
    system_prompt: Optional[str] = None


class SMTPConfig(BaseModel):
    host: str
    port: int = Field(587, ge=25, le=65535)
    user: str
    password: str
    from_email: str
    from_name: str = "CODVerify"
    enabled: bool = True


class TestEmailRequest(BaseModel):
    to_email: str


# ─── Get all integration statuses ────────────────────────────────

@router.get("/status")
async def get_integration_status(admin: dict = Depends(get_current_admin)):
    """Get current status of all integrations"""
    db = get_db()
    result = db.table("admin_settings").select("*").limit(1).execute()
    row = result.data[0] if result.data else {}

    return success_response({
        "groq": {
            "enabled": row.get("groq_enabled", False),
            "configured": bool(row.get("groq_api_key")),
            "model": row.get("groq_model", "llama-3.1-8b-instant"),
            "temperature": row.get("groq_temperature", 0.3),
            "system_prompt": row.get("groq_system_prompt", ""),
        },
        "smtp": {
            "enabled": row.get("smtp_enabled", False),
            "configured": bool(row.get("smtp_host") and row.get("smtp_user")),
            "host": row.get("smtp_host", ""),
            "port": row.get("smtp_port", 587),
            "from_email": row.get("smtp_from_email", ""),
            "from_name": row.get("smtp_from_name", "CODVerify"),
        },
    })


# ─── Groq ─────────────────────────────────────────────────────────

@router.post("/groq")
async def save_groq_config(body: GroqConfig, admin: dict = Depends(get_current_admin)):
    """Save Groq API configuration"""
    db = get_db()
    _ensure_admin_settings(db)
    
    update_data = {
        "groq_api_key": body.api_key,
        "groq_model": body.model,
        "groq_temperature": body.temperature,
        "groq_enabled": body.enabled,
    }
    if body.system_prompt:
        update_data["groq_system_prompt"] = body.system_prompt
    
    db.table("admin_settings").update(update_data).eq("id", _get_settings_id(db)).execute()
    return success_response(message="Groq configuration saved")


@router.post("/groq/test")
async def test_groq(admin: dict = Depends(get_current_admin)):
    result = await test_groq_connection()
    if result["success"]:
        return success_response(result, "Groq connection successful")
    raise HTTPException(status_code=400, detail=result.get("error", "Groq test failed"))


# ─── SMTP Email ────────────────────────────────────────────────────

@router.post("/smtp")
async def save_smtp_config(body: SMTPConfig, admin: dict = Depends(get_current_admin)):
    """Save SMTP email configuration"""
    db = get_db()
    _ensure_admin_settings(db)
    
    # Encrypt password
    encrypted_pass = encrypt_value(body.password) if body.password else ""
    
    db.table("admin_settings").update({
        "smtp_host": body.host,
        "smtp_port": body.port,
        "smtp_user": body.user,
        "smtp_password": encrypted_pass,
        "smtp_from_email": body.from_email,
        "smtp_from_name": body.from_name,
        "smtp_enabled": body.enabled,
    }).eq("id", _get_settings_id(db)).execute()
    
    return success_response(message="SMTP configuration saved")


@router.post("/smtp/test")
async def test_smtp(admin: dict = Depends(get_current_admin)):
    """Test email webhook connection"""
    if not _email_configured():
        raise HTTPException(status_code=400, detail="EMAIL_WEBHOOK_URL not set in environment")
    return success_response({"configured": True}, "Email webhook is configured")


@router.post("/smtp/send-test")
async def send_test_email(body: TestEmailRequest, admin: dict = Depends(get_current_admin)):
    """Send a test email to verify SMTP config"""
    try:
        _send_email_async(
            body.to_email,
            "CODVerify — Email Test",
            "<h2>✅ Email webhook is working!</h2><p>This is a test email from your CODVerify admin dashboard.</p>"
        )
        return success_response(message=f"Test email sent to {body.to_email}")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ─── Pricing per country ────────────────────────────────────────── 

class CountryPricing(BaseModel):
    india_whatsapp_rate: float = Field(1.0, description="INR per WhatsApp verification")
    india_chatbot_rate: float = Field(0.5, description="INR per Groq chatbot conversation")
    usa_sms_rate: float = Field(0.08, description="USD per SMS verification")
    usa_voice_rate_per_min: float = Field(0.14, description="USD per voice call minute")
    usa_chatbot_rate: float = Field(0.02, description="USD per Groq chatbot conversation")
    int_sms_rate: float = Field(0.10, description="USD per SMS for international")


@router.get("/pricing")
async def get_pricing_config(admin: dict = Depends(get_current_admin)):
    db = get_db()
    result = db.table("admin_settings").select(
        "india_whatsapp_rate, india_chatbot_rate, usa_sms_rate, usa_voice_rate_per_min, usa_chatbot_rate, int_sms_rate"
    ).limit(1).execute()
    row = result.data[0] if result.data else {}
    return success_response({
        "india_whatsapp_rate": row.get("india_whatsapp_rate", 1.0),
        "india_chatbot_rate": row.get("india_chatbot_rate", 0.5),
        "usa_sms_rate": row.get("usa_sms_rate", 0.08),
        "usa_voice_rate_per_min": row.get("usa_voice_rate_per_min", 0.14),
        "usa_chatbot_rate": row.get("usa_chatbot_rate", 0.02),
        "int_sms_rate": row.get("int_sms_rate", 0.10),
    })



@router.put("/pricing")
async def update_pricing_config(body: CountryPricing, admin: dict = Depends(get_current_admin)):
    db = get_db()
    _ensure_admin_settings(db)
    db.table("admin_settings").update(body.model_dump()).eq("id", _get_settings_id(db)).execute()
    return success_response(message="Pricing updated")


# ─── Payment Gateways ─────────────────────────────────────────────


class RazorpayConfig(BaseModel):
    key_id: str
    key_secret: str
    enabled: bool = True


class StripeConfig(BaseModel):
    secret_key: str
    publishable_key: str
    webhook_secret: str = ""
    enabled: bool = True


@router.get("/payment-gateways")
async def get_payment_gateways(admin: dict = Depends(get_current_admin)):
    """Get configured payment gateways (keys masked)."""
    from config.settings import settings
    return success_response({
        "razorpay": {
            "enabled": bool(settings.RAZORPAY_KEY_ID),
            "configured": bool(settings.RAZORPAY_KEY_ID and settings.RAZORPAY_KEY_SECRET),
            "key_id": settings.RAZORPAY_KEY_ID[:8] + "..." if settings.RAZORPAY_KEY_ID else "",
        },
        "stripe": {
            "enabled": bool(settings.STRIPE_SECRET_KEY),
            "configured": bool(settings.STRIPE_SECRET_KEY and settings.STRIPE_PUBLISHABLE_KEY),
            "publishable_key": settings.STRIPE_PUBLISHABLE_KEY,
            "mode": "live" if (settings.STRIPE_SECRET_KEY and not settings.STRIPE_SECRET_KEY.startswith("sk_test")) else "test",
        },
    })


@router.post("/razorpay")
async def save_razorpay(body: RazorpayConfig, admin: dict = Depends(get_current_admin)):
    """
    Save Razorpay credentials.
    NOTE: These are saved into admin_settings DB so they persist without redeployment.
    The payment_service reads from DB first, env vars as fallback.
    """
    db = get_db()
    _ensure_admin_settings(db)
    db.table("admin_settings").update({
        "razorpay_key_id": body.key_id,
        "razorpay_key_secret": encrypt_value(body.key_secret),
        "razorpay_enabled": body.enabled,
    }).eq("id", _get_settings_id(db)).execute()
    return success_response(message="Razorpay configuration saved")


@router.post("/razorpay/test")
async def test_razorpay_endpoint(admin: dict = Depends(get_current_admin)):
    """Test Razorpay connection."""
    from services.payment_service import test_razorpay_connection
    result = await test_razorpay_connection()
    if result["success"]:
        return success_response(result, "Razorpay connection successful")
    raise HTTPException(status_code=400, detail=result.get("error", "Razorpay test failed"))


@router.post("/stripe")
async def save_stripe(body: StripeConfig, admin: dict = Depends(get_current_admin)):
    """
    Save Stripe credentials.
    These are saved into admin_settings DB so they persist without redeployment.
    """
    db = get_db()
    _ensure_admin_settings(db)
    db.table("admin_settings").update({
        "stripe_publishable_key": body.publishable_key,
        "stripe_secret_key": encrypt_value(body.secret_key),
        "stripe_webhook_secret": encrypt_value(body.webhook_secret) if body.webhook_secret else "",
        "stripe_enabled": body.enabled,
    }).eq("id", _get_settings_id(db)).execute()
    return success_response(message="Stripe configuration saved")


@router.post("/stripe/test")
async def test_stripe_endpoint(admin: dict = Depends(get_current_admin)):
    """Test Stripe connection."""
    from services.payment_service import test_stripe_connection
    result = await test_stripe_connection()
    if result["success"]:
        return success_response(result, f"Stripe connection successful (mode: {result.get('mode', 'unknown')})")
    raise HTTPException(status_code=400, detail=result.get("error", "Stripe test failed"))


# ─── Helpers ──────────────────────────────────────────────────────

def _ensure_admin_settings(db):
    """Ensure admin_settings row exists"""
    result = db.table("admin_settings").select("id").limit(1).execute()
    if not result.data:
        db.table("admin_settings").insert({"placeholder": True}).execute()


def _get_settings_id(db) -> str:
    result = db.table("admin_settings").select("id").limit(1).execute()
    return result.data[0]["id"] if result.data else None


# ══════════════════════════════════════════════════════════════════════════════
# SHOPIFY APPS — DB-Driven Credential Management
# ══════════════════════════════════════════════════════════════════════════════

class ShopifyAppCreate(BaseModel):
    app_name: str
    api_key: str
    api_secret: str
    scopes: str = "read_orders,write_orders,read_customers,write_customers,read_fulfillments,write_fulfillments"
    is_active: bool = True
    notes: str = ""


class ShopifyAppUpdate(BaseModel):
    app_name: Optional[str] = None
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    scopes: Optional[str] = None
    is_active: Optional[bool] = None
    status: Optional[str] = None
    notes: Optional[str] = None


# ── List all Shopify Apps ──────────────────────────────────────────────────────
@router.get("/shopify-apps")
async def list_shopify_apps(admin: dict = Depends(get_current_admin)):
    """
    List all configured Shopify apps.
    Secrets are masked — never returned in full to the frontend.
    """
    apps = shopify_app_service.get_all_shopify_apps(include_secrets=False)

    # Enrich each app with live install count from shopify_install_keys
    if apps:
        db = get_db()
        for app in apps:
            idx = app["app_index"]
            try:
                count_res = db.table("shopify_install_keys").select(
                    "id", count="exact"
                ).eq("app_index", idx).execute()
                app["live_install_count"] = count_res.count or 0
            except Exception:
                app["live_install_count"] = app.get("install_count", 0)

    return success_response({
        "apps": apps,
        "total": len(apps),
        "next_app_index": shopify_app_service.get_next_app_index(),
    })


# ── Add a new Shopify App ──────────────────────────────────────────────────────
@router.post("/shopify-apps")
async def add_shopify_app(body: ShopifyAppCreate, admin: dict = Depends(get_current_admin)):
    """
    Add a new Shopify App to the system.
    app_index is auto-assigned (next available slot).
    The api_secret is encrypted before storage.
    """
    db = get_db()

    # Validate app_name is non-empty
    if not body.app_name.strip():
        raise HTTPException(status_code=400, detail="app_name is required")
    if not body.api_key.strip():
        raise HTTPException(status_code=400, detail="api_key (Client ID) is required")
    if not body.api_secret.strip():
        raise HTTPException(status_code=400, detail="api_secret is required")

    # Auto-assign next app_index
    next_index = shopify_app_service.get_next_app_index()

    # Encrypt the secret
    encrypted_secret = encrypt_value(body.api_secret.strip())

    now = datetime.now(timezone.utc).isoformat()
    try:
        result = db.table("shopify_apps").insert({
            "app_index": next_index,
            "app_name": body.app_name.strip(),
            "api_key": body.api_key.strip(),
            "api_secret_encrypted": encrypted_secret,
            "scopes": body.scopes.strip(),
            "is_active": body.is_active,
            "status": "active" if body.is_active else "inactive",
            "install_count": 0,
            "notes": body.notes.strip(),
            "created_at": now,
            "updated_at": now,
        }).execute()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create Shopify app: {str(e)}")

    shopify_app_service.invalidate_cache()
    created = result.data[0] if result.data else {}

    return success_response(
        {"app_index": next_index, "app_name": body.app_name},
        f"Shopify app '{body.app_name}' added as App #{next_index}"
    )


# ── Update a Shopify App ──────────────────────────────────────────────────────
@router.put("/shopify-apps/{app_index}")
async def update_shopify_app(app_index: int, body: ShopifyAppUpdate, admin: dict = Depends(get_current_admin)):
    """
    Update an existing Shopify App.
    Only provided fields are updated. If api_secret is provided, it is re-encrypted.
    """
    db = get_db()

    # Check app exists
    existing = db.table("shopify_apps").select("id, app_name").eq("app_index", app_index).execute()
    if not existing.data:
        raise HTTPException(status_code=404, detail=f"Shopify app with app_index={app_index} not found")

    updates: dict = {"updated_at": datetime.now(timezone.utc).isoformat()}

    if body.app_name is not None:
        updates["app_name"] = body.app_name.strip()
    if body.api_key is not None:
        updates["api_key"] = body.api_key.strip()
    if body.api_secret is not None and body.api_secret.strip():
        updates["api_secret_encrypted"] = encrypt_value(body.api_secret.strip())
    if body.scopes is not None:
        updates["scopes"] = body.scopes.strip()
    if body.is_active is not None:
        updates["is_active"] = body.is_active
        updates["status"] = "active" if body.is_active else "inactive"
    if body.status is not None:
        updates["status"] = body.status
    if body.notes is not None:
        updates["notes"] = body.notes.strip()

    db.table("shopify_apps").update(updates).eq("app_index", app_index).execute()
    shopify_app_service.invalidate_cache()

    return success_response(
        {"app_index": app_index},
        f"Shopify app #{app_index} updated successfully"
    )


# ── Toggle active/inactive ────────────────────────────────────────────────────
@router.patch("/shopify-apps/{app_index}/toggle")
async def toggle_shopify_app(app_index: int, admin: dict = Depends(get_current_admin)):
    """Toggle is_active on a Shopify App."""
    db = get_db()
    existing = db.table("shopify_apps").select("id, is_active, app_name").eq("app_index", app_index).execute()
    if not existing.data:
        raise HTTPException(status_code=404, detail=f"Shopify app #{app_index} not found")

    current_active = existing.data[0].get("is_active", True)
    new_active = not current_active
    new_status = "active" if new_active else "inactive"

    db.table("shopify_apps").update({
        "is_active": new_active,
        "status": new_status,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("app_index", app_index).execute()
    shopify_app_service.invalidate_cache()

    return success_response(
        {"app_index": app_index, "is_active": new_active},
        f"Shopify app #{app_index} is now {new_status}"
    )


# ── Delete a Shopify App ──────────────────────────────────────────────────────
@router.delete("/shopify-apps/{app_index}")
async def delete_shopify_app(app_index: int, admin: dict = Depends(get_current_admin)):
    """
    Delete a Shopify App from the system.
    WARNING: Existing shops that installed via this app (shopify_install_keys.app_index=N)
    will still work as long as their access tokens are stored. Only future installs will fail.
    """
    db = get_db()
    existing = db.table("shopify_apps").select("id, app_name").eq("app_index", app_index).execute()
    if not existing.data:
        raise HTTPException(status_code=404, detail=f"Shopify app #{app_index} not found")

    app_name = existing.data[0].get("app_name", f"App #{app_index}")  # extract before delete

    # Check how many shops are using this app — warn admin
    install_count = db.table("shopify_install_keys").select(
        "id", count="exact"
    ).eq("app_index", app_index).execute()
    active_installs = install_count.count or 0

    db.table("shopify_apps").delete().eq("app_index", app_index).execute()
    shopify_app_service.invalidate_cache()

    return success_response(
        {"app_index": app_index, "app_name": app_name, "affected_stores": active_installs},
        f"Shopify app '{app_name}' (#{app_index}) deleted. {active_installs} existing store(s) may be affected."
    )


# ── Check status of a Shopify App ─────────────────────────────────────────────
@router.get("/shopify-apps/{app_index}/status")
async def shopify_app_status(app_index: int, admin: dict = Depends(get_current_admin)):
    """
    Get live status of a Shopify App:
    - Is it configured in DB?
    - How many stores have it installed?
    - Last install timestamp
    """
    db = get_db()
    app = db.table("shopify_apps").select("*").eq("app_index", app_index).execute()
    if not app.data:
        return success_response({
            "app_index": app_index,
            "configured": False,
            "install_count": 0,
            "is_active": False,
            "status": "not_configured",
        })

    row = app.data[0]

    # Count stores using this app_index
    count_res = db.table("shopify_install_keys").select(
        "id", count="exact"
    ).eq("app_index", app_index).execute()
    live_count = count_res.count or 0

    return success_response({
        "app_index": app_index,
        "configured": True,
        "app_name": row.get("app_name"),
        "api_key_masked": shopify_app_service._mask(row.get("api_key", "")),
        "is_active": row.get("is_active", True),
        "status": row.get("status", "active"),
        "scopes": row.get("scopes", ""),
        "install_count": live_count,
        "last_install_at": row.get("last_install_at"),
        "notes": row.get("notes", ""),
        "created_at": row.get("created_at"),
    })


# ══════════════════════════════════════════════════════════════════════════════
# INTERNAL ENDPOINT — for Shopify Plugin (Node.js) to fetch credentials from DB
# Protected by X-Internal-Token header (NOT admin JWT)
# ══════════════════════════════════════════════════════════════════════════════

from fastapi import Request as _Request

@router.get("/shopify-apps-internal/all")
async def get_shopify_apps_for_plugin(request: _Request):
    """
    Internal endpoint called by the Shopify Node.js plugin on startup
    and periodically to fetch fresh app credentials from DB.

    Returns: [{app_index, key, secret, label, scopes, is_active}, ...]
    Format matches what the plugin expects in SHOPIFY_APPS env var.

    Protected by X-Internal-Token header — NOT admin JWT.
    """
    from config.settings import settings as _settings
    internal_token = request.headers.get("X-Internal-Token", "")
    if not internal_token or internal_token != _settings.INTERNAL_API_TOKEN:
        raise HTTPException(status_code=403, detail="Unauthorized")

    apps = shopify_app_service.get_all_shopify_apps(include_secrets=True)

    # Format for the plugin: [{key, secret, label, scopes, app_index}]
    plugin_format = []
    for app in apps:
        if not app.get("is_active", True):
            continue  # skip inactive apps
        plugin_format.append({
            "app_index": app["app_index"],
            "key": app["api_key"],
            "secret": app.get("api_secret", ""),
            "label": app["app_name"],
            "scopes": app.get("scopes", ""),
        })

    return success_response({
        "apps": plugin_format,
        "total": len(plugin_format),
        "source": "database",
    })
