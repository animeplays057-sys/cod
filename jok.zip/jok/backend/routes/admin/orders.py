from fastapi import APIRouter, Depends
from config.database import get_db
from middleware.auth import get_current_admin
from utils.helpers import success_response, paginate_params, pagination_meta

router = APIRouter(prefix="/api/v1/admin/orders", tags=["Admin Orders"])


@router.get("")
async def list_all_orders(
    page: int = 1, limit: int = 20, merchant_id: str = None, status: str = None,
    order_type: str = None, delivery_status: str = None,
    date_from: str = None, date_to: str = None, search: str = None,
    user: dict = Depends(get_current_admin)
):
    db = get_db()
    offset, limit = paginate_params(page, limit)
    # Use left join style (no !inner to avoid FK requirement)
    query = db.table("orders").select("*, users(name, company_name, email)", count="exact")
    if merchant_id:
        query = query.eq("user_id", merchant_id)
    if status:
        query = query.eq("verification_status", status)
    if order_type:
        query = query.eq("order_type", order_type)
    if delivery_status:
        query = query.eq("delivery_status", delivery_status)
    if date_from:
        query = query.gte("created_at", date_from)
    if date_to:
        query = query.lte("created_at", date_to)
    if search:
        query = query.or_(f"customer_name.ilike.%{search}%,order_number.ilike.%{search}%,tracking_number.ilike.%{search}%")
    result = query.order("created_at", desc=True).range(offset, offset + limit - 1).execute()
    return success_response({"orders": result.data or [], "pagination": pagination_meta(result.count or 0, page, limit)})


@router.get("/analytics")
async def analytics(period: str = "30d", user: dict = Depends(get_current_admin)):
    db = get_db()
    from datetime import datetime, timezone, timedelta
    days = {"7d": 7, "30d": 30, "90d": 90}.get(period, 30)
    start = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

    orders = db.table("orders").select("verification_status, order_amount, response_time_seconds, created_at").gte("created_at", start).execute()
    data = orders.data or []

    status_dist = {}
    total_resp = []
    for o in data:
        s = o.get("verification_status", "unknown")
        status_dist[s] = status_dist.get(s, 0) + 1
        if o.get("response_time_seconds"):
            total_resp.append(o["response_time_seconds"])

    return success_response({
        "total": len(data),
        "status_distribution": status_dist,
        "avg_response_time_seconds": round(sum(total_resp) / len(total_resp)) if total_resp else 0,
        "confirmation_rate": round(status_dist.get("confirmed", 0) / len(data) * 100, 1) if data else 0,
    })


# ── Multi-Store Dashboard Endpoint ─────────────────────────────────────────
stores_router = APIRouter(prefix="/api/v1/admin/stores", tags=["Admin Stores"])


@stores_router.get("")
async def list_merchant_stores(
    page: int = 1, limit: int = 20, search: str = None,
    user: dict = Depends(get_current_admin)
):
    """Get all merchant stores with order stats for the multi-store admin dashboard."""
    db = get_db()
    offset, limit = paginate_params(page, limit)

    query = db.table("users").select(
        "id, name, email, company_name, status, created_at, shopify_shop_domain, shopify_shop_id",
        count="exact"
    ).eq("role", "merchant")

    if search:
        query = query.or_(
            f"name.ilike.%{search}%,email.ilike.%{search}%,company_name.ilike.%{search}%,shopify_shop_domain.ilike.%{search}%"
        )

    merchants_result = query.order("created_at", desc=True).range(offset, offset + limit - 1).execute()
    merchants = merchants_result.data or []

    if not merchants:
        return success_response({"stores": [], "pagination": pagination_meta(0, page, limit)})

    merchant_ids = [m["id"] for m in merchants]

    # Get order counts per merchant
    orders_result = db.table("orders").select("user_id, verification_status").in_("user_id", merchant_ids).execute()
    stats: dict = {}
    for o in (orders_result.data or []):
        uid = o["user_id"]
        if uid not in stats:
            stats[uid] = {"total": 0, "confirmed": 0, "cancelled": 0, "pending": 0}
        stats[uid]["total"] += 1
        s = o.get("verification_status", "pending")
        if s in stats[uid]:
            stats[uid][s] += 1

    # Get active subscriptions
    subs_result = db.table("service_subscriptions").select(
        "user_id, plan_type, plan_name, status"
    ).in_("user_id", merchant_ids).eq("status", "active").execute()
    subs_map = {s["user_id"]: s for s in (subs_result.data or [])}

    stores = []
    for m in merchants:
        uid = m["id"]
        order_stats = stats.get(uid, {"total": 0, "confirmed": 0, "cancelled": 0, "pending": 0})
        sub = subs_map.get(uid, {})
        stores.append({
            "merchant_id": uid,
            "name": m.get("name", ""),
            "email": m.get("email", ""),
            "company_name": m.get("company_name", ""),
            "status": m.get("status", "trial"),
            "platform": "shopify" if m.get("shopify_shop_domain") else "custom",
            "shop_domain": m.get("shopify_shop_domain", ""),
            "plan_type": sub.get("plan_type", "trial"),
            "plan_name": sub.get("plan_name", "Trial"),
            "joined_at": m.get("created_at", ""),
            "order_stats": order_stats,
        })

    return success_response({
        "stores": stores,
        "pagination": pagination_meta(merchants_result.count or 0, page, limit),
    })
