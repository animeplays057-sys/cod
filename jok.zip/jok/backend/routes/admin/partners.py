from fastapi import APIRouter, Depends, HTTPException
from config.database import get_db
from middleware.auth import get_current_admin
from models.admin import CreatePartnerRequest, UpdatePartnerRequest, ReorderPartnersRequest
from utils.helpers import success_response, slugify

router = APIRouter(prefix="/api/v1/admin/partners", tags=["Admin Partners"])


@router.get("")
async def list_partners(user: dict = Depends(get_current_admin)):
    db = get_db()
    result = db.table("trusted_partners").select("*").order("display_order").execute()
    return success_response(result.data or [])


@router.post("")
async def create_partner(body: CreatePartnerRequest, user: dict = Depends(get_current_admin)):
    db = get_db()
    data = body.model_dump()
    data["seo_slug"] = slugify(body.partner_name)
    result = db.table("trusted_partners").insert(data).execute()
    return success_response(result.data[0], "Partner created")


@router.put("/{partner_id}")
async def update_partner(partner_id: str, body: UpdatePartnerRequest, user: dict = Depends(get_current_admin)):
    db = get_db()
    updates = body.model_dump(exclude_unset=True)
    if updates:
        db.table("trusted_partners").update(updates).eq("id", partner_id).execute()
    return success_response(message="Partner updated")


@router.delete("/{partner_id}")
async def delete_partner(partner_id: str, user: dict = Depends(get_current_admin)):
    db = get_db()
    db.table("trusted_partners").delete().eq("id", partner_id).execute()
    return success_response(message="Partner deleted")


@router.put("/reorder")
async def reorder(body: ReorderPartnersRequest, user: dict = Depends(get_current_admin)):
    db = get_db()
    for item in body.items:
        db.table("trusted_partners").update({"display_order": item["display_order"]}).eq("id", item["id"]).execute()
    return success_response(message="Partners reordered")
