"""
Admin — Service Pricing API
Allows admin to view, update, and reset service pricing in real time.
Changes propagate to all wallet debit calls within 60 seconds (cache TTL).

404 on update = run the migration SQL first:
  INSERT INTO service_pricing (service_key, label, icon, amount, notes, active, display_order) ...
"""
from fastapi import APIRouter, Depends, HTTPException, Body
from pydantic import BaseModel
from typing import Optional
from middleware.auth import get_current_admin
from config.database import get_db
from config.service_pricing import get_all_pricing_with_keys, invalidate_cache
from utils.helpers import success_response
from loguru import logger


# ── Public endpoint (no auth) — merchants & topup page use this ──────────────
public_router = APIRouter(prefix="/api/v1/pricing", tags=["Public Pricing"])


@public_router.get("")
async def get_public_pricing():
    """Public: returns all active service prices for display on merchant Topup/Billing pages."""
    prices = get_all_pricing_with_keys()
    # Only return active ones with safe fields
    public = [
        {
            "service_key": p["service_key"],
            "label": p.get("label", ""),
            "icon": p.get("icon", ""),
            "notes": p.get("notes", ""),
            "amount": float(p.get("amount", 0)),
            "currency": p.get("currency", "INR"),
            "active": p.get("active", True),
        }
        for p in prices
        if p.get("active", True)
    ]
    return success_response({"pricing": public})


# ── Admin router ──────────────────────────────────────────────────────────────
router = APIRouter(prefix="/api/v1/admin/pricing", tags=["Admin Pricing"])


class UpdatePricingBody(BaseModel):
    amount: Optional[float] = None
    label:  Optional[str]   = None
    icon:   Optional[str]   = None
    notes:  Optional[str]   = None
    active: Optional[bool]  = None


@router.get("")
async def list_all_pricing(admin=Depends(get_current_admin)):
    """Admin: list all service pricing entries with full detail."""
    prices = get_all_pricing_with_keys()
    return success_response({"pricing": prices})


@router.post("/reset-cache")
async def reset_pricing_cache(admin=Depends(get_current_admin)):
    """Admin: force-refresh the in-memory pricing cache."""
    invalidate_cache()
    return success_response(message="Pricing cache cleared — will reload on next request")


# ── NOTE: This route MUST come AFTER /reset-cache to avoid path conflict ──────
@router.put("/{service_key}")
@router.post("/{service_key}/update")  # POST alias — some proxies block PUT
async def update_service_price(
    service_key: str,
    body: UpdatePricingBody,
    admin=Depends(get_current_admin),
):
    """Admin: update price/label/icon/notes/active for a specific service."""
    db = get_db()
    existing = db.table("service_pricing").select("id").eq("service_key", service_key).execute()
    if not existing.data:
        raise HTTPException(
            404,
            f"Service '{service_key}' not found. Run the migration SQL to seed the service_pricing table first."
        )

    updates: dict = {}
    if body.amount is not None:
        if body.amount < 0:
            raise HTTPException(400, "Amount cannot be negative")
        updates["amount"] = body.amount
    if body.label  is not None: updates["label"]  = body.label
    if body.icon   is not None: updates["icon"]   = body.icon
    if body.notes  is not None: updates["notes"]  = body.notes
    if body.active is not None: updates["active"] = body.active

    if not updates:
        raise HTTPException(400, "No fields provided to update")

    db.table("service_pricing").update(updates).eq("service_key", service_key).execute()

    # Immediately propagate to all active debit calls (within next poll cycle)
    invalidate_cache()

    logger.info(f"✏️  Admin [{admin.get('id', '')}] updated pricing [{service_key}]: {updates}")
    return success_response(message=f"Pricing for '{service_key}' updated successfully")
