"""
Return & Refund Requests — Admin API
Admins see ALL return requests across ALL merchants,
with full website, order, and customer context.
Admin status updates also trigger WhatsApp to customer + ₹0.50 wallet debit.
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone
from config.database import get_db
from middleware.auth import get_current_admin
from utils.helpers import success_response, paginate_params, pagination_meta
from loguru import logger

router = APIRouter(prefix="/api/v1/admin/returns", tags=["Admin Returns"])


class AdminUpdateReturn(BaseModel):
    status: str
    worker_notes: Optional[str] = None


@router.get("")
async def list_all_returns(
    page: int = 1,
    limit: int = 30,
    status: Optional[str] = None,
    request_type: Optional[str] = None,
    merchant_id: Optional[str] = None,
    search: Optional[str] = None,
    admin: dict = Depends(get_current_admin),
):
    """List ALL return requests across all merchants — admin only."""
    db = get_db()
    offset, limit = paginate_params(page, limit)

    query = db.table("return_requests").select("*", count="exact")

    # Optional filters
    if merchant_id:
        query = query.eq("merchant_id", merchant_id)
    if status:
        query = query.eq("status", status)
    if request_type:
        query = query.eq("request_type", request_type)
    if search:
        query = query.or_(
            f"order_number.ilike.%{search}%,"
            f"customer_name.ilike.%{search}%,"
            f"customer_email.ilike.%{search}%,"
            f"store_url.ilike.%{search}%"
        )

    result = (
        query.order("created_at", desc=True)
        .range(offset, offset + limit - 1)
        .execute()
    )

    # Enrich with merchant email for admin display
    rows = result.data or []
    if rows:
        merchant_ids = list({r["merchant_id"] for r in rows if r.get("merchant_id")})
        users_res = (
            db.table("users")
            .select("id, email, company_name")
            .in_("id", merchant_ids)
            .execute()
        )
        users_map = {str(u["id"]): u for u in (users_res.data or [])}
        for r in rows:
            mid = str(r.get("merchant_id", ""))
            r["merchant_email"] = users_map.get(mid, {}).get("email", "")
            r["merchant_company"] = users_map.get(mid, {}).get("company_name", "")

    return success_response({
        "returns": rows,
        "pagination": pagination_meta(result.count or 0, page, limit),
    })


@router.get("/stats")
async def get_admin_return_stats(admin: dict = Depends(get_current_admin)):
    """Global stats across all merchants."""
    db = get_db()
    all_res = db.table("return_requests").select("status, request_type").execute()
    rows = all_res.data or []
    stats = {
        "total": len(rows),
        "pending": 0, "approved": 0, "rejected": 0, "completed": 0,
        "returns": 0, "refunds": 0,
    }
    for r in rows:
        s = r.get("status", "pending")
        if s in stats:
            stats[s] += 1
        t = r.get("request_type", "")
        if t == "return":
            stats["returns"] += 1
        elif t == "refund":
            stats["refunds"] += 1
    return success_response(stats)


@router.get("/{return_id}")
async def get_return_detail(return_id: str, admin: dict = Depends(get_current_admin)):
    """Full detail of any return request."""
    db = get_db()
    result = db.table("return_requests").select("*").eq("id", return_id).execute()
    if not result.data:
        raise HTTPException(404, "Return request not found")
    row = result.data[0]
    # Enrich merchant info
    if row.get("merchant_id"):
        u = db.table("users").select("email, company_name").eq("id", row["merchant_id"]).execute()
        if u.data:
            row["merchant_email"] = u.data[0].get("email", "")
            row["merchant_company"] = u.data[0].get("company_name", "")
    return success_response({"return": row})


@router.put("/{return_id}")
async def admin_update_return(
    return_id: str,
    body: AdminUpdateReturn,
    admin: dict = Depends(get_current_admin),
):
    """Admin override: update any return request status → sends WhatsApp to customer."""
    valid_statuses = {"pending", "approved", "rejected", "completed"}
    if body.status not in valid_statuses:
        raise HTTPException(400, f"Invalid status. Must be one of: {valid_statuses}")

    db = get_db()
    existing = db.table("return_requests").select("*").eq("id", return_id).execute()
    if not existing.data:
        raise HTTPException(404, "Return request not found")

    ret = existing.data[0]

    updates = {
        "status": body.status,
        "resolved_by": admin["id"],
        "resolved_at": datetime.now(timezone.utc).isoformat(),
    }
    if body.worker_notes is not None:
        updates["worker_notes"] = body.worker_notes

    db.table("return_requests").update(updates).eq("id", return_id).execute()

    # ── Send WhatsApp notification to customer + debit merchant wallet ────
    if body.status in ("approved", "rejected", "completed"):
        customer_phone = ret.get("customer_phone", "")
        if customer_phone and not customer_phone.startswith("+"):
            customer_phone = "+91" + customer_phone.lstrip("0")
        merchant_id = ret.get("merchant_id")

        if customer_phone and merchant_id:
            try:
                from services.whatsapp_service import send_return_status_customer
                from services import wallet_service
                from config.service_pricing import get_price

                ok = await send_return_status_customer(
                    customer_phone=customer_phone,
                    customer_name=ret.get("customer_name", "Customer"),
                    order_number=ret.get("order_number", "N/A"),
                    status=body.status,
                    notes=body.worker_notes or "",
                    store_name=ret.get("store_name", "Our Store"),
                )
                if ok:
                    charge = get_price("return_status_update")  # ✅ Correct key (was: return_whatsapp)
                    if charge > 0:
                        await wallet_service.debit_wallet(
                            db,
                            user_id=merchant_id,
                            amount=charge,
                            service_key="return_whatsapp",
                            description=f"[Admin] Return status WA — #{ret.get('order_number')} ({body.status})",
                            reference_id=return_id,
                        )
            except Exception as e:
                logger.warning(f"Admin return WA failed (non-critical): {e}")

    return success_response(message=f"Return request updated to '{body.status}'")
