"""
Admin Reviews — manage customer reviews submitted via public API.
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from config.database import get_db
from middleware.auth import get_current_admin
from utils.helpers import success_response, paginate_params, pagination_meta

router = APIRouter(prefix="/api/v1/admin/reviews", tags=["Admin Reviews"])


class UpdateReviewBody(BaseModel):
    is_featured: Optional[bool] = None
    is_approved: Optional[bool] = None
    admin_note: Optional[str] = None


@router.get("")
async def list_reviews(
    page: int = 1,
    limit: int = 20,
    featured_only: bool = False,
    user: dict = Depends(get_current_admin),
):
    """List all customer reviews with pagination."""
    db = get_db()
    offset, limit = paginate_params(page, limit)

    query = db.table("reviews").select("*", count="exact")
    if featured_only:
        query = query.eq("is_featured", True)

    result = (
        query.order("created_at", desc=True)
        .range(offset, offset + limit - 1)
        .execute()
    )

    return success_response({
        "reviews": result.data or [],
        "pagination": pagination_meta(result.count or 0, page, limit),
    })


@router.put("/{review_id}")
async def update_review(
    review_id: str,
    body: UpdateReviewBody,
    user: dict = Depends(get_current_admin),
):
    """Update review — feature, approve, or add admin note."""
    db = get_db()

    existing = db.table("reviews").select("id").eq("id", review_id).execute()
    if not existing.data:
        raise HTTPException(404, "Review not found")

    updates = {}
    if body.is_featured is not None:
        updates["is_featured"] = body.is_featured
    if body.is_approved is not None:
        updates["is_approved"] = body.is_approved
    if body.admin_note is not None:
        updates["admin_note"] = body.admin_note

    if not updates:
        raise HTTPException(400, "No fields to update")

    db.table("reviews").update(updates).eq("id", review_id).execute()
    return success_response(message="Review updated successfully")


@router.delete("/{review_id}")
async def delete_review(review_id: str, user: dict = Depends(get_current_admin)):
    """Delete a review permanently."""
    db = get_db()

    existing = db.table("reviews").select("id").eq("id", review_id).execute()
    if not existing.data:
        raise HTTPException(404, "Review not found")

    db.table("reviews").delete().eq("id", review_id).execute()
    return success_response(message="Review deleted successfully")
