from fastapi import APIRouter, Depends, HTTPException
from config.database import get_db
from middleware.auth import get_current_admin
from models.admin import AdminTicketUpdate, AdminSettingsUpdate, AdminBlacklistRequest
from models.merchant import TicketReplyRequest
from utils.helpers import success_response, paginate_params, pagination_meta
from utils.phone_utils import hash_phone, phone_last_four, normalize_phone

router = APIRouter(prefix="/api/v1/admin", tags=["Admin Operations"])


# --- Support ---
@router.get("/support/tickets")
async def list_tickets(page: int = 1, limit: int = 20, status: str = None, priority: str = None, merchant_id: str = None, user: dict = Depends(get_current_admin)):
    db = get_db()
    offset, limit = paginate_params(page, limit)
    query = db.table("support_tickets").select("*, users!support_tickets_user_id_fkey(name, email, company_name)", count="exact")
    if status:
        query = query.eq("status", status)
    if priority:
        query = query.eq("priority", priority)
    if merchant_id:
        query = query.eq("user_id", merchant_id)
    result = query.order("created_at", desc=True).range(offset, offset + limit - 1).execute()
    return success_response({"tickets": result.data or [], "pagination": pagination_meta(result.count or 0, page, limit)})


@router.put("/support/tickets/{ticket_id}")
async def update_ticket(ticket_id: str, body: AdminTicketUpdate, user: dict = Depends(get_current_admin)):
    db = get_db()
    updates = body.model_dump(exclude_unset=True)
    if updates:
        db.table("support_tickets").update(updates).eq("id", ticket_id).execute()
    return success_response(message="Ticket updated")


@router.post("/support/tickets/{ticket_id}/reply")
async def admin_reply(ticket_id: str, body: TicketReplyRequest, user: dict = Depends(get_current_admin)):
    db = get_db()
    result = db.table("support_ticket_replies").insert({
        "ticket_id": ticket_id, "user_id": user["id"], "message": body.message, "is_admin_reply": True,
    }).execute()
    db.table("support_tickets").update({"status": "in_progress"}).eq("id", ticket_id).execute()
    return success_response(result.data[0], "Reply sent")


# --- Blacklist ---
@router.get("/blacklist")
async def list_blacklist(page: int = 1, limit: int = 20, search: str = None, user: dict = Depends(get_current_admin)):
    db = get_db()
    offset, limit = paginate_params(page, limit)
    query = db.table("customers_directory").select("*", count="exact").eq("is_globally_blacklisted", True)
    if search:
        query = query.ilike("phone_last_four", f"%{search}%")
    result = query.range(offset, offset + limit - 1).execute()
    return success_response({"blacklisted": result.data or [], "pagination": pagination_meta(result.count or 0, page, limit)})


@router.post("/blacklist")
async def add_blacklist(body: AdminBlacklistRequest, user: dict = Depends(get_current_admin)):
    db = get_db()
    p_hash = hash_phone(normalize_phone(body.phone_number))
    existing = db.table("customers_directory").select("id").eq("phone_number_hash", p_hash).execute()
    if existing.data:
        db.table("customers_directory").update({"is_globally_blacklisted": True, "global_blacklist_reason": body.reason}).eq("id", existing.data[0]["id"]).execute()
    else:
        db.table("customers_directory").insert({
            "phone_number_hash": p_hash, "phone_last_four": phone_last_four(body.phone_number),
            "is_globally_blacklisted": True, "global_blacklist_reason": body.reason,
        }).execute()
    return success_response(message="Added to global blacklist")


@router.delete("/blacklist/{id}")
async def remove_blacklist(id: str, user: dict = Depends(get_current_admin)):
    db = get_db()
    db.table("customers_directory").update({"is_globally_blacklisted": False, "global_blacklist_reason": None}).eq("id", id).execute()
    return success_response(message="Removed from blacklist")


# --- Settings ---
@router.get("/settings")
async def get_settings(user: dict = Depends(get_current_admin)):
    db = get_db()
    result = db.table("admin_settings").select("*").execute()
    return success_response(result.data or [])


@router.put("/settings")
async def update_settings(body: AdminSettingsUpdate, user: dict = Depends(get_current_admin)):
    db = get_db()
    for s in body.settings:
        db.table("admin_settings").update({"setting_value": s["value"], "updated_by": user["id"]}).eq("setting_key", s["key"]).execute()
    return success_response(message="Settings updated")


# --- Logs ---
@router.get("/activity-logs")
async def activity_logs(page: int = 1, limit: int = 50, user_id: str = None, action: str = None, entity_type: str = None, user: dict = Depends(get_current_admin)):
    db = get_db()
    offset, limit = paginate_params(page, limit)
    query = db.table("activity_logs").select("*", count="exact")
    if user_id:
        query = query.eq("user_id", user_id)
    if action:
        query = query.eq("action", action)
    if entity_type:
        query = query.eq("entity_type", entity_type)
    result = query.order("created_at", desc=True).range(offset, offset + limit - 1).execute()
    return success_response({"logs": result.data or [], "pagination": pagination_meta(result.count or 0, page, limit)})


@router.get("/system/health")
async def system_health(user: dict = Depends(get_current_admin)):
    db = get_db()
    db_ok = False
    try:
        db.table("admin_settings").select("id").limit(1).execute()
        db_ok = True
    except Exception:
        pass

    pending_count = 0
    failed_count = 0
    try:
        pending = db.table("orders").select("id", count="exact").eq("verification_status", "pending").execute()
        pending_count = pending.count or 0
    except Exception:
        pass
    try:
        failed = db.table("messages").select("id", count="exact").eq("status", "failed").execute()
        failed_count = failed.count or 0
    except Exception:
        pass

    from config.settings import settings
    email_ok = bool(getattr(settings, 'EMAIL_WEBHOOK_URL', ''))

    return success_response({
        "database": {"status": "connected" if db_ok else "error"},
        "whatsapp_api": {"status": "configured" if getattr(settings, 'WHATSAPP_ACCESS_TOKEN', '') else "not_configured"},
        "email_service": {"status": "configured" if email_ok else "not_configured"},
        "payment_gateway": {"status": "configured" if getattr(settings, 'RAZORPAY_KEY_ID', '') else "not_configured"},
        "queue": {"pending_messages": pending_count, "failed_messages": failed_count},
    })


# --- Contact Inquiries ---
@router.get("/contact-inquiries")
async def list_contact_inquiries(page: int = 1, limit: int = 20, user: dict = Depends(get_current_admin)):
    """List all contact form submissions."""
    db = get_db()
    offset, limit = paginate_params(page, limit)
    result = db.table("support_tickets").select("*", count="exact").eq(
        "category", "contact_form"
    ).order("created_at", desc=True).range(offset, offset + limit - 1).execute()
    return success_response({
        "inquiries": result.data or [],
        "pagination": pagination_meta(result.count or 0, page, limit)
    })


@router.put("/contact-inquiries/{ticket_id}/handled")
async def mark_inquiry_handled(ticket_id: str, user: dict = Depends(get_current_admin)):
    """Mark a contact inquiry as handled/resolved."""
    db = get_db()
    db.table("support_tickets").update({"status": "resolved"}).eq("id", ticket_id).execute()
    return success_response(message="Marked as handled")


# --- Reviews ---
@router.get("/reviews")
async def list_reviews(status: str = None, page: int = 1, limit: int = 50, user: dict = Depends(get_current_admin)):
    """List all reviews (pending, approved, all)."""
    db = get_db()
    offset, limit = paginate_params(page, limit)
    query = db.table("reviews").select("*", count="exact")
    if status == "pending":
        query = query.eq("is_approved", False)
    elif status == "approved":
        query = query.eq("is_approved", True)
    elif status == "featured":
        query = query.eq("is_featured", True)
    result = query.order("created_at", desc=True).range(offset, offset + limit - 1).execute()
    return success_response({
        "reviews": result.data or [],
        "pagination": pagination_meta(result.count or 0, page, limit)
    })


@router.put("/reviews/{review_id}")
async def update_review(review_id: str, body: dict, user: dict = Depends(get_current_admin)):
    """Update review — approve, feature, edit content."""
    db = get_db()
    from models.admin import UpdateReviewRequest
    # Only allow valid fields
    allowed = {"author_name", "author_company", "author_role", "rating", "title",
               "body", "is_approved", "is_featured", "is_visible", "admin_note"}
    updates = {k: v for k, v in body.items() if k in allowed}
    if updates:
        from datetime import datetime, timezone
        updates["updated_at"] = datetime.now(timezone.utc).isoformat()
        result = db.table("reviews").update(updates).eq("id", review_id).execute()
        return success_response(result.data[0] if result.data else {}, "Review updated")
    return success_response(message="No changes made")


@router.delete("/reviews/{review_id}")
async def delete_review(review_id: str, user: dict = Depends(get_current_admin)):
    """Permanently delete a review."""
    db = get_db()
    db.table("reviews").delete().eq("id", review_id).execute()
    return success_response(message="Review deleted")

