from fastapi import APIRouter, Depends, HTTPException
from config.database import get_db
from middleware.auth import get_current_admin
from utils.helpers import success_response
from config.settings import settings
import httpx
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/admin/webhooks", tags=["Admin Webhooks"])

SHOPIFY_PLUGIN_URL = getattr(settings, "SHOPIFY_PLUGIN_URL", "http://shopify:3000")
INTERNAL_TOKEN = getattr(settings, "INTERNAL_API_TOKEN", "")


@router.get("")
async def list_webhook_stores(user: dict = Depends(get_current_admin)):
    """
    List all Shopify-connected stores with webhook status.
    Data is fetched entirely from Supabase — no live Shopify calls.
    """
    db = get_db()

    # Fetch all shopify install keys (one row per shop — latest per shop)
    keys_res = db.table("shopify_install_keys").select(
        "id, shop_domain, shop_name, app_index, is_used, created_at"
    ).order("created_at", desc=True).execute()

    keys_data = keys_res.data or []

    # Deduplicate — keep latest record per shop_domain
    seen = {}
    for k in keys_data:
        sd = k.get("shop_domain", "")
        if sd and sd not in seen:
            seen[sd] = k

    shops = list(seen.values())

    # Enrich with connected merchant info from users table
    if shops:
        shop_domains = [s["shop_domain"] for s in shops]
        # Get all merchants that have a shopify_shop_domain
        merchant_res = db.table("users").select(
            "id, name, email, company_name, shopify_shop_domain"
        ).in_("shopify_shop_domain", shop_domains).execute()
        merchant_map = {m["shopify_shop_domain"]: m for m in (merchant_res.data or [])}

        # Enrich each shop with merchant data and webhook status
        for shop in shops:
            sd = shop["shop_domain"]
            merchant = merchant_map.get(sd)
            shop["is_connected"] = merchant is not None
            shop["merchant_name"] = (
                merchant.get("company_name") or merchant.get("name") or ""
            ) if merchant else ""
            shop["merchant_email"] = merchant.get("email", "") if merchant else ""
            shop["merchant_id"] = merchant.get("id", "") if merchant else ""
            # webhook_ok: True if shop has access token (= webhooks can be registered)
            has_token_res = db.table("shopify_install_keys").select(
                "access_token_encrypted"
            ).eq("shop_domain", sd).order("created_at", desc=True).limit(1).execute()
            has_token = bool(
                has_token_res.data and has_token_res.data[0].get("access_token_encrypted")
            )
            shop["has_access_token"] = has_token
            # Determine webhook status from webhook_logs if available
            try:
                log_res = db.table("webhook_logs").select(
                    "status, created_at"
                ).eq("shop_domain", sd).order("created_at", desc=True).limit(1).execute()
                if log_res.data:
                    latest_log = log_res.data[0]
                    shop["last_webhook_at"] = latest_log.get("created_at")
                    shop["last_webhook_status"] = latest_log.get("status", "unknown")
                else:
                    shop["last_webhook_at"] = None
                    shop["last_webhook_status"] = "never"
            except Exception:
                # webhook_logs table may not have expected columns — skip gracefully
                shop["last_webhook_at"] = None
                shop["last_webhook_status"] = "never"

    return success_response({
        "stores": shops,
        "total": len(shops),
    })


@router.post("/{shop_domain}/reconnect")
async def reconnect_webhooks(shop_domain: str, user: dict = Depends(get_current_admin)):
    """
    Reconnect (re-register) webhooks for a specific Shopify store.
    Calls the Shopify plugin's /setup/webhooks endpoint internally.
    """
    db = get_db()

    # Verify this shop is in our system
    key_res = db.table("shopify_install_keys").select(
        "shop_domain, access_token_encrypted"
    ).eq("shop_domain", shop_domain).order("created_at", desc=True).limit(1).execute()

    if not key_res.data:
        raise HTTPException(
            status_code=404,
            detail=f"Shop '{shop_domain}' not found in system"
        )

    if not key_res.data[0].get("access_token_encrypted"):
        raise HTTPException(
            status_code=400,
            detail="No access token available for this shop. The merchant must reinstall the Shopify app."
        )

    # Call Shopify plugin to re-register webhooks
    if not SHOPIFY_PLUGIN_URL or not INTERNAL_TOKEN:
        raise HTTPException(
            status_code=503,
            detail="Shopify plugin URL or internal token not configured"
        )

    try:
        async with httpx.AsyncClient(timeout=20.0) as client:
            resp = await client.post(
                f"{SHOPIFY_PLUGIN_URL}/setup/webhooks",
                json={"shop": shop_domain},
                headers={
                    "x-internal-token": INTERNAL_TOKEN,
                    "Content-Type": "application/json",
                },
            )
        result = resp.json()
        if resp.status_code == 200 and result.get("success"):
            logger.info(f"✅ Webhooks reconnected for {shop_domain} by admin {user['id']}")
            return success_response(
                data={"shop_domain": shop_domain},
                message=f"Webhooks successfully reconnected for {shop_domain}"
            )
        else:
            raise HTTPException(
                status_code=502,
                detail=result.get("message") or f"Shopify plugin returned {resp.status_code}"
            )
    except httpx.RequestError as e:
        raise HTTPException(
            status_code=503,
            detail=f"Could not reach Shopify plugin: {str(e)}"
        )


@router.get("/summary")
async def webhook_summary(user: dict = Depends(get_current_admin)):
    """Quick stats for the webhook health overview card."""
    db = get_db()

    # Total unique shops in shopify_install_keys
    total_res = db.table("shopify_install_keys").select(
        "shop_domain", count="exact"
    ).execute()

    # Connected merchants (have shopify_shop_domain set)
    connected_res = db.table("users").select(
        "id", count="exact"
    ).not_.is_("shopify_shop_domain", "null").eq("role", "merchant").execute()

    return success_response({
        "total_shops": total_res.count or 0,
        "connected_merchants": connected_res.count or 0,
    })
