from fastapi import APIRouter, Depends, HTTPException
from loguru import logger
from pydantic import BaseModel
from typing import Optional, List
import httpx

from config.database import get_db
from config.settings import settings
from middleware.auth import get_current_admin
from services.whatsapp_service import send_text_message, send_template_message

router = APIRouter(prefix="/api/v1/admin/whatsapp", tags=["admin-whatsapp-crm"])

WA_API = "https://graph.facebook.com/v18.0"


class SendMessageRequest(BaseModel):
    to_phone: str
    message_type: str = "text"          # text | template
    text: Optional[str] = None
    template_name: Optional[str] = None
    template_params: Optional[List[str]] = None
    template_language: Optional[str] = "en"


@router.get("/status")
async def get_whatsapp_status(_=Depends(get_current_admin)):
    """Check WhatsApp Business API phone number status."""
    phone_id = settings.WHATSAPP_PHONE_NUMBER_ID
    token = settings.WHATSAPP_ACCESS_TOKEN
    if not phone_id or not token:
        return {"success": True, "data": {"configured": False, "phone_id": None}}
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                f"{WA_API}/{phone_id}",
                headers={"Authorization": f"Bearer {token}"},
                params={"fields": "display_phone_number,verified_name,quality_rating,status"}
            )
            if resp.status_code == 200:
                data = resp.json()
                return {"success": True, "data": {
                    "configured": True,
                    "phone_id": phone_id,
                    "display_number": data.get("display_phone_number"),
                    "verified_name": data.get("verified_name"),
                    "quality_rating": data.get("quality_rating"),
                    "status": data.get("status"),
                }}
    except Exception as e:
        logger.warning(f"WA status check failed: {e}")
    return {"success": True, "data": {"configured": bool(phone_id and token), "phone_id": phone_id, "display_number": None}}


@router.get("/conversations")
async def get_conversations(_=Depends(get_current_admin)):
    """Get all WhatsApp conversations grouped by customer phone."""
    db = get_db()
    try:
        # Fetch messages linked to orders
        msgs = db.table("messages").select(
            "order_id, direction, content, message_type, status, created_at, whatsapp_message_id"
        ).order("created_at", desc=True).limit(500).execute()

        if not msgs.data:
            return {"success": True, "data": {"conversations": []}}

        # Get associated orders for phone numbers
        order_ids = list({m["order_id"] for m in msgs.data if m.get("order_id")})
        orders_res = db.table("orders").select(
            "id, customer_phone_normalized, customer_name, user_id"
        ).in_("id", order_ids[:100]).execute()
        orders_map = {o["id"]: o for o in (orders_res.data or [])}

        # Get merchant names
        user_ids = list({o["user_id"] for o in orders_map.values()})
        merchants_res = db.table("users").select("id, name, company_name").in_("id", user_ids[:50]).execute()
        merchants_map = {u["id"]: u for u in (merchants_res.data or [])}

        # Also load CRM-sent messages
        crm_msgs = db.table("whatsapp_crm_messages").select("*").order("created_at", desc=True).limit(200).execute()
        crm_data = crm_msgs.data or []

        # Build conversations map
        convs: dict = {}

        for msg in msgs.data:
            order = orders_map.get(msg.get("order_id"))
            if not order:
                continue
            phone = order.get("customer_phone_normalized", "")
            if not phone:
                continue
            merchant = merchants_map.get(order.get("user_id"), {})
            merchant_name = merchant.get("company_name") or merchant.get("name") or ""

            if phone not in convs:
                convs[phone] = {
                    "phone": phone,
                    "customer_name": order.get("customer_name") or phone,
                    "merchant_name": merchant_name,
                    "last_message": msg.get("content", "")[:80],
                    "last_message_direction": msg.get("direction"),
                    "last_message_time": msg.get("created_at"),
                    "last_message_status": msg.get("status"),
                    "unread_count": 1 if msg.get("direction") == "inbound" else 0,
                    "message_count": 1,
                }
            else:
                convs[phone]["message_count"] += 1
                if msg.get("direction") == "inbound":
                    convs[phone]["unread_count"] += 1

        # Add CRM-sent conversations
        for cm in crm_data:
            phone = cm.get("to_phone", "")
            if not phone:
                continue
            if phone not in convs:
                convs[phone] = {
                    "phone": phone,
                    "customer_name": phone,
                    "merchant_name": "Admin CRM",
                    "last_message": cm.get("content") or cm.get("template_name") or "",
                    "last_message_direction": "outbound",
                    "last_message_time": cm.get("created_at"),
                    "last_message_status": cm.get("status", "sent"),
                    "unread_count": 0,
                    "message_count": 1,
                }

        sorted_convs = sorted(convs.values(), key=lambda x: x["last_message_time"] or "", reverse=True)
        return {"success": True, "data": {"conversations": sorted_convs}}

    except Exception as e:
        logger.error(f"CRM conversations error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/conversations/{phone}")
async def get_conversation_messages(phone: str, _=Depends(get_current_admin)):
    """Get full message history for a specific phone number."""
    db = get_db()
    # Normalize phone — strip + prefix (DB stores without +)
    phone_normalized = phone.replace("+", "").strip()
    try:
        # Find all orders for this phone (try both with and without +)
        orders_res = db.table("orders").select("id, customer_name, order_number, store_order_id, user_id").eq(
            "customer_phone_normalized", phone_normalized
        ).order("created_at", desc=True).limit(20).execute()

        # Retry with + if no results
        if not orders_res.data:
            orders_res = db.table("orders").select("id, customer_name, order_number, store_order_id, user_id").eq(
                "customer_phone_normalized", f"+{phone_normalized}"
            ).order("created_at", desc=True).limit(20).execute()

        orders = orders_res.data or []
        order_ids = [o["id"] for o in orders]
        customer_name = orders[0].get("customer_name") if orders else phone

        all_msgs = []

        if order_ids:
            msgs_res = db.table("messages").select("*").in_("order_id", order_ids).order("created_at").execute()
            for m in (msgs_res.data or []):
                order_info = next((o for o in orders if o["id"] == m.get("order_id")), {})
                all_msgs.append({
                    "id": m.get("id"),
                    "direction": m.get("direction"),
                    "content": m.get("content"),
                    "message_type": m.get("message_type", "text"),
                    "status": m.get("status"),
                    "created_at": m.get("created_at"),
                    "order_number": order_info.get("order_number") or order_info.get("store_order_id"),
                    "customer_name": customer_name,
                    "is_crm": False,
                })

        # CRM messages for this phone
        crm_res = db.table("whatsapp_crm_messages").select("*").eq("to_phone", phone).order("created_at").execute()
        for cm in (crm_res.data or []):
            all_msgs.append({
                "id": cm.get("id"),
                "direction": "outbound",
                "content": cm.get("content") or f"[Template: {cm.get('template_name')}]",
                "message_type": cm.get("message_type", "text"),
                "status": cm.get("status", "sent"),
                "created_at": cm.get("created_at"),
                "order_number": None,
                "customer_name": customer_name,
                "is_crm": True,
            })

        all_msgs.sort(key=lambda x: x.get("created_at") or "")
        return {"success": True, "data": {"phone": phone, "customer_name": customer_name, "messages": all_msgs}}

    except Exception as e:
        logger.error(f"CRM conversation detail error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/send")
async def send_whatsapp_message(req: SendMessageRequest, admin=Depends(get_current_admin)):
    """Send a WhatsApp message (text or template) to any number."""
    phone_id = settings.WHATSAPP_PHONE_NUMBER_ID
    token = settings.WHATSAPP_ACCESS_TOKEN

    if not phone_id or not token:
        raise HTTPException(status_code=503, detail="WhatsApp not configured. Set WHATSAPP_PHONE_NUMBER_ID and WHATSAPP_ACCESS_TOKEN.")

    phone = req.to_phone.replace("+", "").replace(" ", "")
    db = get_db()
    msg_id = None

    try:
        if req.message_type == "text":
            if not req.text:
                raise HTTPException(status_code=400, detail="text is required for text messages")
            msg_id = await send_text_message(phone_id, token, phone, req.text)
            db.table("whatsapp_crm_messages").insert({
                "to_phone": phone,
                "message_type": "text",
                "content": req.text,
                "whatsapp_message_id": msg_id,
                "status": "sent" if msg_id else "failed",
            }).execute()

        elif req.message_type == "template":
            if not req.template_name:
                raise HTTPException(status_code=400, detail="template_name is required")

            components = []
            if req.template_params:
                components = [{"type": "body", "parameters": [
                    {"type": "text", "text": p} for p in req.template_params
                ]}]

            msg_id = await send_template_message(
                phone_id, token, phone,
                req.template_name,
                req.template_language or "en",
                components if components else None
            )
            db.table("whatsapp_crm_messages").insert({
                "to_phone": phone,
                "message_type": "template",
                "template_name": req.template_name,
                "template_params": req.template_params,
                "whatsapp_message_id": msg_id,
                "status": "sent" if msg_id else "failed",
            }).execute()
        else:
            raise HTTPException(status_code=400, detail="message_type must be 'text' or 'template'")

        if not msg_id:
            raise HTTPException(status_code=502, detail="WhatsApp API accepted but no message ID returned. Check token and phone number.")

        return {"success": True, "data": {"message_id": msg_id, "to": phone, "status": "sent"}}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"CRM send error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/templates")
async def get_templates(_=Depends(get_current_admin)):
    """Fetch approved WhatsApp message templates from Meta."""
    token = settings.WHATSAPP_ACCESS_TOKEN
    waba_id = getattr(settings, "WHATSAPP_WABA_ID", None) or "960191450282800"

    if not token:
        raise HTTPException(status_code=503, detail="WHATSAPP_ACCESS_TOKEN not configured")

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(
                f"{WA_API}/{waba_id}/message_templates",
                headers={"Authorization": f"Bearer {token}"},
                params={"limit": 50, "fields": "name,status,category,language,components"}
            )
            if resp.status_code != 200:
                raise HTTPException(status_code=resp.status_code, detail=resp.text[:300])

            raw = resp.json().get("data", [])
            templates = []
            for t in raw:
                body_text = ""
                params_count = 0
                for comp in t.get("components", []):
                    if comp.get("type") == "BODY":
                        body_text = comp.get("text", "")
                        import re
                        params_count = len(re.findall(r"\{\{\d+\}\}", body_text))
                templates.append({
                    "name": t.get("name"),
                    "status": t.get("status"),
                    "category": t.get("category"),
                    "language": t.get("language"),
                    "body_text": body_text,
                    "params_count": params_count,
                })
            return {"success": True, "data": {"templates": templates}}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Fetch templates error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
