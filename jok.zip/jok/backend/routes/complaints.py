"""
Complaints API — Merchant, Worker, Admin, and Public endpoints in one file.
Separated into 3 routers:
  - merchant_router  → /api/v1/merchant/complaints
  - worker_router    → /api/v1/worker/complaints
  - admin_router     → /api/v1/admin/complaints
  - public_router    → /api/v1/help-center/complaint  (POST only)
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone
from config.database import get_db
from middleware.auth import get_current_merchant, get_current_user
from utils.helpers import success_response, paginate_params, pagination_meta

# ── Routers ───────────────────────────────────────────────────────────────────

merchant_router = APIRouter(prefix="/api/v1/merchant/complaints", tags=["Merchant Complaints"])
worker_router   = APIRouter(prefix="/api/v1/worker/complaints",   tags=["Worker Complaints"])
admin_router    = APIRouter(prefix="/api/v1/admin/complaints",    tags=["Admin Complaints"])
public_router   = APIRouter(prefix="/api/v1/help-center",         tags=["Public Help Center"])


# ── Pydantic models ───────────────────────────────────────────────────────────

class ComplaintCreate(BaseModel):
    """Public complaint submission (from Help Center widget)."""
    api_key: str
    customer_name: str
    customer_email: Optional[str] = None
    customer_phone: Optional[str] = None
    order_number: Optional[str] = None
    subject: str
    description: str


class ComplaintUpdate(BaseModel):
    """Update a complaint — merchant or worker."""
    status: Optional[str] = None          # open | in_progress | resolved | closed
    priority: Optional[str] = None        # low | normal | high | urgent
    assigned_to: Optional[str] = None     # worker user_id
    resolution_note: Optional[str] = None
    resolved_by: Optional[str] = None     # 'merchant' | 'worker' | 'admin'


class AdminComplaintUpdate(BaseModel):
    status: Optional[str] = None
    priority: Optional[str] = None
    assigned_to: Optional[str] = None
    admin_note: Optional[str] = None      # internal admin note
    resolved_by: Optional[str] = None


# ── Helpers ───────────────────────────────────────────────────────────────────

def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _get_complaint_or_404(complaint_id: str, merchant_id: str) -> dict:
    db = get_db()
    res = (
        db.table("complaints")
        .select("*")
        .eq("id", complaint_id)
        .eq("merchant_id", merchant_id)
        .execute()
    )
    if not res.data:
        raise HTTPException(404, "Complaint not found")
    return res.data[0]


# ══════════════════════════════════════════════════════════════════════════════
# PUBLIC — Customer submits a complaint
# ══════════════════════════════════════════════════════════════════════════════

@public_router.post("/complaint")
async def submit_complaint(body: ComplaintCreate):
    """Customer submits a complaint via the Help Center widget."""
    db = get_db()

    # Resolve api_key → merchant
    cfg_res = (
        db.table("merchant_chatbot_config")
        .select("merchant_id, is_enabled, help_center_enabled")
        .eq("api_key", body.api_key)
        .execute()
    )
    if not cfg_res.data:
        raise HTTPException(403, "Invalid API key")

    cfg = cfg_res.data[0]
    if not cfg.get("is_enabled"):
        raise HTTPException(403, "Help Center not enabled")

    merchant_id = cfg["merchant_id"]

    row = {
        "merchant_id": merchant_id,
        "api_key": body.api_key,
        "customer_name": body.customer_name,
        "customer_email": body.customer_email,
        "customer_phone": body.customer_phone,
        "order_number": body.order_number,
        "subject": body.subject,
        "description": body.description,
        "status": "open",
        "priority": "normal",
        "created_at": _now(),
        "updated_at": _now(),
    }

    result = db.table("complaints").insert(row).execute()
    complaint = result.data[0] if result.data else {}

    return success_response(
        {"complaint_id": complaint.get("id"), "reference": complaint.get("id", "")[:8].upper()},
        message="Your complaint has been submitted. We'll get back to you soon!"
    )


# ══════════════════════════════════════════════════════════════════════════════
# MERCHANT — View & manage complaints for their store
# ══════════════════════════════════════════════════════════════════════════════

@merchant_router.get("")
async def list_merchant_complaints(
    page: int = 1,
    limit: int = 20,
    status: Optional[str] = None,
    priority: Optional[str] = None,
    search: Optional[str] = None,
    user: dict = Depends(get_current_merchant),
):
    db = get_db()
    offset, limit = paginate_params(page, limit)

    query = (
        db.table("complaints")
        .select("*", count="exact")
        .eq("merchant_id", user["id"])
    )
    if status:
        query = query.eq("status", status)
    if priority:
        query = query.eq("priority", priority)
    if search:
        query = query.or_(
            f"customer_name.ilike.%{search}%,"
            f"customer_email.ilike.%{search}%,"
            f"order_number.ilike.%{search}%,"
            f"subject.ilike.%{search}%"
        )

    result = query.order("created_at", desc=True).range(offset, offset + limit - 1).execute()

    return success_response({
        "complaints": result.data or [],
        "pagination": pagination_meta(result.count or 0, page, limit),
    })


@merchant_router.get("/stats")
async def merchant_complaint_stats(user: dict = Depends(get_current_merchant)):
    """Quick stats for dashboard badge."""
    db = get_db()
    all_res = (
        db.table("complaints")
        .select("status, priority")
        .eq("merchant_id", user["id"])
        .execute()
    )
    rows = all_res.data or []
    stats = {"open": 0, "in_progress": 0, "resolved": 0, "closed": 0, "total": len(rows)}
    for r in rows:
        s = r.get("status", "open")
        if s in stats:
            stats[s] += 1
    return success_response(stats)


@merchant_router.get("/{complaint_id}")
async def get_merchant_complaint(complaint_id: str, user: dict = Depends(get_current_merchant)):
    complaint = _get_complaint_or_404(complaint_id, user["id"])
    return success_response({"complaint": complaint})


@merchant_router.put("/{complaint_id}")
async def update_merchant_complaint(
    complaint_id: str,
    body: ComplaintUpdate,
    user: dict = Depends(get_current_merchant),
):
    _get_complaint_or_404(complaint_id, user["id"])  # verify ownership
    db = get_db()

    updates = body.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(400, "No fields to update")

    valid_statuses = {"open", "in_progress", "resolved", "closed"}
    if "status" in updates and updates["status"] not in valid_statuses:
        raise HTTPException(400, f"Invalid status. Use: {valid_statuses}")

    # If merchant resolves → mark resolved_by as merchant
    if updates.get("status") in {"resolved", "closed"}:
        updates.setdefault("resolved_by", "merchant")

    updates["updated_at"] = _now()
    db.table("complaints").update(updates).eq("id", complaint_id).execute()
    return success_response(message="Complaint updated")


# ══════════════════════════════════════════════════════════════════════════════
# WORKER — View complaints assigned to them
# ══════════════════════════════════════════════════════════════════════════════

@worker_router.get("")
async def list_worker_complaints(
    page: int = 1,
    limit: int = 20,
    status: Optional[str] = None,
    user: dict = Depends(get_current_user),
):
    db = get_db()
    offset, limit = paginate_params(page, limit)

    query = (
        db.table("complaints")
        .select("*", count="exact")
        .eq("assigned_to", user["id"])
    )
    if status:
        query = query.eq("status", status)

    result = query.order("created_at", desc=True).range(offset, offset + limit - 1).execute()

    return success_response({
        "complaints": result.data or [],
        "pagination": pagination_meta(result.count or 0, page, limit),
    })


@worker_router.get("/stats")
async def worker_complaint_stats(user: dict = Depends(get_current_user)):
    db = get_db()
    all_res = (
        db.table("complaints")
        .select("status")
        .eq("assigned_to", user["id"])
        .execute()
    )
    rows = all_res.data or []
    stats = {"open": 0, "in_progress": 0, "resolved": 0, "total": len(rows)}
    for r in rows:
        s = r.get("status", "open")
        if s in stats:
            stats[s] += 1
    return success_response(stats)


@worker_router.get("/{complaint_id}")
async def get_worker_complaint(complaint_id: str, user: dict = Depends(get_current_user)):
    db = get_db()
    res = (
        db.table("complaints")
        .select("*")
        .eq("id", complaint_id)
        .eq("assigned_to", user["id"])
        .execute()
    )
    if not res.data:
        raise HTTPException(404, "Complaint not found or not assigned to you")
    return success_response({"complaint": res.data[0]})


@worker_router.put("/{complaint_id}")
async def update_worker_complaint(
    complaint_id: str,
    body: ComplaintUpdate,
    user: dict = Depends(get_current_user),
):
    db = get_db()
    res = (
        db.table("complaints")
        .select("id, assigned_to")
        .eq("id", complaint_id)
        .eq("assigned_to", user["id"])
        .execute()
    )
    if not res.data:
        raise HTTPException(403, "Not authorized to update this complaint")

    updates = body.model_dump(exclude_unset=True)
    valid_statuses = {"open", "in_progress", "resolved", "closed"}
    if "status" in updates and updates["status"] not in valid_statuses:
        raise HTTPException(400, f"Invalid status")

    if updates.get("status") in {"resolved", "closed"}:
        updates.setdefault("resolved_by", "worker")

    updates["updated_at"] = _now()
    db.table("complaints").update(updates).eq("id", complaint_id).execute()
    return success_response(message="Complaint updated")


# ══════════════════════════════════════════════════════════════════════════════
# ADMIN — Full visibility across all merchants + workers
# ══════════════════════════════════════════════════════════════════════════════

@admin_router.get("")
async def admin_list_complaints(
    page: int = 1,
    limit: int = 25,
    status: Optional[str] = None,
    merchant_id: Optional[str] = None,
    assigned_to: Optional[str] = None,
    priority: Optional[str] = None,
    search: Optional[str] = None,
    user: dict = Depends(get_current_user),
):
    db = get_db()
    offset, limit = paginate_params(page, limit)

    query = db.table("complaints").select("*", count="exact")

    if status:
        query = query.eq("status", status)
    if merchant_id:
        query = query.eq("merchant_id", merchant_id)
    if assigned_to:
        query = query.eq("assigned_to", assigned_to)
    if priority:
        query = query.eq("priority", priority)
    if search:
        query = query.or_(
            f"customer_name.ilike.%{search}%,"
            f"subject.ilike.%{search}%,"
            f"order_number.ilike.%{search}%"
        )

    result = query.order("created_at", desc=True).range(offset, offset + limit - 1).execute()

    return success_response({
        "complaints": result.data or [],
        "pagination": pagination_meta(result.count or 0, page, limit),
    })


@admin_router.get("/stats")
async def admin_complaint_stats(user: dict = Depends(get_current_user)):
    db = get_db()
    all_res = db.table("complaints").select("status, resolved_by, priority").execute()
    rows = all_res.data or []
    stats = {
        "total": len(rows),
        "open": 0, "in_progress": 0, "resolved": 0, "closed": 0,
        "resolved_by_merchant": 0, "resolved_by_worker": 0, "resolved_by_admin": 0,
        "high_priority": 0, "urgent": 0,
    }
    for r in rows:
        s = r.get("status", "open")
        if s in stats:
            stats[s] += 1
        rb = r.get("resolved_by", "")
        if rb == "merchant":
            stats["resolved_by_merchant"] += 1
        elif rb == "worker":
            stats["resolved_by_worker"] += 1
        elif rb == "admin":
            stats["resolved_by_admin"] += 1
        p = r.get("priority", "normal")
        if p == "high":
            stats["high_priority"] += 1
        elif p == "urgent":
            stats["urgent"] += 1
    return success_response(stats)


@admin_router.get("/{complaint_id}")
async def admin_get_complaint(complaint_id: str, user: dict = Depends(get_current_user)):
    db = get_db()
    res = db.table("complaints").select("*").eq("id", complaint_id).execute()
    if not res.data:
        raise HTTPException(404, "Complaint not found")
    return success_response({"complaint": res.data[0]})


@admin_router.put("/{complaint_id}")
async def admin_update_complaint(
    complaint_id: str,
    body: AdminComplaintUpdate,
    user: dict = Depends(get_current_user),
):
    db = get_db()
    res = db.table("complaints").select("id").eq("id", complaint_id).execute()
    if not res.data:
        raise HTTPException(404, "Complaint not found")

    updates = body.model_dump(exclude_unset=True)
    if updates.get("status") in {"resolved", "closed"} and "resolved_by" not in updates:
        updates["resolved_by"] = "admin"

    updates["updated_at"] = _now()
    db.table("complaints").update(updates).eq("id", complaint_id).execute()
    return success_response(message="Complaint updated by admin")
