"""
Influencer Dashboard Routes
GET /api/v1/influencer/dashboard   — Stats overview
GET /api/v1/influencer/leads       — All leads with pagination
GET /api/v1/influencer/earnings    — Payout history
GET /api/v1/influencer/ref-link    — Get referral link + QR details
"""
from fastapi import APIRouter, HTTPException, Depends, Query
from datetime import datetime, timezone, timedelta
from loguru import logger

from config.database import get_db
from config.settings import settings
from middleware.auth import get_current_user
from services.influencer_service import get_payout_tier
from utils.helpers import success_response

router = APIRouter(prefix="/api/v1/influencer", tags=["Influencer"])


def _require_influencer(user: dict):
    if user.get("role") != "influencer":
        raise HTTPException(status_code=403, detail="Influencer access only")


# ── Dashboard Stats ─────────────────────────────────────────────────────────────

@router.get("/dashboard")
async def influencer_dashboard(user: dict = Depends(get_current_user)):
    _require_influencer(user)
    db = get_db()

    profile_res = db.table("influencer_profiles").select("*").eq("user_id", user["id"]).execute()
    if not profile_res.data:
        raise HTTPException(status_code=404, detail="Profile not found")

    profile = profile_res.data[0]
    influencer_id = profile["id"]
    ref_code = profile["ref_code"]

    # Leads breakdown
    leads_res = db.table("influencer_leads").select("status").eq("influencer_id", influencer_id).execute()
    leads = leads_res.data or []

    status_counts = {
        "pending": 0, "called": 0, "qualified": 0, "not_qualified": 0
    }
    for l in leads:
        s = l.get("status", "pending")
        if s in status_counts:
            status_counts[s] += 1

    # Recent leads (last 10)
    recent_leads_res = (
        db.table("influencer_leads")
        .select("id, status, created_at, lead_payout_amount, lead_payout_status, subscription_payout_status")
        .eq("influencer_id", influencer_id)
        .order("created_at", desc=True)
        .limit(10)
        .execute()
    )

    # Recent payouts (last 10)
    recent_payouts_res = (
        db.table("influencer_payouts")
        .select("*")
        .eq("influencer_id", influencer_id)
        .order("created_at", desc=True)
        .limit(10)
        .execute()
    )

    # Current tier
    tier = get_payout_tier(influencer_id)

    # Referral link
    ref_link = f"{settings.FRONTEND_URL}/signup?ref={ref_code}"

    return success_response({
        "profile": {
            "ref_code": ref_code,
            "status": profile.get("status"),
            "wallet_balance": float(profile.get("wallet_balance") or 0),
            "total_earned": float(profile.get("total_earned") or 0),
            "total_leads": profile.get("total_leads") or 0,
            "qualified_leads": profile.get("qualified_leads") or 0,
        },
        "leads_breakdown": status_counts,
        "current_tier": tier,
        "ref_link": ref_link,
        "recent_leads": recent_leads_res.data or [],
        "recent_payouts": recent_payouts_res.data or [],
    })


# ── All Leads ───────────────────────────────────────────────────────────────────

@router.get("/leads")
async def get_influencer_leads(
    user: dict = Depends(get_current_user),
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    status: str = Query(None),
):
    _require_influencer(user)
    db = get_db()

    profile_res = db.table("influencer_profiles").select("id").eq("user_id", user["id"]).execute()
    if not profile_res.data:
        raise HTTPException(status_code=404, detail="Profile not found")
    influencer_id = profile_res.data[0]["id"]

    offset = (page - 1) * per_page
    query = (
        db.table("influencer_leads")
        .select("""
            id, status, created_at, qualified_at, worker_notes,
            lead_payout_amount, lead_payout_status,
            subscription_payout_amount, subscription_payout_status,
            subscription_at,
            merchant:merchant_id(name, email, company_name, created_at)
        """)
        .eq("influencer_id", influencer_id)
        .order("created_at", desc=True)
        .range(offset, offset + per_page - 1)
    )

    if status:
        query = query.eq("status", status)

    leads_res = query.execute()

    # Total count
    count_q = db.table("influencer_leads").select("id", count="exact").eq("influencer_id", influencer_id)
    if status:
        count_q = count_q.eq("status", status)
    total_res = count_q.execute()

    return success_response({
        "leads": leads_res.data or [],
        "total": total_res.count or 0,
        "page": page,
        "per_page": per_page,
    })


# ── Earnings / Payout History ───────────────────────────────────────────────────

@router.get("/earnings")
async def get_influencer_earnings(
    user: dict = Depends(get_current_user),
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
):
    _require_influencer(user)
    db = get_db()

    profile_res = db.table("influencer_profiles").select("id, total_earned, wallet_balance").eq("user_id", user["id"]).execute()
    if not profile_res.data:
        raise HTTPException(status_code=404, detail="Profile not found")

    profile = profile_res.data[0]
    influencer_id = profile["id"]
    offset = (page - 1) * per_page

    payouts_res = (
        db.table("influencer_payouts")
        .select("*")
        .eq("influencer_id", influencer_id)
        .order("created_at", desc=True)
        .range(offset, offset + per_page - 1)
        .execute()
    )

    total_res = (
        db.table("influencer_payouts")
        .select("id", count="exact")
        .eq("influencer_id", influencer_id)
        .execute()
    )

    return success_response({
        "total_earned": float(profile.get("total_earned") or 0),
        "wallet_balance": float(profile.get("wallet_balance") or 0),
        "payouts": payouts_res.data or [],
        "total": total_res.count or 0,
        "page": page,
        "per_page": per_page,
    })


# ── Referral Link Info ──────────────────────────────────────────────────────────

@router.get("/ref-link")
async def get_ref_link(user: dict = Depends(get_current_user)):
    _require_influencer(user)
    db = get_db()

    profile_res = db.table("influencer_profiles").select("ref_code, qualified_leads, total_leads").eq("user_id", user["id"]).execute()
    if not profile_res.data:
        raise HTTPException(status_code=404, detail="Profile not found")

    profile = profile_res.data[0]
    ref_code = profile["ref_code"]
    ref_link = f"{settings.FRONTEND_URL}/signup?ref={ref_code}"

    return success_response({
        "ref_code": ref_code,
        "ref_link": ref_link,
        "total_leads": profile.get("total_leads") or 0,
        "qualified_leads": profile.get("qualified_leads") or 0,
    })
