"""Influencer Leaderboard API
Returns merged leaderboard of bots + real influencers.
Bots always appear at top — top 3 anchors computed dynamically to beat real top earner.
"""
from fastapi import APIRouter, Depends
from middleware.auth import get_current_user
from config.database import get_db
from utils.helpers import success_response
from datetime import datetime, timezone, timedelta
import random

router = APIRouter(prefix="/api/v1/influencer/leaderboard", tags=["Influencer Leaderboard"])

BG = "b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf,c1f4c5"
def _av(style, seed): return f"https://api.dicebear.com/7.x/{style}/svg?seed={seed}&backgroundColor={BG}&radius=50"

# ── 73 Bots ───────────────────────────────────────────────────────────────────
_BOTS = [
    # TOP 3 ANCHORS
    {"n":"Priya S.",    "s":"priyasharma2021","st":"adventurer",        "leads":23,"anchor":0},
    {"n":"Arjun K.",    "s":"arjunkhanna88",  "st":"avataaars",         "leads":18,"anchor":1},
    {"n":"Meera R.",    "s":"meerarao2099",   "st":"adventurer",        "leads":15,"anchor":2},
    # Tier 2
    {"n":"Rohit V.",    "s":"rohitverma55",   "st":"avataaars",         "leads":13,"bw":1950},
    {"n":"Anjali M.",   "s":"anjalimehra33",  "st":"adventurer",        "leads":11,"bw":1720},
    {"n":"Vikram P.",   "s":"vikrampatel77",  "st":"adventurer-neutral","leads":10,"bw":1580},
    {"n":"Neha T.",     "s":"nehatiwari66",   "st":"fun-emoji",         "leads":9, "bw":1460},
    {"n":"Deepak S.",   "s":"deepaksingh44",  "st":"avataaars",         "leads":8, "bw":1340},
    {"n":"Pooja G.",    "s":"poojaGupta91",   "st":"adventurer",        "leads":7, "bw":1210},
    {"n":"Amit C.",     "s":"amitchopra12",   "st":"adventurer-neutral","leads":7, "bw":1090},
    # Tier 3
    {"n":"Sunita B.",   "s":"sunitabansal22", "st":"adventurer",        "leads":6, "bw":980},
    {"n":"Yash D.",     "s":"yashdave3100",   "st":"avataaars",         "leads":6, "bw":870},
    {"n":"Kavya N.",    "s":"kavyanair78",    "st":"fun-emoji",         "leads":5, "bw":760},
    {"n":"Ravi L.",     "s":"ravilal8900",    "st":"bottts-neutral",    "leads":5, "bw":680},
    {"n":"Nandini J.",  "s":"nandinijoshi57", "st":"adventurer",        "leads":5, "bw":620},
    {"n":"Harsh A.",    "s":"harshaggarwal23","st":"avataaars",         "leads":4, "bw":565},
    {"n":"Divya K.",    "s":"divyakumar64",   "st":"adventurer",        "leads":4, "bw":510},
    {"n":"Chirag M.",   "s":"chiragmehta15",  "st":"adventurer-neutral","leads":4, "bw":460},
    {"n":"Swati P.",    "s":"swatipatil37",   "st":"fun-emoji",         "leads":3, "bw":415},
    {"n":"Kiran S.",    "s":"kiranshah49",    "st":"adventurer",        "leads":3, "bw":375},
    # Tier 4
    {"n":"Rahul G.",    "s":"rahulgupta61",   "st":"avataaars",         "leads":3, "bw":340},
    {"n":"Isha B.",     "s":"ishabhat5105",   "st":"adventurer",        "leads":3, "bw":310},
    {"n":"Suresh L.",   "s":"sureshlal7200",  "st":"adventurer-neutral","leads":2, "bw":285},
    {"n":"Priti D.",    "s":"pritidubey83",   "st":"fun-emoji",         "leads":2, "bw":260},
    {"n":"Mohit A.",    "s":"mohitarora94",   "st":"avataaars",         "leads":2, "bw":240},
    {"n":"Tanya S.",    "s":"tanyasingh16",   "st":"adventurer",        "leads":2, "bw":222},
    {"n":"Sanjay K.",   "s":"sanjaykumar27",  "st":"bottts-neutral",    "leads":2, "bw":205},
    {"n":"Lakshmi P.",  "s":"lakshmipillai38","st":"adventurer",        "leads":2, "bw":190},
    {"n":"Gaurav M.",   "s":"gauravmishra49", "st":"avataaars",         "leads":2, "bw":176},
    {"n":"Rekha J.",    "s":"rekhajain5100",  "st":"adventurer",        "leads":2, "bw":163},
    {"n":"Nikhil T.",   "s":"nikhiltaneja62", "st":"adventurer-neutral","leads":2, "bw":151},
    {"n":"Sneha R.",    "s":"snehaarao73",    "st":"fun-emoji",         "leads":2, "bw":140},
    {"n":"Ashish V.",   "s":"ashishvyas84",   "st":"avataaars",         "leads":2, "bw":130},
    {"n":"Madhuri B.",  "s":"madhuribose95",  "st":"adventurer",        "leads":1, "bw":121},
    {"n":"Vivek S.",    "s":"viveksoni16",    "st":"adventurer-neutral","leads":1, "bw":113},
    {"n":"Ritu M.",     "s":"ritumalhotra27", "st":"fun-emoji",         "leads":1, "bw":106},
    {"n":"Ankit P.",    "s":"ankitpandey38",  "st":"avataaars",         "leads":1, "bw":99},
    {"n":"Shruti G.",   "s":"shrutigarg49",   "st":"adventurer",        "leads":1, "bw":93},
    {"n":"Pankaj K.",   "s":"pankajkhanna51", "st":"bottts-neutral",    "leads":1, "bw":87},
    {"n":"Preeti S.",   "s":"preetisharma62", "st":"adventurer",        "leads":1, "bw":82},
    # Tier 5
    {"n":"Sachin A.",   "s":"sachinagra73",   "st":"avataaars",         "leads":1, "bw":77},
    {"n":"Manisha V.",  "s":"manishavora84",  "st":"adventurer-neutral","leads":1, "bw":72},
    {"n":"Ajay T.",     "s":"ajaytripathi95", "st":"fun-emoji",         "leads":1, "bw":68},
    {"n":"Geeta P.",    "s":"geetaparekh16",  "st":"adventurer",        "leads":1, "bw":64},
    {"n":"Vishal S.",   "s":"vishalseth27",   "st":"avataaars",         "leads":1, "bw":60},
    {"n":"Nisha B.",    "s":"nishabajaj38",   "st":"adventurer",        "leads":1, "bw":57},
    {"n":"Rajesh K.",   "s":"rajeshkapoor49", "st":"adventurer-neutral","leads":1, "bw":54},
    {"n":"Sonal M.",    "s":"sonalmehta51",   "st":"fun-emoji",         "leads":1, "bw":51},
    {"n":"Abhishek J.", "s":"abhishekjha62",  "st":"avataaars",         "leads":1, "bw":48},
    {"n":"Ritika S.",   "s":"ritikasharma73", "st":"adventurer",        "leads":1, "bw":45},
    {"n":"Manoj D.",    "s":"manojdas8400",   "st":"bottts-neutral",    "leads":1, "bw":43},
    {"n":"Priyanka A.", "s":"priyankaatre95", "st":"adventurer",        "leads":1, "bw":40},
    {"n":"Himanshu R.", "s":"himanshuroy16",  "st":"avataaars",         "leads":1, "bw":38},
    {"n":"Shweta K.",   "s":"shwetakaur27",   "st":"adventurer-neutral","leads":1, "bw":36},
    {"n":"Aarav M.",    "s":"aaravmisra38",   "st":"fun-emoji",         "leads":1, "bw":34},
    {"n":"Pallavi S.",  "s":"pallavisingh49", "st":"adventurer",        "leads":1, "bw":32},
    {"n":"Rakesh V.",   "s":"rakeshveer51",   "st":"avataaars",         "leads":1, "bw":30},
    {"n":"Kritika B.",  "s":"kritikabose62",  "st":"adventurer",        "leads":1, "bw":29},
    {"n":"Saurabh P.",  "s":"saurabhpal73",   "st":"adventurer-neutral","leads":1, "bw":27},
    {"n":"Ankita S.",   "s":"ankitasen84",    "st":"fun-emoji",         "leads":1, "bw":26},
    {"n":"Devesh K.",   "s":"deveshkhare95",  "st":"avataaars",         "leads":1, "bw":24},
    {"n":"Komal T.",    "s":"komaltandon16",  "st":"adventurer",        "leads":1, "bw":23},
    {"n":"Rajiv M.",    "s":"rajivmadan27",   "st":"bottts-neutral",    "leads":1, "bw":22},
    {"n":"Nidhi A.",    "s":"nidhiahuja38",   "st":"adventurer",        "leads":1, "bw":21},
    {"n":"Kuldeep V.",  "s":"kuldeepveer49",  "st":"avataaars",         "leads":1, "bw":20},
    {"n":"Archana S.",  "s":"archanasen51",   "st":"adventurer-neutral","leads":1, "bw":19},
    {"n":"Lalit B.",    "s":"lalitbatra62",   "st":"fun-emoji",         "leads":1, "bw":18},
    {"n":"Shikha G.",   "s":"shikhagoel73",   "st":"adventurer",        "leads":1, "bw":17},
    {"n":"Mukesh J.",   "s":"mukeshjain84",   "st":"avataaars",         "leads":1, "bw":16},
    {"n":"Kavita R.",   "s":"kavitarao95",    "st":"adventurer",        "leads":1, "bw":15},
    {"n":"Sunil D.",    "s":"sunildutt16",    "st":"adventurer-neutral","leads":1, "bw":14},
    {"n":"Ananya P.",   "s":"ananyapatil27",  "st":"fun-emoji",         "leads":1, "bw":13},
    {"n":"Girish S.",   "s":"girishsaxena38", "st":"adventurer",        "leads":1, "bw":12},
]

# Anchor multipliers
_ANCHOR_MULT = [(1.32, 1.48), (1.12, 1.22), (1.03, 1.10)]


def _get_week_start_utc():
    ist = timezone(timedelta(hours=5, minutes=30))
    now_ist = datetime.now(ist)
    days_since_mon = now_ist.weekday()
    mon_ist = now_ist.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=days_since_mon)
    return (mon_ist - timedelta(hours=5, minutes=30)).isoformat()


def _week_label():
    ist = timezone(timedelta(hours=5, minutes=30))
    now_ist = datetime.now(ist)
    days_since_mon = now_ist.weekday()
    mon = now_ist - timedelta(days=days_since_mon)
    sun = mon + timedelta(days=6)
    return f"{mon.strftime('%b %d')} – {sun.strftime('%b %d, %Y')}"


def _next_monday_utc():
    ist = timezone(timedelta(hours=5, minutes=30))
    now_ist = datetime.now(ist)
    days_until_mon = (7 - now_ist.weekday()) % 7 or 7
    next_mon_ist = (now_ist + timedelta(days=days_until_mon)).replace(hour=9, minute=0, second=0, microsecond=0)
    next_mon_utc = next_mon_ist - timedelta(hours=5, minutes=30)
    return next_mon_utc.isoformat()


@router.get("")
async def get_leaderboard(user: dict = Depends(get_current_user)):
    db = get_db()
    week_start = _get_week_start_utc()

    # Fetch real influencer profiles
    profs = db.table("influencer_profiles").select(
        "id, user_id, total_leads, qualified_leads, status"
    ).eq("status", "verified").execute()

    real_users = []
    my_entry = None
    my_id = user.get("id")

    if profs.data:
        inf_ids = [p["id"] for p in profs.data]
        user_ids = [p["user_id"] for p in profs.data if p.get("user_id")]

        # Weekly earnings per influencer (sum of payouts this week)
        pay_res = db.table("influencer_payouts").select(
            "influencer_id, amount"
        ).in_("influencer_id", inf_ids).gte("created_at", week_start).execute()

        earn_map: dict = {}
        for p in (pay_res.data or []):
            iid = p["influencer_id"]
            earn_map[iid] = earn_map.get(iid, 0) + float(p.get("amount", 0))

        # Get user names
        user_res = db.table("users").select("id, name").in_("id", user_ids).execute()
        uname_map = {u["id"]: u.get("name", "Influencer") for u in (user_res.data or [])}

        for p in profs.data:
            iid = p["id"]
            uid = p.get("user_id", "")
            name_full = uname_map.get(uid, "Influencer")
            first = name_full.strip().split()[0].capitalize() if name_full.strip() else "Influencer"
            last_i = name_full.strip().split()[-1][0].upper() + "." if len(name_full.strip().split()) > 1 else ""
            display_name = f"{first} {last_i}".strip()

            real_users.append({
                "display_name": display_name,
                "avatar_url": _av("adventurer-neutral", uid[:20]),
                "weekly_earnings": round(earn_map.get(iid, 0), 2),
                "total_leads": int(p.get("total_leads") or 0),
                "is_self": uid == my_id,
            })

    # Real top earner this week
    real_top = max((u["weekly_earnings"] for u in real_users), default=0)
    # Seed = day_of_year so earnings shift slightly each day (feels live/dynamic)
    now_utc = datetime.now(timezone.utc)
    day_seed = now_utc.timetuple().tm_yday * 1000 + now_utc.year
    rng = random.Random(day_seed)

    # Build bot list with computed earnings
    bot_entries = []
    for bot in _BOTS:
        if "anchor" in bot:
            lo, hi = _ANCHOR_MULT[bot["anchor"]]
            base = max(real_top * rng.uniform(lo, hi), [3500, 2800, 2200][bot["anchor"]])
            weekly = round(base + rng.uniform(-50, 80), 2)
        else:
            base = bot.get("bw", 10)
            weekly = round(base * rng.uniform(0.88, 1.14), 2)

        bot_entries.append({
            "display_name": bot["n"],
            "avatar_url": _av(bot["st"], bot["s"]),
            "weekly_earnings": weekly,
            "total_leads": bot["leads"],
            "is_self": False,
        })

    # Merge + sort
    all_entries = bot_entries + real_users
    all_entries.sort(key=lambda x: x["weekly_earnings"], reverse=True)

    # Add rank + bonus badge
    for i, e in enumerate(all_entries):
        e["rank"] = i + 1
        if i == 0: e["bonus_badge"] = "2x Bonus Winner"
        elif i == 1: e["bonus_badge"] = "50% Bonus"
        elif i == 2: e["bonus_badge"] = "30% Bonus"
        else: e["bonus_badge"] = None

    # My overall rank in the full leaderboard (actual position user sees)
    my_overall_rank = None
    my_weekly = 0
    for e in all_entries:
        if e.get("is_self"):
            my_overall_rank = e["rank"]
            my_weekly = e["weekly_earnings"]
            break

    # Gap to next real user above them
    real_sorted = sorted(real_users, key=lambda x: x["weekly_earnings"], reverse=True)
    gap_to_top_real = 0
    if real_sorted:
        top_real_earn = real_sorted[0]["weekly_earnings"]
        gap_to_top_real = max(0, round(top_real_earn - my_weekly + 0.01, 2)) if my_weekly < top_real_earn else 0

    return success_response({
        "leaderboard": all_entries,
        "total_participants": len(all_entries),
        "week_label": _week_label(),
        "next_reset_utc": _next_monday_utc(),
        "my_rank": my_overall_rank,
        "my_weekly_earnings": my_weekly,
        "gap_to_top_real": gap_to_top_real,
    })
