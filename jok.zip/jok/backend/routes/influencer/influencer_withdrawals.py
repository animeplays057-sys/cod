"""
Influencer Withdrawal Routes
POST /api/v1/influencer/withdraw         — Request a withdrawal
GET  /api/v1/influencer/withdrawals      — Get withdrawal history
GET  /api/v1/influencer/withdrawals/:id  — Get single withdrawal status
"""
from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone
from loguru import logger

from config.database import get_db
from middleware.auth import get_current_user
from services.influencer_service import process_razorpay_payout
from utils.helpers import success_response

router = APIRouter(prefix="/api/v1/influencer", tags=["Influencer"])

MINIMUM_WITHDRAWAL = 2000.00  # ₹2,000


class WithdrawalRequest(BaseModel):
    amount: float
    payment_method: str = "upi"   # upi | bank
    upi_id: Optional[str] = None
    bank_account_number: Optional[str] = None
    bank_ifsc: Optional[str] = None
    bank_account_name: Optional[str] = None


def _require_influencer(user: dict):
    if user.get("role") != "influencer":
        raise HTTPException(status_code=403, detail="Influencer access only")


# ── Request Withdrawal ─────────────────────────────────────────────────────────

@router.post("/withdraw")
async def request_withdrawal(
    body: WithdrawalRequest,
    background_tasks: BackgroundTasks,
    user: dict = Depends(get_current_user),
):
    _require_influencer(user)
    db = get_db()

    # Get influencer profile
    profile_res = db.table("influencer_profiles").select("*").eq("user_id", user["id"]).execute()
    if not profile_res.data:
        raise HTTPException(status_code=404, detail="Profile not found")
    profile = profile_res.data[0]

    # Check status
    if profile.get("status") != "verified":
        raise HTTPException(status_code=403, detail="Your account must be verified before withdrawing")

    # Check minimum amount
    if body.amount < MINIMUM_WITHDRAWAL:
        raise HTTPException(status_code=400, detail=f"Minimum withdrawal amount is ₹{MINIMUM_WITHDRAWAL:,.0f}")

    # Check sufficient balance
    wallet_balance = float(profile.get("wallet_balance") or 0)
    if body.amount > wallet_balance:
        raise HTTPException(status_code=400, detail=f"Insufficient balance. Available: ₹{wallet_balance:,.2f}")

    # Validate payment details
    if body.payment_method == "upi":
        if not body.upi_id:
            raise HTTPException(status_code=400, detail="UPI ID is required for UPI withdrawal")
    else:
        if not all([body.bank_account_number, body.bank_ifsc, body.bank_account_name]):
            raise HTTPException(status_code=400, detail="Bank account details are incomplete")

    # Check no pending withdrawal already
    pending = (
        db.table("influencer_withdrawals")
        .select("id")
        .eq("influencer_id", profile["id"])
        .in_("status", ["pending", "processing"])
        .execute()
    )
    if pending.data:
        raise HTTPException(status_code=409, detail="You already have a pending withdrawal request")

    # Create withdrawal record
    wd_data = {
        "influencer_id": profile["id"],
        "amount": body.amount,
        "payment_method": body.payment_method,
        "upi_id": body.upi_id or "",
        "bank_account_number": body.bank_account_number or "",
        "bank_ifsc": body.bank_ifsc or "",
        "bank_account_name": body.bank_account_name or "",
        "status": "pending",
        "requested_at": datetime.now(timezone.utc).isoformat(),
    }
    wd_res = db.table("influencer_withdrawals").insert(wd_data).execute()
    withdrawal_id = wd_res.data[0]["id"]

    # Attempt automated Razorpay payout in background
    async def _try_auto_payout():
        result = await process_razorpay_payout(withdrawal_id)
        if not result["success"]:
            logger.warning(f"⚠️ Auto payout failed for withdrawal {withdrawal_id} — manual required")

    background_tasks.add_task(_try_auto_payout)

    return success_response(
        {"withdrawal_id": withdrawal_id},
        f"Withdrawal request of ₹{body.amount:,.2f} submitted. Processing via Razorpay. You'll be notified once complete."
    )


# ── Withdrawal History ─────────────────────────────────────────────────────────

@router.get("/withdrawals")
async def get_withdrawals(user: dict = Depends(get_current_user)):
    _require_influencer(user)
    db = get_db()

    profile_res = db.table("influencer_profiles").select("id").eq("user_id", user["id"]).execute()
    if not profile_res.data:
        raise HTTPException(status_code=404, detail="Profile not found")
    influencer_id = profile_res.data[0]["id"]

    wd_res = (
        db.table("influencer_withdrawals")
        .select("*")
        .eq("influencer_id", influencer_id)
        .order("requested_at", desc=True)
        .execute()
    )

    return success_response(wd_res.data or [])


# ── Single Withdrawal Status ────────────────────────────────────────────────────

@router.get("/withdrawals/{withdrawal_id}")
async def get_withdrawal_status(withdrawal_id: str, user: dict = Depends(get_current_user)):
    _require_influencer(user)
    db = get_db()

    profile_res = db.table("influencer_profiles").select("id").eq("user_id", user["id"]).execute()
    if not profile_res.data:
        raise HTTPException(status_code=404, detail="Profile not found")
    influencer_id = profile_res.data[0]["id"]

    wd_res = (
        db.table("influencer_withdrawals")
        .select("*")
        .eq("id", withdrawal_id)
        .eq("influencer_id", influencer_id)
        .execute()
    )
    if not wd_res.data:
        raise HTTPException(status_code=404, detail="Withdrawal not found")

    return success_response(wd_res.data[0])
