from fastapi import APIRouter, Depends, HTTPException
import secrets
from config.database import get_db
from config.security import generate_api_key, hash_password
from middleware.auth import get_current_merchant
from models.merchant import GenerateApiKeyRequest
from utils.helpers import success_response

router = APIRouter(prefix="/api/v1/merchant/api-keys", tags=["Merchant API Keys"])


@router.get("")
async def list_keys(user: dict = Depends(get_current_merchant)):
    db = get_db()
    result = db.table("api_keys").select("id, api_key, label, is_active, last_used_at, last_used_ip, created_at").eq("user_id", user["id"]).order("created_at", desc=True).execute()
    return success_response(result.data or [])


@router.post("/generate")
async def generate_key(body: GenerateApiKeyRequest, user: dict = Depends(get_current_merchant)):
    db = get_db()
    api_key = generate_api_key()
    secret_key = secrets.token_hex(32)

    db.table("api_keys").insert({
        "user_id": user["id"],
        "api_key": api_key,
        "secret_key_hash": hash_password(secret_key),
        "label": body.label,
    }).execute()

    return success_response({
        "api_key": api_key,
        "secret_key": secret_key,
        "label": body.label,
        "warning": "Save your Secret Key now. It won't be shown again!",
    }, "API key generated")


@router.delete("/{key_id}")
async def revoke_key(key_id: str, user: dict = Depends(get_current_merchant)):
    db = get_db()
    key = db.table("api_keys").select("id").eq("id", key_id).eq("user_id", user["id"]).execute()
    if not key.data:
        raise HTTPException(status_code=404, detail="API key not found")
    db.table("api_keys").update({"is_active": False}).eq("id", key_id).execute()
    return success_response(message="API key revoked")
