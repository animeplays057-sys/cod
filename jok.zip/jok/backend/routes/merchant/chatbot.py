"""Merchant chatbot configuration endpoints."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from config.database import get_db
from middleware.auth import get_current_merchant
from middleware.contract import require_service
from utils.helpers import success_response
from config.settings import settings
from services.website_scraper_service import scrape_website

router = APIRouter(
    prefix="/api/v1/merchant/chatbot",
    tags=["Merchant Chatbot"],
    dependencies=[Depends(require_service("customer_support"))]
)


class MenuOption(BaseModel):
    id: str
    label: str
    answer: str


class ChatbotConfigUpdate(BaseModel):
    business_name: Optional[str] = None
    business_description: Optional[str] = None
    business_services: Optional[str] = None
    business_website: Optional[str] = None
    business_faq: Optional[str] = None
    welcome_message: Optional[str] = None
    menu_options: Optional[List[MenuOption]] = None
    primary_color: Optional[str] = None
    bot_name: Optional[str] = None
    widget_theme: Optional[str] = None   # 'light' | 'dark'
    logo_url: Optional[str] = None       # favicon / logo URL (auto-filled by scan)
    font_family: Optional[str] = None    # e.g. 'Inter', 'Poppins', 'Playfair Display'
    # Fields from smart scraper
    contact_info: Optional[str] = None   # email, phone, social links
    shipping_info: Optional[str] = None  # shipping policy text
    return_policy: Optional[str] = None  # return/refund policy text
    platform: Optional[str] = None       # 'shopify' | 'woocommerce' | 'generic'
    return_policy_days: Optional[int] = None   # days after order that returns are accepted
    refund_policy_days: Optional[int] = None   # days after order that refunds are accepted


class ScanWebsiteRequest(BaseModel):
    url: str


@router.get("/config")
async def get_chatbot_config(user: dict = Depends(get_current_merchant)):
    """Get merchant's chatbot configuration."""
    db = get_db()
    config = db.table("merchant_chatbot_config").select("*").eq(
        "merchant_id", user["id"]
    ).execute()

    if not config.data:
        # Auto-create config with defaults
        new_config = db.table("merchant_chatbot_config").insert({
            "merchant_id": user["id"],
            "business_name": user.get("company_name", ""),
            "business_website": "",
        }).execute()
        return success_response({"config": new_config.data[0] if new_config.data else {}})

    return success_response({"config": config.data[0]})


@router.put("/config")
async def update_chatbot_config(body: ChatbotConfigUpdate, user: dict = Depends(get_current_merchant)):
    """Update merchant's chatbot configuration."""
    db = get_db()

    # Ensure config exists
    existing = db.table("merchant_chatbot_config").select("id").eq(
        "merchant_id", user["id"]
    ).execute()

    updates = body.model_dump(exclude_unset=True)
    if "menu_options" in updates and updates["menu_options"] is not None:
        updates["menu_options"] = [opt.model_dump() if hasattr(opt, 'model_dump') else opt for opt in updates["menu_options"]]

    if existing.data:
        db.table("merchant_chatbot_config").update(updates).eq(
            "merchant_id", user["id"]
        ).execute()
    else:
        updates["merchant_id"] = user["id"]
        db.table("merchant_chatbot_config").insert(updates).execute()

    return success_response(message="Chatbot configuration updated")


@router.post("/toggle")
async def toggle_chatbot(user: dict = Depends(get_current_merchant)):
    """Enable/disable chatbot."""
    db = get_db()
    config = db.table("merchant_chatbot_config").select("is_enabled").eq(
        "merchant_id", user["id"]
    ).execute()

    if not config.data:
        db.table("merchant_chatbot_config").insert({
            "merchant_id": user["id"],
            "is_enabled": True,
        }).execute()
        return success_response({"is_enabled": True}, "Chatbot enabled")

    new_state = not config.data[0].get("is_enabled", False)
    db.table("merchant_chatbot_config").update({"is_enabled": new_state}).eq(
        "merchant_id", user["id"]
    ).execute()
    return success_response({"is_enabled": new_state}, f"Chatbot {'enabled' if new_state else 'disabled'}")


@router.get("/usage")
async def get_chatbot_usage(user: dict = Depends(get_current_merchant)):
    """Get chatbot API usage stats."""
    db = get_db()
    config = db.table("merchant_chatbot_config").select(
        "monthly_request_limit, current_month_usage, usage_reset_date"
    ).eq("merchant_id", user["id"]).execute()

    c = config.data[0] if config.data else {}
    return success_response({
        "monthly_limit": c.get("monthly_request_limit", 100),
        "used": c.get("current_month_usage", 0),
        "remaining": max(0, c.get("monthly_request_limit", 100) - c.get("current_month_usage", 0)),
        "reset_date": c.get("usage_reset_date"),
    })


@router.get("/embed-code")
async def get_embed_code(user: dict = Depends(get_current_merchant)):
    """Get the embed code snippet for the merchant's website."""
    db = get_db()
    config = db.table("merchant_chatbot_config").select("api_key, is_enabled").eq(
        "merchant_id", user["id"]
    ).execute()

    if not config.data:
        raise HTTPException(404, "Chatbot not configured yet. Please set up your chatbot first.")

    api_key = config.data[0]["api_key"]
    backend_url = settings.BACKEND_URL.rstrip("/")

    embed_script = f"""<!-- CODVerify Chatbot Widget -->
<script>
  (function() {{
    var s = document.createElement('script');
    s.src = '{backend_url}/static/chatbot-widget.js?v=7';
    s.setAttribute('data-codverify-key', '{api_key}');
    s.setAttribute('data-codverify-api', '{backend_url}');
    s.async = true;
    document.head.appendChild(s);
  }})();
</script>"""

    return success_response({
        "api_key": api_key,
        "embed_code": embed_script,
        "is_enabled": config.data[0].get("is_enabled", False),
    })


@router.get("/help-center-embed")
async def get_help_center_embed_code(user: dict = Depends(get_current_merchant)):
    """Get the Help Center embed HTML snippet for pasting into a Shopify page."""
    db = get_db()
    config = db.table("merchant_chatbot_config").select("api_key, is_enabled").eq(
        "merchant_id", user["id"]
    ).execute()

    if not config.data:
        raise HTTPException(404, "Chatbot not configured yet. Please set up your chatbot first.")

    api_key = config.data[0]["api_key"]
    backend_url = settings.BACKEND_URL.rstrip("/")

    embed_html = f"""<!-- CODVerify Help Center — paste inside your Shopify page content -->
<div id="codverify-help-center" style="border-radius:20px;overflow:hidden;box-shadow:0 8px 40px rgba(0,0,0,0.12);min-height:500px"></div>
<script
  src="{backend_url}/static/help-center.js"
  data-key="{api_key}"
  data-api="{backend_url}"
  async>
</script>"""

    return success_response({
        "api_key": api_key,
        "embed_code": embed_html,
        "is_enabled": config.data[0].get("is_enabled", False),
        "preview_note": "Paste this HTML into your Shopify page content editor (HTML view). The Help Center will auto-render with your branding.",
    })




@router.post("/scan-website")
async def scan_website_endpoint(body: ScanWebsiteRequest, user: dict = Depends(get_current_merchant)):
    """Scrape merchant's website URL, return extracted branding/business info,
    and upsert scraped products (with image_url + product_url) into the products table.
    """
    url = body.url.strip()
    if not url:
        raise HTTPException(400, "URL cannot be empty")

    result = await scrape_website(url)

    if "error" in result:
        return success_response(
            {"scraped": False, "error": result["error"]},
            message=result["error"],
        )

    # ── Save scraped products to DB so the chatbot widget shows images + links ──
    raw_products = result.get("raw_products") or []
    if raw_products:
        db = get_db()
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc).isoformat()

        # Delete existing products for this merchant (full refresh on re-scan)
        try:
            db.table("products").delete().eq("user_id", user["id"]).execute()
        except Exception:
            pass  # table may not exist yet — handled on insert

        rows = []
        for p in raw_products[:500]:  # cap at 500 products per merchant
            try:
                price_raw = p.get("price", "") or ""
                # Normalize price string to float (e.g. "Rs. 1,299" → 1299.0)
                import re as _re
                price_digits = _re.sub(r"[^\d.]", "", price_raw.replace(",", ""))
                price_val = float(price_digits) if price_digits else None

                rows.append({
                    "user_id": user["id"],
                    "title": (p.get("title") or "")[:255],
                    "price": price_val,
                    "currency": "INR",
                    "image_url": (p.get("image_url") or "")[:1000],
                    "product_url": (p.get("product_url") or "")[:1000],
                    "product_type": (p.get("type") or "")[:100],
                    "handle": "",
                    "status": "active",
                    "created_at": now,
                    "updated_at": now,
                })
            except Exception:
                continue

        if rows:
            try:
                # Insert in batches of 100
                for i in range(0, len(rows), 100):
                    db.table("products").insert(rows[i:i+100]).execute()
            except Exception as e:
                # Log but don't fail — products save is non-critical
                from loguru import logger
                logger.warning(f"Products save failed for merchant {user['id']}: {e}")

    return success_response(
        {
            "scraped": True,
            "business_name": result.get("business_name"),
            "business_description": result.get("business_description"),
            "business_services": result.get("business_services"),
            "business_faq": result.get("business_faq"),
            "primary_color": result.get("primary_color"),
            "bot_name": result.get("bot_name"),
            "logo_url": result.get("favicon_url"),
            "scraped_url": result.get("scraped_url"),
            "contact_info": result.get("contact_info"),
            "shipping_info": result.get("shipping_info"),
            "return_policy": result.get("return_policy"),
            "platform": result.get("platform"),
            "product_count": result.get("product_count", 0),
            "products_saved": len(raw_products),
        },
        message=f"Website scanned — found {result.get('product_count', 0)} product(s), {len(raw_products)} saved to DB",
    )
