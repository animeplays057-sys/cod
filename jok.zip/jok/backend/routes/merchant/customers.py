from fastapi import APIRouter, Depends, HTTPException
from config.database import get_db
from middleware.auth import get_current_merchant
from middleware.contract import require_service
from models.merchant import BlacklistRequest
from utils.helpers import success_response, paginate_params, pagination_meta
from utils.phone_utils import hash_phone, phone_last_four, normalize_phone

router = APIRouter(
    prefix="/api/v1/merchant/customers",
    tags=["Merchant Customers"],
    dependencies=[Depends(require_service("cod_verification"))]
)


@router.get("")
async def list_customers(
    page: int = 1, limit: int = 20, search: str = None,
    risk_score_min: int = None, risk_score_max: int = None,
    blacklisted: bool = None, user: dict = Depends(get_current_merchant)
):
    db = get_db()
    offset, limit = paginate_params(page, limit)

    # Get unique phone hashes from this merchant's orders
    orders = db.table("orders").select("customer_phone_normalized").eq("user_id", user["id"]).execute()
    phone_hashes = list(set(hash_phone(o["customer_phone_normalized"]) for o in (orders.data or []) if o.get("customer_phone_normalized")))

    if not phone_hashes:
        return success_response({"customers": [], "pagination": pagination_meta(0, page, limit)})

    query = db.table("customers_directory").select("*", count="exact").in_("phone_number_hash", phone_hashes[:100])

    if risk_score_min is not None:
        query = query.gte("risk_score", risk_score_min)
    if risk_score_max is not None:
        query = query.lte("risk_score", risk_score_max)
    if search:
        query = query.ilike("phone_last_four", f"%{search}%")

    result = query.range(offset, offset + limit - 1).execute()
    customers = result.data or []

    # Check merchant blacklist
    bl = db.table("merchant_blacklist").select("phone_number_hash").eq("user_id", user["id"]).execute()
    bl_hashes = set(b["phone_number_hash"] for b in (bl.data or []))
    for c in customers:
        c["is_blacklisted"] = c["phone_number_hash"] in bl_hashes

    if blacklisted is not None:
        customers = [c for c in customers if c["is_blacklisted"] == blacklisted]

    return success_response({
        "customers": customers,
        "pagination": pagination_meta(result.count or 0, page, limit),
    })


@router.post("/blacklist")
async def blacklist_customer(body: BlacklistRequest, user: dict = Depends(get_current_merchant)):
    db = get_db()
    # When frontend sends phone_hash (from existing masked customer data), use it directly
    # Otherwise hash the provided phone_number
    p_hash = body.phone_hash if body.phone_hash else hash_phone(normalize_phone(body.phone_number))
    existing = db.table("merchant_blacklist").select("id").eq("user_id", user["id"]).eq("phone_number_hash", p_hash).execute()
    if existing.data:
        raise HTTPException(status_code=409, detail="Already blacklisted")

    db.table("merchant_blacklist").insert({
        "user_id": user["id"],
        "phone_number_hash": p_hash,
        "phone_last_four": phone_last_four(body.phone_number),
        "reason": body.reason,
    }).execute()
    return success_response(message="Customer blacklisted")


@router.delete("/blacklist/{phone_hash}")
async def unblacklist_customer(phone_hash: str, user: dict = Depends(get_current_merchant)):
    db = get_db()
    db.table("merchant_blacklist").delete().eq("user_id", user["id"]).eq("phone_number_hash", phone_hash).execute()
    return success_response(message="Customer removed from blacklist")
