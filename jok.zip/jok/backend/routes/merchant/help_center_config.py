"""
Merchant Help Center Configuration API
Merchants control their Help Center widget: theme, sections toggle, FAQ, policies, custom sections.
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Any
from config.database import get_db
from middleware.auth import get_current_merchant
from middleware.contract import require_service
from utils.helpers import success_response

router = APIRouter(
    prefix="/api/v1/merchant/help-center",
    tags=["Merchant Help Center Config"],
    dependencies=[Depends(require_service("help_center"))]
)

# ── Default section config ────────────────────────────────────────────────────

DEFAULT_SECTIONS = {
    "track_order": True,
    "return_exchange": True,
    "call_me_back": True,
    "chat_with_us": True,
    "faqs": True,
    "our_policies": True,
    "raise_complaint": True,
}


# ── Pydantic models ───────────────────────────────────────────────────────────

class CustomSection(BaseModel):
    id: str
    label: str
    icon: Optional[str] = "star"          # lucide icon name
    content: Optional[str] = None         # rich text / markdown
    enabled: bool = True


class HelpCenterConfigUpdate(BaseModel):
    help_center_enabled: Optional[bool] = None
    help_center_theme: Optional[str] = None         # modern | glass | minimal | bold
    help_center_sections: Optional[dict] = None     # section toggles
    help_center_custom_sections: Optional[List[Any]] = None
    help_center_faq: Optional[str] = None
    help_center_shipping: Optional[str] = None
    help_center_return: Optional[str] = None
    help_center_contact: Optional[str] = None


# ── Helpers ───────────────────────────────────────────────────────────────────

def _get_hc_config(merchant_id: str) -> dict:
    db = get_db()
    res = db.table("merchant_chatbot_config").select("*").eq("merchant_id", merchant_id).execute()
    if not res.data:
        raise HTTPException(404, "Help Center config not found. Please set up chatbot first.")
    return res.data[0]


# ── Routes ────────────────────────────────────────────────────────────────────

@router.get("/config")
async def get_help_center_config(user: dict = Depends(get_current_merchant)):
    """Get merchant's Help Center configuration."""
    cfg = _get_hc_config(user["id"])

    # Normalise: merge defaults with stored sections so new sections always appear
    stored_sections = cfg.get("help_center_sections") or {}
    merged_sections = {**DEFAULT_SECTIONS, **stored_sections}

    return success_response({
        "config": {
            "help_center_enabled": cfg.get("help_center_enabled", True),
            "help_center_theme": cfg.get("help_center_theme", "modern"),
            "help_center_sections": merged_sections,
            "help_center_custom_sections": cfg.get("help_center_custom_sections") or [],
            "help_center_faq": cfg.get("help_center_faq") or cfg.get("business_faq") or "",
            "help_center_shipping": cfg.get("help_center_shipping") or cfg.get("shipping_info") or "",
            "help_center_return": cfg.get("help_center_return") or cfg.get("return_policy") or "",
            "help_center_contact": cfg.get("help_center_contact") or cfg.get("contact_info") or "",
            # Passthrough branding
            "business_name": cfg.get("business_name", ""),
            "primary_color": cfg.get("primary_color", "#2563eb"),
            "logo_url": cfg.get("logo_url", ""),
            "font_family": cfg.get("font_family", "DM Sans"),
            "return_policy_days": cfg.get("return_policy_days", 7),
        }
    })


@router.put("/config")
async def update_help_center_config(
    body: HelpCenterConfigUpdate,
    user: dict = Depends(get_current_merchant),
):
    """Update Help Center configuration fields."""
    db = get_db()
    _get_hc_config(user["id"])  # Ensure exists

    updates = body.model_dump(exclude_unset=True)

    # Validate theme
    if "help_center_theme" in updates:
        valid_themes = {"modern", "glass", "minimal", "bold"}
        if updates["help_center_theme"] not in valid_themes:
            raise HTTPException(400, f"Invalid theme. Must be one of: {valid_themes}")

    # Validate + merge sections — never lose existing sections
    if "help_center_sections" in updates:
        current_cfg = _get_hc_config(user["id"])
        existing = current_cfg.get("help_center_sections") or {}
        merged = {**DEFAULT_SECTIONS, **existing, **updates["help_center_sections"]}
        updates["help_center_sections"] = merged

    db.table("merchant_chatbot_config").update(updates).eq("merchant_id", user["id"]).execute()
    return success_response(message="Help Center configuration updated")


@router.post("/toggle")
async def toggle_help_center(user: dict = Depends(get_current_merchant)):
    """Enable / disable the entire Help Center widget."""
    db = get_db()
    cfg = _get_hc_config(user["id"])
    new_state = not cfg.get("help_center_enabled", True)
    db.table("merchant_chatbot_config").update(
        {"help_center_enabled": new_state}
    ).eq("merchant_id", user["id"]).execute()
    return success_response(
        {"help_center_enabled": new_state},
        message=f"Help Center {'enabled' if new_state else 'disabled'}"
    )
