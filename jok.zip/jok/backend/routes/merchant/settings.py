from fastapi import APIRouter, Depends, HTTPException
from config.database import get_db
from middleware.auth import get_current_merchant
from models.merchant import UpdateSettingsRequest, ConnectWhatsAppRequest
from utils.helpers import success_response
from utils.encryption import encrypt_value, decrypt_value
from services.whatsapp_service import get_business_profile

router = APIRouter(prefix="/api/v1/merchant/settings", tags=["Merchant Settings"])


@router.get("")
async def get_settings(user: dict = Depends(get_current_merchant)):
    db = get_db()
    result = db.table("merchant_settings").select("*").eq("user_id", user["id"]).execute()
    if not result.data:
        db.table("merchant_settings").insert({"user_id": user["id"]}).execute()
        result = db.table("merchant_settings").select("*").eq("user_id", user["id"]).execute()
    data = result.data[0]
    data.pop("whatsapp_access_token_encrypted", None)
    return success_response(data)


@router.put("")
async def update_settings(body: UpdateSettingsRequest, user: dict = Depends(get_current_merchant)):
    db = get_db()
    updates = body.model_dump(exclude_unset=True)
    if updates:
        db.table("merchant_settings").update(updates).eq("user_id", user["id"]).execute()
    result = db.table("merchant_settings").select("*").eq("user_id", user["id"]).execute()
    data = result.data[0] if result.data else {}
    data.pop("whatsapp_access_token_encrypted", None)
    return success_response(data, "Settings updated")


@router.post("/whatsapp/connect")
async def connect_whatsapp(body: ConnectWhatsAppRequest, user: dict = Depends(get_current_merchant)):
    profile = await get_business_profile(body.whatsapp_phone_number_id, body.whatsapp_access_token)
    if not profile:
        raise HTTPException(status_code=400, detail="Could not verify WhatsApp credentials. Check your IDs and token.")

    db = get_db()
    phone_display = profile.get("display_phone_number", "")
    biz_name = profile.get("verified_name", "")
    quality = profile.get("quality_rating", "")

    db.table("merchant_settings").update({
        "whatsapp_business_id": body.whatsapp_business_id,
        "whatsapp_phone_number_id": body.whatsapp_phone_number_id,
        "whatsapp_access_token_encrypted": encrypt_value(body.whatsapp_access_token),
        "whatsapp_connected": True,
        "whatsapp_phone_display": phone_display,
        "whatsapp_business_name": biz_name,
        "whatsapp_quality_rating": quality,
    }).eq("user_id", user["id"]).execute()

    return success_response({
        "connected": True, "phone_display": phone_display,
        "business_name": biz_name, "quality_rating": quality,
    }, "WhatsApp connected successfully")


@router.get("/whatsapp/status")
async def whatsapp_status(user: dict = Depends(get_current_merchant)):
    db = get_db()
    ms = db.table("merchant_settings").select("whatsapp_connected, whatsapp_phone_display, whatsapp_business_name, whatsapp_quality_rating").eq("user_id", user["id"]).execute()
    return success_response(ms.data[0] if ms.data else {"whatsapp_connected": False})


@router.post("/whatsapp/disconnect")
async def disconnect_whatsapp(user: dict = Depends(get_current_merchant)):
    db = get_db()
    db.table("merchant_settings").update({
        "whatsapp_business_id": None, "whatsapp_phone_number_id": None,
        "whatsapp_access_token_encrypted": None, "whatsapp_connected": False,
        "whatsapp_phone_display": None, "whatsapp_business_name": None,
    }).eq("user_id", user["id"]).execute()
    return success_response(message="WhatsApp disconnected")
