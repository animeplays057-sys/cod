from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from config.database import get_db
from config.settings import settings
from middleware.auth import get_current_merchant
from middleware.contract import require_service
from models.merchant import ConnectStoreRequest, UpdateStoreRequest
from utils.helpers import success_response
from utils.encryption import encrypt_value, decrypt_value
from datetime import datetime, timezone
from typing import Optional
from loguru import logger
import uuid, httpx

router = APIRouter(
    prefix="/api/v1/merchant/stores",
    tags=["Merchant Stores"],
    dependencies=[Depends(require_service("cod_verification"))],
)

@router.get("")
async def list_stores(user: dict = Depends(get_current_merchant)):
    db = get_db()
    result = db.table("stores").select("id, user_id, platform, store_url, store_name, is_active, last_order_received_at, total_orders, connected_at").eq("user_id", user["id"]).execute()

    stores_list = result.data or []

    # ── Multi-store: use stores table as source of truth (NOT users.shopify_shop_domain) ──
    shopify_stores = [s for s in stores_list if s.get("platform") == "shopify" and s.get("is_active")]
    shopify_connected = len(shopify_stores) > 0
    # First active shopify domain (for backwards compat with frontend single-domain field)
    shopify_domain = shopify_stores[0].get("store_url") if shopify_stores else None
    # All active shopify domains (for multi-store UI)
    shopify_domains = [s.get("store_url") for s in shopify_stores]

    # WooCommerce connection status
    wc_stores = [s for s in stores_list if s.get("platform") == "woocommerce" and s.get("is_active")]
    woocommerce_connected = len(wc_stores) > 0
    woocommerce_domain = wc_stores[0].get("store_url") if wc_stores else None

    return success_response({
        "stores": stores_list,
        "shopify_connected": shopify_connected,
        "shopify_domain": shopify_domain,
        "shopify_domains": shopify_domains,
        "woocommerce_connected": woocommerce_connected,
        "woocommerce_domain": woocommerce_domain,
    })


class ConnectViaKeyRequest(BaseModel):
    secret_key: str


@router.post("/connect-via-key")
async def connect_store_via_key(body: ConnectViaKeyRequest, user: dict = Depends(get_current_merchant)):
    """
    Connect a Shopify store using the secret key generated during app installation.
    This links the merchant's CODVerify account to their Shopify store.
    """
    db = get_db()
    secret_key = body.secret_key.strip().upper()

    if not secret_key:
        raise HTTPException(status_code=400, detail="Secret key is required")

    # Look up the key
    key_res = db.table("shopify_install_keys").select("*").eq("secret_key", secret_key).execute()
    if not key_res.data:
        raise HTTPException(status_code=404, detail="Invalid secret key. Please check and try again.")

    key_record = key_res.data[0]

    # Check if already used
    if key_record.get("is_used"):
        # Allow reconnection if the linked user was deleted
        linked_uid = key_record.get("linked_user_id")
        can_reuse = False
        if linked_uid:
            linked_check = db.table("users").select("id").eq("id", linked_uid).execute()
            if not linked_check.data:
                # Linked user was deleted — reset key so it can be reused
                db.table("shopify_install_keys").update({
                    "is_used": False,
                    "linked_user_id": None,
                    "linked_at": None,
                }).eq("id", key_record["id"]).execute()
                key_record["is_used"] = False
                logger.info(f"🔄 Key reset — linked user {linked_uid} was deleted, allowing reconnection")
                can_reuse = True
        if not can_reuse:
            raise HTTPException(status_code=409, detail="This key has already been used to connect a store. Go to the Shopify app and click 'Generate New Code'.")

    # Check expiry
    if key_record.get("expires_at"):
        from datetime import datetime, timezone
        expires = datetime.fromisoformat(key_record["expires_at"].replace("Z", "+00:00"))
        if datetime.now(timezone.utc) > expires:
            raise HTTPException(status_code=410, detail="This key has expired. Please re-install the Shopify app to get a new key.")

    shop_domain = key_record["shop_domain"]
    shop_name = key_record.get("shop_name") or shop_domain

    # ── Multi-store: allow multiple stores per merchant ──
    # Check if this exact install key is already linked to a DIFFERENT user (not same user reconnecting)
    key_linked_user = key_record.get("linked_user_id")
    if key_record.get("is_used") and key_linked_user and str(key_linked_user) != str(user["id"]):
        # Key is used by a different merchant — block (already handled above in is_used check)
        pass
    # If this store_url is already active for THIS user, just return success (idempotent)
    already_this_user = db.table("stores").select("id").eq("user_id", user["id"]).eq("store_url", shop_domain).eq("is_active", True).execute()
    if already_this_user.data:
        return success_response({
            "connected": True,
            "shop_domain": shop_domain,
            "store_name": shop_name,
        }, "Store is already connected to your account")

    # Update users.shopify_shop_domain only if not already set (first store wins, keeps backwards compat)
    user_data = db.table("users").select("shopify_shop_domain").eq("id", user["id"]).execute()
    if user_data.data and not user_data.data[0].get("shopify_shop_domain"):
        db.table("users").update({
            "shopify_shop_domain": shop_domain,
            "shopify_shop_id": key_record.get("shopify_shop_id", ""),
            "onboarding_completed": True,
        }).eq("id", user["id"]).execute()
    else:
        # Already has a domain set — just mark onboarding complete
        db.table("users").update({"onboarding_completed": True}).eq("id", user["id"]).execute()

    # Check if there's an existing inactive store for this user+domain — reactivate it
    access_token_enc = key_record.get("access_token_encrypted", "")
    webhook_secret = str(uuid.uuid4())
    backend_url = settings.BACKEND_URL.rstrip('/')
    webhook_url = f"{backend_url}/api/v1/webhook/order/new"

    existing_store = db.table("stores").select("id").eq("user_id", user["id"]).eq("store_url", shop_domain).execute()
    if existing_store.data:
        # Reactivate existing store
        db.table("stores").update({
            "is_active": True,
            "access_token_encrypted": access_token_enc,
            "webhook_secret": webhook_secret,
            "webhook_url": webhook_url,
            "shopify_install_key_id": key_record["id"],
            "connected_at": datetime.now(timezone.utc).isoformat(),
        }).eq("id", existing_store.data[0]["id"]).execute()
        store_result = db.table("stores").select("*").eq("id", existing_store.data[0]["id"]).execute()
    else:
        # Create new store record — read platform from the install key (shopify or woocommerce)
        platform = key_record.get("platform") or "shopify"
        store_data = {
            "user_id": user["id"],
            "platform": platform,
            "store_url": shop_domain,
            "store_name": shop_name,
            "api_key_encrypted": "",
            "api_secret_encrypted": "",
            "access_token_encrypted": access_token_enc,
            "webhook_secret": webhook_secret,
            "webhook_url": webhook_url,
            "is_active": True,
            "shopify_install_key_id": key_record["id"],
        }
        store_result = db.table("stores").insert(store_data).execute()

    # Mark key as used
    db.table("shopify_install_keys").update({
        "is_used": True,
        "linked_user_id": user["id"],
        "linked_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", key_record["id"]).execute()

    logger.info(f"✅ Store connected via key: {shop_domain} → user {user['id']} ({user.get('email', '')})")

    store = store_result.data[0] if store_result.data else {}
    store.pop("api_key_encrypted", None)
    store.pop("api_secret_encrypted", None)
    store.pop("access_token_encrypted", None)

    # For Shopify only: register ScriptTag + webhooks via Shopify plugin
    # WooCommerce chatbot injection is handled by the WP plugin itself (wp_enqueue_scripts)
    platform = key_record.get("platform") or "shopify"
    if platform == "shopify":
        plugin_url = settings.SHOPIFY_PLUGIN_URL.rstrip("/") if settings.SHOPIFY_PLUGIN_URL else ""
        if plugin_url:
            try:
                async with httpx.AsyncClient(timeout=15) as client:
                    await client.get(
                        f"{plugin_url}/setup/auto-register",
                        params={"shop": shop_domain, "token": settings.INTERNAL_API_TOKEN},
                    )
                logger.info(f"✅ ScriptTag + webhooks registered for {shop_domain} via plugin")
            except Exception as e:
                logger.warning(f"⚠️ ScriptTag auto-register failed (non-critical): {e}")
        else:
            logger.warning("⚠️ SHOPIFY_PLUGIN_URL not set — ScriptTag not registered. Set it in .env")

    # Ensure chatbot config exists and is enabled for this merchant
    try:
        chatbot_existing = db.table("merchant_chatbot_config").select("id, is_enabled").eq("merchant_id", user["id"]).execute()
        if not chatbot_existing.data:
            db.table("merchant_chatbot_config").insert({
                "merchant_id": user["id"],
                "is_enabled": True,
                "business_name": user.get("company_name", ""),
                "business_website": shop_domain,
            }).execute()
        elif not chatbot_existing.data[0].get("is_enabled"):
            db.table("merchant_chatbot_config").update({"is_enabled": True}).eq("merchant_id", user["id"]).execute()
        logger.info(f"✅ Chatbot config ensured enabled for {user['id']}")
    except Exception as e:
        logger.warning(f"⚠️ Chatbot config setup failed (non-critical): {e}")

    return success_response({
        "connected": True,
        "store": store,
        "shop_domain": shop_domain,
        "store_name": shop_name,
    }, "Shopify store connected successfully! Your orders will now sync automatically.")


@router.get("/connection-status")
async def get_connection_status(user: dict = Depends(get_current_merchant)):
    """Check if the current user has a Shopify store connected."""
    db = get_db()
    user_data = db.table("users").select("shopify_shop_domain, shopify_shop_id").eq("id", user["id"]).execute()
    
    if not user_data.data or not user_data.data[0].get("shopify_shop_domain"):
        return success_response({
            "is_connected": False,
            "shop_domain": None,
        }, "No Shopify store connected")

    shop_domain = user_data.data[0]["shopify_shop_domain"]
    
    # Get store details
    store_res = db.table("stores").select("id, store_name, is_active, total_orders, last_order_received_at, connected_at").eq("user_id", user["id"]).eq("platform", "shopify").execute()
    store = store_res.data[0] if store_res.data else None

    return success_response({
        "is_connected": True,
        "shop_domain": shop_domain,
        "store": store,
    }, "Shopify store is connected")

@router.post("/connect")
async def connect_store(body: ConnectStoreRequest, user: dict = Depends(get_current_merchant)):
    db = get_db()
    webhook_secret = str(uuid.uuid4())
    backend_url = settings.BACKEND_URL.rstrip('/')
    webhook_url = f"{backend_url}/api/v1/webhook/order/new"

    store_data = {
        "user_id": user["id"],
        "platform": body.platform.value,
        "store_url": body.store_url,
        "store_name": body.store_name or body.store_url,
        "api_key_encrypted": encrypt_value(body.api_key or ""),
        "api_secret_encrypted": encrypt_value(body.api_secret or ""),
        "access_token_encrypted": encrypt_value(body.access_token or ""),
        "webhook_secret": webhook_secret,
        "webhook_url": webhook_url,
    }
    result = db.table("stores").insert(store_data).execute()
    store = result.data[0]
    store.pop("api_key_encrypted", None)
    store.pop("api_secret_encrypted", None)
    store.pop("access_token_encrypted", None)
    return success_response({"store": store, "webhook_url": webhook_url, "webhook_secret": webhook_secret},
        "Store connected. Configure the webhook URL in your store settings.")

@router.put("/{store_id}")
async def update_store(store_id: str, body: UpdateStoreRequest, user: dict = Depends(get_current_merchant)):
    db = get_db()
    store = db.table("stores").select("id").eq("id", store_id).eq("user_id", user["id"]).execute()
    if not store.data:
        raise HTTPException(status_code=404, detail="Store not found")
    updates = body.model_dump(exclude_unset=True)
    if updates:
        db.table("stores").update(updates).eq("id", store_id).execute()
    return success_response(message="Store updated")

@router.delete("/{store_id}")
async def disconnect_store(store_id: str, user: dict = Depends(get_current_merchant)):
    db = get_db()
    store = db.table("stores").select("id, store_url, shopify_install_key_id, platform").eq("id", store_id).eq("user_id", user["id"]).execute()
    if not store.data:
        raise HTTPException(status_code=404, detail="Store not found")

    store_record = store.data[0]
    disconnected_url = store_record.get("store_url", "")

    # 1. Deactivate THIS specific store only
    db.table("stores").update({"is_active": False}).eq("id", store_id).execute()

    # 2. ── Multi-store fix: only clear users.shopify_shop_domain if NO other active Shopify stores remain ──
    if store_record.get("platform") == "shopify":
        remaining = db.table("stores").select("id").eq("user_id", user["id"]).eq("platform", "shopify").eq("is_active", True).neq("id", store_id).execute()
        if not remaining.data:
            # No other active Shopify stores — safe to clear the domain field
            db.table("users").update({
                "shopify_shop_domain": None,
                "shopify_shop_id": None,
            }).eq("id", user["id"]).execute()
        else:
            # Other active Shopify stores exist — update domain to one of them
            next_store = db.table("stores").select("store_url").eq("user_id", user["id"]).eq("platform", "shopify").eq("is_active", True).neq("id", store_id).limit(1).execute()
            if next_store.data:
                db.table("users").update({
                    "shopify_shop_domain": next_store.data[0]["store_url"],
                }).eq("id", user["id"]).execute()

    # 3. Reset the install key so merchant can reconnect with the same key
    if store_record.get("shopify_install_key_id"):
        db.table("shopify_install_keys").update({
            "is_used": False,
            "linked_user_id": None,
            "linked_at": None,
        }).eq("id", store_record["shopify_install_key_id"]).execute()

    logger.info(f"Store {store_id} ({disconnected_url}) disconnected by user {user['id']}")
    return success_response(message="Store disconnected")

@router.post("/{store_id}/test")
async def test_connection(store_id: str, user: dict = Depends(get_current_merchant)):
    db = get_db()
    store = db.table("stores").select("*").eq("id", store_id).eq("user_id", user["id"]).execute()
    if not store.data:
        raise HTTPException(status_code=404, detail="Store not found")
    return success_response({"connected": True, "platform": store.data[0].get("platform")}, "Store connection is active")
