from fastapi import APIRouter, Depends, HTTPException
from config.database import get_db
from middleware.auth import get_current_merchant
from middleware.contract import require_service
from models.merchant import CreateTemplateRequest
from utils.helpers import success_response

router = APIRouter(
    prefix="/api/v1/merchant/templates",
    tags=["Merchant Templates"],
    dependencies=[Depends(require_service("cod_verification"))]
)


@router.get("")
async def list_templates(user: dict = Depends(get_current_merchant)):
    db = get_db()
    result = db.table("message_templates").select("*").eq("user_id", user["id"]).order("created_at", desc=True).execute()
    return success_response(result.data or [])


@router.post("")
async def create_template(body: CreateTemplateRequest, user: dict = Depends(get_current_merchant)):
    db = get_db()
    data = {
        "user_id": user["id"],
        "template_name": body.template_name,
        "template_type": body.template_type,
        "template_body": body.template_body,
        "template_header": body.template_header,
        "template_footer": body.template_footer,
        "template_buttons_json": body.template_buttons_json,
        "template_language": body.template_language,
        "variables_json": body.variables_json,
        "approval_status": "pending",
    }
    result = db.table("message_templates").insert(data).execute()
    return success_response(result.data[0], "Template created and submitted for approval")


@router.get("/{template_id}")
async def get_template(template_id: str, user: dict = Depends(get_current_merchant)):
    db = get_db()
    result = db.table("message_templates").select("*").eq("id", template_id).eq("user_id", user["id"]).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Template not found")
    return success_response(result.data[0])


@router.delete("/{template_id}")
async def delete_template(template_id: str, user: dict = Depends(get_current_merchant)):
    db = get_db()
    result = db.table("message_templates").select("id").eq("id", template_id).eq("user_id", user["id"]).execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Template not found")
    db.table("message_templates").delete().eq("id", template_id).execute()
    return success_response(message="Template deleted")
