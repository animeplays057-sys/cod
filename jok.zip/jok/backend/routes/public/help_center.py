"""
Public Help Center API — endpoints for the standalone Help Center page.
Separate from the chatbot widget. Authenticated via api_key only.
All endpoints are merchant-scoped through api_key → merchant_id resolution.
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone
from config.database import get_db
import re as _re

router = APIRouter(prefix="/api/v1/help-center", tags=["Public Help Center"])


# ── Internal helpers ──────────────────────────────────────────────────

def _get_merchant_config(api_key: str) -> dict:
    """Resolve api_key → merchant config. Raises 403 if invalid."""
    db = get_db()
    result = db.table("merchant_chatbot_config").select("*").eq("api_key", api_key).execute()
    if not result.data:
        raise HTTPException(403, "Invalid API key")
    c = result.data[0]
    if not c.get("is_enabled"):
        raise HTTPException(403, "Help center is not enabled for this merchant")
    return c


def _lookup_order(merchant_id: str, order_number: str) -> Optional[dict]:
    """Find an order by number scoped to merchant. Returns None if not found."""
    db = get_db()
    # normalize: strip leading # or ORDER prefix
    norm = _re.sub(r'^[#\s]+', '', order_number.strip()).upper()
    result = db.table("orders").select(
        "id, order_number, customer_name, customer_email, customer_phone, "
        "delivery_status, fulfillment_status, tracking_number, tracking_company, "
        "tracking_url, order_amount, currency, created_at, delivery_updated_at, "
        "verification_status, notes, payment_method, order_type"
    ).eq("user_id", merchant_id).or_(
        f"order_number.eq.{norm},order_number.ilike.%{norm}%"
    ).limit(1).execute()
    return result.data[0] if result.data else None


def _verify_identity(order: dict, contact: str) -> bool:
    """Return True if contact (email or phone) matches order's customer info."""
    contact = contact.strip().lower()
    email = (order.get("customer_email") or "").strip().lower()
    phone_raw = (order.get("customer_phone") or "").strip()
    # normalize phone: digits only
    phone_digits = _re.sub(r'\D', '', phone_raw)[-10:]
    contact_digits = _re.sub(r'\D', '', contact)[-10:]

    if email and contact == email:
        return True
    if phone_digits and contact_digits and contact_digits == phone_digits:
        return True
    return False


def _format_order_for_help_center(order: dict, return_days: int, refund_days: int) -> dict:
    """Format order data with return/refund window flags for Help Center UI."""
    now = datetime.now(timezone.utc)
    created_raw = order.get("created_at")
    days_since = 999
    if created_raw:
        try:
            created_dt = datetime.fromisoformat(str(created_raw).replace("Z", "+00:00"))
            days_since = (now - created_dt).days
        except Exception:
            pass

    status_map = {
        "pending":           "Pending",
        "confirmed":         "Confirmed",
        "cancelled":         "Cancelled",
        "manual_confirmed":  "Confirmed",
        "manual_cancelled":  "Cancelled",
        "failed":            "Failed",
    }
    delivery_map = {
        "pending":     "Order Placed",
        "processing":  "Processing",
        "shipped":     "Shipped",
        "out_for_delivery": "Out for Delivery",
        "delivered":   "Delivered",
        "returned":    "Returned",
        "cancelled":   "Cancelled",
        "failed":      "Failed Delivery",
    }

    return {
        "order_number":        order.get("order_number", ""),
        "customer_name":       order.get("customer_name", ""),
        "customer_email":      order.get("customer_email", ""),
        "order_amount":        order.get("order_amount"),
        "currency":            order.get("currency", "INR"),
        "payment_method":      order.get("payment_method", ""),
        "order_type":          order.get("order_type", ""),
        "status":              status_map.get(order.get("verification_status", ""), order.get("verification_status", "")),
        "delivery_status":     delivery_map.get(order.get("delivery_status", ""), order.get("delivery_status", "")),
        "delivery_status_raw": order.get("delivery_status", ""),
        "fulfillment_status":  order.get("fulfillment_status", ""),
        "tracking_number":     order.get("tracking_number") or "",
        "tracking_company":    order.get("tracking_company") or "",
        "tracking_url":        order.get("tracking_url") or "",
        "created_at":          order.get("created_at"),
        "delivery_updated_at": order.get("delivery_updated_at"),
        "days_since_order":    days_since,
        "within_return_window": days_since <= return_days,
        "within_refund_window": days_since <= refund_days,
        "return_policy_days":  return_days,
        "refund_policy_days":  refund_days,
    }


# ── Endpoints ─────────────────────────────────────────────────────────


@router.get("/config")
async def get_help_center_config(api_key: str):
    """
    Return branding + FAQ + policy data for the Help Center page.
    Called immediately on Help Center page load.
    """
    config = _get_merchant_config(api_key)
    return {
        "success": True,
        "data": {
            "business_name":   config.get("business_name", ""),
            "bot_name":        config.get("bot_name", "Support"),
            "primary_color":   config.get("primary_color", "#6366f1"),
            "logo_url":        config.get("logo_url") or config.get("bot_avatar_url") or "",
            "widget_theme":    config.get("widget_theme", "light"),
            "font_family":     config.get("font_family", "Inter"),
            "business_faq":    config.get("business_faq") or "",
            "shipping_info":   config.get("shipping_info") or "",
            "return_policy":   config.get("return_policy") or "",
            "contact_info":    config.get("contact_info") or "",
            "business_website":config.get("business_website") or "",
            "return_policy_days": int(config.get("return_policy_days") or 7),
            "refund_policy_days": int(config.get("refund_policy_days") or 7),
            # ── Return / Exchange config ──────────────────────────────────
            # return_enabled: show the "Return" option
            "return_enabled":  config.get("help_center_return_enabled", True),
            # exchange_enabled: show the "Exchange" option
            "exchange_enabled": config.get("help_center_exchange_enabled", True),
            # exchange_options: list of {label, type, choices[]}
            # type: "select" | "text" | "none"
            # If empty/null → no extra field shown for exchange
            # Examples:
            #   clothes store: [{"label":"Size","type":"select","choices":["XS","S","M","L","XL","XXL"]}]
            #   color variant: [{"label":"Color","type":"select","choices":["Red","Blue","Green"]}]
            #   food/no-variant: [] (empty → just reason field, no extra options)
            "exchange_options": config.get("help_center_exchange_options") or [],
        }
    }



class TrackOrderBody(BaseModel):
    api_key: str
    order_number: str
    contact: str   # email OR phone — either accepted


@router.post("/track")
async def track_order(body: TrackOrderBody):
    """
    Track an order by order number + contact (email or phone).
    Returns full order status with tracking info and return window flags.
    """
    config = _get_merchant_config(body.api_key)
    merchant_id = config.get("merchant_id")
    return_days = int(config.get("return_policy_days") or 7)
    refund_days = int(config.get("refund_policy_days") or 7)

    if not body.order_number.strip():
        raise HTTPException(400, "Order number is required")
    if not body.contact.strip():
        raise HTTPException(400, "Email or phone is required for verification")

    order = _lookup_order(merchant_id, body.order_number)
    if not order:
        return {
            "success": False,
            "error": "not_found",
            "message": f"No order found with number '{body.order_number}'. Please check and try again."
        }

    if not _verify_identity(order, body.contact):
        return {
            "success": False,
            "error": "verification_failed",
            "message": "The contact details provided do not match the records for this order. Please check your email or phone number."
        }

    return {
        "success": True,
        "data": {
            "order": _format_order_for_help_center(order, return_days, refund_days)
        }
    }


class SubmitReturnBody(BaseModel):
    api_key: str
    order_number: str
    contact: str          # email or phone for identity
    request_type: str     # 'return' | 'exchange' | 'refund'
    reason: str
    exchange_size: Optional[str] = None
    customer_name: Optional[str] = None


@router.post("/return")
async def submit_return(body: SubmitReturnBody):
    """
    Submit a return/exchange/refund request from the Help Center page.
    Verifies order identity before accepting. Writes to return_requests table.
    """
    config = _get_merchant_config(body.api_key)
    merchant_id = config.get("merchant_id")

    if body.request_type not in ("return", "exchange", "refund"):
        raise HTTPException(400, "request_type must be 'return', 'exchange', or 'refund'")

    if not body.order_number.strip():
        raise HTTPException(400, "Order number is required")

    if not body.contact.strip():
        raise HTTPException(400, "Email or phone is required")

    # Verify order ownership
    order = _lookup_order(merchant_id, body.order_number)
    if not order:
        return {
            "success": False,
            "error": "not_found",
            "message": f"No order found with number '{body.order_number}'."
        }

    if not _verify_identity(order, body.contact):
        return {
            "success": False,
            "error": "verification_failed",
            "message": "Contact details do not match this order."
        }

    # Check return window
    return_days = int(config.get("return_policy_days") or 7)
    now = datetime.now(timezone.utc)
    created_raw = order.get("created_at")
    if created_raw:
        try:
            created_dt = datetime.fromisoformat(str(created_raw).replace("Z", "+00:00"))
            days_since = (now - created_dt).days
            if days_since > return_days:
                return {
                    "success": False,
                    "error": "window_expired",
                    "message": f"Return/exchange window has expired. Orders can only be returned within {return_days} days of placement."
                }
        except Exception:
            pass

    db = get_db()
    customer_name = body.customer_name or order.get("customer_name") or "Customer"
    # resolve email/phone from order
    customer_email = order.get("customer_email") or ""
    customer_phone = order.get("customer_phone") or ""

    # Build insert payload — only columns that exist in return_requests table
    return_data = {
        "merchant_id":     merchant_id,
        "order_number":    body.order_number,
        "request_type":    body.request_type,
        "reason":          body.reason,
        "status":          "pending",
        "customer_name":   customer_name,
        "customer_email":  customer_email,
        "customer_phone":  customer_phone,
        "order_amount":    order.get("order_amount"),
        "delivery_status": order.get("delivery_status") or "",
    }
    # Add optional columns only if they exist — avoids schema cache errors
    if body.exchange_size:
        return_data["notes"] = f"Exchange size: {body.exchange_size}"
    db.table("return_requests").insert(return_data).execute()

    # ── WhatsApp: notify customer ─────────────────────────────────────────
    customer_phone_normalized = order.get("customer_phone_normalized") or customer_phone
    if customer_phone_normalized:
        try:
            from services.whatsapp_service import send_return_received_customer
            from services import wallet_service as _ws
            from config.service_pricing import get_price as _gp
            store_name = config.get("business_name") or "Our Store"
            _cust_ok = await send_return_received_customer(
                customer_phone=customer_phone_normalized,
                customer_name=customer_name,
                order_number=body.order_number,
                request_type=body.request_type,
                store_name=store_name,
            )
            # ── Debit merchant wallet for customer WA ──────────────────
            if _cust_ok:
                _charge_cust = _gp("return_wa_notification")  # ✅ Correct key (was: return_new_request_wa)
                if _charge_cust > 0:
                    await _ws.debit_wallet(
                        db,
                        user_id=merchant_id,
                        amount=_charge_cust,
                        service_key="return_new_request_wa",
                        description=f"New {body.request_type} request WA to customer — #{body.order_number}",
                        reference_id=body.order_number,
                    )
        except Exception as _wa_err:
            pass  # non-critical

    # ── WhatsApp: alert merchant ──────────────────────────────────────────
    try:
        from services.whatsapp_service import send_return_alert_merchant
        from services import wallet_service as _ws2
        from config.service_pricing import get_price as _gp2
        from config.database import get_db as _gdb
        _db2 = _gdb()
        _merchant = _db2.table("users").select("phone, name, company_name").eq("id", merchant_id).execute()
        if _merchant.data and _merchant.data[0].get("phone"):
            _m = _merchant.data[0]
            _merch_ok = await send_return_alert_merchant(
                merchant_phone=_m["phone"],
                merchant_name=_m.get("company_name") or _m.get("name") or "Merchant",
                customer_name=customer_name,
                order_number=body.order_number,
                request_type=body.request_type,
                reason=body.reason,
            )
            # ── Debit merchant wallet for merchant alert WA ────────────
            if _merch_ok:
                _charge_merch = _gp2("return_merchant_alert")  # ✅ Correct key (was: return_merchant_alert_wa)
                if _charge_merch > 0:
                    await _ws2.debit_wallet(
                        db,
                        user_id=merchant_id,
                        amount=_charge_merch,
                        service_key="return_merchant_alert_wa",
                        description=f"New {body.request_type} alert WA to merchant — #{body.order_number}",
                        reference_id=body.order_number,
                    )
    except Exception:
        pass  # non-critical

    # Notify merchant in dashboard (non-critical)
    try:
        from services.notification_service import create_notification
        icon = "↩️" if body.request_type == "return" else ("🔄" if body.request_type == "exchange" else "💰")
        size_info = f" | Size: {body.exchange_size}" if body.exchange_size else ""
        await create_notification(
            merchant_id,
            f"{icon} New {body.request_type.title()} Request — Order #{body.order_number}",
            f"Customer: {customer_name} | Reason: {body.reason[:80]}{size_info}",
            "warning", "returns", None
        )
    except Exception:
        pass

    label = body.request_type.title()
    return {
        "success": True,
        "data": {
            "message": f"Your {label} request for Order #{body.order_number} has been submitted successfully. Our team will review it within 1–2 business days."
        }
    }


class CallbackBody(BaseModel):
    api_key: str
    visitor_name: str
    visitor_phone: str
    visitor_email: Optional[str] = None
    reason: Optional[str] = None


@router.post("/callback")
async def request_callback(body: CallbackBody):
    """
    Submit a callback request from the Help Center page.
    Assigns to best available worker. Notifies them.
    """
    import random
    config = _get_merchant_config(body.api_key)
    merchant_id = config.get("merchant_id")

    db = get_db()

    callback_data = {
        "merchant_id":   merchant_id,
        "visitor_name":  body.visitor_name,
        "visitor_phone": body.visitor_phone,
        "visitor_email": body.visitor_email or "",
        "reason":        body.reason or "",
        "status":        "pending",
        "source":        "help_center",
    }

    # Assign to online worker or any worker
    from datetime import timedelta
    cutoff = (datetime.now(timezone.utc) - timedelta(minutes=2)).isoformat()
    active = db.table("users").select("id").eq("role", "worker").eq(
        "duty_status", "on_duty"
    ).gte("last_heartbeat", cutoff).execute()

    pool = active.data if active.data else []
    if not pool:
        all_w = db.table("users").select("id").eq("role", "worker").execute()
        pool = all_w.data or []

    if pool:
        callback_data["assigned_worker_id"] = random.choice(pool)["id"]

    db.table("callback_requests").insert(callback_data).execute()

    if callback_data.get("assigned_worker_id"):
        try:
            from services.notification_service import create_notification
            await create_notification(
                callback_data["assigned_worker_id"],
                f"📞 Callback Request from {body.visitor_name}",
                f"Phone: {body.visitor_phone} | Reason: {(body.reason or 'Not specified')[:100]}",
                "info", "callbacks", None
            )
        except Exception:
            pass

    return {
        "success": True,
        "data": {
            "message": "Thank you! Your callback request has been submitted. Our team will call you back shortly."
        }
    }
