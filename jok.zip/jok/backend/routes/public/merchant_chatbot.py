"""Public merchant chatbot API — embeddable widget endpoints.
Rate-limited per merchant, with merchant-specific AI context.
"""
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone, timedelta
from config.database import get_db
from services.groq_service import get_merchant_ai_response, get_merchant_ai_with_order_data
import json
import random
import re

router = APIRouter(prefix="/api/v1/merchant-chat", tags=["Public Merchant Chatbot"])


class MerchantStartChatBody(BaseModel):
    api_key: str
    visitor_name: Optional[str] = "Visitor"
    visitor_email: Optional[str] = None
    message: str
    page_url: Optional[str] = None
    page_title: Optional[str] = None


class MerchantMessageBody(BaseModel):
    api_key: str
    message: str


class MerchantOfflineCallbackBody(BaseModel):
    api_key: str
    visitor_name: str
    visitor_phone: str
    visitor_email: Optional[str] = None
    reason: Optional[str] = None
    message: Optional[str] = None


class MerchantCallbackRequestBody(BaseModel):
    api_key: str
    visitor_name: str
    visitor_phone: str
    visitor_email: Optional[str] = None
    reason: Optional[str] = None


def _get_merchant_config(api_key: str):
    """Validate API key and get merchant chatbot config."""
    db = get_db()
    config = db.table("merchant_chatbot_config").select("*").eq("api_key", api_key).execute()
    if not config.data:
        raise HTTPException(403, "Invalid API key")
    c = config.data[0]
    if not c.get("is_enabled"):
        raise HTTPException(403, "Chatbot is not enabled for this merchant")
    return c


def _check_rate_limit(merchant_id: str, config: dict):
    """Check if merchant has exceeded monthly request limit."""
    limit = config.get("monthly_request_limit", 100)
    used = config.get("current_month_usage", 0)

    # Reset counter if past reset date
    reset_date = config.get("usage_reset_date")
    now = datetime.now(timezone.utc)
    if reset_date:
        try:
            rd = datetime.fromisoformat(str(reset_date).replace("Z", "+00:00"))
            if now >= rd:
                db = get_db()
                next_reset = (now.replace(day=1) + timedelta(days=32)).replace(day=1)
                db.table("merchant_chatbot_config").update({
                    "current_month_usage": 0,
                    "usage_reset_date": next_reset.isoformat(),
                }).eq("merchant_id", merchant_id).execute()
                # Fix Bug 3: update local config so limit check below uses fresh value
                config["current_month_usage"] = 0
                used = 0
        except Exception:
            pass
    else:
        # NULL reset_date: set it now so reset works in future
        try:
            db = get_db()
            next_reset = (now.replace(day=1) + timedelta(days=32)).replace(day=1)
            db.table("merchant_chatbot_config").update({
                "usage_reset_date": next_reset.isoformat(),
            }).eq("merchant_id", merchant_id).execute()
        except Exception:
            pass

    if used >= limit:
        raise HTTPException(429, f"Monthly chatbot request limit reached ({limit} requests). Contact support to increase.")



def _is_working_hours() -> bool:
    """Check if current time is within working hours: 8AM–8PM IST, Mon–Sat.
    IST = UTC+5:30. Uses stdlib only (no pytz dependency).
    """
    ist_offset = timedelta(hours=5, minutes=30)
    now_ist = datetime.now(timezone.utc) + ist_offset
    # Monday=0, Sunday=6 — skip Sunday only; Mon-Sat is 0-5
    if now_ist.weekday() == 6:  # Sunday
        return False
    return 8 <= now_ist.hour < 20


def _get_active_workers(db):
    """Find on-duty workers with fresh heartbeat (last 2 minutes)."""
    cutoff = (datetime.now(timezone.utc) - timedelta(minutes=2)).isoformat()
    workers = db.table("users").select("id, name, duty_status, last_heartbeat").eq(
        "role", "worker"
    ).eq("duty_status", "on_duty").gte("last_heartbeat", cutoff).execute()
    return workers.data or []


def _pick_best_worker(db, active_workers):
    """Pick the worker with the least number of active chats."""
    if not active_workers:
        return None

    worker_ids = [w["id"] for w in active_workers]
    # Count active chats for each worker
    active_chats_count: dict = {}
    for worker_id in worker_ids:
        count_res = db.table("chat_sessions").select("id", count="exact").eq(
            "assigned_worker_id", worker_id
        ).in_("status", ["waiting_human", "human_active"]).execute()
        active_chats_count[worker_id] = count_res.count if count_res.count else 0

    # Find worker with minimum active chats
    best_worker_id = min(active_chats_count, key=lambda k: active_chats_count[k])
    return next((w for w in active_workers if w["id"] == best_worker_id), None)


def _increment_usage(merchant_id: str, session_id: Optional[str] = None, request_type: str = "chat", visitor_ip: str = ""):
    """Increment usage counter and log the request."""
    db = get_db()
    # Increment counter
    db.rpc("increment_chatbot_usage", {"p_merchant_id": merchant_id}).execute()
    # Log the request
    db.table("chatbot_api_usage").insert({
        "merchant_id": merchant_id,
        "session_id": session_id,
        "request_type": request_type,
        "visitor_ip": visitor_ip,
    }).execute()


def _build_merchant_system_prompt(config: dict) -> str:
    """Build a merchant-specific system prompt from their config."""
    biz = config.get("business_name", "this business")
    desc = config.get("business_description", "")
    services = config.get("business_services", "")
    faq = config.get("business_faq", "")
    website = config.get("business_website", "")
    tier = config.get("chatbot_tier", "chatbot_full")
    contact_info = config.get("contact_info", "")
    shipping_info = config.get("shipping_info", "")
    return_policy = config.get("return_policy", "")

    if tier == "chatbot_ai":
        handoff_rule = (
            "You are the ONLY support available. If you cannot resolve something, "
            "apologize and direct the customer to the website or email. "
            "NEVER output [HANDOFF_REQUESTED]."
        )
    else:
        handoff_rule = (
            "Try your best to resolve the issue. Only if truly stuck or customer explicitly "
            "asks for a human agent, output exactly: [HANDOFF_REQUESTED]"
        )

    prompt = f"""You are the AI support assistant for {biz}. You ONLY help with {biz}-related topics.

About {biz}:
{desc}

{f'Products/Services:{chr(10)}{services}' if services else ''}
{f'Website: {website}' if website else ''}
{f'Contact Information: {contact_info}' if contact_info else ''}
{f'Shipping Policy: {shipping_info}' if shipping_info else ''}
{f'Return/Refund Policy: {return_policy}' if return_policy else ''}
{f'FAQ:{chr(10)}{faq}' if faq else ''}

{handoff_rule}

== ORDER STATUS ==
You can help customers check their order status. Follow this process:

1. If a customer asks about an order but has NOT given an order number — ask for it.
2. If a customer gives an order number but has NOT given their email/phone — ask for their registered email or phone number for identity verification.
3. If the customer provides their contact info (email/phone), say: "Let me verify and check your order status." The system will automatically look up the order and I will share the result.
4. When you see "VERIFIED ORDER DATA" in this conversation — that is real verified data. Use it to answer the customer naturally.

DO NOT make up or guess order status. Only report what appears in VERIFIED ORDER DATA.
After showing order details, answer follow-up questions (dispatch time, delivery estimate, etc.) using the verified data you already have.

== PRODUCT BROWSING ==
When the customer EXPLICITLY asks to SEE, VIEW, or BROWSE products (do NOT show products if they just say purely greetings like "hi" or general questions):

CRITICAL RULE: If and ONLY IF they explicitly ask to see products, output ONLY the signal below at the end of your response. Do NOT output this for general greetings. Do NOT describe any products in text.

For ALL stores: Respond with ONE short sentence, then on the SAME line:
[SHOW_PRODUCTS]

If the store clearly has many distinct categories (5+): ask which category, then:
[ASK_CATEGORY:Cat1,Cat2,Cat3,Cat4]

EXAMPLE CORRECT outputs:
  "Sure! Here are our products 😊 [SHOW_PRODUCTS]"
  "Which category? [ASK_CATEGORY:Kurta,Saree,Jewellery]"

WRONG (NEVER DO THIS):
  X Describing product names, prices, or details in your response text
  X Writing a list of products
  X Saying what products are available without the signal

== LANGUAGE ==
- First message: English
- After that: match customer's language (Hindi/Hinglish/English)

== RULES ==
- Only discuss {biz} topics
- No markdown bold in responses
- Keep responses concise and professional

"""
    return prompt



# =======================================================
#  ORDER TRACKING HELPERS
# =======================================================

_TRACKING_PHRASES = [
    # Must have order-specific context
    "order status", "order id", "order number", "order no", "order #",
    "where is my order", "where is my package", "track my order",
    "delivery status", "shipment status", "out for delivery",
    "tracking number", "awb number", "waybill",
    # Hinglish — clear order references
    "mera order", "mera parcel", "order kahan", "order kab",
    "order ka status", "delivery kab", "kab aayega", "kab milega",
    "track karo", "status batao", "status bata",
    "shipped hua", "nikal gaya", "deliver hua",
]

# These ALONE (without a clear order context phrase) signal tracking
_TRACKING_WITH_NUMBER = [
    "track", "tracking", "shipment", "shipped", "dispatch",
    "courier", "docket", "waybill", "parcel",
]

# Patterns to extract an order number — MUST exclude phone numbers (10+ digits)
_ORDER_NUM_PATTERNS = [
    r'#([A-Za-z0-9]+)',                              # #1234 or #ORD123
    r'order[:\s#-]+([A-Za-z0-9]{2,10})\b',          # order: 1234 (max 10 chars)
    r'(?:order[_\s-]?(?:id|no|number|num)[:\s#-]+)([A-Za-z0-9]{2,10})\b',
    r'\b([A-Z]{1,4}\d{3,8})\b',                    # SHP1234, ORD12345 (max 8 total digits)
    r'\b(\d{3,7})\b',                               # 3-7 digit plain numbers ONLY (avoids 10-digit phones)
]


def _is_tracking_intent(message: str) -> bool:
    """Return True only if message clearly references order tracking.
    Requires either a direct tracking phrase, OR a tracking keyword + order number present.
    """
    msg = message.lower()
    # Direct phrase match (strong signal)
    if any(ph in msg for ph in _TRACKING_PHRASES):
        return True
    # Weaker keywords only count if an order number pattern is also present
    if any(kw in msg for kw in _TRACKING_WITH_NUMBER):
        return _extract_order_number(message) is not None
    return False


def _extract_order_number(message: str) -> Optional[str]:
    """Extract order number. Explicitly avoids phone numbers (10+ digits)."""
    for pat in _ORDER_NUM_PATTERNS:
        m = re.search(pat, message, re.IGNORECASE)
        if m:
            val = m.group(1).strip().lstrip('#')
            # Reject if it looks like a phone number (all digits, 9+ chars)
            if val and not (val.isdigit() and len(val) >= 9):
                return val
    return None


def _extract_contact_identifier(message: str) -> Optional[str]:
    """Extract email address or phone number from a message."""
    # Email pattern
    email_match = re.search(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}', message)
    if email_match:
        return email_match.group(0).lower()
    # Phone - strip spaces/dashes, 10-13 digits
    phone_match = re.search(r'(?:\+?91[\s\-]?)?([6-9]\d{9})|(?:\+?\d{1,3}[\s\-]?)?\d{10,12}', message)
    if phone_match:
        digits = re.sub(r'\D', '', phone_match.group(0))
        return digits
    return None


def _lookup_order(merchant_id: str, order_number: str) -> Optional[dict]:
    """Fetch order from DB. Includes customer contact fields for verification."""
    db = get_db()
    result = db.table("orders").select(
        "order_number, customer_name, customer_email, customer_phone, "
        "customer_phone_normalized, delivery_status, fulfillment_status, "
        "tracking_number, tracking_company, tracking_url, order_amount, "
        "currency, created_at, delivery_updated_at"
    ).eq("user_id", merchant_id).ilike(
        "order_number", f"%{order_number}%"
    ).order("created_at", desc=True).limit(1).execute()
    return result.data[0] if result.data else None


def _verify_order_identity(order: dict, identifier: str) -> bool:
    """Return True if the provided email/phone matches the order's customer."""
    ident = identifier.lower().strip()

    # Check email
    stored_email = (order.get("customer_email") or "").lower().strip()
    if stored_email and ident == stored_email:
        return True

    # Check phone — compare digits only
    ident_digits = re.sub(r'\D', '', ident)
    for phone_field in ["customer_phone", "customer_phone_normalized"]:
        stored = re.sub(r'\D', '', order.get(phone_field) or "")
        if stored and ident_digits and (
            stored == ident_digits
            or stored.endswith(ident_digits[-10:])
            or ident_digits.endswith(stored[-10:])
        ):
            return True
    return False


def _format_order_response(order: dict) -> str:
    """Format order details as plain professional text — no emojis, no markdown bold."""
    STATUS_LABELS = {
        "pending":          "Pending - not yet dispatched",
        "shipped":          "Shipped",
        "in_transit":       "In Transit",
        "out_for_delivery": "Out for Delivery",
        "delivered":        "Delivered",
        "returned":         "Returned",
        "cancelled":        "Cancelled",
    }
    ds = (order.get("delivery_status") or "pending").lower()
    status_label = STATUS_LABELS.get(ds, ds.replace("_", " ").title())

    lines = [
        f"Order #{order.get('order_number', 'N/A')} details:",
        f"Status: {status_label}",
    ]

    if order.get("customer_name"):
        lines.append(f"Customer: {order['customer_name']}")

    if order.get("tracking_company"):
        lines.append(f"Courier: {order['tracking_company']}")

    if order.get("tracking_number"):
        lines.append(f"Tracking No: {order['tracking_number']}")

    if order.get("tracking_url"):
        lines.append(f"Track here: {order['tracking_url']}")

    if ds == "pending":
        lines.append("Your order has been received and is being processed. It has not been dispatched yet.")
    elif ds == "delivered":
        updated = order.get("delivery_updated_at") or order.get("created_at") or ""
        if updated:
            try:
                dt = datetime.fromisoformat(str(updated).replace("Z", "+00:00"))
                ist = dt + timedelta(hours=5, minutes=30)
                lines.append(f"Delivered on: {ist.strftime('%d %b %Y at %I:%M %p IST')}")
            except Exception:
                pass

    lines.append("\nIs there anything else I can help you with?")
    return "\n".join(lines)


def _check_recent_order_number(history: list) -> Optional[str]:
    """Scan last 4 visitor messages for an order number."""
    visitor_msgs = [
        m["message"] for m in history
        if m.get("sender_type") == "visitor"
    ][-4:]
    for msg in reversed(visitor_msgs):
        num = _extract_order_number(msg)
        if num:
            return num
    return None


def _was_bot_asking_for_order_number(history: list) -> bool:
    """Check if the bot's last message was asking for an order number."""
    bot_msgs = [
        m["message"] for m in history
        if m.get("sender_type") in ("ai", "system")
    ]
    if not bot_msgs:
        return False
    last = bot_msgs[-1].lower()
    return any(kw in last for kw in ["order number", "order id", "order no", "order #",
                                      "order numb", "apna order", "batao", "share"])


def _was_order_just_shown(history: list) -> bool:
    """Check if the bot's last substantive message was an order details response."""
    bot_msgs = [
        m["message"] for m in history
        if m.get("sender_type") in ("ai", "system")
    ]
    if not bot_msgs:
        return False
    last = bot_msgs[-1].lower()
    return "order #" in last and "status:" in last


def _was_bot_asking_for_verification(history: list) -> bool:
    """Check if the bot's last message was asking for email/phone verification."""
    bot_msgs = [
        m["message"] for m in history
        if m.get("sender_type") in ("ai", "system")
    ]
    if not bot_msgs:
        return False
    last = bot_msgs[-1].lower()
    return any(kw in last for kw in [
        "email address", "phone number", "registered email", "registered phone",
        "verify your identity", "verification", "email or phone", "email id"
    ])


def _find_pending_order_number_in_history(history: list) -> Optional[str]:
    """Find the order number from recent bot messages only (avoids phone number false-positives)."""
    for m in reversed(history):
        if m.get("sender_type") in ("ai", "system"):
            msg = m.get("message", "")
            # Only look for explicit #XXXX pattern in bot messages
            m2 = re.search(r'order\s*#([A-Za-z0-9]{1,10})\b', msg, re.IGNORECASE)
            if m2:
                val = m2.group(1).strip()
                if val and not (val.isdigit() and len(val) >= 9):
                    return val
    return None


def _extract_contact_from_message(message: str) -> Optional[str]:
    """Extract email OR Indian phone number from a user message.
    Returns the raw matched string (digits stripped for phone), or None.
    """
    import re as _re
    # Email
    m = _re.search(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}', message)
    if m:
        return m.group(0).lower().strip()
    # Indian phone: optional +91 prefix, then 10 digits starting 6-9
    # Strip whitespace/dashes first to handle "98765 43210" style
    digits_only = _re.sub(r'[\s\-]', '', message)
    m = _re.search(r'(?:\+?91)?([6-9]\d{9})\b', digits_only)
    if m:
        return m.group(1)  # 10-digit normalized phone
    return None


def _find_order_in_history(history: list) -> Optional[str]:
    """Scan recent chat history for an explicitly mentioned order number.
    Catches: 'order 1022', '#1022', 'order #1022', 'order status 1022',
    'order check 1022', 'check order 1022', and any standalone 3-7 digit
    number. Never matches 10+ digit numbers (phones).
    """
    import re as _re
    # Patterns in priority order — most specific first
    patterns = [
        r'order\s*[\w\s]{0,20}?#?\s*(\d{3,8})\b',  # order <any words> 1022
        r'#(\d{3,8})\b',                               # #1022
        r'\b(\d{3,7})\b',                              # plain 3-7 digit number
    ]
    # Scan last 10 messages (both visitor and bot)
    for msg in reversed(history[-10:]):
        text = msg.get("message", "")
        for pat in patterns:
            m = _re.search(pat, text, _re.IGNORECASE)
            if m:
                val = m.group(1)
                # Reject if length >= 9 (phone-like) or all zeros
                if val and len(val) < 9 and val != '0' * len(val):
                    return val
    return None


def _process_order_signal(merchant_id: str, order_num: str, contact: str) -> str:
    """Look up and verify order identity. Returns a plain-text result string."""
    order = _lookup_order(merchant_id, order_num)
    if not order:
        return f"ORDER NOT FOUND: No order with number {order_num} was found."
    if not _verify_order_identity(order, contact):
        return (
            f"VERIFICATION FAILED: The contact details provided ({contact}) "
            f"do not match the records for order {order_num}. "
            "Please double-check and try again."
        )
    return _format_order_response(order)


@router.get("/config/{api_key}")
async def get_widget_config(api_key: str):
    """Get chatbot config for widget initialization (public, no auth)."""
    config = _get_merchant_config(api_key)
    # Return only public-safe fields
    menu_options = config.get("menu_options") or []
    if isinstance(menu_options, str):
        try:
            menu_options = json.loads(menu_options)
        except Exception:
            menu_options = []

    return {
        "success": True,
        "data": {
            "bot_name": config.get("bot_name", "Support Bot"),
            "welcome_message": config.get("welcome_message", "Hi! 👋 How can I help you today?"),
            "primary_color": config.get("primary_color", "#6366f1"),
            "menu_options": menu_options,
            "business_name": config.get("business_name", ""),
            "chatbot_tier": config.get("chatbot_tier", "chatbot_basic"),
            "widget_theme": config.get("widget_theme", "dark"),
            "bot_avatar_url": config.get("bot_avatar_url", ""),
            "logo_url": config.get("logo_url") or config.get("bot_avatar_url", ""),
            "font_family": config.get("font_family", "Inter"),
        }
    }


@router.get("/config-by-shop")
async def get_widget_config_by_shop(shop_domain: str):
    """Get chatbot config by shop domain — used by Shopify embed script.
    Looks up the merchant via shopify_shop_domain or business_website in users table,
    then fetches their chatbot config.
    """
    db = get_db()
    # Find user by shopify_shop_domain
    user_res = db.table("users").select("id").eq("shopify_shop_domain", shop_domain).execute()
    if not user_res.data:
        # Fallback 1: look up merchant via WooCommerce store URL in stores table
        clean_domain = shop_domain.replace("https://", "").replace("http://", "").rstrip("/")
        wc_store_res = db.table("stores").select("user_id").eq("store_url", clean_domain).eq("platform", "woocommerce").eq("is_active", True).limit(1).execute()
        if wc_store_res.data:
            user_id = wc_store_res.data[0]["user_id"]
            config_res = db.table("merchant_chatbot_config").select("*").eq("merchant_id", user_id).execute()
            if config_res.data and config_res.data[0].get("is_enabled"):
                config = config_res.data[0]
                menu_options = config.get("menu_options") or []
                if isinstance(menu_options, str):
                    try:
                        menu_options = json.loads(menu_options)
                    except Exception:
                        menu_options = []
                return {
                    "success": True,
                    "data": {
                        "enabled": True,
                        "merchant_id": user_id,
                        "api_key": config.get("api_key", ""),
                        "bot_name": config.get("bot_name", "Support Bot"),
                        "welcome_message": config.get("welcome_message", "Hi! 👋 How can I help you today?"),
                        "primary_color": config.get("primary_color", "#6366f1"),
                        "menu_options": menu_options,
                        "business_name": config.get("business_name", ""),
                        "chatbot_tier": config.get("chatbot_tier", "chatbot_basic"),
                        "widget_theme": config.get("widget_theme", "dark"),
                        "bot_avatar_url": config.get("bot_avatar_url", ""),
                        "logo_url": config.get("logo_url") or config.get("bot_avatar_url", ""),
                    }
                }

        # Fallback 2: look up merchant by business_website in chatbot config
        config_res = db.table("merchant_chatbot_config").select("merchant_id").ilike(
            "business_website", f"%{clean_domain}%"
        ).eq("is_enabled", True).limit(1).execute()
        if config_res.data:
            # Return config directly since we already have merchant_id
            config = db.table("merchant_chatbot_config").select("*").eq(
                "merchant_id", config_res.data[0]["merchant_id"]
            ).single().execute()
            if config.data and config.data.get("is_enabled"):
                menu_options = config.data.get("menu_options") or []
                if isinstance(menu_options, str):
                    try:
                        menu_options = json.loads(menu_options)
                    except Exception:
                        menu_options = []
                return {
                    "success": True,
                    "data": {
                        "enabled": True,
                        "api_key": config.data["api_key"],
                        "bot_name": config.data.get("bot_name", "Support Bot"),
                        "welcome_message": config.data.get("welcome_message", "Hi! How can I help?"),
                        "primary_color": config.data.get("primary_color", "#6366f1"),
                        "bot_avatar_url": config.data.get("bot_avatar_url", ""),
                        "logo_url": config.data.get("logo_url") or config.data.get("bot_avatar_url", ""),
                        "menu_options": menu_options,
                        "business_name": config.data.get("business_name", ""),
                        "chatbot_tier": config.data.get("chatbot_tier", "chatbot_basic"),
                        "widget_theme": config.data.get("widget_theme", "dark"),
                    }
                }
        return {"success": False, "data": {"enabled": False}}
    if not user_res.data:
        return {"success": False, "data": {"enabled": False}}

    user_id = user_res.data[0]["id"]
    config_res = db.table("merchant_chatbot_config").select("*").eq("merchant_id", user_id).execute()
    if not config_res.data:
        return {"success": False, "data": {"enabled": False}}

    config = config_res.data[0]
    if not config.get("is_enabled"):
        return {"success": True, "data": {"enabled": False}}

    menu_options = config.get("menu_options") or []
    if isinstance(menu_options, str):
        try:
            menu_options = json.loads(menu_options)
        except Exception:
            menu_options = []

    return {
        "success": True,
        "data": {
            "enabled": True,
            "merchant_id": user_id,
            "api_key": config.get("api_key", ""),
            "bot_name": config.get("bot_name", "Support Bot"),
            "welcome_message": config.get("welcome_message", "Hi! 👋 How can I help you today?"),
            "primary_color": config.get("primary_color", "#6366f1"),
            "menu_options": menu_options,
            "business_name": config.get("business_name", ""),
            "chatbot_tier": config.get("chatbot_tier", "chatbot_basic"),
            "widget_theme": config.get("widget_theme", "dark"),
            "bot_avatar_url": config.get("bot_avatar_url", ""),
            "logo_url": config.get("logo_url") or config.get("bot_avatar_url", ""),
        }
    }


@router.post("/start")
async def start_merchant_chat(body: MerchantStartChatBody, request: Request):
    """Start a new chat session on merchant's website."""
    config = _get_merchant_config(body.api_key)
    merchant_id = config.get("merchant_id")
    _check_rate_limit(merchant_id, config)

    db = get_db()
    visitor_ip = request.client.host if request.client else ""
    chatbot_tier = config.get("chatbot_tier", "chatbot_basic")

    # Determine initial status based on tier
    # Basic = no AI, immediate worker handoff
    # AI / Full = AI auto-responses first
    if chatbot_tier == "chatbot_basic":
        initial_status = "waiting_human"
    else:
        initial_status = "ai_active"

    session_data = {
        "visitor_name": body.visitor_name or "Visitor",
        "visitor_email": body.visitor_email,
        "merchant_id": merchant_id,
        "status": initial_status,
        "source": "merchant_widget",
        "metadata": {
            "api_key": body.api_key,
            "visitor_ip": visitor_ip,
            "chatbot_tier": chatbot_tier,
            "page_url": body.page_url or "",
            "page_title": body.page_title or "",
        },
    }

    ai_text = ""
    handoff = False
    tracking_response = None

    # ── KEYWORD TRACKING INTERCEPT REMOVED — AI handles order flow via [ORDER_LOOKUP] signal

    if chatbot_tier == "chatbot_basic":
        # Basic tier: NO AI, direct handoff to worker
        # First check working hours (8AM-8PM IST)
        if not _is_working_hours():
            return {
                "success": True,
                "data": {
                    "session_id": None,
                    "ai_response": "",
                    "no_workers_available": True,
                    "offline_message": "Our support team is available Mon–Sat, 8AM–8PM IST. We are currently outside service hours. Please share your contact details and we'll call you back during working hours!",
                    "chatbot_tier": chatbot_tier,
                }
            }
        # Check if any worker is actually online
        active_workers = _get_active_workers(db)
        if not active_workers:
            # No workers online — return offline flag
            return {
                "success": True,
                "data": {
                    "session_id": None,
                    "ai_response": "",
                    "no_workers_available": True,
                    "offline_message": "We're extremely sorry, there is no one active right now to handle your chat. Please share your details and we'll call you back as soon as possible.",
                    "chatbot_tier": chatbot_tier,
                }
            }

        ai_text = "Thank you for reaching out! We're connecting you with a support agent. Please wait a moment..."
        handoff = True

        # Assign to the worker with least active chats
        best_worker = _pick_best_worker(db, active_workers)
        if best_worker:
            session_data["assigned_worker_id"] = best_worker["id"]

        session = db.table("chat_sessions").insert(session_data).execute()
        session_id = session.data[0]["id"]

        db.table("chat_messages").insert({
            "session_id": session_id,
            "sender_type": "visitor",
            "message": body.message,
        }).execute()
        db.table("chat_messages").insert({
            "session_id": session_id,
            "sender_type": "system",
            "message": "🔔 Connecting you with a support agent. Please wait...",
        }).execute()
    else:
        # AI / Full tier: AI auto-responses
        session = db.table("chat_sessions").insert(session_data).execute()
        session_id = session.data[0]["id"]

        # Save visitor message
        db.table("chat_messages").insert({
            "session_id": session_id,
            "sender_type": "visitor",
            "message": body.message,
        }).execute()

        system_prompt = _build_merchant_system_prompt(config)
        ai_result = await get_merchant_ai_response(
            messages=[{"sender_type": "visitor", "message": body.message}],
            system_prompt=system_prompt,
        )

        # Handle ORDER_LOOKUP signal from AI
        if ai_result.get("order_signal"):
            sig = ai_result["order_signal"]
            order_data_msg = _process_order_signal(
                merchant_id, sig["order_number"], sig["contact"]
            )
            ai_result2 = await get_merchant_ai_with_order_data(
                messages=[{"sender_type": "visitor", "message": body.message}],
                system_prompt=system_prompt,
                order_data=order_data_msg,
            )
            ai_text = ai_result2["message"]
            handoff = False
        else:
            ai_text = ai_result["message"]
            handoff = ai_result["handoff_requested"] and chatbot_tier != "chatbot_ai"

        db.table("chat_messages").insert({
            "session_id": session_id,
            "sender_type": "ai",
            "message": ai_text,
        }).execute()

        if handoff:
            db.table("chat_sessions").update({"status": "waiting_human"}).eq("id", session_id).execute()
            db.table("chat_messages").insert({
                "session_id": session_id,
                "sender_type": "system",
                "message": "Connecting you with a support agent. Please wait...",
            }).execute()


    # Increment usage
    _increment_usage(merchant_id, session_id, "start", visitor_ip)

    return {
        "success": True,
        "data": {
            "session_id": session_id,
            "ai_response": ai_text,
            "handoff_requested": handoff,
            "status": "waiting_human" if handoff else "ai_active",
            "chatbot_tier": chatbot_tier,
        }
    }


@router.post("/message/{session_id}")
async def send_merchant_message(session_id: str, body: MerchantMessageBody, request: Request):
    """Visitor sends a message in existing merchant chat session."""
    config = _get_merchant_config(body.api_key)
    merchant_id = config.get("merchant_id")
    _check_rate_limit(merchant_id, config)

    db = get_db()
    visitor_ip = request.client.host if request.client else ""

    # Verify session belongs to this merchant
    session = db.table("chat_sessions").select("id, status, merchant_id").eq("id", session_id).execute()
    if not session.data or session.data[0].get("merchant_id") != merchant_id:
        raise HTTPException(404, "Session not found")

    status = session.data[0]["status"]

    # Save visitor message
    db.table("chat_messages").insert({
        "session_id": session_id,
        "sender_type": "visitor",
        "message": body.message,
    }).execute()

    result = {"status": status}

    if status == "ai_active":
        # Get conversation history
        history = db.table("chat_messages").select("sender_type, message").eq(
            "session_id", session_id
        ).order("created_at").execute()
        history_data = history.data or []

        # ── SMART BACKEND ORDER DETECTION ──────────────────────────────────
        # If this message looks like an email/phone AND recent history has an
        # order number → backend verifies + injects result into AI call.
        # No AI signal needed at all.
        contact = _extract_contact_from_message(body.message)
        order_num = _find_order_in_history(history_data) if contact else None

        # Get tier from session metadata
        session_meta = session.data[0].get("metadata") or {}
        if isinstance(session_meta, str):
            try:
                session_meta = json.loads(session_meta)
            except Exception:
                session_meta = {}
        session_tier_meta = session_meta.get("chatbot_tier", "chatbot_full")

        system_prompt = _build_merchant_system_prompt(config)

        if contact and order_num:
            # Both pieces available → backend does the lookup, no round-trip to AI for signal
            order_data = _process_order_signal(merchant_id, order_num, contact)
            ai_result = await get_merchant_ai_with_order_data(
                messages=history_data,
                system_prompt=system_prompt,
                order_data=order_data,
            )
            ai_text = ai_result["message"]
            handoff = False
        else:
            # Normal AI call — AI handles conversation (asks for order num, asks for contact, etc.)
            ai_result = await get_merchant_ai_response(
                messages=history_data,
                system_prompt=system_prompt,
            )
            ai_text = ai_result["message"]
            handoff = ai_result["handoff_requested"] and session_tier_meta != "chatbot_ai"
        # ───────────────────────────────────────────────────────────────────


        db.table("chat_messages").insert({
            "session_id": session_id,
            "sender_type": "ai",
            "message": ai_text,
        }).execute()

        result["ai_response"] = ai_text
        result["handoff_requested"] = handoff

        if handoff:
            db.table("chat_sessions").update({"status": "waiting_human"}).eq("id", session_id).execute()
            active_workers = _get_active_workers(db)
            if active_workers:
                best_worker = _pick_best_worker(db, active_workers)
                if best_worker:
                    db.table("chat_sessions").update({
                        "assigned_worker_id": best_worker["id"],
                    }).eq("id", session_id).execute()
            db.table("chat_messages").insert({
                "session_id": session_id,
                "sender_type": "system",
                "message": "Connecting you with a support agent. Please wait...",
            }).execute()
            result["status"] = "waiting_human"


    elif status == "human_active":
        result["message"] = "Message sent to support agent"

    elif status == "waiting_human":
        result["message"] = "Your message has been received. An agent will respond shortly."

    # Increment usage
    _increment_usage(merchant_id, session_id, "message", visitor_ip)

    return {"success": True, "data": result}


@router.get("/messages/{session_id}")
async def get_merchant_chat_messages(session_id: str, api_key: str):
    """Get messages for a merchant chat session (public, for widget polling)."""
    config = _get_merchant_config(api_key)
    merchant_id = config.get("merchant_id")

    db = get_db()
    session = db.table("chat_sessions").select("id, status, merchant_id, assigned_worker_id").eq("id", session_id).execute()
    if not session.data or session.data[0].get("merchant_id") != merchant_id:
        raise HTTPException(404, "Session not found")

    messages = db.table("chat_messages").select("*").eq(
        "session_id", session_id
    ).order("created_at").execute()

    # Get worker name if assigned
    worker_name = None
    if session.data[0].get("assigned_worker_id"):
        worker = db.table("users").select("name").eq("id", session.data[0]["assigned_worker_id"]).execute()
        if worker.data:
            worker_name = worker.data[0].get("name")

    return {
        "success": True,
        "data": {
            "messages": messages.data or [],
            "session_status": session.data[0]["status"],
            "worker_name": worker_name,
        }
    }


@router.post("/offline-callback")
async def submit_offline_callback(body: MerchantOfflineCallbackBody):
    """Visitor submits callback form when no worker is available."""
    config = _get_merchant_config(body.api_key)
    merchant_id = config.get("merchant_id")

    db = get_db()

    visitor_name = body.visitor_name
    visitor_phone = body.visitor_phone
    visitor_email = body.visitor_email or ""
    reason = body.reason or ""

    # Save callback request
    callback_data = {
        "merchant_id": merchant_id,
        "visitor_name": visitor_name,
        "visitor_phone": visitor_phone,
        "visitor_email": visitor_email,
        "reason": reason,
        "status": "pending",
        "source": "chatbot_offline",
    }

    # Assign to a random worker (they'll see it when back)
    all_workers = db.table("users").select("id").eq("role", "worker").execute()
    if all_workers.data:
        random_worker = random.choice(all_workers.data)
        callback_data["assigned_worker_id"] = random_worker["id"]

    db.table("callback_requests").insert(callback_data).execute()

    # Notify assigned worker
    if callback_data.get("assigned_worker_id"):
        from services.notification_service import create_notification
        await create_notification(
            callback_data["assigned_worker_id"],
            f"📞 Offline Callback from {visitor_name}",
            f"Phone: {visitor_phone} | Reason: {reason[:100] if reason else 'Not specified'}",
            "info", "callbacks", None
        )

    return {
        "success": True,
        "data": {
            "message": "Thank you! We've received your details. Our team will call you back shortly."
        }
    }


@router.post("/callback-request")
async def submit_callback_request(body: MerchantCallbackRequestBody):
    """Visitor submits callback request via chatbot widget (permanent button, works anytime)."""
    config = _get_merchant_config(body.api_key)
    merchant_id = config.get("merchant_id")

    db = get_db()

    visitor_name = body.visitor_name
    visitor_phone = body.visitor_phone
    visitor_email = body.visitor_email or ""
    reason = body.reason or ""

    # Save callback request
    callback_data = {
        "merchant_id": merchant_id,
        "visitor_name": visitor_name,
        "visitor_phone": visitor_phone,
        "visitor_email": visitor_email,
        "reason": reason,
        "status": "pending",
        "source": "chatbot_widget",
    }

    # Assign to online worker (least loaded) or any worker if none online
    active_workers = _get_active_workers(db)
    if active_workers:
        best_worker = _pick_best_worker(db, active_workers)
        if best_worker:
            callback_data["assigned_worker_id"] = best_worker["id"]
    else:
        all_workers = db.table("users").select("id").eq("role", "worker").execute()
        if all_workers.data:
            callback_data["assigned_worker_id"] = random.choice(all_workers.data)["id"]

    result = db.table("callback_requests").insert(callback_data).execute()

    # Notify assigned worker
    if callback_data.get("assigned_worker_id"):
        from services.notification_service import create_notification
        await create_notification(
            callback_data["assigned_worker_id"],
            f"📞 Callback Request from {visitor_name}",
            f"Phone: {visitor_phone} | Reason: {reason[:100] if reason else 'Not specified'}",
            "info", "callbacks", None
        )

    return {
        "success": True,
        "data": {
            "message": "Your callback request has been submitted! Our team will call you back shortly."
        }
    }


@router.get("/workers-status")
async def check_workers_status(api_key: str):
    """Check if any support workers are currently online (for widget UI)."""
    _get_merchant_config(api_key)  # validate api_key
    db = get_db()
    active_workers = _get_active_workers(db)
    return {
        "success": True,
        "data": {
            "workers_online": len(active_workers) > 0,
            "count": len(active_workers),
        }
    }


# =======================================================
#  MISSING ENDPOINTS — added to fix chatbot-widget.js 404s
# =======================================================

@router.get("/recent-orders")
async def get_recent_orders(api_key: str, email: str = ""):
    """
    Fetch recent orders for a logged-in customer (identified by email).
    Called by chatbot-widget.js when data-customer-email is set.
    Returns orders with within_return_window / within_refund_window flags.
    """
    config = _get_merchant_config(api_key)
    merchant_id = config.get("merchant_id")

    if not email:
        return {"success": True, "data": {"orders": []}}

    db = get_db()
    email_clean = email.lower().strip()

    # Fetch up to 5 recent orders for this customer on this merchant's store
    result = db.table("orders").select(
        "id, order_number, customer_name, customer_email, customer_phone, "
        "delivery_status, fulfillment_status, tracking_number, tracking_company, "
        "tracking_url, order_amount, currency, created_at, delivery_updated_at"
    ).eq("user_id", merchant_id).ilike(
        "customer_email", email_clean
    ).order("created_at", desc=True).limit(5).execute()

    orders = result.data or []

    # Get return/refund policy windows from config (default 7 days each)
    return_days = int(config.get("return_policy_days") or 7)
    refund_days = int(config.get("refund_policy_days") or 7)
    now = datetime.now(timezone.utc)

    def add_window_flags(order: dict) -> dict:
        """Add within_return_window / within_refund_window + days_since_order."""
        created_raw = order.get("created_at")
        if created_raw:
            try:
                created_dt = datetime.fromisoformat(str(created_raw).replace("Z", "+00:00"))
                days_since = (now - created_dt).days
                order["days_since_order"] = days_since
                order["within_return_window"] = days_since <= return_days
                order["within_refund_window"] = days_since <= refund_days
                order["return_policy_days"] = return_days
                order["refund_policy_days"] = refund_days
            except Exception:
                order["within_return_window"] = False
                order["within_refund_window"] = False
                order["days_since_order"] = 999
                order["return_policy_days"] = return_days
        else:
            order["within_return_window"] = False
            order["within_refund_window"] = False
            order["days_since_order"] = 999
            order["return_policy_days"] = return_days
        return order

    orders_with_flags = [add_window_flags(o) for o in orders]

    return {
        "success": True,
        "data": {"orders": orders_with_flags},
    }


class SubmitReturnBody(BaseModel):
    api_key: str
    order_number: str
    request_type: str           # 'return' | 'exchange'
    reason: str
    exchange_size: Optional[str] = None
    session_id: Optional[str] = None
    customer_email: Optional[str] = None
    customer_name: Optional[str] = None


@router.post("/submit-return")
async def submit_return_request_public(body: SubmitReturnBody):
    """
    Submit a return/refund request from the chatbot widget.
    Called by chatbot-widget.js submitReturnRequest().
    Stores into return_requests table so merchant can manage via dashboard.
    """
    config = _get_merchant_config(body.api_key)
    merchant_id = config.get("merchant_id")

    if body.request_type not in ("return", "exchange", "refund"):
        raise HTTPException(400, "request_type must be 'return', 'exchange', or 'refund'")

    db = get_db()

    # Look up the order to get full customer info (best-effort)
    order = None
    if body.order_number:
        try:
            ord_res = db.table("orders").select(
                "customer_name, customer_email, customer_phone, order_amount, delivery_status"
            ).eq("user_id", merchant_id).eq("order_number", body.order_number).limit(1).execute()
            if ord_res.data:
                order = ord_res.data[0]
        except Exception:
            pass

    customer_name = body.customer_name or (order.get("customer_name") if order else "") or "Widget Customer"
    customer_email = body.customer_email or (order.get("customer_email") if order else "") or ""
    customer_phone = (order.get("customer_phone") if order else "") or ""
    order_amount = (order.get("order_amount") if order else None)
    delivery_status = (order.get("delivery_status") if order else "") or ""

    return_data = {
        "merchant_id": merchant_id,
        "order_number": body.order_number,
        "request_type": body.request_type,
        "reason": body.reason,
        "status": "pending",
        "customer_name": customer_name,
        "customer_email": customer_email,
        "customer_phone": customer_phone,
        "order_amount": order_amount,
        "delivery_status": delivery_status,
    }
    # Store exchange_size in notes if provided (avoids schema errors)
    if body.exchange_size:
        return_data["notes"] = f"Exchange size: {body.exchange_size}"

    db.table("return_requests").insert(return_data).execute()

    # Optionally notify merchant (non-critical — don't fail on error)
    try:
        from services.notification_service import create_notification
        icon = "↩️" if body.request_type == "return" else ("🔄" if body.request_type == "exchange" else "💰")
        size_info = f" | Size: {body.exchange_size}" if body.exchange_size else ""
        await create_notification(
            merchant_id,
            f"{icon} New {body.request_type.title()} Request — Order #{body.order_number}",
            f"Customer: {customer_name} | Reason: {body.reason[:80]}{size_info}",
            "warning", "returns", None
        )
    except Exception:
        pass

    return {
        "success": True,
        "data": {
            "message": f"Your {body.request_type} request for Order #{body.order_number} has been submitted. Our team will review and respond within 1–2 business days.",
        }
    }


@router.get("/products")
async def get_chatbot_products(api_key: str, category: str = ""):
    """
    Fetch products for the chatbot widget carousel.
    Priority:
      1. products table (synced via Shopify webhook)
      2. business_services text fallback (parsed from config)
    Each product always gets a store URL.
    """
    config = _get_merchant_config(api_key)
    merchant_id = config.get("merchant_id")

    db = get_db()
    products = []

    # -- Resolve best store URL from config or users table --
    store_url = (
        config.get("store_url") or
        config.get("store_website") or
        config.get("business_url") or
        config.get("website_url") or
        ""
    )
    if not store_url:
        try:
            user_res = db.table("users").select(
                "shopify_shop_domain, website_url"
            ).eq("id", merchant_id).limit(1).execute()
            if user_res.data:
                u = user_res.data[0]
                domain = u.get("shopify_shop_domain") or ""
                store_url = u.get("website_url") or (
                    f"https://{domain}" if domain else ""
                )
        except Exception:
            pass
    store_url = store_url.rstrip("/")

    # -- 1. Try products table --
    try:
        query = db.table("products").select(
            "id, title, price, currency, image_url, product_url, product_type, status, handle"
        ).eq("user_id", merchant_id).eq("status", "active")

        if category:
            query = query.ilike("product_type", f"%{category}%")

        result = query.order("created_at", desc=True).limit(20).execute()
        products_raw = result.data or []

        for p in products_raw:
            price_val = p.get("price", "")
            try:
                formatted_price = f"₹{float(price_val):,.0f}" if price_val else ""
            except Exception:
                formatted_price = str(price_val) if price_val else ""

            # Build product URL: prefer explicit product_url, then handle + store_url
            prod_url = p.get("product_url") or ""
            if not prod_url and p.get("handle") and store_url:
                prod_url = f"{store_url}/products/{p['handle']}"
            if not prod_url and store_url:
                prod_url = store_url

            products.append({
                "id": p.get("id"),
                "title": p.get("title", ""),
                "price": formatted_price,
                "currency": p.get("currency") or "INR",
                "image": p.get("image_url") or "",
                "url": prod_url,
                "type": p.get("product_type") or "",
            })
    except Exception as e:
        # products table may not exist — fall through to business_services
        pass

    # -- 2. Fallback: parse business_services text --
    if not products:
        import re as _re
        services_text = config.get("business_services", "") or ""
        if services_text.strip():
            lines = [ln.strip() for ln in services_text.splitlines() if ln.strip()]
            for i, line in enumerate(lines[:20]):
                if category and category.lower() not in line.lower():
                    continue

                # Skip header/summary lines generated by the scraper
                line_u = line.upper()
                if line_u.startswith(("PRODUCTS (", "LARGE CATALOG (", "[SHOWING TOP")):
                    continue

                # Extract hidden metadata
                image_url = ""
                img_match = _re.search(r'✨\s*IMG:\s*(https?://[^\s|]+)', line)
                if img_match:
                    image_url = img_match.group(1)
                    line = line.replace(img_match.group(0), "")
                
                prod_url = store_url
                url_match = _re.search(r'🔗\s*URL:\s*(https?://[^\s|]+)', line)
                if url_match:
                    prod_url = url_match.group(1)
                    line = line.replace(url_match.group(0), "")

                # Extract price
                price_match = _re.search(r'(?:Rs\.?\s?|INR\s?|₹\s?)([\d,]+)', line)
                price_str = f"₹{price_match.group(1).replace(',', ',')}" if price_match else ""
                
                # Clean product name
                name = _re.sub(r'(?:Rs\.?\s?|INR\s?|₹\s?)[\d,]+', '', line)
                name = _re.sub(r'^[-:\|.\s]+|[-:\|.\s]+$', '', name).strip()
                name = _re.sub(r'^\d+\.\s*', '', name).strip()
                
                if not name or len(name) < 3:
                    continue
                products.append({
                    "id": f"svc-{i}",
                    "title": name,
                    "price": price_str,
                    "currency": "INR",
                    "image": image_url,
                    "url": prod_url,
                    "type": "",
                })

    return {
        "success": True,
        "data": {
            "products": products,
            "store_url": store_url,
            "total": len(products),
        },
    }
