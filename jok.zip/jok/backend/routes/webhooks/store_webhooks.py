from fastapi import APIRouter, Request, HTTPException, Depends, Header
from datetime import datetime, timezone, timedelta
from loguru import logger
from config.database import get_db
from config.settings import settings
from middleware.auth import get_api_key_user
from middleware.rate_limiter import limiter
from models.webhooks import NewOrderWebhook, DeliveryUpdateWebhook
from utils.helpers import success_response, error_response
from utils.phone_utils import normalize_phone, hash_phone, phone_last_four
from services.risk_scoring import calculate_risk_score
from services.notification_service import create_notification
import json, hmac, hashlib

router = APIRouter(prefix="/api/v1/webhook", tags=["Store Webhooks"])


@router.post("/order/new")
@limiter.limit("100/minute")
async def new_order(request: Request, body: NewOrderWebhook, user: dict = Depends(get_api_key_user)):
    db = get_db()
    user_id = user["id"]

    # Determine order type from payment method
    payment_lower = body.payment_method.lower()
    is_cod = payment_lower in ("cod", "cash on delivery", "cash")
    order_type = body.order_type or ("cod" if is_cod else "prepaid")

    # Validate phone — support India (+91) and international (+1, etc.)
    phone_normalized = normalize_phone(body.customer_phone) if body.customer_phone else ""
    if not phone_normalized:
        # Allow orders without phone — they just won't get WhatsApp verification
        logger.warning(f"Order {body.store_order_id} has no valid phone: '{body.customer_phone}'")
        phone_normalized = ""
    p_hash = hash_phone(phone_normalized) if phone_normalized else None

    # ── Check active contract (new system) ──────────────────────────────
    # New system uses `contracts` table. Legacy system used `service_subscriptions`.
    # We check contracts first; fall back to service_subscriptions for old merchants.
    active_contract = db.table("contracts").select("id, services") \
        .eq("user_id", user_id).eq("status", "active") \
        .order("created_at", desc=True).limit(1).execute()

    subscription = None  # for legacy quota tracking
    used_quota = 0
    monthly_quota = 0

    if active_contract.data:
        # ✅ New contract system — check cod_verification service
        c = active_contract.data[0]
        services = c.get("services") or []
        services_lower = [s.strip().lower() for s in services]
        cod_keys = {
            "cod_verification", "cod", "cod verify", "sms verification",
            "whatsapp verification", "order verification", "cod order verification",
        }
        has_cod = any(s in cod_keys for s in services_lower)
        if not has_cod:
            raise HTTPException(status_code=402, detail="Your contract does not include COD Verification service.")
        # ── Wallet balance check — reject only if wallet is completely empty ──
        from services.wallet_service import get_or_create_wallet
        wallet = await get_or_create_wallet(db, user_id)
        if float(wallet.get("balance", 0)) <= 0:
            raise HTTPException(
                status_code=402,
                detail="Wallet balance is zero. Please recharge your wallet to continue receiving orders."
            )
    else:
        # ── Fallback: legacy service_subscriptions table ─────────────────
        sub = db.table("service_subscriptions").select("*") \
            .eq("user_id", user_id).eq("status", "active") \
            .order("created_at", desc=True).limit(1).execute()
        if not sub.data:
            raise HTTPException(status_code=402, detail="No active subscription or contract found.")
        subscription = sub.data[0]
        used_quota = subscription.get("used_quota") or 0
        monthly_quota = subscription.get("monthly_quota") or 0
        if monthly_quota > 0 and used_quota >= monthly_quota:
            raise HTTPException(status_code=402, detail="Monthly quota exceeded. Please upgrade your plan.")


    # Check global blacklist (skip if no phone)
    customer_data = None
    if p_hash:
        customer_res = db.table("customers_directory").select("*").eq("phone_number_hash", p_hash).execute()
        customer_data = customer_res.data[0] if customer_res.data else None
        if customer_data and customer_data.get("is_globally_blacklisted"):
            raise HTTPException(status_code=403, detail="Phone number is globally blacklisted")

        # Check merchant blacklist
        merchant_bl = db.table("merchant_blacklist").select("id").eq("user_id", user_id).eq("phone_number_hash", p_hash).execute()
        if merchant_bl.data:
            raise HTTPException(status_code=403, detail="Phone number is blacklisted by merchant")

    # Get store
    stores = db.table("stores").select("*").eq("user_id", user_id).eq("is_active", True).limit(1).execute()
    store_id = stores.data[0]["id"] if stores.data else None

    # Check duplicate
    if store_id:
        dup = db.table("orders").select("id").eq("user_id", user_id).eq("store_id", store_id).eq("store_order_id", body.store_order_id).execute()
        if dup.data:
            raise HTTPException(status_code=409, detail="Order already exists")

    # Get merchant settings
    ms_res = db.table("merchant_settings").select("*").eq("user_id", user_id).execute()
    merchant_settings = ms_res.data[0] if ms_res.data else {}

    # Check min order amount
    min_amount = merchant_settings.get("min_order_amount", 0)
    if body.order_amount < min_amount:
        return success_response({"skipped": True}, f"Order below minimum amount ₹{min_amount}")

    # Build address dict — needed for both risk scoring and order record
    addr = body.shipping_address.model_dump() if body.shipping_address else None

    # Risk scoring — only if we have a valid phone hash
    if p_hash:
        risk_score, risk_factors = calculate_risk_score(p_hash, body.order_amount, addr)
    else:
        risk_score, risk_factors = 0, ["No phone provided"]

    # Calculate scheduled send time (only for COD orders)
    # NOTE: Working hours do NOT apply to COD verification — messages go instantly
    # after the configured delay. Working hours only apply to chatbot live-agent forwarding.
    now = datetime.now(timezone.utc)
    delay = merchant_settings.get("message_delay_seconds", 0)  # 0 = instant
    scheduled = now + timedelta(seconds=delay)

    # Create/update customer directory (skip if no phone)
    if p_hash:
        if not customer_data:
            db.table("customers_directory").insert({
                "phone_number_hash": p_hash,
                "phone_last_four": phone_last_four(phone_normalized),
                "total_orders": 1,
                "total_order_value": body.order_amount,
                "first_order_date": now.isoformat(),
                "last_order_date": now.isoformat(),
                "risk_score": risk_score,
            }).execute()
        else:
            db.table("customers_directory").update({
                "total_orders": customer_data["total_orders"] + 1,
                "total_order_value": float(customer_data.get("total_order_value", 0)) + body.order_amount,
                "last_order_date": now.isoformat(),
                "risk_score": risk_score,
            }).eq("id", customer_data["id"]).execute()

    # Create order
    addr_text = ""
    if addr:
        parts = [addr.get("line1", ""), addr.get("line2", ""), addr.get("city", ""), addr.get("state", ""), addr.get("pincode", ""), addr.get("country", "")]
        addr_text = ", ".join([p for p in parts if p])

    # For COD orders: schedule verification; for prepaid/manual: just store
    if not phone_normalized:
        verification_status = "phone_missing"
    elif is_cod:
        verification_status = "pending"
    else:
        verification_status = "not_required"  # prepaid orders don't need COD verification

    order_data = {
        "user_id": user_id,
        "store_id": store_id,
        "store_order_id": body.store_order_id,
        "order_number": body.order_number or body.store_order_id,
        "customer_name": body.customer_name,
        "customer_phone": body.customer_phone,
        "customer_phone_normalized": phone_normalized,
        "customer_email": body.customer_email,
        "customer_address": addr_text,
        "order_amount": body.order_amount,
        "currency": body.currency,
        "payment_method": body.payment_method,
        "order_type": order_type,
        "payment_status": "paid" if not is_cod else "pending",
        "fulfillment_status": body.fulfillment_status,
        "products_json": [p.model_dump() for p in body.products],
        "shipping_address_json": addr,
        "verification_status": verification_status,
        "risk_score": risk_score,
        "risk_factors_json": risk_factors,
        "scheduled_send_at": scheduled.isoformat() if is_cod else None,
        "tracking_number": body.tracking_number,
        "tracking_url": body.tracking_url,
        "tracking_company": body.tracking_company,
        "delivery_status": "pending",
        "source": body.source or "shopify",
        "tags": [t.strip() for t in body.tags.split(",") if t.strip()] if body.tags else [],
        "notes": body.notes,
    }
    order_result = db.table("orders").insert(order_data).execute()
    order = order_result.data[0]

    # Update quota (only for COD orders that need verification)
    if is_cod:
        if subscription:
            # Legacy system only — contracts have no quota column
            db.table("service_subscriptions").update({
                "used_quota": used_quota + 1
            }).eq("id", subscription["id"]).execute()


    # Update store order count
    if store_id:
        db.table("stores").update({
            "total_orders": (stores.data[0].get("total_orders", 0) + 1),
            "last_order_received_at": now.isoformat(),
        }).eq("id", store_id).execute()

    # Notification
    order_label = f"{'COD' if is_cod else 'Prepaid'} Order #{order.get('order_number', '')}"
    await create_notification(user_id, f"New {order_label}",
        f"₹{body.order_amount} from {body.customer_name}", "info", "orders", f"/dashboard/orders/{order['id']}")

    # Log webhook
    db.table("webhook_logs").insert({
        "user_id": user_id, "direction": "incoming", "source": "store",
        "endpoint": "/api/v1/webhook/order/new", "method": "POST",
        "request_payload": body.model_dump(), "status_code": 200,
    }).execute()

    # ── Instant WA send for COD orders ───────────────────────────────────────
    # Send immediately — don't wait for the 30-second scheduler cycle.
    # Scheduler remains as fallback for retries only.
    if is_cod and phone_normalized and verification_status == "pending":
        try:
            from services.order_processing import _send_verification_for_order
            await _send_verification_for_order(db, order)
        except Exception as e:
            logger.warning(f"Instant WA send failed for order {order['id']}: {e} — scheduler will retry")

    return success_response({
        "order_id": order["id"],
        "order_type": order_type,
        "verification_status": verification_status,
        "scheduled_send_at": scheduled.isoformat() if is_cod else None,
        "risk_score": risk_score,
    }, "Order received successfully")


@router.post("/order/delivery-update")
@limiter.limit("100/minute")
async def delivery_update(request: Request, body: DeliveryUpdateWebhook, user: dict = Depends(get_api_key_user)):
    db = get_db()
    order_res = db.table("orders").select("*").eq("user_id", user["id"]).eq("store_order_id", body.store_order_id).execute()
    if not order_res.data:
        raise HTTPException(status_code=404, detail="Order not found")
    order_data = order_res.data[0]

    updates = {
        "delivery_status": body.delivery_status,
        "delivery_updated_at": datetime.now(timezone.utc).isoformat(),
    }
    if body.tracking_number:
        updates["tracking_number"] = body.tracking_number
    if body.tracking_url:
        updates["tracking_url"] = body.tracking_url
    if body.tracking_company:
        updates["tracking_company"] = body.tracking_company

    db.table("orders").update(updates).eq("id", order_data["id"]).execute()

    # Send WhatsApp delivery notification to customer (always — for all notifiable statuses)
    import asyncio
    from services.order_processing import send_delivery_update_message
    # Re-fetch order so it has the latest tracking fields we just saved
    updated_order = db.table("orders").select("*").eq("id", order_data["id"]).execute()
    order_for_wa = updated_order.data[0] if updated_order.data else order_data
    asyncio.create_task(send_delivery_update_message(
        order_for_wa,
        body.delivery_status,
        body.tracking_url or "",
    ))
    logger.info(f"Delivery WA notification queued for order {order_data['id']}: {body.delivery_status}")

    return success_response(message=f"Delivery status updated to {body.delivery_status}")


@router.post("/order/cancel")
@limiter.limit("100/minute")
async def cancel_order(request: Request, user: dict = Depends(get_api_key_user)):
    """Cancel an order when merchant cancels it in Shopify."""
    db = get_db()
    data = await request.json()
    store_order_id = str(data.get("store_order_id") or data.get("id") or "")
    shop = data.get("shop_domain") or data.get("shop") or ""

    if not store_order_id:
        raise HTTPException(status_code=400, detail="store_order_id required")

    order_res = db.table("orders").select("id, verification_status").eq(
        "user_id", user["id"]
    ).eq("store_order_id", store_order_id).execute()

    if not order_res.data:
        # Try without user_id filter (shop-wide cancel from Shopify webhook)
        order_res = db.table("orders").select("id, verification_status, user_id").eq(
            "store_order_id", store_order_id
        ).execute()
        if not order_res.data:
            raise HTTPException(status_code=404, detail="Order not found")

    order = order_res.data[0]
    db.table("orders").update({
        "verification_status": "cancelled",
        "delivery_status": "returned",  # 'cancelled' not in enum; 'returned' is closest valid value
    }).eq("id", order["id"]).execute()

    # Notification to merchant
    await create_notification(
        order.get("user_id", user["id"]),
        "Order Cancelled",
        f"Order #{store_order_id} has been cancelled.",
        "warning", "orders", f"/dashboard/orders/{order['id']}"
    )

    logger.info(f"Order {store_order_id} cancelled by webhook/admin")
    return success_response({"order_id": order["id"]}, "Order cancelled successfully")


@router.post("/order/tag")
@limiter.limit("200/minute")
async def update_order_tag(request: Request, user: dict = Depends(get_api_key_user)):
    """Update order verification tag: confirmed / not_answered / cancelled."""
    db = get_db()
    data = await request.json()
    order_id = data.get("order_id")
    store_order_id = str(data.get("store_order_id") or "")
    status = data.get("status")  # confirmed | not_answered | cancelled | pending

    ALLOWED = {"confirmed", "not_answered", "cancelled", "pending", "phone_missing", "not_required"}
    if status not in ALLOWED:
        raise HTTPException(status_code=400, detail=f"Invalid status. Allowed: {ALLOWED}")

    query = db.table("orders").update({
        "verification_status": status
    }).eq("user_id", user["id"])

    if order_id:
        query = query.eq("id", order_id)
    elif store_order_id:
        query = query.eq("store_order_id", store_order_id)
    else:
        raise HTTPException(status_code=400, detail="order_id or store_order_id required")

    result = query.execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Order not found")

    return success_response({"order_id": result.data[0]["id"], "status": status}, "Order tag updated")
