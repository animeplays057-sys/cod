"""Worker chat endpoints — AI chatbot + human handoff support system."""
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timezone
from config.database import get_db
from middleware.auth import get_current_worker, get_current_admin
from utils.helpers import success_response
from services.groq_service import get_ai_response

router = APIRouter(prefix="/api/v1/worker/chat", tags=["Worker Chat"])


class SendMessageBody(BaseModel):
    message: str


# ── WORKER: Get active/waiting sessions ───────────────────────────
@router.get("/sessions")
async def get_chat_sessions(user: dict = Depends(get_current_worker)):
    """Get all chat sessions: active (assigned to worker) + waiting (need human)."""
    db = get_db()
    worker_id = user["id"]

    # Sessions assigned to this worker (active)
    my_sessions = db.table("chat_sessions").select("*").eq(
        "assigned_worker_id", worker_id
    ).in_("status", ["human_active"]).order("updated_at", desc=True).execute()

    my_list = my_sessions.data or []

    # Enrich each session with merchant store name + page source
    for sess in my_list:
        if sess.get("merchant_id"):
            store = db.table("stores").select("store_name, store_url, platform").eq("user_id", sess["merchant_id"]).limit(1).execute()
            if store.data:
                sess["merchant_store_name"] = store.data[0].get("store_name", "")
                sess["merchant_store_url"] = store.data[0].get("store_url", "")
                sess["merchant_platform"] = store.data[0].get("platform", "")
        # Extract page_url from metadata
        meta = sess.get("metadata") or {}
        if isinstance(meta, str):
            import json as _j
            try: meta = _j.loads(meta)
            except: meta = {}
        sess["visitor_page_url"] = meta.get("page_url", "")
        sess["visitor_page_title"] = meta.get("page_title", "")
        sess["source_label"] = (
            meta.get("page_title") or meta.get("page_url") or
            ("CODVerify Website" if sess.get("source") == "website" else "Merchant Widget")
        )

    # Sessions waiting for human (unassigned or assigned to this worker but not yet active)
    waiting = db.table("chat_sessions").select("*").eq(
        "status", "waiting_human"
    ).order("created_at", desc=False).execute()

    waiting_list = waiting.data or []
    for sess in waiting_list:
        if sess.get("merchant_id"):
            store = db.table("stores").select("store_name, store_url, platform").eq("user_id", sess["merchant_id"]).limit(1).execute()
            if store.data:
                sess["merchant_store_name"] = store.data[0].get("store_name", "")
                sess["merchant_store_url"] = store.data[0].get("store_url", "")
                sess["merchant_platform"] = store.data[0].get("platform", "")
        # Extract page_url from metadata
        meta = sess.get("metadata") or {}
        if isinstance(meta, str):
            import json as _j
            try: meta = _j.loads(meta)
            except: meta = {}
        sess["visitor_page_url"] = meta.get("page_url", "")
        sess["visitor_page_title"] = meta.get("page_title", "")
        sess["source_label"] = (
            meta.get("page_title") or meta.get("page_url") or
            ("CODVerify Website" if sess.get("source") == "website" else "Merchant Widget")
        )

    # Recent resolved sessions (last 20)
    resolved = db.table("chat_sessions").select("*").in_(
        "status", ["resolved"]
    ).order("resolved_at", desc=True).limit(20).execute()

    return success_response({
        "my_sessions": my_list,
        "waiting_sessions": waiting_list,
        "resolved_sessions": resolved.data or [],
        "active_count": len(my_list),
        "max_chats": 4,
    })


# ── WORKER: Get messages for a session ────────────────────────────
@router.get("/sessions/{session_id}/messages")
async def get_session_messages(session_id: str, user: dict = Depends(get_current_worker)):
    db = get_db()
    messages = db.table("chat_messages").select("*").eq(
        "session_id", session_id
    ).order("created_at", desc=False).execute()

    session = db.table("chat_sessions").select("*").eq("id", session_id).execute()

    return success_response({
        "messages": messages.data or [],
        "session": session.data[0] if session.data else None,
    })


# ── WORKER: Accept a waiting session ──────────────────────────────
@router.post("/sessions/{session_id}/accept")
async def accept_session(session_id: str, user: dict = Depends(get_current_worker)):
    db = get_db()
    worker_id = user["id"]

    # Enforce 4-chat limit
    active_count = db.table("chat_sessions").select("id", count="exact").eq(
        "assigned_worker_id", worker_id
    ).eq("status", "human_active").execute()
    if (active_count.count or 0) >= 4:
        raise HTTPException(400, "You have reached the maximum of 4 active chats. Resolve one before accepting new sessions.")

    session = db.table("chat_sessions").select("*").eq("id", session_id).execute()
    if not session.data:
        raise HTTPException(404, "Session not found")

    if session.data[0]["status"] not in ("waiting_human", "ai_active"):
        raise HTTPException(400, "Session is not available for acceptance")

    now = datetime.now(timezone.utc).isoformat()
    db.table("chat_sessions").update({
        "assigned_worker_id": user["id"],
        "status": "human_active",
        "updated_at": now,
    }).eq("id", session_id).execute()

    # Mark worker as actively working (prevents auto-off-duty)
    db.table("users").update({
        "last_activity_at": now,
    }).eq("id", worker_id).execute()

    # Send professional system notification
    worker_name = user.get('name', 'Support Agent')
    db.table("chat_messages").insert({
        "session_id": session_id,
        "sender_type": "system",
        "message": f"✅ Agent {worker_name} joined the chat",
    }).execute()

    # Send worker greeting
    db.table("chat_messages").insert({
        "session_id": session_id,
        "sender_type": "worker",
        "sender_id": user["id"],
        "message": f"Hi! I'm {worker_name}. How can I help you today?",
    }).execute()

    return success_response(message="Session accepted")


# ── WORKER: Send reply in a session ───────────────────────────────
@router.post("/sessions/{session_id}/reply")
async def worker_reply(session_id: str, body: SendMessageBody, user: dict = Depends(get_current_worker)):
    db = get_db()

    # Verify session is assigned to this worker
    session = db.table("chat_sessions").select("*").eq("id", session_id).execute()
    if not session.data:
        raise HTTPException(404, "Session not found")

    now = datetime.now(timezone.utc).isoformat()
    msg = db.table("chat_messages").insert({
        "session_id": session_id,
        "sender_type": "worker",
        "sender_id": user["id"],
        "message": body.message,
    }).execute()

    db.table("chat_sessions").update({
        "updated_at": now,
    }).eq("id", session_id).execute()

    # Mark worker as actively working (prevents auto-off-duty)
    db.table("users").update({
        "last_activity_at": now,
    }).eq("id", user["id"]).execute()

    return success_response({"message": msg.data[0] if msg.data else None})


# ── WORKER: Resolve a session ─────────────────────────────────────
@router.post("/sessions/{session_id}/resolve")
async def resolve_session(session_id: str, user: dict = Depends(get_current_worker)):
    db = get_db()
    db.table("chat_sessions").update({
        "status": "resolved",
        "resolved_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", session_id).execute()

    db.table("chat_messages").insert({
        "session_id": session_id,
        "sender_type": "system",
        "message": "✅ This conversation has been resolved. Thank you for contacting support!",
    }).execute()

    return success_response(message="Session resolved")


# ── WORKER: Export & Archive selected resolved sessions ──────────────────
class ExportChatsBody(BaseModel):
    session_ids: List[str]


@router.post("/export")
async def export_chats(body: ExportChatsBody, user: dict = Depends(get_current_worker)):
    """Export selected resolved sessions as JSON archive, then delete them from DB."""
    db = get_db()
    if not body.session_ids:
        raise HTTPException(400, "No sessions selected")
    if len(body.session_ids) > 200:
        raise HTTPException(400, "Max 200 sessions per export")

    sessions_data = []
    for sid in body.session_ids:
        sess = db.table("chat_sessions").select("*").eq("id", sid).execute()
        if not sess.data:
            continue
        s = sess.data[0]
        msgs = db.table("chat_messages").select(
            "sender_type, sender_id, message, created_at"
        ).eq("session_id", sid).order("created_at", desc=False).execute()

        # Enrich with store info
        store_name = ""
        if s.get("merchant_id"):
            store = db.table("stores").select("store_name").eq("user_id", s["merchant_id"]).limit(1).execute()
            if store.data:
                store_name = store.data[0].get("store_name", "")

        sessions_data.append({
            "id": s["id"],
            "visitor_name": s.get("visitor_name", "Visitor"),
            "visitor_email": s.get("visitor_email"),
            "visitor_phone": s.get("visitor_phone"),
            "merchant_store_name": store_name,
            "source": s.get("source", "website"),
            "status": s.get("status"),
            "created_at": s.get("created_at"),
            "resolved_at": s.get("resolved_at"),
            "updated_at": s.get("updated_at"),
            "messages": [
                {
                    "sender_type": m["sender_type"],
                    "message": m["message"],
                    "created_at": m["created_at"],
                }
                for m in (msgs.data or [])
            ]
        })

    if not sessions_data:
        raise HTTPException(404, "No valid sessions found")

    import uuid, json
    archive = {
        "export_id": str(uuid.uuid4()),
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "exported_by": user.get("name", "Worker"),
        "exported_by_id": user.get("id"),
        "session_count": len(sessions_data),
        "sessions": sessions_data,
    }

    # Delete in FK order: api_usage → messages → sessions
    valid_ids = [s["id"] for s in sessions_data]
    for sid in valid_ids:
        db.table("chatbot_api_usage").delete().eq("session_id", sid).execute()
        db.table("chat_messages").delete().eq("session_id", sid).execute()
    db.table("chat_sessions").delete().in_("id", valid_ids).execute()

    now_str = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    filename = f"chat_archive_{now_str}_{archive['export_id'][:8]}.json"

    return JSONResponse(
        content=archive,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Type": "application/json",
        }
    )


# ── ADMIN: Export sessions from any worker ───────────────────────────────
admin_chat_router = APIRouter(prefix="/api/v1/admin/chat", tags=["Admin Chat"])


@admin_chat_router.post("/export")
async def admin_export_chats(body: ExportChatsBody, user: dict = Depends(get_current_admin)):
    """Admin export selected sessions as JSON archive, then delete from DB."""
    db = get_db()
    if not body.session_ids:
        raise HTTPException(400, "No sessions selected")
    if len(body.session_ids) > 200:
        raise HTTPException(400, "Max 200 sessions per export")

    sessions_data = []
    for sid in body.session_ids:
        sess = db.table("chat_sessions").select("*").eq("id", sid).execute()
        if not sess.data:
            continue
        s = sess.data[0]
        msgs = db.table("chat_messages").select(
            "sender_type, sender_id, message, created_at"
        ).eq("session_id", sid).order("created_at", desc=False).execute()

        store_name = ""
        if s.get("merchant_id"):
            store = db.table("stores").select("store_name").eq("user_id", s["merchant_id"]).limit(1).execute()
            if store.data:
                store_name = store.data[0].get("store_name", "")

        sessions_data.append({
            "id": s["id"],
            "visitor_name": s.get("visitor_name", "Visitor"),
            "visitor_email": s.get("visitor_email"),
            "visitor_phone": s.get("visitor_phone"),
            "merchant_store_name": store_name,
            "source": s.get("source", "website"),
            "status": s.get("status"),
            "created_at": s.get("created_at"),
            "resolved_at": s.get("resolved_at"),
            "updated_at": s.get("updated_at"),
            "messages": [
                {
                    "sender_type": m["sender_type"],
                    "message": m["message"],
                    "created_at": m["created_at"],
                }
                for m in (msgs.data or [])
            ]
        })

    if not sessions_data:
        raise HTTPException(404, "No valid sessions found")

    import uuid, json
    archive = {
        "export_id": str(uuid.uuid4()),
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "exported_by": user.get("name", "Admin"),
        "exported_by_id": user.get("id"),
        "session_count": len(sessions_data),
        "sessions": sessions_data,
    }

    # Delete in FK order: api_usage → messages → sessions
    valid_ids = [s["id"] for s in sessions_data]
    for sid in valid_ids:
        db.table("chatbot_api_usage").delete().eq("session_id", sid).execute()
        db.table("chat_messages").delete().eq("session_id", sid).execute()
    db.table("chat_sessions").delete().in_("id", valid_ids).execute()

    now_str = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    filename = f"chat_archive_{now_str}_{archive['export_id'][:8]}.json"

    return JSONResponse(
        content=archive,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Type": "application/json",
        }
    )


# ══════════════════════════════════════════════════════════════════
# PUBLIC ENDPOINTS (no auth) — For website chatbot widget
# ══════════════════════════════════════════════════════════════════

public_router = APIRouter(prefix="/api/v1/chat", tags=["Public Chat"])


class StartChatBody(BaseModel):
    visitor_name: Optional[str] = "Visitor"
    visitor_email: Optional[str] = None
    message: str


class VisitorMessageBody(BaseModel):
    message: str


@public_router.post("/start")
async def start_chat(body: StartChatBody):
    """Start a new chat session — AI responds first."""
    db = get_db()

    # Create session
    session = db.table("chat_sessions").insert({
        "visitor_name": body.visitor_name or "Visitor",
        "visitor_email": body.visitor_email,
        "status": "ai_active",
        "source": "website",
    }).execute()

    if not session.data:
        raise HTTPException(500, "Failed to create chat session")

    session_id = session.data[0]["id"]

    # Save visitor message
    db.table("chat_messages").insert({
        "session_id": session_id,
        "sender_type": "visitor",
        "message": body.message,
    }).execute()

    # Get AI response
    ai_result = await get_ai_response([{"sender_type": "visitor", "message": body.message}])

    # Save AI response
    db.table("chat_messages").insert({
        "session_id": session_id,
        "sender_type": "ai",
        "message": ai_result["message"],
    }).execute()

    # If handoff requested, update session status
    if ai_result["handoff_requested"]:
        db.table("chat_sessions").update({
            "status": "waiting_human",
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }).eq("id", session_id).execute()

    return success_response({
        "session_id": session_id,
        "ai_response": ai_result["message"],
        "handoff_requested": ai_result["handoff_requested"],
    })


@public_router.post("/sessions/{session_id}/message")
async def visitor_message(session_id: str, body: VisitorMessageBody):
    """Visitor sends a message in existing session."""
    db = get_db()

    session = db.table("chat_sessions").select("*").eq("id", session_id).execute()
    if not session.data:
        raise HTTPException(404, "Session not found")

    session_data = session.data[0]

    # Save visitor message
    db.table("chat_messages").insert({
        "session_id": session_id,
        "sender_type": "visitor",
        "message": body.message,
    }).execute()

    # If AI is active, get AI response
    if session_data["status"] == "ai_active":
        # Get conversation history
        history = db.table("chat_messages").select("sender_type, message").eq(
            "session_id", session_id
        ).order("created_at", desc=False).execute()

        ai_result = await get_ai_response(history.data or [])

        # Save AI response
        db.table("chat_messages").insert({
            "session_id": session_id,
            "sender_type": "ai",
            "message": ai_result["message"],
        }).execute()

        if ai_result["handoff_requested"]:
            db.table("chat_sessions").update({
                "status": "waiting_human",
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }).eq("id", session_id).execute()

        return success_response({
            "ai_response": ai_result["message"],
            "handoff_requested": ai_result["handoff_requested"],
            "status": "waiting_human" if ai_result["handoff_requested"] else "ai_active",
        })

    # If human active or waiting, just confirm message was sent
    db.table("chat_sessions").update({
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", session_id).execute()

    return success_response({
        "status": session_data["status"],
        "message_sent": True,
    })


@public_router.get("/sessions/{session_id}/messages")
async def get_visitor_messages(session_id: str):
    """Get all messages for a session (public, for chat widget polling)."""
    db = get_db()
    messages = db.table("chat_messages").select(
        "id, sender_type, message, created_at"
    ).eq("session_id", session_id).order("created_at", desc=False).execute()

    session = db.table("chat_sessions").select("status").eq("id", session_id).execute()
    status = session.data[0]["status"] if session.data else "unknown"

    return success_response({
        "messages": messages.data or [],
        "session_status": status,
    })


# ─────────────────────────────────────────────────────────────────────────────
# CHAT EXPORT SYSTEM
# ─────────────────────────────────────────────────────────────────────────────

import json as _json
from fastapi.responses import Response as _Response

# Separate router for admin-level chat endpoints
admin_chat_router = APIRouter(prefix="/api/v1/admin/chat", tags=["Admin Chat"])


class ExportChatsBody(BaseModel):
    session_ids: List[str]


@router.post("/export")
async def worker_export_chats(
    body: ExportChatsBody,
    user: dict = Depends(get_current_worker),
):
    """
    Worker exports selected resolved chat sessions.
    - Bundles messages + metadata into a JSON blob
    - Deletes the sessions (and cascade messages) from DB after export
    - Returns the JSON file as a download
    """
    db = get_db()
    worker_id = user["id"]

    if not body.session_ids:
        raise HTTPException(status_code=400, detail="No session IDs provided")

    sessions_out = []

    for sid in body.session_ids:
        # Verify session belongs to this worker and is resolved
        sess_res = db.table("chat_sessions").select("*").eq("id", sid).eq(
            "assigned_worker_id", worker_id
        ).execute()
        if not sess_res.data:
            continue  # Skip sessions not owned by this worker

        sess = sess_res.data[0]

        # Fetch messages
        msgs_res = db.table("chat_messages").select(
            "sender_type, message, created_at"
        ).eq("session_id", sid).order("created_at", desc=False).execute()

        sessions_out.append({
            "id": sid,
            "status": sess.get("status"),
            "visitor_name": sess.get("visitor_name"),
            "visitor_email": sess.get("visitor_email"),
            "merchant_id": sess.get("merchant_id"),
            "created_at": sess.get("created_at"),
            "updated_at": sess.get("updated_at"),
            "messages": msgs_res.data or [],
        })

        # Delete messages first (FK constraint), then session
        db.table("chat_messages").delete().eq("session_id", sid).execute()
        db.table("chat_sessions").delete().eq("id", sid).execute()

    if not sessions_out:
        raise HTTPException(status_code=404, detail="No valid sessions found to export")

    export_payload = {
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "exported_by": worker_id,
        "session_count": len(sessions_out),
        "sessions": sessions_out,
    }

    filename = f"chat_archive_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json"
    content = _json.dumps(export_payload, ensure_ascii=False, indent=2)

    return _Response(
        content=content,
        media_type="application/json",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@admin_chat_router.post("/export")
async def admin_export_chats(
    body: ExportChatsBody,
    user: dict = Depends(get_current_admin),
):
    """
    Admin exports any resolved chat sessions by ID.
    Same logic as worker export but no worker_id restriction.
    """
    db = get_db()

    if not body.session_ids:
        raise HTTPException(status_code=400, detail="No session IDs provided")

    sessions_out = []

    for sid in body.session_ids:
        sess_res = db.table("chat_sessions").select("*").eq("id", sid).execute()
        if not sess_res.data:
            continue

        sess = sess_res.data[0]
        msgs_res = db.table("chat_messages").select(
            "sender_type, message, created_at"
        ).eq("session_id", sid).order("created_at", desc=False).execute()

        sessions_out.append({
            "id": sid,
            "status": sess.get("status"),
            "visitor_name": sess.get("visitor_name"),
            "visitor_email": sess.get("visitor_email"),
            "merchant_id": sess.get("merchant_id"),
            "assigned_worker_id": sess.get("assigned_worker_id"),
            "created_at": sess.get("created_at"),
            "updated_at": sess.get("updated_at"),
            "messages": msgs_res.data or [],
        })

        db.table("chat_messages").delete().eq("session_id", sid).execute()
        db.table("chat_sessions").delete().eq("id", sid).execute()

    if not sessions_out:
        raise HTTPException(status_code=404, detail="No valid sessions found to export")

    export_payload = {
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "exported_by_admin": user["id"],
        "session_count": len(sessions_out),
        "sessions": sessions_out,
    }

    filename = f"admin_chat_archive_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json"
    content = _json.dumps(export_payload, ensure_ascii=False, indent=2)

    return _Response(
        content=content,
        media_type="application/json",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )
