"""Worker order verification & tracking endpoints."""
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone, timedelta
from loguru import logger
from config.database import get_db
from middleware.auth import get_current_worker
from utils.helpers import success_response
from services.order_processing import update_store_order
from services.notification_service import create_notification

router = APIRouter(prefix="/api/v1/worker/orders", tags=["Worker Orders"])

# ── Active-workers endpoint (team presence) ───────────────────────────────
_active_workers_router = APIRouter(prefix="/api/v1/worker", tags=["Worker"])

@_active_workers_router.get("/active-workers")
async def get_active_workers(user: dict = Depends(get_current_worker)):
    """List all currently online/break workers for team coordination."""
    db = get_db()
    workers = db.table("users").select(
        "id, name, email, duty_status, last_heartbeat, current_duty_start, total_duty_seconds"
    ).eq("role", "worker").in_("duty_status", ["on_duty", "break"]).execute()

    now = datetime.now(timezone.utc)
    result = []
    for w in (workers.data or []):
        # Compute current session seconds
        session_seconds = 0
        if w.get("current_duty_start"):
            try:
                start = datetime.fromisoformat(w["current_duty_start"].replace("Z", "+00:00"))
                session_seconds = int((now - start).total_seconds())
            except Exception:
                pass
        result.append({
            "id": w["id"],
            "name": w.get("name", ""),
            "email": w.get("email", ""),
            "duty_status": w.get("duty_status", "off_duty"),
            "session_seconds": session_seconds,
            "last_heartbeat": w.get("last_heartbeat"),
        })

    return success_response({"workers": result, "total": len(result)})

# export this so main.py can register it
active_workers_router = _active_workers_router


class VerifyOrderBody(BaseModel):
    call_status: str  # answered, not_picked, cancel, callback
    call_notes: Optional[str] = ""
    call_duration_seconds: Optional[int] = 0


@router.get("/pending")
async def get_pending_orders(
    store_id: str = None,
    page: int = 1,
    limit: int = 100,
    user: dict = Depends(get_current_worker),
):
    """Get pending COD orders that need verification calls.
    Only shows orders from merchants who have cod_verification_enabled=True.
    """
    db = get_db()
    offset = (page - 1) * limit

    # Get list of merchants who have COD verification enabled
    # Default is True — only exclude if explicitly set to False
    ms_res = db.table("merchant_settings").select("user_id, cod_verification_enabled").execute()
    excluded_user_ids = [
        row["user_id"] for row in (ms_res.data or [])
        if row.get("cod_verification_enabled") is False
    ]

    query = db.table("orders").select(
        "id, user_id, store_id, store_order_id, order_number, customer_name, customer_phone, "
        "customer_email, customer_address, order_amount, currency, verification_status, "
        "order_type, payment_method, created_at"
    ).in_("verification_status", [
        "pending",          # not yet sent / WA send failed — needs manual call
        "queued",           # sent to WA, awaiting delivery
        "sent",             # WA delivered
        "delivered",        # customer received
        "read",             # customer read but hasn't replied
        "not_on_whatsapp",  # customer not on WA — needs phone call
        "failed",           # WhatsApp delivery failed automatically — worker will verify
    ]).order("created_at", desc=False).range(offset, offset + limit - 1)

    # Exclude customer-support-only merchants
    if excluded_user_ids:
        query = query.not_.in_("user_id", excluded_user_ids)

    if store_id and store_id != "undefined":
        query = query.eq("store_id", store_id)

    orders = query.execute()

    # Get claimed order ids for this batch
    order_ids = [o["id"] for o in (orders.data or [])]
    claims_map: dict = {}
    if order_ids:
        claims = db.table("order_verifications").select(
            "order_id, worker_id"
        ).eq("call_status", "claimed").in_("order_id", order_ids).execute()
        for c in (claims.data or []):
            claims_map[c["order_id"]] = c["worker_id"]

    # Enrich with merchant info
    enriched = []
    merchant_cache = {}
    for o in (orders.data or []):
        uid = o.get("user_id")
        if uid and uid not in merchant_cache:
            m = db.table("users").select("name, email, company_name").eq("id", uid).execute()
            merchant_cache[uid] = m.data[0] if m.data else {}
            store = db.table("stores").select("store_name, platform, store_url").eq("user_id", uid).limit(1).execute()
            merchant_cache[uid]["store"] = store.data[0] if store.data else {}

        merchant = merchant_cache.get(uid, {})
        claimed_by = claims_map.get(o["id"])
        enriched.append({
            **o,
            "claimed_by_worker_id": claimed_by,
            "claimed_by_me": claimed_by == user["id"],
            "merchant": {
                "name": merchant.get("name", ""),
                "company_name": merchant.get("company_name", ""),
                "store_name": merchant.get("store", {}).get("store_name", ""),
                "platform": merchant.get("store", {}).get("platform", ""),
                "domain": merchant.get("store", {}).get("store_url", ""),
            },
        })

    return success_response({"orders": enriched, "total": len(enriched)})


@router.get("/all")
async def get_all_orders(
    order_type: str = None,
    status: str = None,
    page: int = 1,
    limit: int = 50,
    search: str = None,
    user: dict = Depends(get_current_worker),
):
    """Get ALL orders (COD + prepaid + manual) with tracking info for worker dashboard."""
    db = get_db()
    offset = (page - 1) * limit

    query = db.table("orders").select(
        "id, user_id, store_id, store_order_id, order_number, customer_name, customer_phone, "
        "customer_email, customer_address, order_amount, currency, verification_status, "
        "order_type, payment_method, payment_status, fulfillment_status, "
        "tracking_number, tracking_url, tracking_company, delivery_status, delivery_updated_at, "
        "source, tags, notes, created_at",
        count="exact"
    )

    if order_type:
        query = query.eq("order_type", order_type)
    if status:
        query = query.eq("verification_status", status)
    if search:
        query = query.or_(f"customer_name.ilike.%{search}%,order_number.ilike.%{search}%,customer_phone.ilike.%{search}%")

    result = query.order("created_at", desc=True).range(offset, offset + limit - 1).execute()

    # Enrich with merchant/store info
    enriched = []
    merchant_cache = {}
    for o in (result.data or []):
        uid = o.get("user_id")
        if uid and uid not in merchant_cache:
            m = db.table("users").select("name, email, company_name, shopify_shop_domain").eq("id", uid).execute()
            merchant_cache[uid] = m.data[0] if m.data else {}
            store = db.table("stores").select("store_name, platform, store_url").eq("user_id", uid).limit(1).execute()
            merchant_cache[uid]["store"] = store.data[0] if store.data else {}

        merchant = merchant_cache.get(uid, {})
        enriched.append({
            **o,
            "merchant": {
                "name": merchant.get("name", ""),
                "company_name": merchant.get("company_name", ""),
                "store_name": merchant.get("store", {}).get("store_name", "") or merchant.get("company_name", ""),
                "platform": merchant.get("store", {}).get("platform", ""),
                "domain": merchant.get("store", {}).get("store_url", "") or merchant.get("shopify_shop_domain", ""),
            },
        })

    return success_response({
        "orders": enriched,
        "total": result.count or 0,
        "page": page,
        "limit": limit,
    })


@router.get("/{order_id}/tracking")
async def get_order_tracking(order_id: str, user: dict = Depends(get_current_worker)):
    """Get detailed tracking info for a specific order."""
    db = get_db()
    order = db.table("orders").select(
        "id, store_order_id, order_number, customer_name, customer_phone, customer_email, "
        "customer_address, order_amount, currency, order_type, payment_method, payment_status, "
        "fulfillment_status, verification_status, tracking_number, tracking_url, tracking_company, "
        "delivery_status, delivery_updated_at, products_json, shipping_address_json, "
        "source, tags, notes, created_at, user_id"
    ).eq("id", order_id).execute()

    if not order.data:
        raise HTTPException(404, "Order not found")

    order_data = order.data[0]
    uid = order_data.get("user_id")

    # Get merchant/store info
    merchant_info = {}
    if uid:
        m = db.table("users").select("name, email, company_name, shopify_shop_domain").eq("id", uid).execute()
        store = db.table("stores").select("store_name, platform, store_url").eq("user_id", uid).limit(1).execute()
        merchant_info = {
            "name": m.data[0].get("name", "") if m.data else "",
            "company_name": m.data[0].get("company_name", "") if m.data else "",
            "store_name": (store.data[0].get("store_name", "") if store.data else "") or (m.data[0].get("company_name", "") if m.data else ""),
            "domain": (store.data[0].get("store_url", "") if store.data else "") or (m.data[0].get("shopify_shop_domain", "") if m.data else ""),
        }

    # Get verification history
    verifications = db.table("order_verifications").select("*").eq("order_id", order_id).order("created_at", desc=True).execute()

    return success_response({
        "order": order_data,
        "merchant": merchant_info,
        "verifications": verifications.data or [],
    })


@router.get("/verified")
async def get_verified_orders(user: dict = Depends(get_current_worker)):
    """Get orders verified by this worker today."""
    db = get_db()
    today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0).isoformat()

    verifications = db.table("order_verifications").select("*").eq(
        "worker_id", user["id"]
    ).gte("created_at", today).order("created_at", desc=True).limit(50).execute()

    return success_response({"verifications": verifications.data or []})


@router.post("/{order_id}/verify")
async def verify_order(order_id: str, body: VerifyOrderBody, user: dict = Depends(get_current_worker)):
    """Record verification call result for an order."""
    db = get_db()

    # Get order details
    order = db.table("orders").select("*").eq("id", order_id).execute()
    if not order.data:
        raise HTTPException(404, "Order not found")

    order_data = order.data[0]

    # Map call_status to verification_status
    status_map = {
        "answered": "confirmed",
        "not_picked": "no_response",
        "cancel": "cancelled",
        "callback": "pending",
    }
    new_status = status_map.get(body.call_status, "pending")

    # Update order verification status
    db.table("orders").update({
        "verification_status": new_status,
        "response_received_at": datetime.now(timezone.utc).isoformat() if body.call_status != "callback" else None,
    }).eq("id", order_id).execute()

    # Create verification record
    verification = db.table("order_verifications").insert({
        "order_id": order_id,
        "worker_id": user["id"],
        "merchant_id": order_data.get("user_id"),
        "customer_name": order_data.get("customer_name", ""),
        "customer_phone": order_data.get("customer_phone", ""),
        "customer_address": order_data.get("customer_address", ""),
        "order_amount": order_data.get("order_amount"),
        "call_status": body.call_status,
        "call_notes": body.call_notes or "",
        "call_duration_seconds": body.call_duration_seconds or 0,
    }).execute()

    # Sync status back to Shopify/WooCommerce store
    if new_status in ("confirmed", "cancelled"):
        try:
            await update_store_order(order_data, new_status)
        except Exception as e:
            logger.warning(f"Store sync failed for order {order_id}: {e}")

    # Notify merchant about verification result
    order_num = order_data.get('order_number', order_id)
    if new_status == "confirmed":
        await create_notification(
            order_data.get("user_id"),
            f"Order #{order_num} Confirmed ✅",
            f"Worker {user.get('name', '')} confirmed via call.",
            "success", "orders", f"/dashboard/orders/{order_id}"
        )
    elif new_status == "cancelled":
        await create_notification(
            order_data.get("user_id"),
            f"Order #{order_num} Cancelled ❌",
            f"Customer cancelled during verification call.",
            "error", "orders", f"/dashboard/orders/{order_id}"
        )
    elif new_status == "no_response":
        await create_notification(
            order_data.get("user_id"),
            f"Order #{order_num} — No Response 📞",
            f"Customer did not pick up the call.",
            "warning", "orders", f"/dashboard/orders/{order_id}"
        )

    return success_response(
        {"verification": verification.data[0] if verification.data else None},
        f"Order #{order_num} marked as {body.call_status}"
    )


# ── Order claim / release ─────────────────────────────────────────────────

@router.post("/{order_id}/claim")
async def claim_order(order_id: str, user: dict = Depends(get_current_worker)):
    """Claim an order to coordinate with teammates and avoid double-verification."""
    db = get_db()
    worker_id = user["id"]

    # Verify order exists and get merchant_id
    order = db.table("orders").select("id, user_id").eq("id", order_id).execute()
    if not order.data:
        raise HTTPException(status_code=404, detail="Order not found")
    merchant_id = order.data[0].get("user_id")

    # Check if already claimed by someone else
    existing = db.table("order_verifications").select("worker_id").eq(
        "order_id", order_id
    ).eq("call_status", "claimed").execute()

    if existing.data:
        claimer = existing.data[0].get("worker_id")
        if claimer != worker_id:
            return JSONResponse(status_code=409, content={
                "success": False,
                "message": "Order already claimed by another worker",
                "claimed_by_worker_id": claimer,
            })
        # Already claimed by this worker — idempotent OK
        return success_response({"claimed": True}, "Order already claimed by you")

    db.table("order_verifications").insert({
        "order_id": order_id,
        "worker_id": worker_id,
        "merchant_id": merchant_id,
        "call_status": "claimed",
        "call_notes": "",
        "call_duration_seconds": 0,
    }).execute()

    return success_response({"claimed": True}, "Order claimed successfully")


@router.post("/{order_id}/release")
async def release_order(order_id: str, user: dict = Depends(get_current_worker)):
    """Release a previously claimed order back to the queue."""
    db = get_db()
    db.table("order_verifications").delete().eq(
        "order_id", order_id
    ).eq("worker_id", user["id"]).eq("call_status", "claimed").execute()
    return success_response({}, "Order released successfully")
