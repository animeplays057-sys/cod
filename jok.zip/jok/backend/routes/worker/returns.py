"""
Return & Refund Requests — Worker API
Workers see ALL return requests (across all merchants)
so they can process them. Full website + order + customer context shown.
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone
from config.database import get_db
from middleware.auth import get_current_worker
from utils.helpers import success_response, paginate_params, pagination_meta

router = APIRouter(prefix="/api/v1/worker/returns", tags=["Worker Returns"])


class WorkerUpdateReturn(BaseModel):
    status: str
    worker_notes: Optional[str] = None


@router.get("")
async def list_all_returns_worker(
    page: int = 1,
    limit: int = 20,
    status: Optional[str] = None,
    request_type: Optional[str] = None,
    search: Optional[str] = None,
    worker: dict = Depends(get_current_worker),
):
    """Workers see all return requests across all merchants with full context."""
    db = get_db()
    offset, limit = paginate_params(page, limit)

    query = db.table("return_requests").select("*", count="exact")

    if status:
        query = query.eq("status", status)
    if request_type:
        query = query.eq("request_type", request_type)
    if search:
        query = query.or_(
            f"order_number.ilike.%{search}%,"
            f"customer_name.ilike.%{search}%,"
            f"customer_email.ilike.%{search}%,"
            f"store_url.ilike.%{search}%,"
            f"store_name.ilike.%{search}%"
        )

    result = (
        query.order("created_at", desc=True)
        .range(offset, offset + limit - 1)
        .execute()
    )

    return success_response({
        "returns": result.data or [],
        "pagination": pagination_meta(result.count or 0, page, limit),
    })


@router.get("/stats")
async def worker_return_stats(worker: dict = Depends(get_current_worker)):
    """Quick badge counts for worker dashboard."""
    db = get_db()
    rows = db.table("return_requests").select("status, request_type").execute().data or []
    stats = {
        "total": len(rows),
        "pending": 0, "approved": 0, "rejected": 0, "completed": 0,
        "returns": 0, "refunds": 0,
    }
    for r in rows:
        s = r.get("status", "pending")
        if s in stats:
            stats[s] += 1
        if r.get("request_type") == "return":
            stats["returns"] += 1
        elif r.get("request_type") == "refund":
            stats["refunds"] += 1
    return success_response(stats)


@router.get("/{return_id}")
async def get_return_detail_worker(return_id: str, worker: dict = Depends(get_current_worker)):
    """Full detail of any return request — worker can view all."""
    db = get_db()
    result = db.table("return_requests").select("*").eq("id", return_id).execute()
    if not result.data:
        raise HTTPException(404, "Return request not found")
    return success_response({"return": result.data[0]})


@router.put("/{return_id}")
async def worker_update_return(
    return_id: str,
    body: WorkerUpdateReturn,
    worker: dict = Depends(get_current_worker),
):
    """Worker approves / rejects / completes a return request."""
    valid_statuses = {"approved", "rejected", "completed"}
    if body.status not in valid_statuses:
        raise HTTPException(400, f"Invalid status. Must be one of: {valid_statuses}")

    db = get_db()
    existing = db.table("return_requests").select("id").eq("id", return_id).execute()
    if not existing.data:
        raise HTTPException(404, "Return request not found")

    updates = {
        "status": body.status,
        "resolved_by": worker["id"],
        "resolved_at": datetime.now(timezone.utc).isoformat(),
    }
    if body.worker_notes is not None:
        updates["worker_notes"] = body.worker_notes

    db.table("return_requests").update(updates).eq("id", return_id).execute()
    return success_response(message=f"Return request updated to '{body.status}'")
