"""Worker stores endpoint — list all active merchant stores with order queue stats."""
from fastapi import APIRouter, Depends
from datetime import datetime, timezone
from config.database import get_db
from middleware.auth import get_current_worker
from utils.helpers import success_response

router = APIRouter(prefix="/api/v1/worker/stores", tags=["Worker Stores"])


@router.get("")
async def get_worker_stores(user: dict = Depends(get_current_worker)):
    """Get all active merchant stores with pending order counts for the assignment queue."""
    db = get_db()

    # All active stores
    stores_result = db.table("stores").select(
        "id, store_name, platform, store_url, is_active, user_id, updated_at"
    ).eq("is_active", True).order("updated_at", desc=False).execute()

    merchant_cache: dict = {}
    result = []

    for store in (stores_result.data or []):
        uid = store.get("user_id")
        if uid and uid not in merchant_cache:
            m = db.table("users").select("id, name, company_name, shopify_shop_domain, account_status").eq("id", uid).execute()
            merchant_cache[uid] = m.data[0] if m.data else {}

        merchant = merchant_cache.get(uid, {})

        # Order counts per store
        pending = db.table("orders").select("id", count="exact").eq("store_id", store["id"]).in_(
            "verification_status", ["pending", "sent"]
        ).execute()
        confirmed_today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
        confirmed = db.table("orders").select("id", count="exact").eq("store_id", store["id"]).eq(
            "verification_status", "confirmed"
        ).gte("created_at", confirmed_today_start).execute()
        total = db.table("orders").select("id", count="exact").eq("store_id", store["id"]).gte(
            "created_at", confirmed_today_start
        ).execute()

        result.append({
            "store_id": store["id"],
            "store_name": store.get("store_name") or merchant.get("company_name", ""),
            "platform": store.get("platform", "shopify"),
            "domain": store.get("store_url") or merchant.get("shopify_shop_domain", ""),
            "is_active": store.get("is_active", True),
            "merchant_id": uid,
            "merchant_name": merchant.get("company_name") or merchant.get("name", ""),
            "merchant_status": merchant.get("account_status", "active"),
            "pending_orders": pending.count or 0,
            "confirmed_today": confirmed.count or 0,
            "total_today": total.count or 0,
        })

    # Sort: most pending orders first
    result.sort(key=lambda x: x["pending_orders"], reverse=True)

    return success_response({
        "stores": result,
        "total": len(result),
        "total_pending": sum(s["pending_orders"] for s in result),
    })
