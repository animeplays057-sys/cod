"""
Email service for CODVerify.
Domain: codverify.tech
Uses Google Apps Script webhook (HTTP POST) to send emails.
Works on HuggingFace Spaces / Render where SMTP ports may be restricted.

--- Google Apps Script Setup (UPDATED — supports PDF attachments) ---
1. Go to script.google.com → New Project
2. Paste the code below as doPost function
3. Deploy as Web App → Anyone can access
4. Copy the deployment URL
5. Set EMAIL_WEBHOOK_URL in your environment secrets

function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents);
    var options = {
      htmlBody: data.htmlBody,
      name: 'CODVerify'
    };
    // Handle attachments (base64 encoded PDFs)
    if (data.attachments && data.attachments.length > 0) {
      var blobs = [];
      for (var i = 0; i < data.attachments.length; i++) {
        var att = data.attachments[i];
        var decoded = Utilities.base64Decode(att.content);
        var blob = Utilities.newBlob(decoded, att.mimeType, att.filename);
        blobs.push(blob);
      }
      options.attachments = blobs;
    }
    GmailApp.sendEmail(data.to, data.subject, '', options);
    return ContentService.createTextOutput(JSON.stringify({status: 'ok'}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    return ContentService.createTextOutput(JSON.stringify({status: 'error', message: err.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
"""

import threading
import logging
from datetime import datetime, timezone

import httpx
from loguru import logger

from config.settings import settings

_DOMAIN = "codverify.tech"
_BRAND_NAME = "CODVerify"


# ─── Core Webhook Sender ────────────────────────────────────────────────────

def _is_configured() -> bool:
    """Check if SMTP email sending is properly configured."""
    return bool(
        getattr(settings, 'SMTP_HOST', None) and
        getattr(settings, 'SMTP_USER', None) and
        getattr(settings, 'SMTP_PASSWORD', None)
    )


def _frontend_url() -> str:
    return getattr(settings, 'FRONTEND_URL', f'https://{_DOMAIN}')


def _send_email_async(to_email: str, subject: str, html_body: str, attachments: list = None):
    """Send email via direct SMTP (Gmail or any SMTP server) in a background thread.

    Uses settings.SMTP_* variables:
        SMTP_HOST        e.g. smtp.gmail.com
        SMTP_PORT        587 (STARTTLS) or 465 (SSL)
        SMTP_USER        sender email
        SMTP_PASSWORD    Gmail App Password (16 chars) or SMTP password
        SMTP_FROM_EMAIL  sender email (defaults to SMTP_USER)
        SMTP_FROM_NAME   sender display name (default: CODVerify)

    attachments: list of dicts with keys:
        filename  — attachment filename (e.g. "Invoice-COD-xxx.pdf")
        mimeType  — MIME type (e.g. "application/pdf")
        content   — base64-encoded file contents (str)
    """
    import smtplib
    import base64 as _b64
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email import encoders as _enc

    def _send():
        try:
            smtp_host     = settings.SMTP_HOST or "smtp.gmail.com"
            smtp_port     = settings.SMTP_PORT or 587
            smtp_user     = settings.SMTP_USER
            smtp_password = settings.SMTP_PASSWORD
            from_email    = settings.SMTP_FROM_EMAIL or smtp_user
            from_name     = settings.SMTP_FROM_NAME or "CODVerify"

            if not smtp_user or not smtp_password:
                logger.error("SMTP_USER / SMTP_PASSWORD not configured — email not sent")
                return

            # Build message
            msg = MIMEMultipart("mixed")
            msg["Subject"] = subject
            msg["From"]    = f"{from_name} <{from_email}>"
            msg["To"]      = to_email

            # HTML body
            msg.attach(MIMEText(html_body, "html", "utf-8"))

            # Attachments
            att_count = 0
            if attachments:
                for att in attachments:
                    try:
                        raw = _b64.b64decode(att["content"])
                        part = MIMEBase(*att.get("mimeType", "application/octet-stream").split("/", 1))
                        part.set_payload(raw)
                        _enc.encode_base64(part)
                        part.add_header(
                            "Content-Disposition",
                            "attachment",
                            filename=att["filename"],
                        )
                        msg.attach(part)
                        att_count += 1
                    except Exception as att_err:
                        logger.warning(f"Attachment failed [{att.get('filename')}]: {att_err}")

            # Send via SMTP
            if smtp_port == 465:
                # SSL
                import ssl as _ssl
                ctx = _ssl.create_default_context()
                with smtplib.SMTP_SSL(smtp_host, smtp_port, context=ctx, timeout=30) as server:
                    server.login(smtp_user, smtp_password)
                    server.send_message(msg)
            else:
                # STARTTLS (587 or 25)
                with smtplib.SMTP(smtp_host, smtp_port, timeout=30) as server:
                    server.ehlo()
                    server.starttls()
                    server.ehlo()
                    server.login(smtp_user, smtp_password)
                    server.send_message(msg)

            att_info = f" + {att_count} attachment(s)" if att_count else ""
            logger.info(f"Email sent OK via SMTP | to: {to_email}{att_info}")

        except Exception as e:
            logger.error(f"SMTP email failed | to: {to_email} | error: {e}")

    thread = threading.Thread(target=_send, daemon=True)
    thread.start()



# ─── HTML Design System ──────────────────────────────────────────────────────

_BASE_STYLE = """
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
  * { margin:0; padding:0; box-sizing:border-box; }
  body {
    margin:0; padding:0;
    background:#F0F4FF;
    font-family:'Inter',Arial,sans-serif;
    -webkit-font-smoothing:antialiased;
  }
  .email-wrapper {
    width:100% !important;
    background:#F0F4FF;
    padding:32px 0;
    margin:0 auto;
  }
  .card {
    max-width:580px;
    width:92% !important;
    margin:0 auto;
    background:#FFFFFF;
    border-radius:20px;
    border:1px solid #E0E7FF;
    overflow:hidden;
    box-shadow:0 8px 40px rgba(79,70,229,0.10);
    /* Centering via margin auto on table */
  }

  /* Header */
  .header {
    background:linear-gradient(135deg, #4338CA 0%, #6366F1 50%, #818CF8 100%);
    padding:36px 32px 32px;
    text-align:center;
  }
  .logo-mark {
    margin-bottom:16px;
  }
  .logo-text {
    font-size:20px;
    font-weight:800;
    color:#FFFFFF;
    letter-spacing:-0.5px;
    display:inline-block;
  }
  .logo-text span { color:#C7D2FE; }
  .header-title {
    font-size:24px;
    font-weight:700;
    color:#FFFFFF;
    letter-spacing:-0.5px;
    margin-bottom:8px;
    line-height:1.3;
  }
  .header-subtitle {
    font-size:14px;
    color:rgba(255,255,255,0.80);
    font-weight:400;
  }

  /* Body */
  .body { padding:36px 32px; color:#374151; font-size:15px; line-height:1.75; }
  .greeting { font-size:20px; font-weight:700; color:#111827; margin-bottom:12px; }
  .body p { color:#4B5563; font-size:14px; line-height:1.75; margin-bottom:12px; }

  /* Info Card — TABLE based for email clients */
  .info-card {
    background:#F8FAFF;
    border:1.5px solid #E0E7FF;
    border-radius:14px;
    overflow:hidden;
    margin:20px 0;
    width:100%;
    border-collapse:collapse;
  }
  .info-row {
    border-bottom:1px solid #EEF0FF;
    padding:12px 18px;
  }
  .info-row:last-child { border-bottom:none; }
  .info-label {
    color:#6B7280;
    font-size:13px;
    font-weight:500;
    display:block;
    padding-bottom:1px;
  }
  .info-value {
    color:#111827;
    font-weight:600;
    font-size:13px;
    display:block;
    word-break:break-word;
  }

  /* Buttons */
  .btn-wrap { text-align:center; margin:28px 0; }
  .btn {
    display:inline-block;
    background:linear-gradient(135deg, #4338CA, #6366F1);
    color:#FFFFFF !important;
    padding:14px 40px;
    border-radius:50px;
    text-decoration:none;
    font-weight:700;
    font-size:15px;
    letter-spacing:0.3px;
    box-shadow:0 4px 16px rgba(99,102,241,0.35);
  }

  /* Alert boxes */
  .alert {
    border-radius:12px;
    padding:16px 18px;
    margin:16px 0;
    font-size:13px;
    font-weight:500;
    line-height:1.6;
  }
  .alert-success { background:#ECFDF5; border:1.5px solid #A7F3D0; color:#065F46; }
  .alert-warning { background:#FFFBEB; border:1.5px solid #FDE68A; color:#92400E; }
  .alert-error   { background:#FEF2F2; border:1.5px solid #FECACA; color:#991B1B; }
  .alert-info    { background:#EFF6FF; border:1.5px solid #BFDBFE; color:#1E40AF; }

  /* Tags */
  .tag {
    display:inline-block;
    padding:3px 10px;
    border-radius:20px;
    font-size:11px;
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:0.08em;
  }
  .tag-confirmed  { background:#D1FAE5; color:#065F46; }
  .tag-cancelled  { background:#FEE2E2; color:#991B1B; }
  .tag-pending    { background:#FEF3C7; color:#92400E; }
  .tag-low        { background:#FFF7ED; color:#9A3412; }

  /* Divider */
  .divider { height:1px; background:#F3F4F6; margin:20px 0; }

  /* Invoice table */
  .invoice-table { width:100%; border-collapse:collapse; margin:16px 0; }
  .invoice-table th { background:#F8FAFF; padding:10px 14px; text-align:left; font-size:11px; font-weight:700; color:#6B7280; text-transform:uppercase; letter-spacing:0.08em; border-bottom:2px solid #E0E7FF; }
  .invoice-table td { padding:10px 14px; font-size:13px; color:#374151; border-bottom:1px solid #F3F4F6; }
  .invoice-table tr:last-child td { border-bottom:none; }
  .invoice-total { background:#F0F4FF; font-weight:700; }
  .invoice-total td { color:#111827; font-size:14px; }

  /* Footer */
  .footer {
    padding:24px 32px;
    text-align:center;
    border-top:1px solid #F3F4F6;
    background:#FAFBFF;
  }
  .footer-brand { font-size:14px; font-weight:700; color:#4338CA; margin-bottom:6px; }
  .footer p { margin:4px 0; color:#9CA3AF; font-size:11px; }
  .footer a { color:#6366F1; text-decoration:none; font-weight:500; }
  .footer-links { margin-top:10px; }
  .footer-links a { margin:0 6px; }
  .footer-copy { margin-top:8px; color:#D1D5DB; font-size:10px; }

  /* ── Mobile responsive ── */
  @media only screen and (max-width: 600px) {
    .email-wrapper { padding:16px 0 !important; }
    .card { width:96% !important; border-radius:16px !important; }
    .header { padding:24px 20px 20px !important; }
    .header-title { font-size:20px !important; }
    .header-subtitle { font-size:12px !important; }
    .logo-text { font-size:17px !important; }
    .body { padding:20px 16px !important; font-size:14px !important; }
    .greeting { font-size:18px !important; }
    .body p { font-size:13px !important; line-height:1.7 !important; }
    .info-row { padding:10px 14px !important; }
    .info-value { font-size:13px !important; }
    .info-label { font-size:12px !important; }
    .btn { padding:13px 24px !important; font-size:14px !important; width:85% !important; display:block !important; margin:0 auto !important; }
    .footer { padding:18px 16px !important; }
    .invoice-table th { padding:8px 10px !important; font-size:10px !important; }
    .invoice-table td { padding:8px 10px !important; font-size:12px !important; }
    .alert { padding:14px !important; font-size:13px !important; }
  }
</style>
"""


def _header(title: str, subtitle: str, gradient: str = "linear-gradient(135deg, #4338CA 0%, #6366F1 50%, #818CF8 100%)") -> str:
    return f"""
<div class="header" style="background:{gradient};">
  <div class="logo-mark" style="text-align:center;margin-bottom:16px;">
    <div class="logo-text" style="font-size:20px;font-weight:800;color:#FFFFFF;letter-spacing:-0.5px;display:inline-block;">COD<span style="color:#C7D2FE;">VERIFY</span></div>
  </div>
  <div class="header-title" style="font-size:24px;font-weight:700;color:#FFFFFF;margin-bottom:8px;line-height:1.3;">{title}</div>
  <div class="header-subtitle" style="font-size:14px;color:rgba(255,255,255,0.80);">{subtitle}</div>
</div>"""


def _footer() -> str:
    base = _frontend_url()
    return f"""
<div class="footer">
  <div class="footer-brand">CODVerify</div>
  <p>Intelligent COD Order Verification Platform</p>
  <p>India &amp; International | <a href="https://{_DOMAIN}">{_DOMAIN}</a></p>
  <div class="footer-links">
    <a href="{base}/contact">Contact Us</a>
    <a href="{base}/privacy">Privacy Policy</a>
    <a href="{base}/terms">Terms of Service</a>
  </div>
  <p class="footer-copy">
    You're receiving this because you have an account on CODVerify.<br>
    &copy; 2024&ndash;2026 CODVerify. All rights reserved.
  </p>
</div>"""


def _wrap_html(content: str) -> str:
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="color-scheme" content="light">
  <meta name="x-apple-disable-message-reformatting">
  {_BASE_STYLE}
</head>
<body style="margin:0;padding:0;background:#F0F4FF;">
  <!-- Outlook centering wrapper -->
  <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F0F4FF;padding:32px 0;">
    <tr>
      <td align="center">
        <table width="580" cellpadding="0" cellspacing="0" border="0" style="max-width:580px;width:92%;"
               class="card" style="background:#FFFFFF;border-radius:20px;border:1px solid #E0E7FF;overflow:hidden;">
          <tr><td>
            {content}
          </td></tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>"""


# ─── Email Templates ───────────────────────────────────────────────────────

async def send_verification_email(to_email: str, name: str, verification_link: str):
    """Send email verification link to new user."""
    if not _is_configured():
        logger.warning("EMAIL_WEBHOOK_URL not set — skipping verification email")
        return

    first_name = (name.split()[0] if name else "there").capitalize()
    html = _wrap_html(f"""
{_header("Verify Your Email Address", "One click to activate your account")}
<div class="body">
  <div class="greeting">Hi {first_name},</div>
  <p>Thank you for your interest in <strong>CODVerify</strong> &#8212; the intelligent COD verification platform that helps e-commerce brands eliminate Return-to-Origin losses.</p>
  <p>Please verify your email address by clicking the button below:</p>

  <div class="btn-wrap">
    <a href="{verification_link}" class="btn">Verify My Email Address</a>
  </div>

  <div class="info-card">
    <div class="info-row">
      <span class="info-label">Link expires in</span>
      <span class="info-value">24 hours</span>
    </div>
    <div class="info-row">
      <span class="info-label">Sent to</span>
      <span class="info-value">{to_email}</span>
    </div>
  </div>

  <div class="alert alert-info">
    Button not working? Copy and paste this link in your browser:<br>
    <a href="{verification_link}" style="color:#1E40AF;word-break:break-all;font-size:12px;display:block;margin-top:6px">{verification_link}</a>
  </div>

  <p style="font-size:12px;color:#9CA3AF;text-align:center;margin-top:8px">
    If you didn't create a CODVerify account, you can safely ignore this email.
  </p>
</div>
{_footer()}""")

    _send_email_async(to_email, f"Verify your email — CODVerify", html)


async def send_welcome_email(to_email: str, name: str):
    """Send 'Thank you for applying' email after successful email verification.
    This replaces the old welcome email — now informs user that our team will review and contact within 24-48hrs."""
    if not _is_configured():
        return

    first_name = (name.split()[0] if name else "there").capitalize()
    base = _frontend_url()
    html = _wrap_html(f"""
{_header("Thank You for Applying!", "Your application has been received",
         "linear-gradient(135deg, #059669 0%, #10B981 50%, #34D399 100%)")}
<div class="body">
  <div class="greeting">Hi {first_name},</div>
  <p>Thank you for choosing <strong>CODVerify</strong> as your COD order verification partner. We have received your application and our team is reviewing your details.</p>

  <div class="info-card">
    <div class="info-row">
      <span class="info-label">Application Status</span>
      <span class="tag tag-pending">Under Review</span>
    </div>
    <div class="info-row">
      <span class="info-label">Expected Response</span>
      <span class="info-value">Within 24 hours</span>
    </div>
    <div class="info-row">
      <span class="info-label">High Volume Period</span>
      <span class="info-value">Up to 48 hours</span>
    </div>
  </div>

  <div class="alert alert-success">
    <strong>What happens next?</strong><br>
    Our team will review your application and create a personalized service plan tailored to your business needs. You will receive an email with your contract details and pricing.
  </div>

  <p>In the meantime, here&#8217;s what you can explore:</p>
  <div class="info-card">
    <div class="info-row">
      <span class="info-label">&#10003; WhatsApp Verification</span>
      <span class="info-value">94% response rate</span>
    </div>
    <div class="info-row">
      <span class="info-label">&#10003; SMS + Voice Fallback</span>
      <span class="info-value">97% confirmation</span>
    </div>
    <div class="info-row">
      <span class="info-label">&#10003; AI Chatbot</span>
      <span class="info-value">24/7 customer support</span>
    </div>
    <div class="info-row">
      <span class="info-label">&#10003; Real-time Dashboard</span>
      <span class="info-value">Live analytics</span>
    </div>
  </div>

  <p style="font-size:14px;color:#374151;font-weight:600;margin-top:16px">
    If you have any questions or need immediate assistance, feel free to reach out to us:
  </p>

  <div class="btn-wrap">
    <a href="{base}/contact" class="btn">Contact Us &rarr;</a>
  </div>

  <p style="font-size:13px;color:#6B7280;text-align:center">
    Visit our website: <a href="{base}" style="color:#6366F1">{_DOMAIN}</a>
  </p>
</div>
{_footer()}""")

    _send_email_async(to_email, f"Thank You for Applying — CODVerify", html)


async def send_contract_notification_email(to_email: str, name: str, contract: dict):
    """Send email when admin creates a contract for the user — notifies them to review."""
    if not _is_configured():
        return

    first_name = (name.split()[0] if name else "there").capitalize()
    base = _frontend_url()
    contract_number = contract.get("contract_number", "N/A")
    plan_name       = contract.get("plan_name", "") or "Custom"
    total           = float(contract.get("total_amount") or 0)
    advance         = float(contract.get("advance_amount") or 0)
    currency        = contract.get("currency", "INR")
    sym             = "&#8377;" if currency == "INR" else "$"
    services        = contract.get("services", [])
    notes           = contract.get("notes", "")
    discount_pct    = float(contract.get("discount_percent") or 0)
    discounted_total = float(contract.get("discounted_total") or total)
    display_total   = discounted_total if discounted_total and discounted_total > 0 else total

    services_html = ""
    if services:
        for s in services:
            sname = s if isinstance(s, str) else s.get("name", "")
            if sname:
                services_html += (
                    f'<div style="display:flex;align-items:center;gap:10px;padding:10px 16px;'
                    f'border-bottom:1px solid #EEF0FF;">'
                    f'<span style="display:inline-flex;align-items:center;justify-content:center;'
                    f'width:20px;height:20px;background:#EEF2FF;border-radius:50%;font-size:11px;color:#4338CA;font-weight:800;">&#10003;</span>'
                    f'<span style="font-size:13px;font-weight:600;color:#111827;">{sname}</span>'
                    f'<span style="margin-left:auto;font-size:11px;font-weight:700;color:#059669;background:#ECFDF5;padding:2px 8px;border-radius:20px;">Included</span>'
                    f'</div>'
                )

    amount_section = f"""
    <div class="info-row">
      <span class="info-label">Contract Value</span>
      <span class="info-value" style="font-size:18px;color:#4338CA;font-weight:800">{sym}{display_total:,.2f}</span>
    </div>"""
    if discount_pct > 0:
        amount_section += f"""
    <div class="info-row">
      <span class="info-label" style="color:#059669">&#10003; Discount Applied</span>
      <span class="info-value" style="color:#059669;font-weight:700">{int(discount_pct)}% off &mdash; You save {sym}{total - display_total:,.2f}</span>
    </div>"""
    if advance > 0:
        amount_section += f"""
    <div class="info-row">
      <span class="info-label">Advance Payment</span>
      <span class="info-value" style="color:#4338CA;font-weight:700">{sym}{advance:,.2f}</span>
    </div>"""
        remaining = display_total - advance
        if remaining > 0:
            amount_section += f"""
    <div class="info-row">
      <span class="info-label">Remaining Balance</span>
      <span class="info-value">{sym}{remaining:,.2f}</span>
    </div>"""

    notes_html = ""
    if notes:
        notes_html = f"""
  <div class="alert alert-info" style="margin-top:16px">
    <strong>Note from our team:</strong><br>{notes}
  </div>"""

    html = _wrap_html(f"""
{_header("Your Service Contract is Ready! 🎉", f"Contract #{contract_number} — {plan_name} Plan",
         "linear-gradient(135deg, #1E40AF 0%, #3B82F6 50%, #60A5FA 100%)")}
<div class="body">
  <div class="greeting">Hi {first_name},</div>
  <p>Great news! Our team has prepared a <strong>personalized service contract</strong> for you. Your account is just one step away from going live!</p>

  <!-- Highlight strip -->
  <div style="background:linear-gradient(135deg,#EEF2FF 0%,#F0F9FF 100%);border:1.5px solid #C7D2FE;border-radius:16px;padding:20px;margin:20px 0;text-align:center;">
    <div style="font-size:11px;font-weight:700;color:#6366F1;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:4px;">Contract Reference</div>
    <div style="font-size:24px;font-weight:800;color:#1E40AF;letter-spacing:0.05em;">{contract_number}</div>
    <div style="font-size:12px;color:#6B7280;margin-top:4px;">{plan_name} Plan &nbsp;&bull;&nbsp; {currency}</div>
  </div>

  <!-- Pricing & Details -->
  <div class="info-card">
    <div class="info-row">
      <span class="info-label">Plan Name</span>
      <span class="info-value" style="color:#1E40AF;font-weight:800">{plan_name}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Contract Type</span>
      <span class="info-value">Permanent Service Contract</span>
    </div>
    <div class="info-row">
      <span class="info-label">Currency</span>
      <span class="info-value">{currency}</span>
    </div>
    {amount_section}
  </div>

  {f"<p style='font-size:12px;font-weight:700;color:#6B7280;text-transform:uppercase;letter-spacing:0.08em;margin:20px 0 8px'>Services Included</p><div style='border:1.5px solid #E0E7FF;border-radius:14px;overflow:hidden;'>" + services_html + "</div>" if services_html else ""}

  {notes_html}

  <div class="alert alert-success" style="margin-top:20px">
    <strong>&#127881; What happens next?</strong><br>
    Review your contract details and click <strong>Activate Contract</strong> in your dashboard. Your account will go live immediately after confirmation.
  </div>

  <div class="alert alert-warning">
    <strong>Terms &amp; Conditions:</strong><br>
    &#8226; Service activation begins after payment confirmation.<br>
    &#8226; This is a permanent service contract &mdash; no fixed expiry.<br>
    &#8226; All services are subject to our <a href="{base}/terms" style="color:#92400E;font-weight:600">Terms of Service</a> and <a href="{base}/privacy" style="color:#92400E;font-weight:600">Privacy Policy</a>.<br>
    &#8226; Refunds are processed as per our refund policy.
  </div>

  <div class="btn-wrap">
    <a href="{base}/dashboard/contract" class="btn">View &amp; Activate Contract &rarr;</a>
  </div>

  <p style="font-size:13px;color:#6B7280;text-align:center">
    Questions about your contract? <a href="{base}/contact" style="color:#6366F1;font-weight:600">Contact our team</a>
  </p>
</div>
{_footer()}""")

    _send_email_async(to_email, f"Your CODVerify Contract #{contract_number} is Ready — Action Required", html)


async def send_activation_invoice_email(to_email: str, name: str, contract: dict):
    """Send professional invoice email when account is activated."""
    if not _is_configured():
        return

    first_name = (name.split()[0] if name else "there").capitalize()
    base = _frontend_url()
    contract_number = contract.get("contract_number", "N/A")
    duration        = contract.get("duration_months", 1)
    total           = contract.get("total_amount", 0)
    discount_pct    = contract.get("discount_percent", 0) or 0
    discounted_total= contract.get("discounted_total", 0) or total
    advance         = contract.get("advance_amount", 0) or 0
    emi_amount      = contract.get("emi_amount", 0) or 0
    currency        = contract.get("currency", "INR")
    sym             = "&#8377;" if currency == "INR" else "$"
    services        = contract.get("services", [])
    start_date      = contract.get("start_date", "")
    end_date        = contract.get("end_date", "")
    now_str         = datetime.now(timezone.utc).strftime("%B %d, %Y")
    # Use discounted_total as the effective total for display
    display_total   = discounted_total if discounted_total and discounted_total > 0 else total

    # Format dates
    start_display = start_date[:10] if start_date else now_str
    end_display = end_date[:10] if end_date else "N/A"

    # Build service badge chips
    service_badges = ""
    if services:
        for s in services:
            sname = s if isinstance(s, str) else s.get("name", "Service")
            service_badges += (
                f'<span style="display:inline-block;background:#EEF2FF;color:#4338CA;'
                f'border:1px solid #C7D2FE;border-radius:20px;padding:6px 14px;'
                f'font-size:12px;font-weight:600;margin:4px;">{sname}</span>'
            )
    else:
        service_badges = (
            '<span style="display:inline-block;background:#EEF2FF;color:#4338CA;'
            'border:1px solid #C7D2FE;border-radius:20px;padding:6px 14px;'
            'font-size:12px;font-weight:600;margin:4px;">All contracted services included</span>'
        )

    html = _wrap_html(f"""
{_header("Account Activated!", "Your CODVerify services are now live ✨",
         "linear-gradient(135deg, #064E3B 0%, #059669 50%, #10B981 100%)")}
<div class="body">
  <div class="greeting">Welcome aboard, {first_name}! 🎉</div>
  <p>Your CODVerify account is <strong>officially active</strong>. You’re now part of India’s smartest COD verification network — helping you reduce RTOs, block fraudulent orders, and boost revenue from day one.</p>

  <p>Please find your official invoice attached to this email as a PDF. Here’s a quick summary:</p>

  <div style="background:#F0FDF4;border:2px solid #A7F3D0;border-radius:14px;padding:20px;text-align:center;margin:20px 0">
    <div style="font-size:11px;font-weight:700;color:#059669;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:4px">Account Status</div>
    <div style="font-size:26px;font-weight:800;color:#065F46;letter-spacing:0.05em">✅ ACTIVE</div>
  </div>

  <!-- Invoice Summary -->
  <div style="border:1.5px solid #E0E7FF;border-radius:14px;overflow:hidden;margin:20px 0">
    <div style="background:linear-gradient(135deg,#3730A3 0%,#4338CA 100%);padding:16px 20px;">
      <table style="width:100%;border-collapse:collapse;">
        <tr>
          <td style="color:white;font-weight:800;font-size:15px;letter-spacing:0.05em">INVOICE</td>
          <td style="color:rgba(255,255,255,0.85);font-size:12px;font-weight:600;text-align:right;">{contract_number}</td>
        </tr>
      </table>
    </div>

    <div style="padding:20px">
      <div class="info-card" style="margin:0 0 16px 0">
        <div class="info-row">
          <span class="info-label">Invoice Date</span>
          <span class="info-value">{now_str}</span>
        </div>
        <div class="info-row">
          <span class="info-label">Billed To</span>
          <span class="info-value">{name} &lt;{to_email}&gt;</span>
        </div>
        <div class="info-row">
          <span class="info-label">Activated On</span>
          <span class="info-value">{start_display}</span>
        </div>
        <div class="info-row">
          <span class="info-label">Contract Type</span>
          <span class="info-value">Permanent Service Contract</span>
        </div>
        {'<div class="info-row"><span class="info-label">Original Amount</span><span class="info-value">' + sym + f'{total:,.2f}</span></div><div class="info-row"><span class="info-label" style="color:#059669">Discount ({int(discount_pct)}% off)</span><span class="info-value" style="color:#059669">- ' + sym + f'{total - display_total:,.2f}</span></div>' if discount_pct > 0 else ''}
        {'<div class="info-row"><span class="info-label">Advance Paid</span><span class="info-value" style="color:#4338CA;font-weight:700">' + sym + f'{advance:,.2f}</span></div>' if advance > 0 else ''}
        {'<div class="info-row"><span class="info-label">Monthly EMI (' + str(duration) + ' months)</span><span class="info-value" style="color:#7C3AED;font-weight:700">' + sym + f'{emi_amount:,.2f}/mo</span></div>' if emi_amount > 0 else ''}
        <div class="info-row" style="border-top:2px solid #E0E7FF;margin-top:8px;padding-top:12px">
          <span class="info-label" style="font-weight:700;font-size:14px">Total Contract Value</span>
          <span class="info-value" style="font-size:18px;color:#4338CA;font-weight:800;">{sym}{display_total:,.2f}</span>
        </div>
      </div>
    </div>
  </div>

  <!-- Services -->
  <div style="margin:24px 0">
    <p style="font-size:12px;font-weight:700;color:#6B7280;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:12px;">
      🚀 Services Now Active For You
    </p>
    <div style="background:#F8FAFF;border:1.5px solid #E0E7FF;border-radius:14px;padding:16px;line-height:2;">
      {service_badges}
    </div>
  </div>

  <div class="alert alert-success">
    <strong>📄 Invoice PDF Attached!</strong> Your official invoice is included as a PDF attachment with this email. Save it for your records or share it with your accounts team.
  </div>

  <div style="background:#FFFBEB;border:1.5px solid #FDE68A;border-radius:12px;padding:16px;margin:20px 0;font-size:13px;color:#92400E;line-height:1.7">
    <strong>💡 Pro Tip:</strong> Log in to your dashboard to set up your Shopify store integration, configure AI chatbot responses, and start verifying COD orders in minutes.
  </div>

  <div class="btn-wrap">
    <a href="{base}/dashboard" class="btn">Go to Dashboard &rarr;</a>
  </div>

  <p style="font-size:12px;color:#9CA3AF;text-align:center;margin-top:12px;line-height:1.6">
    Need help getting started? Our support team is here for you.<br>
    <a href="{base}/contact" style="color:#6366F1;font-weight:600">Contact Support</a> &nbsp;&bull;&nbsp;
    <a href="{base}/docs" style="color:#6366F1;font-weight:600">View Docs</a>
  </p>
</div>
{_footer()}""")

    # Generate PDF invoice attachment
    pdf_attachments = []
    try:
        from services.invoice_service import generate_invoice_pdf
        import base64
        pdf_data = {
            "invoice_number":   contract_number,
            "contract_number":  contract_number,
            "issue_date":       now_str,
            "merchant_name":    name,
            "merchant_email":   to_email,
            # Professional fields — pulled from contract
            "plan_name":        contract.get("plan_name", ""),
            "merchant_company": contract.get("merchant_company", ""),
            "merchant_gst":     contract.get("merchant_gst", ""),
            "merchant_address": contract.get("merchant_address", ""),
            "payment_method":   contract.get("payment_method", "Razorpay"),
            "transaction_id":   contract.get("transaction_id", ""),
            "services":         services,
            "chatbot_tier":     contract.get("chatbot_tier", "none"),
            "line_items": (
                [{"name": (s if isinstance(s, str) else s.get("name", "Service")), "description": "", "amount": 0} for s in services]
                if services else []
            ),
            "subtotal":         total,
            "discount_percent": discount_pct,
            "discount_amount":  round(total - display_total, 2) if discount_pct > 0 else 0,
            "advance_amount":   advance,
            "emi_amount":       emi_amount,
            "tax_rate":         0,
            "tax_amount":       0,
            "total":            display_total,
            "currency":         currency.replace("&#8377;", "INR"),
            "payment_status":   "paid",
            "notes": (
                f"Contract period: {start_display} to {end_display} ({duration} months)"
                + (f" | Discount: {int(discount_pct)}% off" if discount_pct > 0 else "")
                + (f" | Advance paid: {sym}{advance:,.2f}" if advance > 0 else "")
                + (f" | Monthly EMI: {sym}{emi_amount:,.2f}/month x {duration} months" if emi_amount > 0 else "")
            ),
        }
        pdf_bytes = generate_invoice_pdf(pdf_data)
        pdf_attachments = [{
            "filename": f"CODVerify-Invoice-{contract_number}.pdf",
            "mimeType": "application/pdf",
            "content": base64.b64encode(pdf_bytes).decode("utf-8"),
        }]
        logger.info(f"PDF invoice generated for {contract_number} ({len(pdf_bytes)} bytes)")
    except Exception as e:
        logger.warning(f"PDF invoice generation failed (sending without attachment): {e}")

    plan_display = contract.get("plan_name", "") or "Service"
    _send_email_async(
        to_email,
        f"CODVerify Service Activation – Invoice #{contract_number} ({plan_display} Plan)",
        html,
        pdf_attachments
    )


async def send_password_reset_email(to_email: str, name: str, reset_link: str):
    """Send password reset link."""
    if not _is_configured():
        logger.warning("EMAIL_WEBHOOK_URL not set — skipping password reset email")
        return

    first_name = (name.split()[0] if name else "there").capitalize()
    base = _frontend_url()
    html = _wrap_html(f"""
{_header("Password Reset Request", "We received a request to reset your password",
         "linear-gradient(135deg, #1E1B4B 0%, #312E81 50%, #4338CA 100%)")}
<div class="body">
  <div class="greeting">Hi {first_name},</div>
  <p>Someone requested a password reset for the CODVerify account associated with <strong>{to_email}</strong>. If this was you, click the button below.</p>

  <div class="btn-wrap">
    <a href="{reset_link}" class="btn">Reset My Password</a>
  </div>

  <div class="info-card">
    <div class="info-row">
      <span class="info-label">Link expires in</span>
      <span class="info-value" style="color:#DC2626;font-weight:700">1 hour</span>
    </div>
    <div class="info-row">
      <span class="info-label">Account email</span>
      <span class="info-value">{to_email}</span>
    </div>
  </div>

  <div class="alert alert-error">
    <strong>Did not request this?</strong> You can safely ignore this email. Your password will remain unchanged. If you're concerned, please <a href="{base}/contact" style="color:#991B1B;font-weight:600">contact our support team</a>.
  </div>

  <div class="alert alert-info" style="margin-top:12px">
    Button not working? Copy and paste this link:<br>
    <a href="{reset_link}" style="color:#1E40AF;word-break:break-all;font-size:12px;display:block;margin-top:6px">{reset_link}</a>
  </div>
</div>
{_footer()}""")

    _send_email_async(to_email, f"Password Reset Request — CODVerify", html)


async def send_low_balance_alert(to_email: str, name: str, balance: float, orders_remaining: int, currency: str = "INR"):
    """Send low wallet balance warning."""
    if not _is_configured():
        return

    base = _frontend_url()
    sym = "&#8377;" if currency == "INR" else "$"
    html = _wrap_html(f"""
{_header("Low Wallet Balance Alert", "Top up your wallet to keep verifications running",
         "linear-gradient(135deg, #D97706 0%, #F59E0B 50%, #FBBF24 100%)")}
<div class="body">
  <div class="greeting">Hi {name},</div>
  <p>Your CODVerify wallet balance is running low. Order verifications will pause when your balance reaches {sym}0.</p>

  <div class="info-card">
    <div class="info-row">
      <span class="info-label">Current Balance</span>
      <span class="info-value" style="color:#D97706;font-size:16px">{sym}{balance:.2f}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Orders Remaining</span>
      <span class="info-value">~{orders_remaining} orders</span>
    </div>
    <div class="info-row">
      <span class="info-label">Status</span>
      <span class="tag tag-low">Low Balance</span>
    </div>
  </div>

  <div class="alert alert-warning">
    Recharge now to avoid interruption in your COD verification workflow.
  </div>

  <div class="btn-wrap">
    <a href="{base}/dashboard/billing" class="btn">Recharge Wallet &rarr;</a>
  </div>
</div>
{_footer()}""")

    _send_email_async(to_email, f"Action Required: Low Wallet Balance — CODVerify", html)


async def send_order_cancellation_alert(to_email: str, name: str, order: dict, reason: str = ""):
    """Send alert when an order is cancelled by customer."""
    if not _is_configured():
        return

    order_id    = order.get("order_number", order.get("store_order_id", "N/A")) if isinstance(order, dict) else str(order)
    amount      = order.get("order_amount", 0) if isinstance(order, dict) else 0
    currency    = order.get("currency", "INR") if isinstance(order, dict) else "INR"
    sym         = "&#8377;" if currency == "INR" else "$"
    cancel_time = order.get("response_received_at", "N/A") if isinstance(order, dict) else "N/A"

    html = _wrap_html(f"""
{_header("Order Cancellation Alert", "A customer cancelled their COD order",
         "linear-gradient(135deg, #991B1B 0%, #DC2626 50%, #EF4444 100%)")}
<div class="body">
  <div class="greeting">Hi {name},</div>
  <p>Good news &#8212; a COD order was cancelled <strong>before shipping</strong>, saving you from an RTO incident. Here are the details:</p>

  <div class="info-card">
    <div class="info-row">
      <span class="info-label">Order Number</span>
      <span class="info-value">#{order_id}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Order Amount</span>
      <span class="info-value">{sym}{amount}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Reason</span>
      <span class="info-value">{reason or 'Customer cancelled'}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Cancelled At</span>
      <span class="info-value">{str(cancel_time)[:16].replace('T',' ') if cancel_time != 'N/A' else 'N/A'}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Status</span>
      <span class="tag tag-cancelled">Cancelled</span>
    </div>
  </div>

  <div class="alert alert-success">
    This RTO was prevented before dispatching. Your shipping costs are saved!
  </div>
</div>
{_footer()}""")

    _send_email_async(to_email, f"Order #{order_id} Cancelled — CODVerify", html)



# send_weekly_summary is defined below (after billing functions) — do not duplicate here


async def send_quota_warning(to_email: str, name: str, used: int, total: int):
    """Send quota usage warning."""
    if not _is_configured():
        return

    percent   = round(used / total * 100) if total > 0 else 0
    remaining = total - used
    base = _frontend_url()

    html = _wrap_html(f"""
{_header("Monthly Quota Warning", f"You've used {percent}% of your monthly verification limit",
         "linear-gradient(135deg, #6D28D9 0%, #7C3AED 50%, #8B5CF6 100%)")}
<div class="body">
  <div class="greeting">Hi {name},</div>
  <p>You are approaching your monthly verification quota. Upgrade your plan to ensure uninterrupted order verification.</p>

  <div class="info-card">
    <div class="info-row">
      <span class="info-label">Verifications Used</span>
      <span class="info-value">{used:,}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Monthly Quota</span>
      <span class="info-value">{total:,}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Remaining</span>
      <span class="info-value" style="color:#6D28D9;font-weight:700">{remaining:,}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Usage</span>
      <span class="info-value">
        <div style="background:#EDE9FE;border-radius:99px;height:8px;overflow:hidden;width:120px">
          <div style="background:#7C3AED;height:8px;width:{min(percent,100)}%"></div>
        </div>
        {percent}%
      </span>
    </div>
  </div>

  <div class="alert alert-warning">
    When your quota runs out, order verifications will stop until the next billing cycle or until you upgrade.
  </div>

  <div class="btn-wrap">
    <a href="{base}/dashboard/billing" class="btn">Upgrade Plan &rarr;</a>
  </div>
</div>
{_footer()}""")

    _send_email_async(to_email, f"Monthly Quota Warning — CODVerify", html)


async def send_shopify_install_email(to_email: str, name: str, shop_domain: str):
    """Send a thank-you email when a merchant installs via Shopify."""
    if not _is_configured():
        return

    first_name = (name.split()[0] if name else "there").capitalize()
    base = _frontend_url()

    html = _wrap_html(f"""
{_header("Shopify App Installed Successfully!", "Thank you for connecting your store",
         "linear-gradient(135deg, #064E3B 0%, #059669 50%, #10B981 100%)")}
<div class="body">
  <div class="greeting">Hi {first_name},</div>
  <p>Thank you for installing CODVerify on your Shopify store. Your store has been successfully connected and our team has been notified.</p>

  <div class="info-card">
    <div class="info-row">
      <span class="info-label">Store Connected</span>
      <span class="info-value">{shop_domain}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Source</span>
      <span class="info-value">Shopify App Store</span>
    </div>
    <div class="info-row">
      <span class="info-label">Status</span>
      <span class="tag tag-pending">Review Pending</span>
    </div>
  </div>

  <div class="alert alert-success">
    <strong>What happens next?</strong><br>
    Our team will review your store details and create a personalized service plan. You will be contacted within <strong>24 hours</strong> (up to 48 hours during high volume periods).
  </div>

  <p style="font-size:14px;color:#374151;font-weight:600">Need immediate help?</p>

  <div class="btn-wrap">
    <a href="{base}/contact" class="btn">Contact Us &rarr;</a>
  </div>

  <p style="font-size:13px;color:#6B7280;text-align:center">
    Visit: <a href="{base}" style="color:#6366F1">{_DOMAIN}</a>
  </p>
</div>
{_footer()}""")

    _send_email_async(to_email, f"Thank You for Installing CODVerify — Shopify", html)


async def send_shopify_welcome_email(to_email: str, name: str, shop_domain: str, auto_password: str, dashboard_url: str):
    """Send welcome email to new Shopify merchant with their auto-created CODVerify credentials."""
    if not _is_configured():
        return

    first_name = (name.split()[0] if name else "there").capitalize()
    base = _frontend_url()

    html = _wrap_html(f"""
{_header("🎉 Your CODVerify Account is Ready!", f"Connected to {shop_domain}",
         "linear-gradient(135deg, #4338CA 0%, #6366F1 50%, #818CF8 100%)")}
<div class="body">
  <div class="greeting">Hi {first_name},</div>
  <p>Your CODVerify account has been <strong>automatically set up</strong> for your Shopify store. You can now log in to your dashboard using the credentials below.</p>

  <div class="info-card">
    <div class="info-row">
      <span class="info-label">Store Connected</span>
      <span class="info-value">{shop_domain}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Login Email</span>
      <span class="info-value">{to_email}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Temporary Password</span>
      <span class="info-value" style="font-family:monospace;font-size:12px;color:#4338CA;font-weight:700">{auto_password}</span>
    </div>
  </div>

  <div class="alert alert-warning">
    <strong>⚠️ Important:</strong> Please change your password immediately after first login for security purposes.
  </div>

  <div class="btn-wrap">
    <a href="{dashboard_url}" class="btn">Open My Dashboard →</a>
  </div>

  <div class="info-card" style="margin-top:24px">
    <div class="info-row">
      <span class="info-label">✓ COD Order Verification</span>
      <span class="info-value">WhatsApp + SMS + Voice</span>
    </div>
    <div class="info-row">
      <span class="info-label">✓ RTO Prevention</span>
      <span class="info-value">AI Risk Scoring</span>
    </div>
    <div class="info-row">
      <span class="info-label">✓ Real-time Dashboard</span>
      <span class="info-value">Analytics & Reports</span>
    </div>
    <div class="info-row">
      <span class="info-label">Account Status</span>
      <span class="tag tag-pending">Trial — Pending Plan Assignment</span>
    </div>
  </div>

  <div class="alert alert-info" style="margin-top:16px">
    Our team will contact you within 24 hours to discuss your personalized service plan.
    <br><a href="{base}/contact" style="color:#1E40AF;font-weight:600">Contact us anytime</a>
  </div>

  <p style="font-size:12px;color:#9CA3AF;text-align:center;margin-top:8px">
    Visit: <a href="{base}" style="color:#6366F1">{_DOMAIN}</a>
  </p>
</div>
{_footer()}""")

    _send_email_async(to_email, f"Welcome to CODVerify — Your Account is Ready!", html)


async def send_contact_form_email(admin_email: str, name: str, email: str, phone: str, company: str, message: str):
    """Send notification to admin when a contact form is submitted."""
    if not _is_configured():
        logger.warning("EMAIL_WEBHOOK_URL not set — skipping contact form email")
        return

    company_row = f"""<div class="info-row"><span class="info-label">Company</span><span class="info-value">{company}</span></div>""" if company else ""
    phone_row = f"""<div class="info-row"><span class="info-label">Phone</span><span class="info-value">{phone}</span></div>""" if phone else ""

    html = _wrap_html(f"""
{_header("New Contact Inquiry", "Someone submitted the contact form on CODVerify",
         "linear-gradient(135deg, #1E40AF 0%, #3B82F6 50%, #60A5FA 100%)")}
<div class="body">
  <div class="greeting">New Inquiry Received</div>
  <p>A visitor has submitted the contact form on <strong>codverify.tech</strong>. Here are the details:</p>

  <div class="info-card">
    <div class="info-row"><span class="info-label">Name</span><span class="info-value">{name}</span></div>
    <div class="info-row"><span class="info-label">Email</span><span class="info-value"><a href="mailto:{email}" style="color:#3B82F6">{email}</a></span></div>
    {phone_row}
    {company_row}
  </div>

  <p style="font-size:12px;font-weight:700;color:#6B7280;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:8px">Message</p>
  <div style="background:#F8FAFF;border:1.5px solid #E0E7FF;border-radius:14px;padding:18px 20px;font-size:14px;line-height:1.8;color:#374151;white-space:pre-wrap">{message}</div>

  <div class="alert alert-info" style="margin-top:20px">
    Reply directly to <strong>{email}</strong> to respond to this inquiry.
  </div>

  <div class="btn-wrap">
    <a href="mailto:{email}?subject=Re: Your CODVerify Inquiry" class="btn">Reply to {name} &rarr;</a>
  </div>
</div>
{_footer()}""")

    _send_email_async(admin_email, f"New Contact Inquiry from {name} — CODVerify", html)


async def send_new_signup_admin_notification(admin_email: str, user_data: dict, source: str = "website"):
    """Notify admin when a new user signs up — includes source (website/shopify)."""
    if not _is_configured():
        return

    name = user_data.get("name", "Unknown")
    email = user_data.get("email", "N/A")
    phone = user_data.get("phone", "N/A")
    company = user_data.get("company_name", "N/A")
    source_label = "Shopify App Installation" if source == "shopify" else "Website Registration"
    source_color = "#059669" if source == "shopify" else "#4338CA"

    html = _wrap_html(f"""
{_header("New Service Request!", f"A new merchant has applied via {source_label}",
         "linear-gradient(135deg, #7C2D12 0%, #EA580C 50%, #F97316 100%)")}
<div class="body">
  <div class="greeting">New Application Received</div>
  <p>A new merchant has applied for CODVerify services. Review their details and create a contract:</p>

  <div class="info-card">
    <div class="info-row">
      <span class="info-label">Name</span>
      <span class="info-value" style="font-weight:800">{name}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Email</span>
      <span class="info-value"><a href="mailto:{email}" style="color:#3B82F6">{email}</a></span>
    </div>
    <div class="info-row">
      <span class="info-label">Phone</span>
      <span class="info-value">{phone}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Company</span>
      <span class="info-value">{company}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Source</span>
      <span class="info-value" style="color:{source_color};font-weight:700">{source_label}</span>
    </div>
  </div>

  <div class="alert alert-warning">
    <strong>Action Required:</strong> Review this application and create a contract within 24 hours.
  </div>

  <div class="btn-wrap">
    <a href="{_frontend_url()}/admin/contracts" class="btn">Create Contract &rarr;</a>
  </div>
</div>
{_footer()}""")

    _send_email_async(admin_email, f"New Service Request from {name} ({source_label})", html)


async def send_worker_credentials_email(to_email: str, name: str, password: str):
    """Send login credentials to a newly created worker account."""
    if not _is_configured():
        logger.warning("EMAIL_WEBHOOK_URL not set — skipping worker credentials email")
        return

    first_name = (name.split()[0] if name else "there").capitalize()
    base = _frontend_url()

    html = _wrap_html(f"""
{_header("Your Agent Account is Ready", "Login credentials for CODVerify Agent Portal",
         "linear-gradient(135deg, #1E3A5F 0%, #1E40AF 50%, #3B82F6 100%)")}
<div class="body">
  <div class="greeting">Hi {first_name},</div>
  <p>Your CODVerify agent account has been created. Use the credentials below to log in to the agent portal and start handling orders, callbacks, and customer chats.</p>

  <div class="info-card">
    <div class="info-row">
      <span class="info-label">Login URL</span>
      <span class="info-value"><a href="{base}/login" style="color:#1E40AF">{base}/login</a></span>
    </div>
    <div class="info-row">
      <span class="info-label">Email</span>
      <span class="info-value">{to_email}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Temporary Password</span>
      <span class="info-value" style="font-family:monospace;font-size:13px;color:#1E40AF;font-weight:700;letter-spacing:0.05em">{password}</span>
    </div>
  </div>

  <div class="alert alert-warning">
    <strong>Security:</strong> Please change your password after your first login. Go to Settings → Change Password.
  </div>

  <div class="alert alert-info">
    <strong>Your responsibilities as an agent:</strong><br>
    &#8226; Verify COD orders via call and update status in real-time<br>
    &#8226; Handle customer callback requests promptly<br>
    &#8226; Assist customers on live chat when AI escalates<br>
    &#8226; Mark your duty status (on duty / break / off duty) accurately
  </div>

  <div class="btn-wrap">
    <a href="{base}/login" class="btn">Login to Agent Portal &rarr;</a>
  </div>

  <p style="font-size:12px;color:#9CA3AF;text-align:center;margin-top:8px">
    For any issues, contact your administrator.
  </p>
</div>
{_footer()}""")

    _send_email_async(to_email, "Your CODVerify Agent Account — Login Credentials", html)


async def send_weekly_summary(to_email: str, merchant_name: str, stats: dict):
    """Send weekly (Monday morning) verification performance summary to merchant."""
    if not _is_configured():
        logger.warning("EMAIL_WEBHOOK_URL not set — skipping weekly summary email")
        return

    first_name = (merchant_name.split()[0] if merchant_name else "there").capitalize()
    total      = stats.get("total", 0)
    confirmed  = stats.get("confirmed", 0)
    cancelled  = stats.get("cancelled", 0)
    pending    = stats.get("pending", 0)
    rto_saved  = stats.get("rto_saved", 0)
    currency   = stats.get("currency", "INR")
    sym        = "₹" if currency == "INR" else "$"
    week_label = stats.get("week_label", "")

    confirm_rate = round((confirmed / total * 100), 1) if total > 0 else 0.0

    # Performance tip
    if confirm_rate < 70:
        tip_color = "#B45309"
        tip_bg    = "#FFFBEB"
        tip       = f"Your confirmation rate was below 70% ({confirm_rate}%) this week. Consider optimizing your verification timing in Settings."
    elif confirm_rate >= 90:
        tip_color = "#065F46"
        tip_bg    = "#ECFDF5"
        tip       = f"Excellent week! {confirm_rate}% confirmation rate — you're in the top tier of CODVerify merchants."
    else:
        tip_color = "#1E40AF"
        tip_bg    = "#EFF6FF"
        tip       = f"Good week! {confirm_rate}% confirmation rate. Fine-tune your message templates to push it higher."

    base = _frontend_url()
    today_str = datetime.now(timezone.utc).strftime("%B %d, %Y")

    html = _wrap_html(f"""
{_header("Your Weekly Summary", f"COD verification performance — {week_label or today_str}")}
<div class="body">
  <div class="greeting">Hi {first_name},</div>
  <p>Here's how your COD order verification performed this week ({week_label or today_str}):</p>

  <div class="info-card">
    <div class="info-row">
      <span class="info-label">Total Orders Processed</span>
      <span class="info-value" style="font-weight:700;color:#1E1B4B">{total}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Confirmed</span>
      <span class="info-value" style="color:#059669;font-weight:700">{confirmed}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Cancelled</span>
      <span class="info-value" style="color:#DC2626;font-weight:700">{cancelled}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Pending Response</span>
      <span class="info-value" style="font-weight:700">{pending}</span>
    </div>
    <div class="info-row">
      <span class="info-label">Confirmation Rate</span>
      <span class="info-value" style="font-weight:800;color:#4338CA">{confirm_rate}%</span>
    </div>
    <div class="info-row">
      <span class="info-label">RTO Saved (est.)</span>
      <span class="info-value" style="color:#059669;font-weight:700">{sym}{rto_saved:,.0f}</span>
    </div>
  </div>

  <div class="alert" style="background:{tip_bg};border-left:4px solid {tip_color};color:{tip_color}">
    {tip}
  </div>

  <div class="btn-wrap">
    <a href="{base}/dashboard/analytics" class="btn">View Full Analytics &rarr;</a>
  </div>

  <p style="font-size:12px;color:#9CA3AF;text-align:center;margin-top:16px">
    To stop receiving weekly summaries, go to Dashboard &rarr; Settings &rarr; Notifications.
  </p>
</div>
{_footer()}""")

    _send_email_async(to_email, f"Your CODVerify Weekly Summary — {week_label or today_str}", html)


# ── BILLING: Payment Due Reminder (3 days before) ────────────────────────────
async def send_payment_due_reminder(
    to_email: str,
    name: str,
    amount: float,
    currency: str,
    due_date: str,
    contract_number: str,
    description: str,
) -> None:
    """Send a 3-day advance payment reminder for an upcoming EMI/monthly invoice."""
    sym = "₹" if currency == "INR" else "$"
    html = _wrap_html(f"""
{_header("Payment Due in 3 Days", f"{contract_number} — Due {due_date}", "linear-gradient(135deg,#92400E,#F97316)")}
<div class="body">
  <div class="greeting">Hi {name},</div>
  <p>A payment is coming up on your CODVerify contract. Please ensure your account is ready before the due date.</p>

  <div class="info-card">
    <div class="info-row"><span class="info-label">Contract</span><span class="info-value">{contract_number}</span></div>
    <div class="info-row"><span class="info-label">Description</span><span class="info-value">{description}</span></div>
    <div class="info-row"><span class="info-label">Amount Due</span><span class="info-value" style="color:#F97316;font-size:18px;font-weight:700;">{sym}{amount:,.2f}</span></div>
    <div class="info-row"><span class="info-label">Due Date</span><span class="info-value" style="color:#F59E0B;font-weight:600;">{due_date}</span></div>
  </div>

  <p style="font-size:13px;color:#6B7280;text-align:center;">
    You will receive the payment link automatically on your due date.<br/>
    Log in to your dashboard anytime to pay early.
  </p>
</div>
{_footer()}""")
    _send_email_async(to_email, f"⏰ Payment Due in 3 Days — {sym}{amount:,.2f} | {contract_number}", html)


# ── BILLING: Overdue Warning ──────────────────────────────────────────────────
async def send_payment_overdue_warning(
    to_email: str,
    name: str,
    amount: float,
    currency: str,
    due_date: str,
    overdue_days: int,
    contract_number: str,
    description: str,
) -> None:
    """Send an overdue payment warning with blacklisting notice."""
    sym = "₹" if currency == "INR" else "$"
    html = _wrap_html(f"""
{_header("Payment Overdue — Action Required", f"{overdue_days} day(s) late — {contract_number}", "linear-gradient(135deg,#7F1D1D,#EF4444)")}
<div class="body">
  <div class="greeting">Hi {name},</div>
  <p>Your payment for contract <strong>{contract_number}</strong> is now <strong>{overdue_days} day(s) overdue</strong>. Please pay immediately to avoid account suspension.</p>

  <div class="info-card">
    <div class="info-row"><span class="info-label">Contract</span><span class="info-value">{contract_number}</span></div>
    <div class="info-row"><span class="info-label">Description</span><span class="info-value">{description}</span></div>
    <div class="info-row"><span class="info-label">Amount Overdue</span><span class="info-value" style="color:#EF4444;font-size:18px;font-weight:700;">{sym}{amount:,.2f}</span></div>
    <div class="info-row"><span class="info-label">Was Due On</span><span class="info-value" style="color:#F59E0B;">{due_date}</span></div>
    <div class="info-row"><span class="info-label">Days Overdue</span><span class="info-value" style="color:#EF4444;font-weight:700;">{overdue_days} days</span></div>
  </div>

  <div class="alert alert-danger" style="background:#FEF2F2;border:1px solid #FECACA;border-radius:8px;padding:14px;margin:16px 0;">
    <p style="color:#991B1B;margin:0;font-size:13px;">
      ⚠️ <strong>Warning:</strong> Continued non-payment will result in your account being
      <strong>blacklisted</strong> and all CODVerify services suspended per your contract terms.
      Please pay immediately or contact support.
    </p>
  </div>

  <p style="font-size:12px;color:#9CA3AF;text-align:center;">Contact: support@codverify.tech</p>
</div>
{_footer()}""")
    _send_email_async(to_email, f"🚨 OVERDUE {overdue_days}d — Payment Required: {sym}{amount:,.2f} | {contract_number}", html)


# ── BILLING: Payment Link Email (sent on due date) ────────────────────────────
async def send_invoice_payment_link(
    to_email: str,
    name: str,
    amount: float,
    currency: str,
    due_date: str,
    contract_number: str,
    description: str,
    payment_url: str,
    razorpay_order_id: str,
    razorpay_key: str,
) -> None:
    """
    Sent automatically on the invoice due date.
    Contains a Pay Now button that opens Razorpay checkout.
    This email IS the monthly billing — merchant clicks, pays, done.
    """
    sym = "₹" if currency == "INR" else "$"
    html = _wrap_html(f"""
{_header("Payment Due Today", f"{sym}{amount:,.2f} — {contract_number}", "linear-gradient(135deg,#065F46,#10B981)")}
<div class="body">
  <div class="greeting">Hi {name},</div>
  <p>Your monthly CODVerify payment is due today. Pay securely using the button below — UPI, Cards, and Net Banking accepted.</p>

  <div class="info-card">
    <div class="info-row"><span class="info-label">Contract</span><span class="info-value">{contract_number}</span></div>
    <div class="info-row"><span class="info-label">Description</span><span class="info-value">{description}</span></div>
    <div class="info-row"><span class="info-label">Amount</span><span class="info-value" style="color:#10B981;font-size:20px;font-weight:700;">{sym}{amount:,.2f}</span></div>
    <div class="info-row"><span class="info-label">Due Date</span><span class="info-value" style="color:#F59E0B;font-weight:600;">{due_date}</span></div>
  </div>

  <div class="btn-wrap">
    <a href="{payment_url}" class="btn" style="background:linear-gradient(135deg,#10B981,#059669);">💳 Pay Now — {sym}{amount:,.2f}</a>
  </div>

  <p style="font-size:12px;color:#6B7280;text-align:center;margin-top:12px;">
    If the button doesn't work: <a href="{payment_url}" style="color:#10B981;word-break:break-all;">{payment_url}</a>
  </p>
  <p style="font-size:11px;color:#9CA3AF;text-align:center;margin-top:8px;">Order ID: {razorpay_order_id}</p>
</div>
{_footer()}""")
    _send_email_async(to_email, f"💳 Pay Now: {sym}{amount:,.2f} Due Today — {contract_number}", html)

def _fmt_amount(amount: float, currency: str) -> str:
    sym = "₹" if currency == "INR" else "$"
    return f"{sym}{amount:,.2f}"


async def send_payment_due_reminder(
    to_email: str,
    name: str,
    amount: float,
    currency: str,
    due_date: str,
    contract_number: str,
    description: str,
) -> None:
    """3-day advance payment reminder email."""
    amt_str = _fmt_amount(amount, currency)
    html = _wrap_html(f"""
<div style="background:#1E293B;border-radius:12px;padding:28px 32px;margin-bottom:24px">
  <h2 style="color:#60A5FA;margin:0 0 4px 0;font-size:18px">⏰ Payment Due in 3 Days</h2>
  <p style="color:#94A3B8;margin:0;font-size:13px">Contract: {contract_number}</p>
</div>

<p style="color:#E2E8F0;font-size:15px">Hi <strong>{name}</strong>,</p>
<p style="color:#94A3B8;font-size:14px;line-height:1.6">
  This is a reminder that a payment of <strong style="color:#60A5FA">{amt_str}</strong>
  is due on <strong style="color:#F8FAFC">{due_date}</strong>.
</p>

<div style="background:#0F172A;border:1px solid #334155;border-radius:10px;padding:20px;margin:20px 0">
  <table width="100%" style="font-size:13px;color:#94A3B8">
    <tr><td style="padding:6px 0">📋 Description</td><td style="color:#E2E8F0;text-align:right">{description}</td></tr>
    <tr><td style="padding:6px 0">💰 Amount Due</td><td style="color:#60A5FA;font-size:16px;font-weight:700;text-align:right">{amt_str}</td></tr>
    <tr><td style="padding:6px 0">📅 Due Date</td><td style="color:#F59E0B;text-align:right">{due_date}</td></tr>
  </table>
</div>

<p style="color:#94A3B8;font-size:13px">
  You will receive a payment link on the due date. Please ensure your payment is ready to avoid any service interruption.
</p>
<p style="color:#EF4444;font-size:12px;margin-top:16px">
  ⚠️ Late payments may result in account suspension or blacklisting as per contract terms.
</p>
""")
    _send_email_async(to_email, f"⏰ Payment Due in 3 Days — {amt_str} | CODVerify", html)


async def send_payment_overdue_warning(
    to_email: str,
    name: str,
    amount: float,
    currency: str,
    due_date: str,
    overdue_days: int,
    contract_number: str,
    description: str,
) -> None:
    """Overdue payment warning with blacklisting notice."""
    amt_str = _fmt_amount(amount, currency)
    html = _wrap_html(f"""
<div style="background:#7F1D1D;border-radius:12px;padding:28px 32px;margin-bottom:24px;border:1px solid #EF4444">
  <h2 style="color:#FCA5A5;margin:0 0 4px 0;font-size:18px">🚨 OVERDUE PAYMENT — Action Required</h2>
  <p style="color:#FCA5A5;margin:0;font-size:13px;opacity:0.8">Contract: {contract_number} | {overdue_days} day(s) overdue</p>
</div>

<p style="color:#E2E8F0;font-size:15px">Hi <strong>{name}</strong>,</p>
<p style="color:#94A3B8;font-size:14px;line-height:1.6">
  Your payment of <strong style="color:#EF4444">{amt_str}</strong> was due on
  <strong style="color:#F8FAFC">{due_date}</strong> and remains unpaid.
  It is now <strong style="color:#EF4444">{overdue_days} day(s) overdue</strong>.
</p>

<div style="background:#0F172A;border:1px solid #EF4444;border-radius:10px;padding:20px;margin:20px 0">
  <table width="100%" style="font-size:13px;color:#94A3B8">
    <tr><td style="padding:6px 0">📋 Description</td><td style="color:#E2E8F0;text-align:right">{description}</td></tr>
    <tr><td style="padding:6px 0">💰 Amount Overdue</td><td style="color:#EF4444;font-size:16px;font-weight:700;text-align:right">{amt_str}</td></tr>
    <tr><td style="padding:6px 0">📅 Was Due On</td><td style="color:#EF4444;text-align:right">{due_date}</td></tr>
    <tr><td style="padding:6px 0">⏱ Days Late</td><td style="color:#EF4444;font-weight:700;text-align:right">{overdue_days} day(s)</td></tr>
  </table>
</div>

<div style="background:#450A0A;border:1px solid #DC2626;border-radius:8px;padding:16px;margin:16px 0">
  <p style="color:#FCA5A5;font-size:13px;margin:0">
    <strong>⚠️ Blacklisting Warning:</strong> Continued non-payment will result in your account being
    <strong>permanently blacklisted</strong> as per your contract terms. Your access to CODVerify
    services will be suspended until this payment is cleared.
  </p>
</div>

<p style="color:#94A3B8;font-size:13px">
  Please contact us immediately at <a href="mailto:support@codverify.tech" style="color:#60A5FA">support@codverify.tech</a>
  to resolve this payment.
</p>
""")
    _send_email_async(to_email, f"🚨 OVERDUE: {amt_str} payment — {overdue_days}d late | CODVerify", html)


async def send_invoice_payment_link(
    to_email: str,
    name: str,
    amount: float,
    currency: str,
    due_date: str,
    contract_number: str,
    description: str,
    payment_url: str,
    razorpay_order_id: str,
    razorpay_key: str,
) -> None:
    """
    Monthly billing email — sent on the due date with a direct Razorpay payment link.
    This replaces Razorpay Subscriptions entirely.
    Merchant clicks 'Pay Now' → Razorpay checkout → payment done → webhook updates invoice.
    """
    amt_str = _fmt_amount(amount, currency)
    html = _wrap_html(f"""
<div style="background:linear-gradient(135deg,#1E3A5F,#0F172A);border-radius:12px;padding:28px 32px;margin-bottom:24px;border:1px solid #3B82F6">
  <h2 style="color:#60A5FA;margin:0 0 4px 0;font-size:20px">💳 Monthly Payment Due</h2>
  <p style="color:#94A3B8;margin:0;font-size:13px">Contract: {contract_number}</p>
</div>

<p style="color:#E2E8F0;font-size:15px">Hi <strong>{name}</strong>,</p>
<p style="color:#94A3B8;font-size:14px;line-height:1.6">
  Your monthly payment of <strong style="color:#60A5FA">{amt_str}</strong> is due today.
  Click the button below to pay securely via Razorpay.
</p>

<div style="background:#0F172A;border:1px solid #334155;border-radius:10px;padding:20px;margin:20px 0">
  <table width="100%" style="font-size:13px;color:#94A3B8">
    <tr><td style="padding:6px 0">📋 Description</td><td style="color:#E2E8F0;text-align:right">{description}</td></tr>
    <tr><td style="padding:6px 0">💰 Amount</td><td style="color:#60A5FA;font-size:18px;font-weight:700;text-align:right">{amt_str}</td></tr>
    <tr><td style="padding:6px 0">📅 Due Date</td><td style="color:#F59E0B;text-align:right">{due_date}</td></tr>
    <tr><td style="padding:6px 0">🔖 Order ID</td><td style="color:#94A3B8;font-size:11px;text-align:right">{razorpay_order_id}</td></tr>
  </table>
</div>

<!-- Big pay button -->
<div style="text-align:center;margin:28px 0">
  <a href="{payment_url}"
     style="display:inline-block;background:linear-gradient(135deg,#2563EB,#3B82F6);
            color:#fff;font-size:16px;font-weight:700;padding:16px 40px;
            border-radius:10px;text-decoration:none;letter-spacing:0.5px;
            box-shadow:0 4px 15px rgba(59,130,246,0.4)">
    💳&nbsp;&nbsp;Pay {amt_str} Now
  </a>
</div>

<p style="color:#64748B;font-size:12px;text-align:center">
  This payment link is unique to your account. Do not share it with others.<br>
  Powered by <strong>Razorpay</strong> — 100% secure payment
</p>

<div style="background:#1E293B;border-radius:8px;padding:14px;margin-top:16px;border-left:3px solid #F59E0B">
  <p style="color:#94A3B8;font-size:12px;margin:0">
    ⚠️ <strong>Payment not made within 7 days</strong> of due date may lead to service suspension
    as per your contract terms. Contact <a href="mailto:support@codverify.tech" style="color:#60A5FA">support@codverify.tech</a> for help.
  </p>
</div>
""")
    _send_email_async(to_email, f"💳 Pay {amt_str} — Monthly Invoice Due Today | CODVerify", html)
