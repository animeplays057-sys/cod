"""Groq AI chatbot service for CODVerify customer support."""

import httpx
from loguru import logger
from config.settings import settings

_GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
_MODEL = settings.GROQ_MODEL or "llama-3.3-70b-versatile"

SYSTEM_PROMPT = """You are CODVerify's AI customer support assistant. You ONLY discuss CODVerify and its services. You do NOT answer any off-topic, general knowledge, or unrelated questions.

About CODVerify:
CODVerify is an intelligent COD (Cash on Delivery) order verification platform that helps e-commerce businesses reduce RTO (Return to Origin) losses.

Our Services:
- WhatsApp-based COD order verification (94% response rate)
- SMS + Voice call fallback verification (97% confirmation rate)
- AI-powered customer chatbot for order support
- Real-time analytics dashboard for merchants
- Shopify & WooCommerce integration (1-click install)
- Multi-language support (Hindi, English, etc.)
- Blacklist management for fraud prevention
- Custom notification templates

How CODVerify Works:
1. Customer places a COD order on merchant's store
2. CODVerify automatically sends a WhatsApp/SMS verification message
3. Customer confirms or cancels the order
4. Merchant gets real-time update — only confirmed orders are shipped
5. This reduces RTO by up to 45%

Pricing: Custom plans based on order volume, starting from ₹999/month.
Website: codverify.tech
Support Email: support@codverify.tech

RULES:
- ONLY answer questions about CODVerify, its services, pricing, features, integration, and setup
- If the customer asks ANYTHING unrelated, politely say: "I can only help with CODVerify-related questions."
- If the customer asks to speak with a human/agent, respond with exactly: [HANDOFF_REQUESTED]
- Keep responses concise (2-3 sentences max)
- Never make up information

LANGUAGE RULES:
- Start your FIRST message in English
- After that, match the customer's language exactly (Hindi, Hinglish, or English)
"""


def _is_configured() -> bool:
    return bool(getattr(settings, 'GROQ_API_KEY', None))


def _build_chat_messages(system_prompt: str, messages: list) -> list:
    """Build Groq chat message list from history."""
    chat = [{"role": "system", "content": system_prompt}]
    for m in messages[-20:]:
        if m.get("sender_type") == "system":
            continue
        role = "assistant" if m.get("sender_type") in ("ai", "worker") else "user"
        chat.append({"role": role, "content": m["message"]})
    return chat


async def _call_groq(chat_messages: list, temperature: float = 0.7, max_tokens: int = 350) -> str | None:
    """Make a Groq API call. Returns response text or None on error."""
    if not _is_configured():
        return None
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(
                _GROQ_URL,
                headers={
                    "Authorization": f"Bearer {settings.GROQ_API_KEY}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": _MODEL,
                    "messages": chat_messages,
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                    "top_p": 0.9,
                },
            )
            data = response.json()
            if response.status_code == 200 and "choices" in data:
                return data["choices"][0]["message"]["content"].strip()
            err = data.get("error", {}).get("message", f"HTTP {response.status_code}")
            logger.error(f"Groq API error: {err}")
            return None
    except Exception as e:
        logger.error(f"Groq API exception: {e}")
        return None


async def get_ai_response(messages: list, visitor_name: str = "Visitor") -> dict:
    """CODVerify main chatbot response.
    Returns: {"message": str, "handoff_requested": bool}
    """
    chat = _build_chat_messages(SYSTEM_PROMPT, messages)
    text = await _call_groq(chat)

    if text is None:
        return {
            "message": "Our AI assistant is currently unavailable. Would you like to speak with a support agent?",
            "handoff_requested": False,
        }

    handoff = "[HANDOFF_REQUESTED]" in text
    if handoff:
        text = text.replace("[HANDOFF_REQUESTED]", "").strip()
        if not text:
            text = "Let me connect you with a support agent. Please wait..."

    return {"message": text, "handoff_requested": handoff}


async def get_merchant_ai_response(messages: list, system_prompt: str) -> dict:
    """Merchant chatbot AI response.
    Returns: {"message": str, "handoff_requested": bool}
    """
    chat = _build_chat_messages(system_prompt, messages)
    text = await _call_groq(chat)

    if text is None:
        return {
            "message": "I'm having trouble right now. Would you like to speak with a support agent?",
            "handoff_requested": False,
        }

    handoff = "[HANDOFF_REQUESTED]" in text
    if handoff:
        text = text.replace("[HANDOFF_REQUESTED]", "").strip()
        if not text:
            text = "Let me connect you with a support agent. Please wait..."

    return {"message": text, "handoff_requested": handoff}


async def get_merchant_ai_with_order_data(messages: list, system_prompt: str, order_data: str) -> dict:
    """Second AI call: inject verified order data and get a natural response.
    Returns: {"message": str, "handoff_requested": bool}
    """
    chat = _build_chat_messages(system_prompt, messages)
    # Inject order data as a final system context
    chat.append({
        "role": "system",
        "content": (
            f"VERIFIED ORDER DATA: {order_data}\n\n"
            "Use the above verified order information to respond to the customer naturally. "
            "Be concise and helpful."
        )
    })

    text = await _call_groq(chat, temperature=0.4)

    if text is None:
        # Fallback: return raw order data formatted nicely
        return {"message": order_data, "handoff_requested": False}

    return {"message": text, "handoff_requested": False}


async def test_groq_connection() -> dict:
    """Test Groq API connectivity."""
    if not _is_configured():
        return {
            "success": False,
            "message": "GROQ_API_KEY is not set in environment variables.",
            "model": None,
        }
    chat = [{"role": "user", "content": "ping"}]
    text = await _call_groq(chat, max_tokens=5)
    if text is not None:
        return {"success": True, "message": "Connected to Groq API successfully.", "model": _MODEL}
    return {"success": False, "message": "Groq API connection failed.", "model": None}
