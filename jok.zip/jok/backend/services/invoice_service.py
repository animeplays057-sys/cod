"""
Invoice PDF generator for CODVerify.
Ultra-premium professional SaaS design using reportlab.
Page 1: Invoice  |  Page 2: Service Agreement
"""
import io
from datetime import datetime, timezone
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Spacer,
    Paragraph, HRFlowable, KeepTogether, PageBreak
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT, TA_JUSTIFY
from reportlab.graphics.shapes import Drawing, Rect, String
from reportlab.graphics import renderPDF
from loguru import logger


# ─── Brand Palette ────────────────────────────────────────────────────────────
BRAND_PURPLE     = colors.HexColor("#3730A3")
BRAND_PURPLE_MID = colors.HexColor("#4F46E5")
BRAND_PURPLE_LT  = colors.HexColor("#818CF8")
BRAND_PURPLE_DARK = colors.HexColor("#1E1B4B")
BRAND_ACCENT     = colors.HexColor("#7C3AED")   # violet accent
BRAND_TEAL       = colors.HexColor("#0891B2")   # cyan-700
BRAND_INDIGO_BG  = colors.HexColor("#EEF2FF")
BRAND_INDIGO_BORDER = colors.HexColor("#C7D2FE")
BRAND_DARK       = colors.HexColor("#0F0A2E")
BRAND_GRAY       = colors.HexColor("#6B7280")
BRAND_GRAY_LT    = colors.HexColor("#9CA3AF")
BRAND_GREEN      = colors.HexColor("#059669")
BRAND_GREEN_DARK = colors.HexColor("#065F46")
BRAND_GREEN_BG   = colors.HexColor("#ECFDF5")
BRAND_RED        = colors.HexColor("#DC2626")
BRAND_RED_BG     = colors.HexColor("#FEF2F2")
BRAND_BODY       = colors.HexColor("#374151")
BRAND_ROW_ALT    = colors.HexColor("#F5F3FF")
BORDER_COLOR     = colors.HexColor("#DDD6FE")
BRAND_AMBER      = colors.HexColor("#D97706")
BRAND_AMBER_BG   = colors.HexColor("#FFFBEB")
WHITE            = colors.white
OFF_WHITE        = colors.HexColor("#FAFBFF")


def _styles():
    s = getSampleStyleSheet()

    def add(name, **kw):
        parent = kw.pop("parent", "Normal")
        s.add(ParagraphStyle(name, parent=s[parent], **kw))

    add("LogoBrand",   fontSize=22, textColor=WHITE,        fontName="Helvetica-Bold", leading=26)
    add("LogoTag",     fontSize=8,  textColor=colors.HexColor("#C7D2FE"), fontName="Helvetica", leading=12)
    add("InvLabel",    fontSize=20, textColor=WHITE,        fontName="Helvetica-Bold", alignment=TA_RIGHT, leading=24)
    add("InvNumR",     fontSize=9,  textColor=colors.HexColor("#C7D2FE"), fontName="Helvetica", alignment=TA_RIGHT, leading=13)
    add("InvDateR",    fontSize=9,  textColor=colors.HexColor("#C7D2FE"), fontName="Helvetica", alignment=TA_RIGHT, leading=13)
    add("PlanBadge",   fontSize=10, textColor=WHITE,        fontName="Helvetica-Bold", alignment=TA_RIGHT, leading=14)

    add("SectionHead", fontSize=7,  textColor=BRAND_GRAY,  fontName="Helvetica-Bold",
        spaceAfter=4, letterSpacing=1.0)
    add("BillName",    fontSize=11, textColor=BRAND_DARK,  fontName="Helvetica-Bold", leading=15)
    add("BillDetail",  fontSize=9,  textColor=BRAND_GRAY,  fontName="Helvetica", leading=13)
    add("BillDetailB", fontSize=9,  textColor=BRAND_DARK,  fontName="Helvetica-Bold", leading=13)

    add("TH",          fontSize=8,  textColor=WHITE,        fontName="Helvetica-Bold", alignment=TA_LEFT)
    add("THR",         fontSize=8,  textColor=WHITE,        fontName="Helvetica-Bold", alignment=TA_RIGHT)
    add("Cell",        fontSize=9,  textColor=BRAND_BODY,   fontName="Helvetica", leading=13)
    add("CellGray",    fontSize=8,  textColor=BRAND_GRAY,  fontName="Helvetica", leading=12)
    add("CellR",       fontSize=9,  textColor=BRAND_BODY,   fontName="Helvetica", alignment=TA_RIGHT, leading=13)
    add("CellBold",    fontSize=9,  textColor=BRAND_DARK,  fontName="Helvetica-Bold", leading=13)
    add("TotalLabel",  fontSize=11, textColor=BRAND_DARK,  fontName="Helvetica-Bold")
    add("TotalAmt",    fontSize=14, textColor=BRAND_PURPLE, fontName="Helvetica-Bold", alignment=TA_RIGHT)

    add("StatusPaid",  fontSize=11, textColor=BRAND_GREEN,  fontName="Helvetica-Bold", alignment=TA_CENTER)
    add("StatusDue",   fontSize=11, textColor=BRAND_RED,    fontName="Helvetica-Bold", alignment=TA_CENTER)

    add("PayHead",     fontSize=7,  textColor=BRAND_GRAY,  fontName="Helvetica-Bold", letterSpacing=1.0)
    add("PayVal",      fontSize=9,  textColor=BRAND_DARK,  fontName="Helvetica-Bold", leading=13)
    add("PaySub",      fontSize=8,  textColor=BRAND_GRAY,  fontName="Helvetica", leading=12)

    add("NoteText",    fontSize=9,  textColor=BRAND_GRAY,  fontName="Helvetica", leading=14)
    add("Footer",      fontSize=7,  textColor=BRAND_GRAY_LT, fontName="Helvetica", alignment=TA_CENTER, leading=11)
    add("FooterBold",  fontSize=8,  textColor=BRAND_PURPLE, fontName="Helvetica-Bold", alignment=TA_CENTER, leading=12)

    # ── Service Agreement styles ──
    add("AgreeTitle",  fontSize=16, textColor=BRAND_DARK,  fontName="Helvetica-Bold", alignment=TA_CENTER, leading=20)
    add("AgreeSub",    fontSize=9,  textColor=BRAND_GRAY,  fontName="Helvetica", alignment=TA_CENTER, leading=13)
    add("ClauseHead",  fontSize=9,  textColor=BRAND_PURPLE, fontName="Helvetica-Bold", leading=14, spaceBefore=8)
    add("ClauseBody",  fontSize=8,  textColor=BRAND_BODY,  fontName="Helvetica", leading=13, alignment=TA_JUSTIFY)
    add("AcceptLine",  fontSize=9,  textColor=BRAND_DARK,  fontName="Helvetica-Bold", alignment=TA_CENTER, leading=14)

    return s


def _accent_bar(doc):
    """3-segment color bar under the header for visual flair."""
    W = doc.width
    seg = W / 3
    bar = Table([[""]*3], colWidths=[seg, seg, seg])
    bar.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, 0), BRAND_PURPLE_MID),
        ("BACKGROUND", (1, 0), (1, 0), BRAND_ACCENT),
        ("BACKGROUND", (2, 0), (2, 0), BRAND_TEAL),
        ("TOPPADDING",    (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
        ("LEFTPADDING",   (0, 0), (-1, -1), 0),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 0),
        ("LINEBELOW", (0, 0), (-1, 0), 5, BRAND_PURPLE_MID),
    ]))
    return bar


def _header_table(doc, invoice_no, issue_date, due_date, plan_name, styles):
    """Deep dark header with brand name + invoice label + plan badge."""
    W = doc.width

    left_rows = [
        [Paragraph("CODVerify", styles["LogoBrand"])],
        [Paragraph("Intelligent COD Order Verification Platform", styles["LogoTag"])],
        [Paragraph("codverify.tech  \u2022  support@codverify.tech", styles["LogoTag"])],
    ]
    left_tbl = Table(left_rows, colWidths=[W * 0.55])
    left_tbl.setStyle(TableStyle([
        ("TOPPADDING", (0, 0), (-1, -1), 1),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ]))

    right_rows = [
        [Paragraph("INVOICE", styles["InvLabel"])],
        [Paragraph(f"<b>{invoice_no}</b>", styles["InvNumR"])],
        [Paragraph(f"Issued: {issue_date}", styles["InvDateR"])],
    ]
    if plan_name:
        right_rows.append([Paragraph(f"\u2605 {plan_name.upper()} PLAN", styles["PlanBadge"])])

    right_tbl = Table(right_rows, colWidths=[W * 0.45])
    right_tbl.setStyle(TableStyle([
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
    ]))

    outer = Table([[left_tbl, right_tbl]], colWidths=[W * 0.55, W * 0.45])
    outer.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), BRAND_DARK),
        ("TOPPADDING", (0, 0), (-1, -1), 26),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 26),
        ("LEFTPADDING", (0, 0), (-1, -1), 26),
        ("RIGHTPADDING", (0, 0), (-1, -1), 26),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return outer


def _bill_section(doc, merchant_name, merchant_email, merchant_store,
                  merchant_address, merchant_company, merchant_gst, styles):
    """Two-column section: Bill To (left) + Company info (right)."""
    W = doc.width

    bill_lines = []
    display_name = merchant_company or merchant_name or ""
    if display_name:
        bill_lines.append(Paragraph(display_name, styles["BillName"]))
    if merchant_company and merchant_name and merchant_name != merchant_company:
        bill_lines.append(Paragraph(f"Contact: {merchant_name}", styles["BillDetail"]))
    if merchant_store:
        bill_lines.append(Paragraph(f"Store: {merchant_store}", styles["BillDetail"]))
    if merchant_email:
        bill_lines.append(Paragraph(f"Email: {merchant_email}", styles["BillDetail"]))
    if merchant_address:
        bill_lines.append(Paragraph(merchant_address, styles["BillDetail"]))
    if merchant_gst:
        bill_lines.append(Paragraph(f"GSTIN: {merchant_gst}", styles["BillDetailB"]))

    company_lines = [
        Paragraph("CODVerify", styles["BillName"]),
        Paragraph("COD Verification & E-Commerce Solutions", styles["BillDetail"]),
        Paragraph("New Delhi, India — 110001", styles["BillDetail"]),
        Paragraph("support@codverify.tech", styles["BillDetail"]),
        Paragraph("codverify.tech", styles["BillDetail"]),
    ]

    def _col(label, items):
        rows = [[Paragraph(label, styles["SectionHead"])]]
        for item in items:
            rows.append([item])
        t = Table(rows, colWidths=[W * 0.45])
        t.setStyle(TableStyle([
            ("TOPPADDING", (0, 0), (-1, -1), 2),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
            ("LEFTPADDING", (0, 0), (-1, -1), 0),
            ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ]))
        return t

    outer = Table(
        [[_col("BILL TO", bill_lines), _col("FROM", company_lines)]],
        colWidths=[W * 0.5, W * 0.5]
    )
    outer.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), BRAND_INDIGO_BG),
        ("BOX", (0, 0), (-1, -1), 0.5, BORDER_COLOR),
        ("TOPPADDING", (0, 0), (-1, -1), 14),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 14),
        ("LEFTPADDING", (0, 0), (-1, -1), 16),
        ("RIGHTPADDING", (0, 0), (-1, -1), 16),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    return outer


def _payment_details_section(doc, payment_method, transaction_id, styles):
    """Payment method + transaction ID strip."""
    if not payment_method and not transaction_id:
        return None
    W = doc.width

    rows = []
    if payment_method:
        rows.append([
            Paragraph("PAYMENT METHOD", styles["PayHead"]),
            Paragraph(payment_method, styles["PayVal"]),
        ])
    if transaction_id:
        rows.append([
            Paragraph("TRANSACTION / REF. ID", styles["PayHead"]),
            Paragraph(transaction_id, styles["PayVal"]),
        ])

    col_w = W * 0.3
    t = Table(rows, colWidths=[col_w, W - col_w])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), BRAND_INDIGO_BG),
        ("BOX", (0, 0), (-1, -1), 0.5, BORDER_COLOR),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("LEFTPADDING", (0, 0), (-1, -1), 14),
        ("RIGHTPADDING", (0, 0), (-1, -1), 14),
        ("LINEBELOW", (0, 0), (-1, -2), 0.3, BORDER_COLOR),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return t


def _items_table(doc, line_items, sym, styles):
    """Ultra-clean services table."""
    W = doc.width
    header = [
        Paragraph("#", styles["TH"]),
        Paragraph("Service / Description", styles["TH"]),
        Paragraph("Amount", styles["THR"]),
    ]
    rows = [header]
    for i, item in enumerate(line_items, 1):
        desc = item.get("description", "")
        name = item.get("name", "Service")
        if desc:
            cell = Paragraph(f"{name}<br/><font size='7' color='#9CA3AF'>{desc}</font>", styles["Cell"])
        else:
            cell = Paragraph(name, styles["Cell"])
        amt = item.get("amount", 0)
        amt_text = f"{sym}{amt:,.2f}" if amt else "—"
        rows.append([
            Paragraph(str(i), styles["CellGray"]),
            cell,
            Paragraph(amt_text, styles["CellR"]),
        ])

    col_w = [W * 0.06, W * 0.68, W * 0.26]
    t = Table(rows, colWidths=col_w, repeatRows=1)
    bg_alt = [BRAND_ROW_ALT, WHITE]
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), BRAND_PURPLE),
        ("LINEBELOW", (0, 0), (-1, 0), 0, WHITE),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), bg_alt),
        ("LINEBELOW", (0, 0), (-1, -1), 0.4, BORDER_COLOR),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, 0), 10),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 10),
        ("TOPPADDING", (0, 1), (-1, -1), 9),
        ("BOTTOMPADDING", (0, 1), (-1, -1), 9),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("BOX", (0, 0), (-1, -1), 0.5, BORDER_COLOR),
    ]))
    return t


def _totals_table(doc, subtotal, tax_rate, tax_amount, total, sym, styles):
    W = doc.width
    rows = [
        [Paragraph("Subtotal", styles["BillDetail"]),
         Paragraph(f"{sym}{subtotal:,.2f}", styles["CellR"])],
    ]
    if tax_rate > 0:
        rows.append([
            Paragraph(f"GST ({tax_rate}%)", styles["BillDetail"]),
            Paragraph(f"{sym}{tax_amount:,.2f}", styles["CellR"])],
        )
    rows.append([
        Paragraph("<b>TOTAL AMOUNT</b>", styles["TotalLabel"]),
        Paragraph(f"<b>{sym}{total:,.2f}</b>", styles["TotalAmt"])],
    )

    right_w = W * 0.35
    t = Table(rows, colWidths=[W - right_w, right_w])
    t.setStyle(TableStyle([
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("LINEABOVE", (0, -1), (-1, -1), 1.5, BRAND_PURPLE),
        ("BACKGROUND", (0, -1), (-1, -1), BRAND_INDIGO_BG),
        ("TOPPADDING", (0, -1), (-1, -1), 10),
        ("BOTTOMPADDING", (0, -1), (-1, -1), 10),
        ("LEFTPADDING", (0, -1), (-1, -1), 10),
        ("RIGHTPADDING", (0, -1), (-1, -1), 10),
        ("BOX", (0, -1), (-1, -1), 0.5, BORDER_COLOR),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return t


def _status_badge(doc, payment_status, styles):
    W = doc.width
    if payment_status == "paid":
        label = "\u2714\u2714  PAYMENT CONFIRMED  \u2714\u2714"
        style = styles["StatusPaid"]
        bg = BRAND_GREEN_BG
        border = BRAND_GREEN
        line_color = BRAND_GREEN
    else:
        label = "\u26a0  PAYMENT DUE  \u26a0"
        style = styles["StatusDue"]
        bg = BRAND_RED_BG
        border = BRAND_RED
        line_color = BRAND_RED

    t = Table([[Paragraph(label, style)]], colWidths=[W])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), bg),
        ("BOX", (0, 0), (-1, -1), 2, border),
        ("LINEABOVE", (0, 0), (-1, 0), 4, line_color),
        ("TOPPADDING", (0, 0), (-1, -1), 12),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 12),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("ROUNDEDCORNERS", [6, 6, 6, 6]),
    ]))
    return t


# ─── SERVICE AGREEMENT (Page 2) ───────────────────────────────────────────────

def _build_service_agreement(doc, invoice_no, merchant_name, merchant_company,
                              issue_date, plan_name, services, styles):
    """Build Service Agreement elements for page 2."""
    W = doc.width
    client = merchant_company or merchant_name or "Client"
    svc_list = ", ".join(
        (s if isinstance(s, str) else s.get("name", "Service")) for s in (services or [])
    ) or "COD Verification Services"
    plan_display = plan_name or "Custom"

    elements = []

    # ── Agreement Header ──
    elements.append(Spacer(1, 4 * mm))
    elements.append(HRFlowable(width="100%", thickness=2, color=BRAND_PURPLE, spaceAfter=6, spaceBefore=0))
    elements.append(Paragraph("SERVICE AGREEMENT", styles["AgreeTitle"]))
    elements.append(Spacer(1, 2 * mm))
    elements.append(Paragraph(
        f"This Agreement is between CODVerify ('Service Provider') and {client} ('Client')  |  "
        f"Contract Ref: {invoice_no}  |  Date: {issue_date}",
        styles["AgreeSub"]
    ))
    elements.append(HRFlowable(width="100%", thickness=1, color=BORDER_COLOR, spaceAfter=4, spaceBefore=6))
    elements.append(Spacer(1, 2 * mm))

    clauses = [
        (
            "1. SCOPE OF SERVICES",
            f"CODVerify agrees to provide the following services under the <b>{plan_display}</b> plan: "
            f"{svc_list}. Services shall be delivered as described in the associated invoice and are subject to "
            f"reasonable fair-use policies."
        ),
        (
            "2. PAYMENT TERMS",
            "All fees are payable in advance as specified in the invoice. Payments are <b>non-refundable</b> "
            "once services have been activated. Any disputed charges must be raised within 7 days of the invoice date."
        ),
        (
            "3. SUBSCRIPTION & RENEWAL",
            "This is a monthly subscription service. The plan renews automatically each billing cycle unless "
            "cancelled by the Client with at least 7 days' notice before the next renewal date. CODVerify reserves "
            "the right to adjust pricing with 30 days' notice."
        ),
        (
            "4. CANCELLATION POLICY",
            "The Client may cancel the subscription by providing written notice to support@codverify.tech at least "
            "7 days before the next billing date. Cancellation takes effect at the end of the current billing period. "
            "No partial refunds will be issued for unused days."
        ),
        (
            "5. ACCEPTABLE USE",
            "The Client agrees not to use CODVerify services for spam, fraud, deceptive practices, or any activity "
            "that violates applicable laws. CODVerify reserves the right to suspend or terminate access immediately "
            "upon detection of misuse without notice or refund."
        ),
        (
            "6. LIMITATION OF LIABILITY",
            "CODVerify is not responsible for delivery failures, courier delays, or order cancellations arising "
            "from factors beyond its control. CODVerify's total liability shall not exceed the fees paid by the "
            "Client in the preceding 30 days."
        ),
        (
            "7. SERVICE UPTIME",
            "CODVerify targets a minimum platform uptime of 95% per calendar month, excluding scheduled maintenance "
            "windows. Planned outages will be communicated at least 24 hours in advance."
        ),
        (
            "8. DATA PRIVACY",
            "All customer data processed through CODVerify is handled in accordance with our Privacy Policy "
            "(codverify.tech/privacy). CODVerify does not sell or share personal data with third parties except "
            "as required for service delivery or by law."
        ),
        (
            "9. TERMINATION",
            "Either party may terminate this Agreement with 15 days' written notice. CODVerify may terminate "
            "immediately in case of non-payment, breach of acceptable use, or violation of any clause herein. "
            "Upon termination, access to services will be revoked within 24 hours."
        ),
        (
            "10. GOVERNING LAW & JURISDICTION",
            "This Agreement is governed by the laws of India. All disputes shall be subject to the exclusive "
            "jurisdiction of courts in <b>New Delhi, India</b>."
        ),
    ]

    for head, body in clauses:
        elements.append(Paragraph(head, styles["ClauseHead"]))
        elements.append(Paragraph(body, styles["ClauseBody"]))

    elements.append(Spacer(1, 6 * mm))
    elements.append(HRFlowable(width="100%", thickness=1, color=BRAND_PURPLE, spaceAfter=6, spaceBefore=0))

    # Acceptance line
    accept_tbl = Table(
        [[Paragraph(
            "By making payment against this invoice, the Client acknowledges having read, understood, "
            "and agreed to all terms of this Service Agreement.",
            styles["AcceptLine"]
        )]],
        colWidths=[W]
    )
    accept_tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), BRAND_INDIGO_BG),
        ("BOX", (0, 0), (-1, -1), 1, BRAND_INDIGO_BORDER),
        ("TOPPADDING", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ("LEFTPADDING", (0, 0), (-1, -1), 16),
        ("RIGHTPADDING", (0, 0), (-1, -1), 16),
    ]))
    elements.append(accept_tbl)

    elements.append(Spacer(1, 4 * mm))
    elements.append(HRFlowable(width="100%", thickness=0.5, color=BORDER_COLOR, spaceAfter=4, spaceBefore=0))
    elements.append(Paragraph("CODVerify", styles["FooterBold"]))
    elements.append(Paragraph(
        f"codverify.tech  •  support@codverify.tech  •  New Delhi, India",
        styles["Footer"]
    ))
    elements.append(Paragraph(
        f"Contract Ref: {invoice_no}  •  © 2024–2026 CODVerify. All rights reserved.",
        styles["Footer"]
    ))

    return elements


# ─── MAIN GENERATOR ───────────────────────────────────────────────────────────

def generate_invoice_pdf(invoice_data: dict) -> bytes:
    """
    Generate ultra-premium 2-page PDF invoice.

    invoice_data keys:
        invoice_number, contract_number, issue_date, due_date,
        merchant_name, merchant_email, merchant_store,
        merchant_address, merchant_company, merchant_gst,
        plan_name (Starter / Growth / Pro / Enterprise / Custom),
        payment_method (e.g. "Razorpay"), transaction_id,
        chatbot_tier, billing_period,
        line_items: [{name, description, amount}],
        subtotal, tax_rate, tax_amount, total,
        currency (INR/USD), payment_status (paid/due),
        notes
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        leftMargin=18 * mm, rightMargin=18 * mm,
        topMargin=12 * mm, bottomMargin=12 * mm,
    )
    styles = _styles()
    elements = []

    # ── Data Extraction ──
    invoice_no     = invoice_data.get("invoice_number", "INV-000000")
    issue_date     = invoice_data.get("issue_date", datetime.now(timezone.utc).strftime("%B %d, %Y"))
    due_date       = invoice_data.get("due_date", "")
    currency       = invoice_data.get("currency", "INR")
    sym            = "\u20B9" if currency == "INR" else "$"
    plan_name      = invoice_data.get("plan_name", "")
    merchant_name  = invoice_data.get("merchant_name", "")
    merchant_email = invoice_data.get("merchant_email", "")
    merchant_store = invoice_data.get("merchant_store", "")
    merchant_addr  = invoice_data.get("merchant_address", "")
    merchant_co    = invoice_data.get("merchant_company", "")
    merchant_gst   = invoice_data.get("merchant_gst", "")
    payment_method = invoice_data.get("payment_method", "")
    transaction_id = invoice_data.get("transaction_id", "")
    subtotal       = invoice_data.get("subtotal", invoice_data.get("total", 0))
    tax_rate       = invoice_data.get("tax_rate", 0)
    tax_amount     = invoice_data.get("tax_amount", 0)
    total          = invoice_data.get("total", 0)
    payment_status = invoice_data.get("payment_status", "due")
    notes          = invoice_data.get("notes", "")
    services       = invoice_data.get("services", [])

    line_items = invoice_data.get("line_items", [])
    if not line_items:
        pname = plan_name or invoice_data.get("chatbot_tier", "") or "CODVerify Service Plan"
        chatbot = invoice_data.get("chatbot_tier", "")
        desc = f"AI Chatbot Tier: {chatbot.replace('_', ' ').capitalize()}" if chatbot and chatbot != "none" else ""
        line_items = [{"name": pname, "description": desc, "amount": total}]

    # ─────────────────────────────────────────────────────────────────────
    # PAGE 1: INVOICE
    # ─────────────────────────────────────────────────────────────────────

    # ── 1. Header + accent bar ──
    elements.append(_header_table(doc, invoice_no, issue_date, due_date, plan_name, styles))
    elements.append(_accent_bar(doc))
    elements.append(Spacer(1, 6 * mm))

    # ── 2. Bill To / From ──
    elements.append(_bill_section(
        doc, merchant_name, merchant_email, merchant_store,
        merchant_addr, merchant_co, merchant_gst, styles
    ))
    elements.append(Spacer(1, 5 * mm))

    # ── 3. Payment Details (if present) ──
    pay_section = _payment_details_section(doc, payment_method, transaction_id, styles)
    if pay_section:
        elements.append(pay_section)
        elements.append(Spacer(1, 5 * mm))

    # ── 4. Services label ──
    elements.append(HRFlowable(width="100%", thickness=1.5, color=BRAND_PURPLE, spaceAfter=2, spaceBefore=0))
    elements.append(Paragraph("SERVICES", styles["SectionHead"]))
    elements.append(Spacer(1, 2 * mm))

    # ── 5. Line Items ──
    elements.append(_items_table(doc, line_items, sym, styles))
    elements.append(Spacer(1, 5 * mm))

    # ── 6. Totals ──
    elements.append(_totals_table(doc, subtotal, tax_rate, tax_amount, total, sym, styles))
    elements.append(Spacer(1, 5 * mm))

    # ── 7. Payment Status Badge ──
    elements.append(_status_badge(doc, payment_status, styles))
    elements.append(Spacer(1, 5 * mm))

    # ── 8. Notes ──
    if notes:
        elements.append(Paragraph("NOTES", styles["SectionHead"]))
        elements.append(Spacer(1, 1 * mm))
        elements.append(Paragraph(notes, styles["NoteText"]))
        elements.append(Spacer(1, 5 * mm))

    # ── 9. Page 1 Footer ──
    elements.append(HRFlowable(width="100%", thickness=0.5, color=BORDER_COLOR, spaceAfter=4, spaceBefore=0))
    elements.append(Paragraph("CODVerify", styles["FooterBold"]))
    elements.append(Paragraph("Intelligent COD Order Verification Platform", styles["Footer"]))
    elements.append(Paragraph(
        f"codverify.tech  •  support@codverify.tech  •  New Delhi, India",
        styles["Footer"]
    ))
    elements.append(Paragraph(
        f"Invoice {invoice_no}  •  Generated {issue_date}  •  © 2024–2026 CODVerify. All rights reserved.",
        styles["Footer"]
    ))

    # ─────────────────────────────────────────────────────────────────────
    # PAGE 2: SERVICE AGREEMENT
    # ─────────────────────────────────────────────────────────────────────
    elements.append(PageBreak())
    elements.extend(_build_service_agreement(
        doc, invoice_no, merchant_name, merchant_co,
        issue_date, plan_name, services, styles
    ))

    # ── Build ──
    try:
        doc.build(elements)
    except Exception as e:
        logger.error(f"PDF generation failed: {e}")
        raise

    pdf_bytes = buffer.getvalue()
    buffer.close()
    return pdf_bytes
