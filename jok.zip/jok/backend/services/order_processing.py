from datetime import datetime, timezone, timedelta
import re
import httpx
from loguru import logger
from config.database import get_db
from config.settings import settings
from utils.encryption import decrypt_value
from services.whatsapp_service import send_interactive_button_message, send_template_message
from services.notification_service import create_notification
from config.service_pricing import get_price


def is_india_number(phone: str) -> bool:
    digits = re.sub(r"\D", "", phone)
    return digits.startswith("91") and len(digits) == 12


async def process_pending_orders():
    """Process orders scheduled for verification via WhatsApp."""
    db = get_db()
    now = datetime.now(timezone.utc).isoformat()

    try:
        # Pick up pending orders + failed orders that were never actually sent (no verification_sent_at)
        pending = db.table("orders").select("*").eq(
            "verification_status", "pending"
        ).lte("scheduled_send_at", now).limit(50).execute()

        never_sent = db.table("orders").select("*").eq(
            "verification_status", "failed"
        ).is_("verification_sent_at", "null").lte("scheduled_send_at", now).limit(10).execute()

        orders_to_process = (pending.data or []) + (never_sent.data or [])
        result_data = {o["id"]: o for o in orders_to_process}  # deduplicate by id

        if not result_data:
            return

        logger.info(f"⏰ Scheduler: {len(result_data)} order(s) ready for WA verification")

        for order in result_data.values():
            logger.info(f"⏰ Processing order #{order.get('order_number')} id={order['id']} phone={order.get('customer_phone_normalized')}")
            try:
                success = await _send_verification_for_order(db, order)
                logger.info(f"⏰ Order #{order.get('order_number')} → send result: {success}")
            except Exception as e:
                logger.error(f"⏰ Exception processing order {order['id']}: {e}")
                continue
    except Exception as e:
        logger.error(f"Error in process_pending_orders: {e}")


async def _send_verification_for_order(db, order: dict):
    """Route verification to the correct channel based on customer phone country."""
    # Check message toggles
    ms_res = db.table("merchant_settings").select(
        "enable_verification_msg, cod_verification_enabled"
    ).eq("user_id", order["user_id"]).execute()

    if ms_res.data:
        ms = ms_res.data[0]
        # Skip if COD verification service is disabled (customer support plan only)
        if ms.get("cod_verification_enabled") is False:
            logger.info(f"COD verification disabled for user {order['user_id']}, skipping order {order['id']}")
            return
        # Skip if verification messages are toggled off
        if ms.get("enable_verification_msg") is False:
            logger.info(f"Verification msg disabled for user {order['user_id']}, skipping order {order['id']}")
            return

    # --- Detect channel from customer phone number ---
    customer_phone = order.get("customer_phone_normalized", "")

    if is_india_number(customer_phone):
        success = await _send_whatsapp_verification(db, order)
    else:
        # Non-India numbers — send WhatsApp as well (works globally if customer has WhatsApp)
        logger.info(f"Order {order['id']} → WhatsApp for phone={customer_phone}")
        success = await _send_whatsapp_verification(db, order)

    return success


async def _build_verification_message(order: dict, channel: str = "whatsapp") -> str:
    """Build the verification message text for WhatsApp (India)."""
    products = order.get("products_json") or []
    product_names = ", ".join([p.get("name", "Item") for p in products[:3]])
    if len(products) > 3:
        product_names += f" +{len(products)-3} more"

    addr = order.get("shipping_address_json") or {}
    address_short = f"{addr.get('city', '')}, {addr.get('state', '')} {addr.get('pincode', '')}".strip(", ")
    amount = order.get("order_amount", 0)
    currency_sym = "$" if order.get("currency") == "USD" else "₹"
    order_num = order.get("order_number", order.get("store_order_id", "N/A"))

    # WhatsApp rich format
    return (
        f"Hi {order['customer_name']}! 👋\n\n"
        f"Your order *#{order_num}* has been placed.\n\n"
        f"📦 Items: {product_names}\n"
        f"💰 Amount: {currency_sym}{amount}\n"
        f"📍 Delivery: {address_short}\n\n"
        f"Please confirm if you want us to ship this order."
    )


async def _send_whatsapp_verification(db, order: dict) -> bool:
    """Send WhatsApp template message for COD order verification."""
    phone_id = settings.WHATSAPP_PHONE_NUMBER_ID
    access_token = settings.WHATSAPP_ACCESS_TOKEN

    logger.info(f"📤 _send_whatsapp_verification: order={order['id']} phone={order.get('customer_phone_normalized')}")
    logger.info(f"📤 Credentials: phone_id={'SET' if phone_id else 'MISSING'} token={'SET' if access_token else 'MISSING'}")

    if not phone_id or not access_token:
        logger.warning(f"WhatsApp credentials not configured — order {order['id']} kept pending for manual worker verification")
        return False

    # Get store name
    store_name = ""
    if order.get("store_id"):
        store_res = db.table("stores").select("store_name, store_url").eq("id", order["store_id"]).execute()
        if store_res.data:
            store_name = store_res.data[0].get("store_name") or store_res.data[0].get("store_url") or ""
    if not store_name:
        # Fallback: use merchant company name
        user_res = db.table("users").select("company_name, name").eq("id", order["user_id"]).execute()
        if user_res.data:
            store_name = user_res.data[0].get("company_name") or user_res.data[0].get("name") or "Our Store"
    if not store_name:
        store_name = "Our Store"

    # Build variables
    products = order.get("products_json") or []
    product_names = ", ".join([p.get("name", "Item") for p in products[:2]])
    if len(products) > 2:
        product_names += f" +{len(products)-2} more"
    if not product_names:
        product_names = "Your ordered items"

    addr = order.get("shipping_address_json") or {}
    address_short = f"{addr.get('city', '')}, {addr.get('state', '')} {addr.get('pincode', '')}".strip(", ") or "N/A"

    amount = order.get("order_amount", 0)
    order_num = order.get("order_number") or order.get("store_order_id") or "N/A"
    customer_name = order.get("customer_name") or "Customer"

    components = [{
        "type": "body",
        "parameters": [
            {"type": "text", "text": customer_name},
            {"type": "text", "text": store_name},
            {"type": "text", "text": str(order_num)},
            {"type": "text", "text": product_names},
            {"type": "text", "text": str(amount)},
            {"type": "text", "text": address_short},
        ]
    }]

    wa_msg_id = await send_template_message(
        phone_id, access_token,
        order["customer_phone_normalized"],
        "order_verification", "en",
        components
    )

    if wa_msg_id:
        now_ts = datetime.now(timezone.utc).isoformat()
        db.table("orders").update({
            "verification_status": "queued",
            "verification_sent_at": now_ts,
            "verification_channel": "whatsapp",
        }).eq("id", order["id"]).execute()

        db.table("messages").insert({
            "order_id": order["id"],
            "user_id": order["user_id"],
            "whatsapp_message_id": wa_msg_id,
            "direction": "outbound",
            "message_type": "template",
            "content": f"Order verification sent for #{order_num} to {customer_name}",
            "status": "queued",
        }).execute()

        # ── Wallet debit ₹0.05 per WhatsApp message ──────────────────────
        charge = get_price("whatsapp_verification")  # ✅ Correct key
        if charge > 0:
            try:
                from services import wallet_service
                await wallet_service.debit_wallet(
                    db,
                    user_id=order["user_id"],
                    amount=charge,
                    service_key="whatsapp_cod_verification",
                    description=f"WhatsApp COD verification — Order #{order_num}",
                    reference_id=order["id"],
                )
            except Exception as e:
                # Non-fatal: log but don't block the message
                logger.warning(f"Wallet debit failed for order {order['id']}: {e}")

        logger.info(f"✅ WA order_verification template sent for order {order['id']}, wa_msg={wa_msg_id}")
        return True
    else:
        logger.warning(f"WhatsApp template send failed for order {order['id']} — kept pending for manual worker verification")
        return False



async def check_timeouts():
    """
    Verification timeout handler — runs every 15 min via scheduler.

    Step 1 — 30-min escalation to worker:
        If order WA was sent 30+ minutes ago and customer hasn't replied,
        move it to 'no_reply' so it appears in the worker call queue.
    """
    db = get_db()
    now = datetime.now(timezone.utc)
    thirty_min_ago = (now - timedelta(minutes=30)).isoformat()

    # Statuses that mean WA was sent but customer hasn't replied yet
    SENT_STATUSES = ["queued", "sent", "delivered", "read"]

    try:
        # ─────────────────────────────────────────────────────
        # 30-MIN ESCALATION → worker call queue
        # ─────────────────────────────────────────────────────
        escalation_res = (
            db.table("orders")
            .select("id, user_id, order_number, store_order_id")
            .in_("verification_status", SENT_STATUSES)
            .lte("verification_sent_at", thirty_min_ago)
            .execute()
        )

        escalated = 0
        for order in (escalation_res.data or []):
            try:
                db.table("orders").update({
                    "verification_status": "no_reply",
                }).eq("id", order["id"]).execute()

                order_label = order.get("order_number") or order.get("store_order_id") or order["id"][:8]
                await create_notification(
                    order["user_id"],
                    f"📞 Order #{order_label} → Call Verification Queue",
                    "No WhatsApp response after 30 minutes. Order forwarded to worker call queue.",
                    "warning", "orders", f"/dashboard/orders/{order['id']}"
                )
                logger.info(f"📞 30min escalation: Order #{order_label} → no_reply (worker queue)")
                escalated += 1
            except Exception as e:
                logger.error(f"Escalation error for order {order['id']}: {e}")

        if escalated:
            logger.info(f"📞 30min escalation: {escalated} order(s) moved to worker call queue")

    except Exception as e:
        logger.error(f"Error in check_timeouts: {e}")




async def update_store_order(order: dict, new_status: str):
    """Update the order on the merchant's e-commerce store (Shopify / WooCommerce / custom)."""
    db = get_db()
    if not order.get("store_id"):
        return

    store_res = db.table("stores").select("*").eq("id", order["store_id"]).execute()
    if not store_res.data:
        return
    store_data = store_res.data[0]
    platform = store_data.get("platform")

    try:
        if platform == "shopify":
            await _update_shopify_order(store_data, order, new_status)
        elif platform == "woocommerce":
            await _update_woocommerce_order(store_data, order, new_status)
        else:
            await _update_custom_store_order(store_data, order, new_status)
        logger.info(f"✅ Store order {order.get('store_order_id')} updated to {new_status} on {platform}")
    except Exception as e:
        logger.warning(f"Store order update failed for {order['id']}: {e}")


async def _update_shopify_order(store: dict, order: dict, status: str):
    access_token = decrypt_value(store.get("access_token_encrypted", ""))
    if not access_token:
        # Fallback to api_secret if access_token not available
        access_token = decrypt_value(store.get("api_secret_encrypted", ""))
    if not access_token:
        logger.warning(f"No Shopify access token for store {store.get('store_url')} — skipping update")
        return

    store_url = store["store_url"].rstrip("/")
    if not store_url.startswith("https://"):
        store_url = f"https://{store_url}"

    tag = "CODVerify-Confirmed" if status == "confirmed" else "CODVerify-Cancelled"
    note = f"CODVerify: Order {status} by customer"
    headers = {"X-Shopify-Access-Token": access_token}

    async with httpx.AsyncClient(timeout=30) as client:
        # Always update tags + note
        url = f"{store_url}/admin/api/2024-01/orders/{order['store_order_id']}.json"
        resp = await client.put(url, json={"order": {"tags": tag, "note": note}}, headers=headers)
        if resp.status_code >= 400:
            logger.error(f"Shopify order update failed ({resp.status_code}): {resp.text[:200]}")
            raise Exception(f"Shopify API returned {resp.status_code}")

        # If cancelled — actually cancel the Shopify order too
        if status == "cancelled":
            cancel_url = f"{store_url}/admin/api/2024-01/orders/{order['store_order_id']}/cancel.json"
            cancel_resp = await client.post(cancel_url, json={"reason": "customer"}, headers=headers)
            if cancel_resp.status_code >= 400:
                logger.warning(f"Shopify order cancel API failed ({cancel_resp.status_code}): {cancel_resp.text[:200]}")
                # Non-fatal — tag is already set, just log
            else:
                logger.info(f"Shopify order {order['store_order_id']} cancelled via API")


async def _update_woocommerce_order(store: dict, order: dict, status: str):
    api_key = decrypt_value(store.get("api_key_encrypted", ""))
    api_secret = decrypt_value(store.get("api_secret_encrypted", ""))
    store_url = store["store_url"].rstrip("/")
    if not store_url.startswith("https://") and not store_url.startswith("http://"):
        store_url = f"https://{store_url}"
    note = f"CODVerify: Order {status} by customer"
    auth = (api_key, api_secret)

    async with httpx.AsyncClient(timeout=30) as client:
        # Add order note
        note_url = f"{store_url}/wp-json/wc/v3/orders/{order['store_order_id']}/notes"
        await client.post(note_url, json={"note": note}, auth=auth)

        # Actually change WooCommerce order status (not just add a note)
        wc_status = "cancelled" if status == "cancelled" else "processing"
        status_url = f"{store_url}/wp-json/wc/v3/orders/{order['store_order_id']}"
        await client.put(status_url, json={"status": wc_status}, auth=auth)


async def _update_custom_store_order(store: dict, order: dict, status: str):
    ms_res = get_db().table("merchant_settings").select("webhook_callback_url").eq(
        "user_id", order["user_id"]
    ).execute()
    callback_url = ms_res.data[0].get("webhook_callback_url") if ms_res.data else None
    if not callback_url:
        return

    async with httpx.AsyncClient(timeout=30) as client:
        await client.post(callback_url, json={
            "event": "order_status_updated",
            "store_order_id": order["store_order_id"],
            "status": status,
            "order_id": order["id"],
        })


# ══════════════════════════════════════════════════════════════════════════════
# DELIVERY STATUS — WhatsApp Notification Dispatcher
# Called from store_webhooks.py → delivery_update endpoint
# ══════════════════════════════════════════════════════════════════════════════

async def send_delivery_update_message(
    order: dict,
    delivery_status: str,
    tracking_url: str = "",
) -> None:
    """
    Send a WhatsApp notification to the customer based on the new delivery_status.

    Status → Template mapping:
      shipped           → order_shipped       (with tracking link)
      out_for_delivery  → order_out_for_delivery
      delivered         → order_delivered     (with help center link)
      processing        → (no notification — internal status only)
    """
    from config.service_pricing import get_price
    from services import wallet_service
    from config.settings import settings as _s

    NOTIFIABLE = {"shipped", "out_for_delivery", "delivered"}
    if delivery_status not in NOTIFIABLE:
        logger.debug(f"Delivery status '{delivery_status}' — no WA notification needed")
        return

    customer_phone = order.get("customer_phone_normalized") or order.get("customer_phone", "")
    if not customer_phone:
        logger.warning(f"Order {order['id']} has no customer phone — delivery WA skipped")
        return

    customer_name = (order.get("customer_name") or "Customer").split()[0]
    order_number  = order.get("order_number") or order.get("store_order_id") or "N/A"
    user_id       = order.get("user_id", "")

    # Get store/merchant name
    store_name = "Our Store"
    try:
        db = get_db()
        _sr = db.table("stores").select("store_name, store_url").eq("id", order.get("store_id", "")).execute()
        if _sr.data:
            store_name = _sr.data[0].get("store_name") or _sr.data[0].get("store_url") or "Our Store"
        if store_name == "Our Store":
            _ur = db.table("users").select("company_name, name").eq("id", user_id).execute()
            if _ur.data:
                store_name = _ur.data[0].get("company_name") or _ur.data[0].get("name") or "Our Store"
    except Exception:
        pass

    # Help center URL (for delivered notification)
    frontend_url = getattr(_s, "FRONTEND_URL", "https://app.codverify.tech").rstrip("/")
    help_center_url = f"{frontend_url}/help"  # publicly accessible help center

    from services.whatsapp_service import (
        send_order_shipped_notification,
        send_order_out_for_delivery_notification,
        send_order_delivered_notification,
    )

    sent = False
    try:
        if delivery_status == "shipped":
            sent = await send_order_shipped_notification(
                customer_phone=customer_phone,
                customer_name=customer_name,
                order_number=order_number,
                store_name=store_name,
                tracking_number=order.get("tracking_number", ""),
                tracking_company=order.get("tracking_company", ""),
                tracking_url=tracking_url or order.get("tracking_url", ""),
            )
        elif delivery_status == "out_for_delivery":
            sent = await send_order_out_for_delivery_notification(
                customer_phone=customer_phone,
                customer_name=customer_name,
                order_number=order_number,
                store_name=store_name,
            )
        elif delivery_status == "delivered":
            sent = await send_order_delivered_notification(
                customer_phone=customer_phone,
                customer_name=customer_name,
                order_number=order_number,
                store_name=store_name,
                help_center_url=help_center_url,
            )
    except Exception as e:
        logger.error(f"Delivery WA notification error for order {order['id']}: {e}")
        return

    # Wallet debit ₹0.50 per delivery notification sent
    if sent and user_id:
        try:
            # Map delivery status to correct pricing key
            _delivery_key_map = {
                "shipped":          "order_shipped",
                "out_for_delivery": "order_shipped",
                "delivered":        "order_delivered",
            }
            charge = get_price(_delivery_key_map.get(delivery_status, "order_shipped"))  # ✅ Fixed
            if charge > 0:
                db = get_db()
                await wallet_service.debit_wallet(
                    db,
                    user_id=user_id,
                    amount=charge,
                    service_key="delivery_notification",
                    description=f"WhatsApp Delivery Update [{delivery_status}] — #{order_number}",
                    reference_id=order["id"],
                )
        except Exception as e:
            logger.warning(f"Wallet debit for delivery notification failed: {e}")

