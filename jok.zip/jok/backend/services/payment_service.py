"""
Payment Service — Multi-Gateway
================================
Handles both Razorpay (India/INR) and Stripe (International/USD).
Gateway is selected automatically based on user's country.
"""
import httpx
import hashlib
import hmac
from loguru import logger
from config.settings import settings

RAZORPAY_BASE = "https://api.razorpay.com/v1"

# Country → Currency/Gateway mapping
COUNTRY_CURRENCY_MAP = {
    "IN": {"currency": "INR", "symbol": "₹", "gateway": "razorpay", "multiplier": 100},   # paise
}
# Default for all other countries = USD + Stripe
DEFAULT_CURRENCY_CONFIG = {"currency": "USD", "symbol": "$", "gateway": "stripe", "multiplier": 100}  # cents


def get_currency_config(country_code: str) -> dict:
    """Return currency config based on user's country."""
    code = (country_code or "").upper().strip()
    return COUNTRY_CURRENCY_MAP.get(code, DEFAULT_CURRENCY_CONFIG)


# ── Razorpay ──────────────────────────────────────────────────────────────────

async def create_razorpay_order(amount_paise: int, currency: str = "INR", receipt: str = None, notes: dict = None) -> dict | None:
    """Create a Razorpay order. amount_paise = amount × 100."""
    razorpay_key = settings.RAZORPAY_KEY_ID
    razorpay_secret = settings.RAZORPAY_KEY_SECRET

    # Allow override from DB (admin can set keys in admin_settings)
    if not razorpay_key or not razorpay_secret:
        logger.error("Razorpay credentials not configured")
        return None

    async with httpx.AsyncClient(timeout=30, auth=(razorpay_key, razorpay_secret)) as client:
        try:
            resp = await client.post(f"{RAZORPAY_BASE}/orders", json={
                "amount": amount_paise,
                "currency": currency,
                "receipt": receipt or "",
                "notes": notes or {},
            })
            if resp.status_code == 200:
                return resp.json()
            logger.error(f"Razorpay create order error: {resp.text}")
            return None
        except Exception as e:
            logger.error(f"Razorpay exception: {e}")
            return None


# Keep backward-compat alias
create_order = create_razorpay_order


async def create_razorpay_subscription(plan_id: str, total_count: int = 12, notes: dict = None) -> dict | None:
    async with httpx.AsyncClient(timeout=30, auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET)) as client:
        try:
            resp = await client.post(f"{RAZORPAY_BASE}/subscriptions", json={
                "plan_id": plan_id,
                "total_count": total_count,
                "notes": notes or {},
            })
            if resp.status_code == 200:
                return resp.json()
            logger.error(f"Razorpay subscription error: {resp.text}")
            return None
        except Exception as e:
            logger.error(f"Razorpay exception: {e}")
            return None


create_subscription = create_razorpay_subscription


def verify_razorpay_signature(order_id: str, payment_id: str, signature: str) -> bool:
    secret = settings.RAZORPAY_KEY_SECRET
    if not secret:
        return False
    message = f"{order_id}|{payment_id}"
    expected = hmac.new(secret.encode(), message.encode(), hashlib.sha256).hexdigest()
    try:
        return hmac.compare_digest(expected, signature)
    except Exception:
        return False


verify_payment_signature = verify_razorpay_signature


def verify_razorpay_webhook(body: bytes, signature: str) -> bool:
    secret = settings.RAZORPAY_KEY_SECRET
    if not secret:
        return False
    expected = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    try:
        return hmac.compare_digest(expected, signature)
    except Exception:
        return False


verify_webhook_signature = verify_razorpay_webhook


# ── Stripe ────────────────────────────────────────────────────────────────────

async def create_stripe_payment_intent(amount_cents: int, currency: str = "usd", metadata: dict = None) -> dict | None:
    """
    Create a Stripe PaymentIntent.
    amount_cents = amount × 100 (e.g. $10 → 1000)
    Returns dict with { client_secret, payment_intent_id, publishable_key }
    """
    stripe_key = settings.STRIPE_SECRET_KEY
    if not stripe_key:
        logger.error("Stripe secret key not configured")
        return None

    async with httpx.AsyncClient(timeout=30) as client:
        try:
            data = {
                "amount": str(amount_cents),
                "currency": currency.lower(),
                "payment_method_types[]": "card",
            }
            if metadata:
                for k, v in metadata.items():
                    data[f"metadata[{k}]"] = str(v)

            resp = await client.post(
                "https://api.stripe.com/v1/payment_intents",
                data=data,
                headers={"Authorization": f"Bearer {stripe_key}"}
            )
            if resp.status_code == 200:
                result = resp.json()
                return {
                    "client_secret": result["client_secret"],
                    "payment_intent_id": result["id"],
                    "publishable_key": settings.STRIPE_PUBLISHABLE_KEY,
                    "amount": amount_cents,
                    "currency": currency.upper(),
                }
            logger.error(f"Stripe PaymentIntent error: {resp.text}")
            return None
        except Exception as e:
            logger.error(f"Stripe exception: {e}")
            return None


async def verify_stripe_payment(payment_intent_id: str) -> dict | None:
    """Retrieve and verify a Stripe PaymentIntent status."""
    stripe_key = settings.STRIPE_SECRET_KEY
    if not stripe_key:
        return None

    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.get(
                f"https://api.stripe.com/v1/payment_intents/{payment_intent_id}",
                headers={"Authorization": f"Bearer {stripe_key}"}
            )
            if resp.status_code == 200:
                data = resp.json()
                return {
                    "id": data["id"],
                    "status": data["status"],
                    "amount": data["amount"],
                    "currency": data["currency"].upper(),
                    "succeeded": data["status"] == "succeeded",
                }
            logger.error(f"Stripe verify error: {resp.text}")
            return None
        except Exception as e:
            logger.error(f"Stripe verify exception: {e}")
            return None


def verify_stripe_webhook(payload: bytes, sig_header: str) -> dict | None:
    """Verify Stripe webhook signature and return event dict."""
    import time
    webhook_secret = settings.STRIPE_WEBHOOK_SECRET
    if not webhook_secret:
        return None

    try:
        # Parse Stripe-Signature header (use maxsplit=1 to handle base64 '=' padding in values)
        parts = {}
        for p in sig_header.split(","):
            k, _, v = p.partition("=")
            parts[k] = v
        timestamp = parts.get("t", "")
        signature = parts.get("v1", "")

        # Check timestamp (prevent replay attacks — 5 min tolerance)
        if abs(time.time() - float(timestamp)) > 300:
            logger.warning("Stripe webhook timestamp too old")
            return None

        signed_payload = f"{timestamp}.{payload.decode()}"
        expected = hmac.new(webhook_secret.encode(), signed_payload.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, signature):
            return None

        import json
        return json.loads(payload)
    except Exception as e:
        logger.error(f"Stripe webhook verify error: {e}")
        return None


async def test_stripe_connection() -> dict:
    """Test if Stripe keys are valid."""
    stripe_key = settings.STRIPE_SECRET_KEY
    if not stripe_key:
        return {"success": False, "error": "Stripe secret key not configured"}

    async with httpx.AsyncClient(timeout=15) as client:
        try:
            resp = await client.get(
                "https://api.stripe.com/v1/balance",
                headers={"Authorization": f"Bearer {stripe_key}"}
            )
            if resp.status_code == 200:
                return {"success": True, "mode": "live" if not stripe_key.startswith("sk_test") else "test"}
            return {"success": False, "error": resp.json().get("error", {}).get("message", "Unknown error")}
        except Exception as e:
            return {"success": False, "error": str(e)}


async def test_razorpay_connection() -> dict:
    """Test if Razorpay keys are valid."""
    key_id = settings.RAZORPAY_KEY_ID
    key_secret = settings.RAZORPAY_KEY_SECRET
    if not key_id or not key_secret:
        return {"success": False, "error": "Razorpay credentials not configured"}

    async with httpx.AsyncClient(timeout=15, auth=(key_id, key_secret)) as client:
        try:
            resp = await client.get(f"{RAZORPAY_BASE}/accounts/me")
            if resp.status_code in (200, 404):  # 404 = valid key but no account endpoint
                return {"success": True, "key_id": key_id[:10] + "..."}
            # Try orders endpoint as fallback
            resp2 = await client.get(f"{RAZORPAY_BASE}/orders?count=1")
            if resp2.status_code in (200, 400):
                return {"success": True, "key_id": key_id[:10] + "..."}
            return {"success": False, "error": f"HTTP {resp.status_code}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
