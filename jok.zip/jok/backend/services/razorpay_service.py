"""Razorpay payment service for contract payments."""
import razorpay
import hmac
import hashlib
from config.settings import settings


def get_client():
    """Get Razorpay client instance."""
    return razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))


def create_order(amount_paise: int, currency: str = "INR", receipt: str = "", notes: dict = None):
    """Create a Razorpay order. Amount must be in paise (1 INR = 100 paise)."""
    client = get_client()
    data = {
        "amount": amount_paise,
        "currency": currency,
        "receipt": receipt or f"rcpt_{amount_paise}",
        "notes": notes or {},
    }
    return client.order.create(data=data)


def verify_payment(razorpay_order_id: str, razorpay_payment_id: str, razorpay_signature: str) -> bool:
    """Verify Razorpay payment signature."""
    try:
        msg = f"{razorpay_order_id}|{razorpay_payment_id}"
        generated_signature = hmac.new(
            settings.RAZORPAY_KEY_SECRET.encode(),
            msg.encode(),
            hashlib.sha256
        ).hexdigest()
        return hmac.compare_digest(generated_signature, razorpay_signature)
    except Exception:
        return False


def fetch_payment(payment_id: str):
    """Fetch payment details from Razorpay."""
    client = get_client()
    return client.payment.fetch(payment_id)
