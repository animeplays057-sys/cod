import asyncio
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from apscheduler.triggers.cron import CronTrigger
from loguru import logger

scheduler = AsyncIOScheduler(job_defaults={'coalesce': True, 'max_instances': 1, 'misfire_grace_time': 60})


def start_scheduler():
    from services.order_processing import process_pending_orders, check_timeouts

    scheduler.add_job(
        process_pending_orders, IntervalTrigger(seconds=30),
        id="process_pending", name="Process pending orders", replace_existing=True,
        max_instances=1, coalesce=True
    )

    scheduler.add_job(
        check_timeouts, IntervalTrigger(minutes=15),
        id="check_timeouts", name="Check order timeouts", replace_existing=True,
        max_instances=1, coalesce=True
    )

    # Weekly summary — every Monday at 9 AM IST (3:30 AM UTC)
    scheduler.add_job(
        _send_weekly_summaries, CronTrigger(day_of_week="mon", hour=3, minute=30, timezone="UTC"),
        id="weekly_summary", name="Send weekly summaries",
        replace_existing=True, max_instances=1, coalesce=True
    )

    # Quota warning at 6 PM IST (12:30 PM UTC)
    scheduler.add_job(
        _check_quota_warnings, CronTrigger(hour=12, minute=30),
        id="quota_warning", name="Check quota warnings", replace_existing=True
    )

    # Subscription expiry at 10 AM IST (4:30 AM UTC)
    scheduler.add_job(
        _check_subscription_expiry, CronTrigger(hour=4, minute=30),
        id="subscription_expiry", name="Check subscription expiry", replace_existing=True
    )

    # Monthly quota reset at 12:01 AM IST on 1st of each month (6:31 PM UTC prev day)
    scheduler.add_job(
        _reset_monthly_quotas, CronTrigger(day=1, hour=0, minute=1),
        id="monthly_quota_reset", name="Reset monthly quotas", replace_existing=True
    )

    # Abandoned chat cleanup — every 6 hours
    scheduler.add_job(
        _cleanup_abandoned_sessions, IntervalTrigger(hours=6),
        id="cleanup_chats", name="Cleanup abandoned chats", replace_existing=True
    )

    # ── Wallet low-balance WhatsApp alert — every 6 hours ─────────────────────
    scheduler.add_job(
        _check_wallet_low_balances, IntervalTrigger(hours=6),
        id="wallet_low_alert", name="Wallet low balance WA alerts",
        replace_existing=True, max_instances=1, coalesce=True
    )

    # Old notification cleanup — daily at 2 AM UTC
    scheduler.add_job(
        _cleanup_old_notifications, CronTrigger(hour=2, minute=0),
        id="cleanup_notifications", name="Cleanup old notifications", replace_existing=True
    )

    # Auto-expire job postings past end_date — daily at 7:30 PM UTC (1 AM IST)
    scheduler.add_job(
        _expire_old_jobs, CronTrigger(hour=19, minute=30),
        id="expire_jobs", name="Auto-expire old job postings", replace_existing=True
    )

    # ── Billing due-date check — 9 AM IST (3:35 AM UTC) ──────────────
    # This IS the entire monthly auto-billing engine.
    # Every day it: sends 3-day reminders, overdue warnings,
    # and auto-creates Razorpay orders + emails payment links for today's invoices.
    scheduler.add_job(
        _check_billing_due_dates, CronTrigger(hour=3, minute=35, timezone="UTC"),
        id="billing_due_dates", name="Check billing due dates",
        replace_existing=True, max_instances=1, coalesce=True
    )

    # Auto-offline workers inactive for 15+ minutes (no chat/call activity)
    scheduler.add_job(
        _auto_offduty_inactive_workers, IntervalTrigger(minutes=5),
        id="auto_offline_inactive", name="Auto-offline inactive workers",
        replace_existing=True, max_instances=1, coalesce=True
    )

    # ── Contract expiry check — DISABLED ────────────────────────────────────
    # Contracts are now lifetime/permanent — they don't auto-expire.
    # Admin must manually deactivate/delete a contract to revoke access.
    # scheduler.add_job(
    #     _expire_contracts, CronTrigger(hour=23, minute=30, timezone="UTC"),
    #     id="expire_contracts", name="Auto-expire stale contracts",
    #     replace_existing=True, max_instances=1, coalesce=True
    # )


    scheduler.start()
    logger.info("Scheduler started with all jobs")




def stop_scheduler():
    if scheduler.running:
        scheduler.shutdown()
        logger.info("Scheduler stopped")


async def _auto_offduty_inactive_workers():
    """
    Auto-mark on_duty workers as off_duty if they haven't done any real work
    (accept chat, send reply, verify call) for INACTIVE_THRESHOLD minutes.

    Runs every 5 minutes via APScheduler.
    """
    from config.database import get_db
    from datetime import datetime, timezone, timedelta

    INACTIVE_THRESHOLD_MINUTES = 15
    db = get_db()
    now = datetime.now(timezone.utc)
    inactive_cutoff = (now - timedelta(minutes=INACTIVE_THRESHOLD_MINUTES)).isoformat()

    try:
        # Find on_duty workers whose last_activity_at is stale (or NULL)
        # We check last_activity_at AND fall back to current_duty_start if activity was never recorded
        inactive = db.table("users").select(
            "id, last_activity_at, current_duty_start, total_duty_seconds"
        ).eq("role", "worker").eq("duty_status", "on_duty").or_(
            f"last_activity_at.lt.{inactive_cutoff},last_activity_at.is.null"
        ).execute()

        for worker in (inactive.data or []):
            # Extra guard: if current_duty_start is also recent (< threshold), skip
            # This handles workers who JUST clocked in but haven't set last_activity_at yet
            duty_start = worker.get("current_duty_start")
            if duty_start:
                try:
                    start_dt = datetime.fromisoformat(duty_start.replace("Z", "+00:00"))
                    if (now - start_dt).total_seconds() < INACTIVE_THRESHOLD_MINUTES * 60:
                        continue  # Still within grace period since clock-in
                except Exception:
                    pass

            # Calculate how long this session lasted
            duration = 0
            if duty_start:
                try:
                    start_dt = datetime.fromisoformat(duty_start.replace("Z", "+00:00"))
                    duration = int((now - start_dt).total_seconds())
                except Exception:
                    pass

            total = (worker.get("total_duty_seconds") or 0) + duration

            db.table("users").update({
                "duty_status": "off_duty",
                "current_duty_start": None,
                "total_duty_seconds": total,
                "last_duty_change": now.isoformat(),
            }).eq("id", worker["id"]).execute()

            db.table("worker_duty_logs").insert({
                "worker_id": worker["id"],
                "action": "auto_offline",
                "duration_seconds": duration,
            }).execute()

            logger.info(
                f"⏸ Worker {worker['id']} auto-clocked out (inactive > {INACTIVE_THRESHOLD_MINUTES} min)"
            )

            # Reassign or unassign any active/waiting chats
            stale_sessions = db.table("chat_sessions").select("id").eq(
                "assigned_worker_id", worker["id"]
            ).in_("status", ["waiting_human", "human_active"]).execute()

            if stale_sessions.data:
                cutoff_ts = (now - timedelta(minutes=2)).isoformat()
                other_workers = db.table("users").select("id").eq(
                    "role", "worker"
                ).eq("duty_status", "on_duty").gte("last_heartbeat", cutoff_ts).neq(
                    "id", worker["id"]
                ).execute()

                for sess in stale_sessions.data:
                    if other_workers.data:
                        db.table("chat_sessions").update({
                            "assigned_worker_id": other_workers.data[0]["id"],
                        }).eq("id", sess["id"]).execute()
                    else:
                        db.table("chat_sessions").update({
                            "assigned_worker_id": None,
                            "status": "waiting_human",
                        }).eq("id", sess["id"]).execute()

    except Exception as e:
        logger.error(f"Auto-offline inactive workers error: {e}")



async def _send_weekly_summaries():
    from config.database import get_db
    from services.email_service import send_weekly_summary
    from services.payment_service import get_currency_config
    from datetime import datetime, timezone, timedelta

    db = get_db()
    try:
        merchants = db.table("users").select("id, email, name, company_name").eq("role", "merchant").eq("status", "active").execute()
        if not merchants.data:
            return

        # Use IST for week window: last 7 days (Mon 00:00 IST → now)
        ist_offset = timedelta(hours=5, minutes=30)
        now_utc = datetime.now(timezone.utc)
        now_ist = now_utc + ist_offset
        # Start of this week Monday 00:00 IST
        days_since_monday = now_ist.weekday()  # Mon=0, Sun=6
        week_start_ist = now_ist.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=days_since_monday)
        week_start_utc = week_start_ist - ist_offset
        week_start_iso = week_start_utc.isoformat()

        # Human-readable label e.g. "Apr 28 – May 04, 2026"
        week_end_ist = week_start_ist + timedelta(days=6)
        week_label = f"{week_start_ist.strftime('%b %d')} – {week_end_ist.strftime('%b %d, %Y')}"

        for m in merchants.data:
            ms = db.table("merchant_settings").select("notification_daily_summary, notification_email").eq("user_id", m["id"]).execute()
            if not ms.data or not ms.data[0].get("notification_daily_summary"):
                continue

            orders = db.table("orders").select("verification_status, order_amount, currency").eq("user_id", m["id"]).gte("created_at", week_start_iso).execute()
            stats = {"total": len(orders.data or []), "confirmed": 0, "cancelled": 0, "pending": 0, "rto_saved": 0, "week_label": week_label}
            for o in (orders.data or []):
                s = o.get("verification_status", "")
                if s in ("confirmed", "manual_confirmed"):
                    stats["confirmed"] += 1
                elif s in ("cancelled", "manual_cancelled"):
                    stats["cancelled"] += 1
                    stats["rto_saved"] += float(o.get("order_amount", 0) or 0)
                elif s in ("pending", "queued", "sent", "delivered", "read"):
                    stats["pending"] += 1

            # Add currency to stats
            cur = get_currency_config(m.get("country", "IN") or "IN")
            stats["currency"] = cur["currency"]

            email = ms.data[0].get("notification_email") or m["email"]
            await send_weekly_summary(email, m.get("company_name", m["name"]), stats)
            logger.info(f"📊 Weekly summary sent to merchant {m['id']} ({email}) for {week_label}")
    except Exception as e:
        logger.error(f"Weekly summary error: {e}")


async def _check_quota_warnings():
    from config.database import get_db
    from services.email_service import send_quota_warning

    db = get_db()
    try:
        subs = db.table("service_subscriptions").select("*, users(email, name, company_name)").eq("status", "active").execute()
        for s in (subs.data or []):
            if s.get("monthly_quota", 0) <= 0:
                continue
            pct = (s.get("used_quota", 0) / s["monthly_quota"]) * 100
            if pct >= 80:
                user = s.get("users", {})
                ms = db.table("merchant_settings").select("notification_quota_warning, notification_email").eq("user_id", s["user_id"]).execute()
                if ms.data and ms.data[0].get("notification_quota_warning"):
                    email = ms.data[0].get("notification_email") or user.get("email", "")
                    await send_quota_warning(email, user.get("company_name", user.get("name", "")), s["used_quota"], s["monthly_quota"])
    except Exception as e:
        logger.error(f"Quota warning error: {e}")


async def _check_subscription_expiry():
    """
    DISABLED — Contracts are now permanent/lifetime.
    Admin must manually deactivate a contract to revoke access.
    This function is kept as a no-op to avoid removing the scheduler job reference.
    """
    logger.debug("_check_subscription_expiry: skipped — contracts are lifetime, no expiry check needed")
    return



async def _reset_monthly_quotas():
    """Reset monthly quotas on 1st of each month for all active subscriptions and chatbot usage."""
    from config.database import get_db
    from datetime import datetime, timezone, timedelta

    db = get_db()
    try:
        # Reset subscription used_quota
        active_subs = db.table("service_subscriptions").select("id, user_id, plan_name, used_quota").eq("status", "active").execute()
        reset_count = 0
        for s in (active_subs.data or []):
            if s.get("used_quota", 0) > 0:
                db.table("service_subscriptions").update({"used_quota": 0}).eq("id", s["id"]).execute()
                reset_count += 1

        # Reset chatbot monthly usage
        chatbot_configs = db.table("merchant_chatbot_config").select("id, current_month_usage").execute()
        chatbot_reset = 0
        next_reset = (datetime.now(timezone.utc).replace(day=1) + timedelta(days=32)).replace(day=1)
        for c in (chatbot_configs.data or []):
            if c.get("current_month_usage", 0) > 0:
                db.table("merchant_chatbot_config").update({
                    "current_month_usage": 0,
                    "usage_reset_date": next_reset.isoformat(),
                }).eq("id", c["id"]).execute()
                chatbot_reset += 1

        logger.info(f"✅ Monthly quota reset: {reset_count} subscriptions, {chatbot_reset} chatbot configs")
    except Exception as e:
        logger.error(f"Monthly quota reset error: {e}")


async def _cleanup_abandoned_sessions():
    """Clean up abandoned chat sessions older than 24 hours.
    Also auto-resolves human_active sessions with no activity for 30+ min
    (customer closed the widget without saying anything)."""
    from config.database import get_db
    from datetime import datetime, timezone, timedelta

    db = get_db()
    try:
        now = datetime.now(timezone.utc)
        cutoff = (now - timedelta(hours=24)).isoformat()

        # ── Auto-resolve human_active sessions where customer went silent ──
        # If updated_at is older than 30 min AND session is human_active,
        # customer has likely abandoned the chat without saying so.
        inactive_cutoff = (now - timedelta(minutes=30)).isoformat()
        inactive_human = db.table("chat_sessions").select("id, assigned_worker_id").eq(
            "status", "human_active"
        ).lt("updated_at", inactive_cutoff).execute()

        for s in (inactive_human.data or []):
            db.table("chat_sessions").update({
                "status": "abandoned",
                "updated_at": now.isoformat(),
            }).eq("id", s["id"]).execute()
            # System message so worker can see what happened
            db.table("chat_messages").insert({
                "session_id": s["id"],
                "sender_type": "system",
                "message": "Customer has left the chat (auto-closed after 30 min of inactivity).",
            }).execute()

        if inactive_human.data:
            logger.info(f"🕐 Auto-resolved {len(inactive_human.data)} abandoned human_active session(s)")

        # Mark old waiting_human / ai_active sessions as abandoned
        stale = db.table("chat_sessions").select("id").in_(
            "status", ["ai_active", "waiting_human"]
        ).lt("updated_at", cutoff).execute()

        abandoned_count = 0
        for s in (stale.data or []):
            db.table("chat_sessions").update({
                "status": "abandoned",
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }).eq("id", s["id"]).execute()
            abandoned_count += 1

        # Delete chat messages for sessions older than 30 days
        old_cutoff = (datetime.now(timezone.utc) - timedelta(days=30)).isoformat()
        old_sessions = db.table("chat_sessions").select("id").in_(
            "status", ["resolved", "abandoned"]
        ).lt("updated_at", old_cutoff).execute()

        for s in (old_sessions.data or []):
            db.table("chat_messages").delete().eq("session_id", s["id"]).execute()
            db.table("chat_sessions").delete().eq("id", s["id"]).execute()

        if abandoned_count > 0 or (old_sessions.data and len(old_sessions.data) > 0):
            logger.info(f"🧹 Chat cleanup: {abandoned_count} abandoned, {len(old_sessions.data or [])} old deleted")
    except Exception as e:
        logger.error(f"Chat session cleanup error: {e}")


async def _cleanup_old_notifications():
    """Delete read notifications older than 30 days and unread older than 90 days."""
    from config.database import get_db
    from datetime import datetime, timezone, timedelta

    db = get_db()
    try:
        # Read notifications > 30 days old
        read_cutoff = (datetime.now(timezone.utc) - timedelta(days=30)).isoformat()
        db.table("notifications").delete().eq("is_read", True).lt("created_at", read_cutoff).execute()

        # Unread notifications > 90 days old
        unread_cutoff = (datetime.now(timezone.utc) - timedelta(days=90)).isoformat()
        db.table("notifications").delete().eq("is_read", False).lt("created_at", unread_cutoff).execute()

        logger.info("🧹 Old notifications cleaned up")
    except Exception as e:
        logger.error(f"Notification cleanup error: {e}")


async def _expire_old_jobs():
    """Auto-deactivate job postings whose end_date has passed."""
    from config.database import get_db
    from datetime import date, datetime, timezone

    db = get_db()
    try:
        today = date.today().isoformat()
        expired = db.table("jobs").select("id, title").eq("is_active", True).lt("end_date", today).execute()
        count = 0
        for j in (expired.data or []):
            db.table("jobs").update({
                "is_active": False,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }).eq("id", j["id"]).execute()
            count += 1
        if count > 0:
            logger.info(f"💼 Auto-expired {count} job posting(s) past end_date")
    except Exception as e:
        logger.error(f"Job expiry error: {e}")


async def _check_billing_due_dates():
    """
    Daily job — 9 AM IST (3:35 AM UTC).

    Three tasks:
    1. Invoices due in 3 days       → send advance reminder email
    2. Invoices past their due date → send overdue/blacklist-warning email
    3. Invoices due TODAY (type=monthly or emi)
                                    → auto-create Razorpay order + email payment link
                                      (This IS the monthly auto-billing system.
                                       No Razorpay Subscriptions needed at all.)
    """
    from config.database import get_db
    from services.email_service import (
        send_payment_due_reminder,
        send_payment_overdue_warning,
        send_invoice_payment_link,
    )
    from datetime import date, timedelta

    db = get_db()
    try:
        today     = date.today()
        tomorrow  = today + timedelta(days=1)
        in_3_days = today + timedelta(days=3)

        today_iso    = today.isoformat()
        tomorrow_iso = tomorrow.isoformat()
        in3_iso      = in_3_days.isoformat()
        in4_iso      = (in_3_days + timedelta(days=1)).isoformat()

        # ── TASK 1: 3-day advance reminders ──────────────────────────
        due_soon = db.table("invoices").select(
            "id, user_id, amount, currency, due_date, description, contract_id"
        ).eq("status", "pending").gte("due_date", in3_iso).lt("due_date", in4_iso).execute()

        reminder_count = 0
        for inv in (due_soon.data or []):
            try:
                user_res = db.table("users").select("email, name").eq("id", inv["user_id"]).single().execute()
                if not user_res.data:
                    continue
                cr = db.table("contracts").select("contract_number").eq("id", inv["contract_id"]).single().execute()
                cno = cr.data.get("contract_number", "") if cr.data else ""
                await send_payment_due_reminder(
                    to_email=user_res.data["email"],
                    name=user_res.data.get("name", ""),
                    amount=float(inv["amount"]),
                    currency=inv.get("currency", "INR"),
                    due_date=inv["due_date"],
                    contract_number=cno,
                    description=inv.get("description", ""),
                )
                reminder_count += 1
            except Exception as e:
                logger.warning(f"Reminder failed invoice {inv['id']}: {e}")

        # ── TASK 2: Overdue blacklist warnings ────────────────────────
        overdue = db.table("invoices").select(
            "id, user_id, amount, currency, due_date, description, contract_id"
        ).eq("status", "pending").lt("due_date", today_iso).execute()

        overdue_count = 0
        for inv in (overdue.data or []):
            try:
                due_str = inv["due_date"][:10]  # strip timezone, keep YYYY-MM-DD
                due = date.fromisoformat(due_str)
                days_late = (today - due).days
                if days_late < 1:
                    continue
                user_res = db.table("users").select("email, name").eq("id", inv["user_id"]).single().execute()
                if not user_res.data:
                    continue
                cr = db.table("contracts").select("contract_number").eq("id", inv["contract_id"]).single().execute()
                cno = cr.data.get("contract_number", "") if cr.data else ""
                await send_payment_overdue_warning(
                    to_email=user_res.data["email"],
                    name=user_res.data.get("name", ""),
                    amount=float(inv["amount"]),
                    currency=inv.get("currency", "INR"),
                    due_date=inv["due_date"],
                    overdue_days=days_late,
                    contract_number=cno,
                    description=inv.get("description", ""),
                )
                overdue_count += 1
            except Exception as e:
                logger.warning(f"Overdue warning failed invoice {inv['id']}: {e}")

        # ── TASK 3: Today's due invoices → Razorpay Order + email link ─
        # This is the core of monthly auto-billing.
        # On each invoice's due_date the scheduler auto-creates a Razorpay
        # order and emails the merchant a pay-now link.
        # Merchant pays via standard Razorpay checkout → webhook marks paid.
        from services.payment_service import create_razorpay_order
        from config.settings import settings as _s

        due_today = db.table("invoices").select(
            "id, user_id, amount, currency, due_date, description, contract_id, invoice_number, type, razorpay_order_id"
        ).eq("status", "pending").gte("due_date", today_iso).lt("due_date", tomorrow_iso).in_("type", ["monthly", "emi"]).execute()

        link_count = 0
        for inv in (due_today.data or []):
            try:
                # Skip if order already generated today (idempotency)
                if inv.get("razorpay_order_id"):
                    continue

                user_res = db.table("users").select("email, name").eq("id", inv["user_id"]).single().execute()
                if not user_res.data:
                    continue
                cr = db.table("contracts").select("contract_number").eq("id", inv["contract_id"]).single().execute()
                cno = cr.data.get("contract_number", "") if cr.data else ""

                # Create Razorpay order for this invoice amount
                order = await create_razorpay_order(
                    amount_paise=int(float(inv["amount"]) * 100),
                    currency=inv.get("currency", "INR"),
                    receipt=inv.get("invoice_number", inv["id"][:12]),
                    notes={
                        "invoice_id":  inv["id"],
                        "contract_id": inv.get("contract_id", ""),
                        "user_id":     inv["user_id"],
                    },
                )
                if not order:
                    logger.warning(f"Razorpay order failed for invoice {inv['id']}")
                    continue

                # Save order ID on invoice
                db.table("invoices").update({"razorpay_order_id": order["id"]}).eq("id", inv["id"]).execute()

                # Build the payment page URL (merchant clicks → Razorpay checkout)
                frontend = getattr(_s, "FRONTEND_URL", "https://app.codverify.tech").rstrip("/")
                pay_url  = f"{frontend}/dashboard/billing?invoice={inv['id']}&razorpay_order={order['id']}&key={_s.RAZORPAY_KEY_ID}"

                await send_invoice_payment_link(
                    to_email=user_res.data["email"],
                    name=user_res.data.get("name", ""),
                    amount=float(inv["amount"]),
                    currency=inv.get("currency", "INR"),
                    due_date=inv["due_date"],
                    contract_number=cno,
                    description=inv.get("description", ""),
                    payment_url=pay_url,
                    razorpay_order_id=order["id"],
                    razorpay_key=_s.RAZORPAY_KEY_ID,
                )
                link_count += 1
            except Exception as e:
                logger.warning(f"Payment link gen failed for invoice {inv['id']}: {e}")

        if reminder_count or overdue_count or link_count:
            logger.info(
                f"📅 Billing: {reminder_count} reminders | "
                f"{overdue_count} overdue warnings | "
                f"{link_count} payment links sent"
            )
    except Exception as e:
        logger.error(f"Billing due-date check error: {e}")


# ── Contract Expiry ───────────────────────────────────────────────────────────
async def _expire_contracts():
    """
    Daily job — runs at 5 AM IST.
    1. Marks contracts that have passed end_date as 'expired'.
    2. Sets merchant account_status = 'contract_expired' (blocks all service API access).
    3. Disables chatbot.
    4. Sends 7-day warning notification before expiry.
    """
    from config.database import get_db
    from services.notification_service import create_notification
    from datetime import datetime, timezone, timedelta

    db = get_db()
    now = datetime.now(timezone.utc)
    today_iso = now.isoformat()
    warn_date_iso = (now + timedelta(days=7)).isoformat()

    try:
        # ── Step 1: Find active contracts that have expired ────────────────
        expired_res = (
            db.table("contracts")
            .select("id, user_id, contract_number, end_date")
            .eq("status", "active")
            .lt("end_date", today_iso)
            .execute()
        )
        expired_count = 0
        for c in (expired_res.data or []):
            try:
                # Mark contract expired
                db.table("contracts").update({
                    "status": "expired",
                    "updated_at": today_iso,
                }).eq("id", c["id"]).execute()

                # Block user services
                db.table("users").update({
                    "account_status": "contract_expired",
                }).eq("id", c["user_id"]).execute()

                # Disable chatbot
                db.table("merchant_chatbot_config").update({
                    "is_enabled": False,
                }).eq("merchant_id", c["user_id"]).execute()

                # Send critical notification
                await create_notification(
                    c["user_id"],
                    "Contract Expired — Services Suspended",
                    f"Your contract {c.get('contract_number', '')} expired on "
                    f"{c.get('end_date', '')[:10]}. All services have been suspended. "
                    "Please contact support to renew.",
                    "error", "contract", "/dashboard/contract"
                )
                expired_count += 1
            except Exception as e:
                logger.warning(f"Failed to expire contract {c['id']}: {e}")

        # ── Step 2: Warn merchants 7 days before expiry ───────────────────
        expiring_res = (
            db.table("contracts")
            .select("id, user_id, contract_number, end_date")
            .eq("status", "active")
            .gte("end_date", today_iso)
            .lte("end_date", warn_date_iso)
            .execute()
        )
        warn_count = 0
        for c in (expiring_res.data or []):
            try:
                days_left = max(0, (
                    datetime.fromisoformat(c["end_date"].replace("Z", "+00:00")) - now
                ).days)
                await create_notification(
                    c["user_id"],
                    f"Contract Expiring in {days_left} Day{'s' if days_left != 1 else ''}",
                    f"Your contract {c.get('contract_number', '')} expires on "
                    f"{c.get('end_date', '')[:10]}. Please renew to avoid service interruption.",
                    "warning", "contract", "/dashboard/contract"
                )
                warn_count += 1
            except Exception as e:
                logger.warning(f"Warning notification failed for contract {c['id']}: {e}")

        if expired_count or warn_count:
            logger.info(f"📋 Contracts: {expired_count} expired | {warn_count} expiry warnings sent")

    except Exception as e:
        logger.error(f"Contract expiry check failed: {e}")


# ── Wallet Low Balance WhatsApp Alert ─────────────────────────────────────────
async def _check_wallet_low_balances():
    """
    Runs every 6 hours.
    Finds merchants whose wallet balance is <= LOW_BALANCE_THRESHOLD.
    Sends them a WhatsApp notification warning that wallet is low.
    Skips merchants who already received an alert in the last 6 hours
    (tracked via a 'wallet_low_wa_sent_at' field in wallets table, or via
    a cooldown check on notifications table).
    """
    from config.database import get_db
    from config.settings import settings as _s
    from datetime import datetime, timezone, timedelta
    from loguru import logger

    LOW_BALANCE_THRESHOLD = 50.0   # ₹ — send alert when balance at or below this
    COOLDOWN_HOURS = 6             # Don't re-alert within 6 hours

    db = get_db()
    now = datetime.now(timezone.utc)
    cooldown_cutoff = (now - timedelta(hours=COOLDOWN_HOURS)).isoformat()

    try:
        # Find all active merchant wallets with low balance
        low_wallets = db.table("merchant_wallets").select(
            "user_id, balance"
        ).lte("balance", LOW_BALANCE_THRESHOLD).execute()

        if not low_wallets.data:
            return

        # Get WA credentials
        phone_id = _s.WHATSAPP_PHONE_NUMBER_ID
        token = _s.WHATSAPP_ACCESS_TOKEN
        if not phone_id or not token:
            logger.warning("Wallet low alert: WhatsApp credentials not set — skipping")
            return

        from services.whatsapp_service import send_template_message
        from services.notification_service import create_notification

        alerted = 0
        for w in low_wallets.data:
            uid = w.get("user_id")
            balance = float(w.get("balance") or 0)
            if not uid:
                continue

            # Cooldown: skip if we already sent a wallet_low notification recently
            recent = db.table("notifications").select("id").eq(
                "user_id", uid
            ).eq("category", "billing").ilike("title", "%wallet%low%").gte(
                "created_at", cooldown_cutoff
            ).limit(1).execute()

            if recent.data:
                logger.debug(f"Wallet low alert: user {uid} already notified recently — skipping")
                continue

            # Get merchant phone number
            user_res = db.table("users").select(
                "phone, name, company_name, status"
            ).eq("id", uid).execute()

            if not user_res.data:
                continue

            user = user_res.data[0]
            if user.get("status") not in (None, "active", ""):
                continue  # skip suspended/blocked accounts

            merchant_phone = user.get("phone", "")
            merchant_name = user.get("company_name") or user.get("name") or "Merchant"

            if not merchant_phone:
                logger.debug(f"Wallet low alert: user {uid} has no phone — skipping WA, sending dashboard notification only")
            else:
                # Normalize phone
                import re as _re
                digits = _re.sub(r"\D", "", merchant_phone)
                if len(digits) == 10:
                    merchant_phone_norm = "+91" + digits
                elif len(digits) == 12 and digits.startswith("91"):
                    merchant_phone_norm = "+" + digits
                else:
                    merchant_phone_norm = "+" + digits if not merchant_phone.startswith("+") else merchant_phone

                # Send WhatsApp template
                try:
                    components = [{
                        "type": "body",
                        "parameters": [
                            {"type": "text", "text": merchant_name},
                            {"type": "text", "text": f"₹{balance:.2f}"},
                            {"type": "text", "text": "₹50"},
                        ]
                    }]
                    _wa_id = await send_template_message(
                        phone_id, token,
                        merchant_phone_norm,
                        "wallet_low_balance", "en",
                        components,
                    )
                    if _wa_id:
                        logger.info(f"💸 Wallet low WA sent to merchant {uid} (balance=₹{balance:.2f})")
                    else:
                        logger.warning(f"Wallet low WA failed for merchant {uid} — WA send returned None")
                except Exception as wa_err:
                    logger.warning(f"Wallet low WA error for merchant {uid}: {wa_err}")

            # Always create dashboard notification (even if WA fails / no phone)
            try:
                await create_notification(
                    uid,
                    "⚠️ Wallet Balance Low — Recharge Now",
                    f"Your wallet balance is ₹{balance:.2f}. Services may pause if balance reaches ₹0. "
                    f"Recharge now to keep verifications running uninterrupted.",
                    "warning", "billing", "/dashboard/topup"
                )
                alerted += 1
            except Exception as notif_err:
                logger.warning(f"Wallet low dashboard notification failed for {uid}: {notif_err}")

        if alerted:
            logger.info(f"💸 Wallet low balance alerts sent to {alerted} merchant(s)")

    except Exception as e:
        logger.error(f"_check_wallet_low_balances error: {e}")
