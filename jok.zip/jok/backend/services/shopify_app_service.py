"""
Shopify App Config Service
==========================
Reads Shopify App credentials (api_key + api_secret) from the `shopify_apps`
Supabase table instead of hardcoded env vars.

app_index: integer slot (0, 1, 2...) that maps a Shopify store install
           to the specific App credentials used for HMAC verification.
           This value is stored in `shopify_install_keys.app_index`.

The backend `auth.py` routes do NOT need to change — they still use
`get_shopify_app(app_index)` which now reads from DB instead of .env.

Cache: 30-second TTL to avoid hitting DB on every webhook request.
"""

from __future__ import annotations
import time
from typing import Optional
from loguru import logger
from config.database import get_db
from utils.encryption import decrypt_value, encrypt_value

# ── In-memory cache (TTL = 30 seconds) ─────────────────────────────────────────
_cache: dict[int, dict] = {}
_cache_ts: float = 0.0
_CACHE_TTL = 30  # seconds


def _is_cache_valid() -> bool:
    return (time.time() - _cache_ts) < _CACHE_TTL


def invalidate_cache() -> None:
    """Call this after adding/updating/deleting a Shopify app."""
    global _cache, _cache_ts
    _cache = {}
    _cache_ts = 0.0
    logger.info("Shopify app config cache invalidated")


def _load_cache() -> None:
    global _cache, _cache_ts
    try:
        db = get_db()
        res = db.table("shopify_apps").select("*").order("app_index").execute()
        _cache = {}
        for row in (res.data or []):
            idx = row.get("app_index")
            if idx is not None:
                _cache[int(idx)] = row
        _cache_ts = time.time()
        logger.debug(f"Shopify app cache loaded: {len(_cache)} app(s)")
    except Exception as e:
        logger.warning(f"Shopify app cache load failed: {e}")


# ── Public API ─────────────────────────────────────────────────────────────────

def get_shopify_app(app_index: int) -> Optional[dict]:
    """
    Returns the Shopify app credentials for a given app_index.
    Returns dict with keys: api_key, api_secret (decrypted), app_name, is_active
    Returns None if not found (caller should fall back to env vars).
    """
    if not _is_cache_valid():
        _load_cache()

    app = _cache.get(int(app_index))
    if not app:
        return None

    if not app.get("is_active", True):
        logger.warning(f"Shopify app index={app_index} is inactive")
        return None

    # Decrypt the secret for use
    raw_secret = app.get("api_secret_encrypted", "")
    try:
        api_secret = decrypt_value(raw_secret) if raw_secret else ""
    except Exception:
        api_secret = raw_secret  # fallback: treat as plain text (legacy)

    return {
        "app_index": app_index,
        "app_name": app.get("app_name", f"App #{app_index}"),
        "api_key": app.get("api_key", ""),
        "api_secret": api_secret,
        "scopes": app.get("scopes", ""),
        "is_active": app.get("is_active", True),
        "status": app.get("status", "active"),
        "install_count": app.get("install_count", 0),
        "last_install_at": app.get("last_install_at"),
        "notes": app.get("notes", ""),
    }


def get_all_shopify_apps(include_secrets: bool = False) -> list[dict]:
    """
    Returns all Shopify apps (for admin listing).
    Secrets are masked by default — set include_secrets=True only for internal use.
    """
    if not _is_cache_valid():
        _load_cache()

    apps = []
    for idx, app in sorted(_cache.items()):
        entry = {
            "app_index": idx,
            "app_name": app.get("app_name", f"App #{idx}"),
            "api_key": app.get("api_key", ""),
            "api_key_masked": _mask(app.get("api_key", "")),
            "api_secret_masked": _mask(app.get("api_secret_encrypted", "")),
            "scopes": app.get("scopes", ""),
            "is_active": app.get("is_active", True),
            "status": app.get("status", "active"),
            "install_count": app.get("install_count", 0),
            "last_install_at": app.get("last_install_at"),
            "notes": app.get("notes", ""),
            "created_at": app.get("created_at"),
            "updated_at": app.get("updated_at"),
        }
        if include_secrets:
            try:
                entry["api_secret"] = decrypt_value(app.get("api_secret_encrypted", ""))
            except Exception:
                entry["api_secret"] = ""
        apps.append(entry)
    return apps


def get_next_app_index() -> int:
    """Returns the next available app_index (max existing + 1)."""
    if not _is_cache_valid():
        _load_cache()
    if not _cache:
        return 0
    return max(_cache.keys()) + 1


def record_install(app_index: int) -> None:
    """Increment install_count and update last_install_at for an app."""
    try:
        from datetime import datetime, timezone
        db = get_db()
        app = _cache.get(int(app_index))
        if not app:
            return
        current_count = int(app.get("install_count", 0)) + 1
        db.table("shopify_apps").update({
            "install_count": current_count,
            "last_install_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }).eq("app_index", app_index).execute()
        invalidate_cache()
    except Exception as e:
        logger.warning(f"record_install failed for app_index={app_index}: {e}")


def _mask(value: str, show: int = 8) -> str:
    """Mask a credential string, showing only first N chars."""
    if not value:
        return ""
    if len(value) <= show:
        return "*" * len(value)
    return value[:show] + "..." + "*" * 6
