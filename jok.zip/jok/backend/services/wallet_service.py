"""
Wallet Service — core wallet operations.
All wallet credits and debits go through this module.
"""

from datetime import datetime, timezone
from loguru import logger
from config.database import get_db


class WalletInsufficientError(Exception):
    """Raised when wallet balance is insufficient for a debit."""
    def __init__(self, balance: float, required: float):
        self.balance = balance
        self.required = required
        super().__init__(
            f"Insufficient wallet balance: ₹{balance:.2f} available, ₹{required:.2f} required."
        )


async def get_or_create_wallet(db, user_id: str) -> dict:
    """
    Fetch the merchant's wallet. If it doesn't exist, create one with zero balance.
    Returns the wallet dict.
    """
    res = db.table("merchant_wallets").select("*").eq("user_id", user_id).execute()
    if res.data:
        return res.data[0]

    # Create wallet for this merchant
    create_res = db.table("merchant_wallets").insert({
        "user_id": user_id,
        "balance": 0.00,
        "total_credited": 0.00,
        "total_debited": 0.00,
        "currency": "INR",
    }).execute()

    if create_res.data:
        logger.info(f"💰 Wallet created for user {user_id}")
        return create_res.data[0]

    raise Exception(f"Failed to create wallet for user {user_id}")


async def get_wallet(db, user_id: str) -> dict:
    """Get wallet balance for a user (alias for get_or_create_wallet)."""
    return await get_or_create_wallet(db, user_id)


async def credit_wallet(
    db,
    user_id: str,
    amount: float,
    description: str,
    contract_id: str = None,
    reference_id: str = None,
    service_key: str = "contract_credit",
) -> dict:
    """
    Credit merchant wallet with given amount.
    Called when:
    - Admin activates a contract (wallet_credit_amount added)
    - Admin manually credits wallet
    Returns updated wallet dict.
    """
    if amount <= 0:
        raise ValueError(f"Credit amount must be positive, got {amount}")

    wallet = await get_or_create_wallet(db, user_id)
    wallet_id = wallet["id"]
    balance_before = float(wallet["balance"])
    balance_after = round(balance_before + amount, 2)

    # Update wallet balance
    db.table("merchant_wallets").update({
        "balance": balance_after,
        "total_credited": round(float(wallet.get("total_credited", 0)) + amount, 2),
        "low_balance_alert_sent": False,  # Reset so future low-balance alerts fire again
    }).eq("id", wallet_id).execute()

    # Sync users.wallet_balance column (used by admin billing overview)
    db.table("users").update({"wallet_balance": balance_after}).eq("id", user_id).execute()

    # Log transaction
    txn = {
        "user_id": user_id,
        "wallet_id": wallet_id,
        "type": "credit",
        "amount": round(amount, 4),
        "balance_before": balance_before,
        "balance_after": balance_after,
        "service_key": service_key,
        "description": description,
        "reference_id": reference_id or "",
    }
    if contract_id:
        txn["contract_id"] = contract_id

    db.table("wallet_transactions").insert(txn).execute()

    logger.info(
        f"💰 CREDIT ₹{amount:.4f} → user={user_id} | "
        f"balance: ₹{balance_before:.2f} → ₹{balance_after:.2f} | {description}"
    )

    # Return updated wallet
    updated = db.table("merchant_wallets").select("*").eq("id", wallet_id).execute()
    return updated.data[0] if updated.data else wallet


async def debit_wallet(
    db,
    user_id: str,
    amount: float,
    service_key: str,
    description: str,
    reference_id: str = None,
    raise_on_insufficient: bool = False,
) -> dict:
    """
    Debit merchant wallet for service usage.
    Called on:
    - WhatsApp COD verification message sent (₹0.05)
    - Worker call verified confirmed/cancelled (₹7.00)

    If raise_on_insufficient=True → raises WalletInsufficientError.
    If False (default) → logs warning but allows debit (balance can go negative).
    Returns updated wallet dict.
    """
    if amount <= 0:
        raise ValueError(f"Debit amount must be positive, got {amount}")

    wallet = await get_or_create_wallet(db, user_id)
    wallet_id = wallet["id"]
    balance_before = float(wallet["balance"])

    if raise_on_insufficient and balance_before < amount:
        raise WalletInsufficientError(balance_before, amount)

    # ── Atomic debit via Supabase RPC (prevents race conditions) ─────────────
    # Uses PostgreSQL row-level FOR UPDATE lock — safe under concurrent requests.
    # Falls back to direct update if RPC not yet deployed.
    balance_after = balance_before  # will be updated below
    try:
        rpc_result = db.rpc(
            "debit_wallet_atomic",
            {
                "p_user_id": user_id,
                "p_amount": round(amount, 4),
                "p_allow_negative": not raise_on_insufficient,
            }
        ).execute()

        if rpc_result.data:
            row = rpc_result.data[0]
            if not row["success"]:
                if row["error_code"] == "INSUFFICIENT_BALANCE":
                    raise WalletInsufficientError(balance_before, amount)
                if row["error_code"] == "WALLET_NOT_FOUND":
                    raise ValueError(f"Wallet not found for user {user_id}")
            balance_after = float(row["new_balance"])
            # BUG-003 FIX: total_debited was never updated via RPC path — fix it here
            db.table("merchant_wallets").update({
                "total_debited": round(float(wallet.get("total_debited", 0)) + round(amount, 2), 2),
                "low_balance_alert_sent": False if balance_after <= 0 else wallet.get("low_balance_alert_sent", False),
            }).eq("id", wallet_id).execute()
        else:
            raise Exception("RPC returned no data — falling back")

    except (WalletInsufficientError, ValueError):
        raise
    except Exception as rpc_err:
        # RPC not deployed yet → fall back to direct update (less safe but functional)
        logger.warning(f"⚠️ debit_wallet_atomic RPC unavailable, using direct update: {rpc_err}")
        balance_after = round(balance_before - amount, 2)
        db.table("merchant_wallets").update({
            "balance": balance_after,
            "total_debited": round(float(wallet.get("total_debited", 0)) + amount, 2),
            "low_balance_alert_sent": False if balance_after <= 0 else wallet.get("low_balance_alert_sent", False),
        }).eq("id", wallet_id).execute()

    # Sync users.wallet_balance column (admin billing overview)
    db.table("users").update({"wallet_balance": balance_after}).eq("id", user_id).execute()

    # Log transaction
    txn = {
        "user_id": user_id,
        "wallet_id": wallet_id,
        "type": "debit",
        "amount": round(amount, 4),
        "balance_before": balance_before,
        "balance_after": balance_after,
        "service_key": service_key,
        "description": description,
        "reference_id": reference_id or "",
    }
    db.table("wallet_transactions").insert(txn).execute()

    logger.info(
        f"💸 DEBIT ₹{amount:.4f} [{service_key}] → user={user_id} | "
        f"balance: ₹{balance_before:.2f} → ₹{balance_after:.2f} | {description}"
    )

    if balance_after < 10 and balance_before >= 10:
        logger.warning(f"⚠️ Low wallet balance for user {user_id}: ₹{balance_after:.2f}")

    updated = db.table("merchant_wallets").select("*").eq("id", wallet_id).execute()
    return updated.data[0] if updated.data else wallet


async def get_transactions(
    db,
    user_id: str,
    limit: int = 50,
    offset: int = 0,
) -> list:
    """Get wallet transaction history for a merchant."""
    res = (
        db.table("wallet_transactions")
        .select("*")
        .eq("user_id", user_id)
        .order("created_at", desc=True)
        .range(offset, offset + limit - 1)
        .execute()
    )
    return res.data or []


async def reset_wallet_for_new_contract(
    db,
    user_id: str,
    contract_number: str = "",
    contract_id: str = "",
) -> dict:
    """
    Reset wallet balance to 0 when a NEW contract replaces an old one.

    Call this BEFORE crediting the new contract's wallet_credit_amount.
    This prevents old stale credits from carrying over to a new contract.

    A 'contract_reset' transaction is logged so the merchant can see why
    their balance dropped to zero.
    """
    wallet = await get_or_create_wallet(db, user_id)
    wallet_id     = wallet["id"]
    balance_before = float(wallet.get("balance", 0))

    if balance_before == 0:
        # Already zero — nothing to reset
        return wallet

    # Zero out the balance
    db.table("merchant_wallets").update({
        "balance":        0.0,
        "total_credited": 0.0,
        "total_debited":  0.0,
        "low_balance_alert_sent": False,
    }).eq("id", wallet_id).execute()

    # Sync users column
    db.table("users").update({"wallet_balance": 0.0}).eq("id", user_id).execute()

    # Log the reset transaction (visible to merchant in billing history)
    ref = contract_id or contract_number or "new_contract"
    desc = f"Wallet reset for new contract — {contract_number or contract_id}"
    txn = {
        "user_id":       user_id,
        "wallet_id":     wallet_id,
        "type":          "debit",                # Debit so balance drops to 0
        "amount":        round(balance_before, 4),
        "balance_before": balance_before,
        "balance_after":  0.0,
        "service_key":   "contract_reset",
        "description":   desc,
        "reference_id":  ref,
    }
    if contract_id:
        txn["contract_id"] = contract_id
    db.table("wallet_transactions").insert(txn).execute()

    logger.info(
        f"🔄 WALLET RESET ₹{balance_before:.2f} → ₹0.00 for user={user_id} "
        f"[new contract: {contract_number or contract_id}]"
    )

    updated = db.table("merchant_wallets").select("*").eq("id", wallet_id).execute()
    return updated.data[0] if updated.data else wallet

