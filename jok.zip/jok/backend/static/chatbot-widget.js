/**
 * CODVerify Chatbot Widget v5.2 — Premium UI
 * Conversational callback flow + premium message design.
 *
 * Usage:
 *   <script src="https://api.codverify.tech/static/chatbot-widget.js?v=5"
 *           data-codverify-key="ck_YOUR_KEY"
 *           data-codverify-api="https://api.codverify.tech"></script>
 */
(function () {
  'use strict';
  
  if (window.__CVW_LOADED__) return;
  window.__CVW_LOADED__ = true;

  var script = document.currentScript || (function () {
    var s = document.getElementsByTagName('script');
    return s[s.length - 1];
  })();
  var API_KEY = (script.getAttribute('data-codverify-key') || '').trim();
  var API_BASE = (script.getAttribute('data-codverify-api') || 'https://api.codverify.tech').replace(/\/$/, '');
  var CUSTOMER_EMAIL = (script.getAttribute('data-customer-email') || '').trim().toLowerCase();


  if (!API_KEY) { console.warn('[CODVerify] data-codverify-key is required'); return; }

  // ── State ────────────────────────────────────────────────────────────────────
  var S = {
    open: false,
    inited: false,
    sessionId: null,
    status: 'idle',
    tier: 'chatbot_basic',
    config: null,
    pollTimer: null,
    msgCount: 0,
    waitingSince: null,
    timeoutFired: false,
    cb: { active: false, step: 0, data: {} },
    botName: 'Support',
    botIni: 'SB',
    botAvatar: '',
    // Logged-in customer order support
    loggedIn: !!CUSTOMER_EMAIL,
    customerEmail: CUSTOMER_EMAIL,
    returnFlow: { active: false, step: 0, order: null, type: null, reason: '' },
    // Product signal dedup
    lastProductSignal: 0,
    productFetching: false,
  };

  // ── Network ──────────────────────────────────────────────────────────────────
  function get(path, cb) {
    fetch(API_BASE + path, { headers: { 'Content-Type': 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (d) { cb(null, d); })
      .catch(function (e) { cb(e, null); });
  }
  function post(path, body, cb) {
    fetch(API_BASE + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).then(function (r) { return r.json(); })
      .then(function (d) { cb(null, d); })
      .catch(function (e) { cb(e, null); });
  }

  // ── CSS ──────────────────────────────────────────────────────────────────────
  function buildCSS(c, theme, fontFamily) {
    var grad = 'linear-gradient(135deg,' + c + ' 0%,#7c3aed 100%)';
    var isDark = (theme !== 'light');
    var font = fontFamily || 'Inter';

    // ── Primary color glow variants
    var glowA = c + '55';
    var glowB = c + '33';
    var glowC = c + '18';
    var glowD = c + 'aa';

    // ── Window
    var winBg = isDark ? '#0b0f1e' : '#ffffff';
    var winBor = isDark ? 'rgba(255,255,255,.08)' : 'rgba(139,92,246,.18)';
    var winShad = isDark
      ? '0 32px 100px rgba(0,0,0,.92),0 0 0 1px rgba(255,255,255,.06),0 -4px 60px -20px ' + c
      : '0 32px 80px rgba(99,102,241,.18),0 0 0 1px rgba(139,92,246,.14),0 8px 32px rgba(0,0,0,.08)';

    // ── Body bg — solid, no gradients that hide
    var bodyBg = isDark ? '#0d1225' : '#f5f3ff';
    var scrollT = isDark ? 'rgba(255,255,255,.15)' : 'rgba(139,92,246,.3)';

    // Label / timestamp colors
    var sLblClr = isDark ? 'rgba(255,255,255,.3)' : 'rgba(80,60,140,.45)';
    var tsClr = isDark ? 'rgba(255,255,255,.25)' : 'rgba(99,102,241,.4)';

    // ── Bot/AI bubble — solid visible dark card
    // Using solid colors so they are ALWAYS visible regardless of backdrop-filter support
    var bBubBg = isDark ? '#1a2544' : '#ffffff';
    var bBubClr = isDark ? '#e8ecf8' : '#1a133d';
    var bBubBor = isDark ? '1px solid rgba(255,255,255,.1)' : '1px solid rgba(139,92,246,.2)';
    var bBubShd = isDark
      ? '0 2px 16px rgba(0,0,0,.4),0 1px 0 rgba(255,255,255,.05) inset'
      : '0 2px 16px rgba(99,102,241,.12),0 1px 4px rgba(0,0,0,.04)';

    // ── Worker bubble
    var wBubBg = isDark ? '#0f2820' : '#f0fdf6';
    var wBubClr = isDark ? '#4ade80' : '#166534';
    var wBubBor = isDark ? '1px solid rgba(74,222,128,.25)' : '1px solid #86efac';

    // ── User bubble shadow
    var vBubShd = '0 6px 24px ' + glowA + ',0 2px 10px rgba(0,0,0,.15)';

    // ── System message
    var sysClr = isDark ? 'rgba(255,255,255,.35)' : 'rgba(99,102,241,.55)';
    var sysBg = isDark ? 'rgba(255,255,255,.07)' : 'rgba(99,102,241,.07)';

    // ── Typing — same solid as bot bubble
    var typBg = isDark ? '#1a2544' : '#ffffff';
    var typBor = isDark ? '1px solid rgba(255,255,255,.1)' : '1px solid rgba(139,92,246,.2)';

    // ── Quick reply buttons
    var qBg = isDark ? '#1e2d50' : '#ffffff';
    var qBor = isDark ? '1.5px solid rgba(255,255,255,.15)' : '1.5px solid rgba(139,92,246,.28)';
    var qClr = isDark ? 'rgba(255,255,255,.88)' : '#4c1d95';

    // ── Footer / input bar
    var footBg = isDark ? '#090d1c' : '#faf9ff';
    var footBor = isDark ? '1px solid rgba(255,255,255,.07)' : '1px solid rgba(139,92,246,.12)';
    var inpBg = isDark ? '#141c35' : '#ffffff';
    var inpBor = isDark ? '1.5px solid rgba(255,255,255,.1)' : '1.5px solid rgba(139,92,246,.22)';
    var inpClr = isDark ? '#e8ecf8' : '#1a133d';
    var inpPh = isDark ? 'rgba(255,255,255,.25)' : 'rgba(99,102,241,.38)';

    // ── Branding
    var brdBg = isDark ? '#090d1c' : '#faf9ff';
    var brdBor = isDark ? '1px solid rgba(255,255,255,.05)' : '1px solid rgba(99,102,241,.1)';
    var brdClr = isDark ? 'rgba(255,255,255,.2)' : 'rgba(99,102,241,.42)';
    var brdLink = isDark ? 'rgba(255,255,255,.6)' : c;

    // ── Mini avatar beside bubbles
    var avMsgBg = isDark ? '#1e2d50' : 'rgba(139,92,246,.12)';
    var avMsgCl = isDark ? 'rgba(255,255,255,.9)' : c;

    return [
      // ── Reset / base ─────────────────────────────────────────────────────────
      '#cvw *{box-sizing:border-box;font-family:"' + font + '",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;margin:0;padding:0;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility}',

      // ── Launcher button ──────────────────────────────────────────────────────
      '#cvw-btn{position:fixed;bottom:28px;right:28px;z-index:2147483646;width:64px;height:64px;border-radius:50%;background:' + grad + ';box-shadow:0 8px 32px ' + glowD + ',0 3px 10px rgba(0,0,0,.35),inset 0 1px 0 rgba(255,255,255,.28);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:transform .28s cubic-bezier(.34,1.56,.64,1),box-shadow .28s;overflow:hidden}',
      // Shimmer on button
      '#cvw-btn::after{content:"";position:absolute;inset:-4px;border-radius:50%;background:' + grad + ';opacity:.2;filter:blur(12px);z-index:-1;animation:cvwglow 3s ease-in-out infinite}',
      '@keyframes cvwglow{0%,100%{opacity:.2;transform:scale(1)}50%{opacity:.4;transform:scale(1.15)}}',
      '#cvw-btn:hover{transform:scale(1.1) translateY(-3px);box-shadow:0 16px 48px ' + glowD + ',0 4px 14px rgba(0,0,0,.35)}',
      '#cvw-btn svg{width:28px;height:28px;fill:#fff;position:relative;z-index:1;filter:drop-shadow(0 2px 4px rgba(0,0,0,.3))}',

      // Notification badge
      '#cvw-badge{position:absolute;top:-3px;right:-3px;background:linear-gradient(135deg,#f43f5e,#e11d48);color:#fff;font-size:10px;font-weight:700;min-width:20px;height:20px;border-radius:10px;padding:0 5px;display:none;align-items:center;justify-content:center;pointer-events:none;box-shadow:0 2px 10px rgba(244,63,94,.55);border:2px solid rgba(0,0,0,.15)}',

      // Pulsing ring
      '#cvw-btn::before{content:"";position:absolute;inset:-8px;border-radius:50%;border:1.5px solid ' + c + ';opacity:.3;animation:cvwring 3s ease-out infinite}',
      '@keyframes cvwring{0%{transform:scale(1);opacity:.4}80%{transform:scale(1.5);opacity:0}100%{transform:scale(1.5);opacity:0}}',

      // ── Chat window ──────────────────────────────────────────────────────────
      // BUGFIX: min-height:0 added — prevents flex children from overflowing
      // and ensures #cvw-body can scroll correctly inside the flex column
      '#cvw-win{position:fixed;bottom:110px;right:28px;z-index:2147483645;width:392px;height:640px;border-radius:28px;background:' + winBg + ';border:1px solid ' + winBor + ';box-shadow:' + winShad + ';display:flex;flex-direction:column;min-height:0;overflow:hidden;transform:translateY(36px) scale(.86);transform-origin:bottom right;opacity:0;pointer-events:none;transition:transform .42s cubic-bezier(.34,1.44,.64,1),opacity .32s ease}',
      '#cvw-win.on{transform:translateY(0) scale(1);opacity:1;pointer-events:all}',
      // Top gradient accent line
      '#cvw-win::before{content:"";position:absolute;top:0;left:0;right:0;height:2px;background:' + grad + ';z-index:10;border-radius:28px 28px 0 0}',

      // ── Header ───────────────────────────────────────────────────────────────
      '#cvw-head{background:' + grad + ';padding:16px 18px 14px;display:flex;align-items:center;gap:13px;flex-shrink:0;position:relative;overflow:hidden}',
      // Shimmer sweep
      '#cvw-head::before{content:"";position:absolute;top:0;left:-100%;width:55%;height:100%;background:linear-gradient(90deg,transparent,rgba(255,255,255,.16),transparent);animation:cvwshimmer 4.5s ease-in-out infinite;pointer-events:none}',
      '@keyframes cvwshimmer{0%{left:-100%}65%,100%{left:150%}}',
      // Top shine
      '#cvw-head::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(255,255,255,.13) 0%,rgba(255,255,255,.04) 55%,transparent 100%);pointer-events:none}',

      // Header avatar
      '#cvw-av{width:46px;height:46px;border-radius:50%;background:rgba(255,255,255,.18);backdrop-filter:blur(16px);border:2px solid rgba(255,255,255,.38);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:14px;color:#fff;flex-shrink:0;box-shadow:0 0 0 3px rgba(255,255,255,.12),0 6px 20px rgba(0,0,0,.28);position:relative;z-index:1;overflow:hidden}',
      '#cvw-hi{flex:1;min-width:0;position:relative;z-index:1}',
      '#cvw-hn{font-size:15px;font-weight:700;color:#fff;letter-spacing:-.015em;line-height:1.2;text-shadow:0 1px 4px rgba(0,0,0,.18)}',
      '#cvw-hs{font-size:11px;color:rgba(255,255,255,.84);display:flex;align-items:center;gap:5px;margin-top:3px;font-weight:500;letter-spacing:.01em}',
      '.cvw-dot{width:6px;height:6px;border-radius:50%;background:#4ade80;flex-shrink:0;box-shadow:0 0 0 3px rgba(74,222,128,.28);animation:cvwpulse 2.5s ease-in-out infinite}',
      '@keyframes cvwpulse{0%,100%{box-shadow:0 0 0 3px rgba(74,222,128,.22)}50%{box-shadow:0 0 0 7px rgba(74,222,128,.05)}}',
      '#cvw-x{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);backdrop-filter:blur(8px);cursor:pointer;padding:8px;border-radius:12px;display:flex;flex-shrink:0;transition:background .2s,transform .22s;margin-left:auto;position:relative;z-index:1}',
      '#cvw-x:hover{background:rgba(255,255,255,.24);transform:scale(1.08) rotate(90deg)}',

      // ── Message body ─────────────────────────────────────────────────────────
      // BUGFIX: flex:1 1 0% + min-height:0 ensures body takes remaining space
      // and scrolls properly — without min-height:0 flex children don't shrink
      '#cvw-body{flex:1 1 0%;min-height:0;overflow-y:auto;overflow-x:hidden;padding:20px 14px 12px;display:flex;flex-direction:column;gap:2px;scroll-behavior:smooth;background:' + bodyBg + '}',
      '#cvw-body::-webkit-scrollbar{width:3px}',
      '#cvw-body::-webkit-scrollbar-track{background:transparent}',
      '#cvw-body::-webkit-scrollbar-thumb{background:' + scrollT + ';border-radius:6px}',

      // Message row — spring fade-up entrance
      '.cw{display:flex;flex-direction:column;align-items:flex-start;margin-bottom:10px;width:100%;flex-shrink:0;animation:cvwfade .35s cubic-bezier(.22,1,.36,1) both}',
      '@keyframes cvwfade{from{opacity:0;transform:translateY(18px) scale(.96)}to{opacity:1;transform:translateY(0) scale(1)}}',
      '.cw.r{align-items:flex-end}',
      '.cw-row{display:inline-flex;align-items:flex-end;gap:9px;max-width:82%;vertical-align:bottom}',
      '.cw.r .cw-row{flex-direction:row-reverse}',

      // Mini avatar beside bubble
      '.cmav{width:28px;height:28px;border-radius:50%;background:' + avMsgBg + ';border:1px solid ' + (isDark ? 'rgba(255,255,255,.09)' : 'rgba(139,92,246,.15)') + ';display:flex;align-items:center;justify-content:center;font-weight:700;font-size:9px;color:' + avMsgCl + ';flex-shrink:0;margin-bottom:2px;box-shadow:0 2px 10px rgba(0,0,0,.12);overflow:hidden}',
      '.cw.r .cmav{display:none}',

      // Sender label
      '.cs{font-size:10px;color:' + sLblClr + ';padding:0 4px;font-weight:600;margin-bottom:4px;letter-spacing:.06em;text-transform:uppercase}',
      '.cw.r .cs{text-align:right}',

      // ── Bubble base ──────────────────────────────────────────────────────────
      '.cm{display:block;max-width:100%;padding:11px 15px;border-radius:18px;font-size:13.5px;line-height:1.68;word-break:break-word;overflow-wrap:break-word;white-space:normal;font-weight:400;position:relative;min-width:44px}',

      // Bot bubble — solid card + left accent bar (no backdrop-filter — breaks inside overflow:hidden)
      '.cm.b{background:' + bBubBg + ';color:' + bBubClr + ';border:' + bBubBor + ';border-left:3px solid ' + c + ';border-bottom-left-radius:5px;box-shadow:' + bBubShd + '}',

      // AI bubble — same as bot
      '.cm.a{background:' + bBubBg + ';color:' + bBubClr + ';border:' + bBubBor + ';border-left:3px solid ' + c + ';border-bottom-left-radius:5px;box-shadow:' + bBubShd + '}',

      // Worker bubble
      '.cm.w{background:' + wBubBg + ';color:' + wBubClr + ';border:' + wBubBor + ';border-left:3px solid #4ade80;border-bottom-left-radius:5px}',

      // User bubble — vivid gradient, right side
      '.cm.v{background:' + grad + ';color:#fff;border-bottom-right-radius:5px;box-shadow:' + vBubShd + ';font-weight:500;letter-spacing:.01em}',

      // System pill message
      '.cm.s{background:' + sysBg + ';color:' + sysClr + ';font-size:11px;font-weight:500;align-self:center;text-align:center;padding:5px 18px;max-width:88%;border:none;border-radius:99px;margin:10px 0;letter-spacing:.03em}',

      // Timestamp row
      '.cts{font-size:10px;color:' + tsClr + ';padding:4px 5px 0;display:flex;align-items:center;gap:4px;font-weight:500}',
      '.cw.r .cts{justify-content:flex-end}',
      '.cvw-tick{display:inline-flex;align-items:center;opacity:.5}',

      // ── Typing indicator ─────────────────────────────────────────────────────
      '.ctyp{display:flex;gap:5px;align-items:center;padding:13px 18px;background:' + typBg + ';border-radius:18px;border-bottom-left-radius:5px;border-left:3px solid ' + c + ';width:max-content;border-top:' + typBor + ';border-right:' + typBor + ';border-bottom:' + typBor + ';box-shadow:' + bBubShd + '}',
      '.ctyp span{width:7px;height:7px;background:' + c + ';border-radius:50%;animation:ctb 1.2s infinite ease-in-out;opacity:.4}',
      '.ctyp span:nth-child(2){animation-delay:.2s}.ctyp span:nth-child(3){animation-delay:.4s}',
      '@keyframes ctb{0%,60%,100%{transform:translateY(0);opacity:.35}30%{transform:translateY(-8px);opacity:1}}',

      // ── Quick reply buttons ──────────────────────────────────────────────────
      '.cqb{display:inline-block;margin:3px 4px 3px 0;padding:8px 16px;background:' + qBg + ';border:' + qBor + ';color:' + qClr + ';border-radius:24px;font-size:12.5px;cursor:pointer;transition:all .22s cubic-bezier(.34,1.56,.64,1);white-space:nowrap;font-weight:600;letter-spacing:.01em}',
      '.cqb:hover{background:' + c + ';border-color:transparent;color:#fff;transform:translateY(-2px) scale(1.03);box-shadow:0 8px 24px ' + glowA + '}',

      // ── Footer / input bar ───────────────────────────────────────────────────
      '#cvw-foot{padding:10px 14px 14px;border-top:' + footBor + ';display:flex;gap:9px;align-items:flex-end;flex-shrink:0;background:' + footBg + '}',
      '#cvw-inp{flex:1;padding:11px 16px;background:' + inpBg + ';border:' + inpBor + ';border-radius:18px;font-size:13.5px;outline:none;resize:none;max-height:80px;min-height:44px;line-height:1.6;color:' + inpClr + ';transition:border-color .22s,box-shadow .22s,background .22s;font-family:inherit;font-weight:400}',
      '#cvw-inp::placeholder{color:' + inpPh + ';font-weight:400}',
      '#cvw-inp:focus{border-color:' + c + ';box-shadow:0 0 0 4px ' + glowC + ';background:' + (isDark ? 'rgba(255,255,255,.07)' : '#fff') + '}',

      // Send button — premium pill
      '#cvw-snd{background:' + grad + ';border:none;border-radius:14px;width:44px;height:44px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:transform .24s cubic-bezier(.34,1.56,.64,1),box-shadow .2s;box-shadow:0 4px 20px ' + glowA + ',inset 0 1px 0 rgba(255,255,255,.25);position:relative;overflow:hidden}',
      '#cvw-snd::before{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(255,255,255,.22),transparent);border-radius:inherit}',
      '#cvw-snd:hover{transform:scale(1.1) translateY(-2px);box-shadow:0 10px 30px ' + glowD + '}',
      '#cvw-snd:active{transform:scale(.94)}',
      '#cvw-snd svg{width:19px;height:19px;fill:#fff;position:relative;filter:drop-shadow(0 1px 4px rgba(0,0,0,.3))}',

      // ── Callback strip ───────────────────────────────────────────────────────
      '#cvw-cbb{padding:0 14px 12px;flex-shrink:0;background:' + footBg + '}',
      '#cvw-cbb button{width:100%;padding:12px 18px;background:' + grad + ';border:none;border-radius:16px;font-size:13px;color:#fff;cursor:pointer;transition:transform .22s cubic-bezier(.34,1.56,.64,1),box-shadow .2s;display:flex;align-items:center;justify-content:center;gap:8px;font-family:inherit;font-weight:700;letter-spacing:.02em;box-shadow:0 6px 24px ' + glowA + ',inset 0 1px 0 rgba(255,255,255,.22)}',
      '#cvw-cbb button:hover{transform:translateY(-2px);box-shadow:0 10px 32px ' + glowD + '}',
      '#cvw-cbb button:active{transform:scale(.97)}',

      // Skip / cancel buttons for callback flow
      '.cvw-skip{display:inline-block;margin:4px 5px 4px 0;padding:8px 18px;background:transparent;border:1.5px solid ' + (isDark ? 'rgba(255,255,255,.1)' : '#e2e8f0') + ';color:' + (isDark ? 'rgba(255,255,255,.45)' : '#94a3b8') + ';border-radius:22px;font-size:12.5px;cursor:pointer;transition:all .2s;font-family:inherit;font-weight:600}',
      '.cvw-skip:hover{border-color:' + c + ';color:' + c + '}',
      '.cvw-cbcancel{display:inline-block;margin:4px 5px 4px 0;padding:8px 18px;background:rgba(239,68,68,.06);border:1.5px solid rgba(239,68,68,.2);color:#f87171;border-radius:22px;font-size:12.5px;cursor:pointer;transition:all .2s;font-family:inherit;font-weight:600}',
      '.cvw-cbcancel:hover{background:rgba(239,68,68,.14)}',

      // ── Branding bar ─────────────────────────────────────────────────────────
      '#cvw-brd{padding:7px 18px 8px;border-top:' + brdBor + ';background:' + brdBg + ';display:flex;align-items:center;justify-content:center;gap:5px;flex-shrink:0}',
      '#cvw-brd span{font-size:10px;color:' + brdClr + ';font-weight:500}',
      '#cvw-brd a{font-size:10px;font-weight:700;color:' + brdLink + ';text-decoration:none;transition:opacity .15s}',
      '#cvw-brd a:hover{opacity:.7}',

      // ── Mobile responsive ────────────────────────────────────────────────────
      '@media(max-width:420px){#cvw-win{width:calc(100vw - 12px);right:6px;border-radius:28px 28px 0 0;bottom:0;height:92dvh}#cvw-btn{bottom:24px;right:20px}}',

      // ── Product carousel ──────────────────────────────────────────────────────
      // Section header
      '.cvw-pc-header{display:flex;align-items:center;gap:7px;padding:10px 4px 6px;font-size:11px;font-weight:700;letter-spacing:.6px;text-transform:uppercase;color:' + (isDark ? 'rgba(255,255,255,.4)' : 'rgba(0,0,0,.35)') + ';flex-shrink:0}',
      '.cvw-pc-header span{flex:1;height:1px;background:' + (isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.07)') + '}',

      // Scrollable rail
      '.cvw-pcwrap{margin:4px -2px 6px;width:calc(100% + 4px);overflow:hidden;flex-shrink:0}',
      '.cvw-pc{display:flex;gap:12px;overflow-x:auto;padding:4px 10px 14px;-webkit-overflow-scrolling:touch;scrollbar-width:none;scroll-snap-type:x mandatory;scroll-padding-left:10px}',
      '.cvw-pc::-webkit-scrollbar{display:none}',

      // Card
      '.cvw-pcard{flex:0 0 155px;border-radius:16px;overflow:hidden;background:' + (isDark ? 'rgba(255,255,255,.08)' : '#fff') + ';border:1px solid ' + (isDark ? 'rgba(255,255,255,.11)' : 'rgba(0,0,0,.07)') + ';box-shadow:0 2px 12px rgba(0,0,0,' + (isDark ? '.35' : '.06') + '),0 1px 3px rgba(0,0,0,' + (isDark ? '.2' : '.04') + ');cursor:pointer;transition:transform .22s cubic-bezier(.34,1.56,.64,1),box-shadow .22s ease;text-decoration:none;display:flex;flex-direction:column;scroll-snap-align:start;position:relative;will-change:transform}',
      '.cvw-pcard:hover{transform:translateY(-5px) scale(1.03);box-shadow:0 14px 36px rgba(0,0,0,' + (isDark ? '.5' : '.13') + ')}',
      '.cvw-pcard:active{transform:scale(.96);transition-duration:.1s}',

      // Image
      '.cvw-pimg-wrap{width:100%;height:150px;overflow:hidden;position:relative;background:' + (isDark ? 'rgba(255,255,255,.05)' : '#f8fafc') + ';flex-shrink:0}',
      '.cvw-pimg{width:100%;height:100%;object-fit:cover;display:block;transition:transform .4s cubic-bezier(.25,.46,.45,.94)}',
      '.cvw-pcard:hover .cvw-pimg{transform:scale(1.09)}',
      // Dark gradient overlay at bottom of image
      '.cvw-pimg-wrap::after{content:"";position:absolute;bottom:0;left:0;right:0;height:55px;background:linear-gradient(to top,rgba(0,0,0,.55) 0%,rgba(0,0,0,.1) 60%,transparent 100%);pointer-events:none;z-index:1}',
      // Price tag overlaid on image (bottom left)
      '.cvw-pprice-img{position:absolute;bottom:8px;left:9px;z-index:2;font-size:12px;font-weight:800;color:#fff;text-shadow:0 1px 4px rgba(0,0,0,.5);letter-spacing:-.3px}',
      // Category badge overlaid top-right
      '.cvw-pbadge{position:absolute;top:8px;right:8px;z-index:2;background:rgba(0,0,0,.45);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);color:#fff;font-size:9px;font-weight:700;padding:3px 8px;border-radius:20px;letter-spacing:.4px;text-transform:uppercase;max-width:70px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
      // No-image placeholder
      '.cvw-pno-img{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:44px;background:' + (isDark ? 'linear-gradient(135deg,rgba(255,255,255,.04),rgba(255,255,255,.08))' : 'linear-gradient(135deg,#f0f4ff,#e8f0fe)') + '}',

      // Card body
      '.cvw-pbody{padding:10px 11px 12px;flex:1;display:flex;flex-direction:column;gap:6px}',
      '.cvw-pname{font-size:12px;font-weight:700;line-height:1.35;color:' + (isDark ? '#f1f5f9' : '#0f172a') + ';display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}',
      '.cvw-pshop{display:flex;align-items:center;justify-content:center;gap:5px;margin-top:auto;padding:7px 10px;background:' + c + ';color:#fff;font-size:10.5px;font-weight:700;border-radius:12px;letter-spacing:.3px;transition:opacity .15s;text-decoration:none}',
      '.cvw-pshop:hover{opacity:.88}',

      // Appear animation for cards
      '@keyframes cvw-card-in{from{opacity:0;transform:translateY(12px) scale(.95)}to{opacity:1;transform:translateY(0) scale(1)}}',
      '.cvw-pcard{animation:cvw-card-in .32s cubic-bezier(.34,1.56,.64,1) both}',

      // Shimmer loading card
      '.cvw-pcard-shimmer{flex:0 0 155px;border-radius:16px;overflow:hidden;background:' + (isDark ? 'rgba(255,255,255,.05)' : '#f1f5f9') + ';border:1px solid ' + (isDark ? 'rgba(255,255,255,.06)' : 'rgba(0,0,0,.05)') + '}',
      '.cvw-pshim-img{height:150px;background:linear-gradient(90deg,' + (isDark ? 'rgba(255,255,255,.05)' : '#e8edf2') + ' 25%,' + (isDark ? 'rgba(255,255,255,.12)' : '#d1d9e0') + ' 50%,' + (isDark ? 'rgba(255,255,255,.05)' : '#e8edf2') + ' 75%);background-size:200% 100%;animation:cvw-shim 1.4s ease-in-out infinite}',
      '.cvw-pshim-body{padding:10px 11px;display:flex;flex-direction:column;gap:7px}',
      '.cvw-pshim-line{height:10px;border-radius:6px;background:linear-gradient(90deg,' + (isDark ? 'rgba(255,255,255,.05)' : '#e8edf2') + ' 25%,' + (isDark ? 'rgba(255,255,255,.12)' : '#d1d9e0') + ' 50%,' + (isDark ? 'rgba(255,255,255,.05)' : '#e8edf2') + ' 75%);background-size:200% 100%;animation:cvw-shim 1.4s ease-in-out infinite}',
      '.cvw-pshim-line.s{width:55%}',
      '.cvw-pshim-btn{height:30px;border-radius:10px;background:linear-gradient(90deg,' + (isDark ? 'rgba(255,255,255,.05)' : '#e8edf2') + ' 25%,' + (isDark ? 'rgba(255,255,255,.12)' : '#d1d9e0') + ' 50%,' + (isDark ? 'rgba(255,255,255,.05)' : '#e8edf2') + ' 75%);background-size:200% 100%;animation:cvw-shim 1.4s ease-in-out infinite;margin-top:4px}',
      '@keyframes cvw-shim{0%{background-position:200% 0}100%{background-position:-200% 0}}',

      // Category chips
      '.cvw-catrow{display:flex;flex-wrap:wrap;gap:8px;margin:10px 0 6px;padding:0 2px}',
      '.cvw-cat{display:inline-flex;align-items:center;gap:5px;padding:8px 15px;background:' + (isDark ? 'rgba(255,255,255,.07)' : 'rgba(0,0,0,.03)') + ';border:1.5px solid ' + (isDark ? 'rgba(255,255,255,.14)' : '#e2e8f0') + ';color:' + (isDark ? '#e2e8f0' : '#374151') + ';border-radius:22px;font-size:12.5px;font-weight:600;cursor:pointer;transition:all .2s cubic-bezier(.34,1.56,.64,1);font-family:inherit;white-space:nowrap}',
      '.cvw-cat:hover{background:' + c + ';border-color:' + c + ';color:#fff;transform:translateY(-2px) scale(1.04);box-shadow:0 4px 12px ' + c + '44}',
      '.cvw-cat:active{transform:scale(.96)}',
      // Order card styles (Flipkart-style)
      '.cvw-orders-hdr{display:flex;align-items:center;gap:7px;padding:10px 4px 6px;font-size:11px;font-weight:700;letter-spacing:.6px;text-transform:uppercase;color:' + (isDark ? 'rgba(255,255,255,.4)' : 'rgba(0,0,0,.35)') + '}',
      '.cvw-orders-hdr span{flex:1;height:1px;background:' + (isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.07)') + '}',
      '.cvw-ocard{display:flex;align-items:center;gap:12px;padding:12px;border-radius:16px;background:' + (isDark ? '#1a2544' : '#fff') + ';border:1px solid ' + (isDark ? 'rgba(255,255,255,.1)' : 'rgba(139,92,246,.15)') + ';margin:4px 0;cursor:pointer;transition:all .22s cubic-bezier(.34,1.56,.64,1);box-shadow:0 2px 10px rgba(0,0,0,' + (isDark ? '.3' : '.05') + ')}',
      '.cvw-ocard:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,' + (isDark ? '.45' : '.1') + ');border-color:' + c + '}',
      '.cvw-oimg{width:56px;height:56px;border-radius:10px;object-fit:cover;flex-shrink:0;background:' + (isDark ? 'rgba(255,255,255,.07)' : '#f1f5f9') + ';display:flex;align-items:center;justify-content:center;font-size:22px;overflow:hidden}',
      '.cvw-oimg img{width:100%;height:100%;object-fit:cover;border-radius:10px}',
      '.cvw-oinfo{flex:1;min-width:0}',
      '.cvw-oname{font-size:12.5px;font-weight:700;color:' + (isDark ? '#f1f5f9' : '#0f172a') + ';white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:3px}',
      '.cvw-ometa{font-size:11px;color:' + (isDark ? 'rgba(255,255,255,.45)' : '#64748b') + '}',
      '.cvw-oprice{font-size:13px;font-weight:800;color:' + c + ';margin-top:3px}',
      // Status badges
      '.cvw-obadge{display:inline-block;padding:2px 9px;border-radius:20px;font-size:10px;font-weight:700;letter-spacing:.3px;margin-top:4px}',
      '.cvw-obadge.delivered{background:rgba(34,197,94,.15);color:#16a34a}',
      '.cvw-obadge.shipped,.cvw-obadge.in_transit,.cvw-obadge.out_for_delivery{background:rgba(59,130,246,.12);color:#2563eb}',
      '.cvw-obadge.pending{background:rgba(245,158,11,.12);color:#d97706}',
      '.cvw-obadge.cancelled,.cvw-obadge.returned{background:rgba(239,68,68,.1);color:#dc2626}',
      // Action buttons panel
      '.cvw-oactions{display:flex;flex-direction:column;gap:8px;padding:12px 4px 4px;animation:cvwfade .28s both}',
      '.cvw-oact-btn{display:flex;align-items:center;gap:10px;padding:12px 16px;border-radius:14px;border:none;cursor:pointer;font-size:13px;font-weight:600;width:100%;text-align:left;transition:all .22s cubic-bezier(.34,1.56,.64,1);font-family:inherit}',
      '.cvw-oact-btn.primary{background:' + c + ';color:#fff;box-shadow:0 4px 14px ' + c + '44}',
      '.cvw-oact-btn.primary:hover{opacity:.9;transform:translateY(-1px)}',
      '.cvw-oact-btn.danger{background:rgba(239,68,68,.08);color:#ef4444;border:1.5px solid rgba(239,68,68,.2)}',
      '.cvw-oact-btn.danger:hover{background:rgba(239,68,68,.16);transform:translateY(-1px)}',
      '.cvw-oact-btn.neutral{background:' + (isDark ? 'rgba(255,255,255,.07)' : '#f8fafc') + ';color:' + (isDark ? 'rgba(255,255,255,.8)' : '#334155') + ';border:1.5px solid ' + (isDark ? 'rgba(255,255,255,.12)' : '#e2e8f0') + '}',
      '.cvw-oact-btn.neutral:hover{background:' + (isDark ? 'rgba(255,255,255,.12)' : '#f1f5f9') + ';transform:translateY(-1px)}',
      '.cvw-oact-icon{font-size:17px;flex-shrink:0}',
      '.cvw-oact-text h4{font-size:13px;font-weight:700;margin:0}',
      '.cvw-oact-text p{font-size:11px;opacity:.65;margin:2px 0 0;font-weight:400}',
      '.cvw-policy-msg{background:rgba(245,158,11,.08);border:1.5px solid rgba(245,158,11,.2);border-radius:14px;padding:12px 14px;font-size:12px;color:' + (isDark ? '#fbbf24' : '#92400e') + ';margin:4px 0;line-height:1.55}',
      // Exchange flow panel
      '.cvw-exbox{background:' + (isDark ? '#1a2544' : '#fff') + ';border:1.5px solid ' + (isDark ? 'rgba(255,255,255,.12)' : 'rgba(139,92,246,.2)') + ';border-radius:18px;padding:16px;margin:6px 0;animation:cvwfade .3s both}',
      '.cvw-exproduct{display:flex;align-items:center;gap:12px;padding:10px 0 14px;border-bottom:1px solid ' + (isDark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.06)') + ';margin-bottom:12px}',
      '.cvw-eximg{width:56px;height:56px;border-radius:12px;object-fit:cover;background:' + (isDark ? '#2a3a60' : '#f1f5f9') + ';flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:22px;overflow:hidden}',
      '.cvw-eximg img{width:100%;height:100%;object-fit:cover;border-radius:12px}',
      '.cvw-exinfo p{font-size:12.5px;font-weight:700;color:' + (isDark ? '#f1f5f9' : '#0f172a') + ';margin-bottom:3px;line-height:1.3}',
      '.cvw-exinfo span{font-size:11px;color:' + (isDark ? 'rgba(255,255,255,.4)' : '#64748b') + '}',
      '.cvw-exlabel{font-size:11px;font-weight:700;color:' + (isDark ? 'rgba(255,255,255,.45)' : '#64748b') + ';text-transform:uppercase;letter-spacing:.5px;margin-bottom:9px}',
      '.cvw-sizes{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px}',
      '.cvw-size{padding:7px 15px;border-radius:10px;border:1.5px solid ' + (isDark ? 'rgba(255,255,255,.14)' : 'rgba(139,92,246,.25)') + ';background:' + (isDark ? 'rgba(255,255,255,.05)' : '#f8fafc') + ';color:' + (isDark ? 'rgba(255,255,255,.8)' : '#334155') + ';font-size:12px;font-weight:700;cursor:pointer;transition:all .18s cubic-bezier(.34,1.56,.64,1);font-family:inherit}',
      '.cvw-size:hover{background:' + (isDark ? 'rgba(255,255,255,.12)' : 'rgba(99,102,241,.1)') + ';border-color:' + (isDark ? 'rgba(255,255,255,.3)' : '#6366f1') + ';transform:scale(1.08)}',
      '.cvw-size.sel{background:' + (isDark ? 'rgba(99,102,241,.3)' : '#6366f1') + ';border-color:' + (isDark ? '#6366f1' : '#4f46e5') + ';color:#fff;box-shadow:0 4px 12px ' + (isDark ? 'rgba(99,102,241,.4)' : 'rgba(99,102,241,.3)') + '}',
      '.cvw-exsubmit{width:100%;padding:11px;border-radius:12px;font-size:13px;font-weight:700;border:none;cursor:pointer;font-family:inherit;transition:all .2s;letter-spacing:.2px}',
      '.cvw-exsubmit.rdy{background:' + (isDark ? 'linear-gradient(135deg,#6366f1,#7c3aed)' : 'linear-gradient(135deg,#6366f1,#4f46e5)') + ';color:#fff;box-shadow:0 4px 14px rgba(99,102,241,.35)}',
      '.cvw-exsubmit.rdy:hover{opacity:.9}',
      '.cvw-exsubmit:not(.rdy){background:' + (isDark ? 'rgba(255,255,255,.06)' : '#f1f5f9') + ';color:' + (isDark ? 'rgba(255,255,255,.3)' : '#94a3b8') + ';cursor:not-allowed}',
      // Email box for anonymous return/refund flow
      '.cvw-email-box{background:' + (isDark ? '#1a2544' : '#fff') + ';border:1.5px solid ' + (isDark ? 'rgba(255,255,255,.12)' : 'rgba(139,92,246,.2)') + ';border-radius:18px;padding:16px;margin:6px 0;animation:cvwfade .3s both}',
      '.cvw-email-box p{font-size:12px;color:' + (isDark ? 'rgba(255,255,255,.5)' : '#64748b') + ';margin-bottom:10px;line-height:1.5}',
      '.cvw-email-inp{width:100%;padding:10px 13px;border-radius:12px;border:1.5px solid ' + (isDark ? 'rgba(255,255,255,.12)' : 'rgba(139,92,246,.25)') + ';background:' + (isDark ? 'rgba(255,255,255,.06)' : '#f8fafc') + ';color:' + (isDark ? '#f1f5f9' : '#0f172a') + ';font-size:13px;font-family:inherit;outline:none;box-sizing:border-box;transition:border-color .2s}',
      '.cvw-email-inp:focus{border-color:' + c + '}',
      '.cvw-email-inp::placeholder{color:' + (isDark ? 'rgba(255,255,255,.25)' : 'rgba(0,0,0,.3)') + '}',
      '.cvw-email-fetch{width:100%;margin-top:9px;padding:11px;border-radius:12px;background:' + c + ';color:#fff;font-size:13px;font-weight:700;border:none;cursor:pointer;font-family:inherit;transition:opacity .15s;letter-spacing:.2px}',
      '.cvw-email-fetch:hover{opacity:.88}',
      '.cvw-email-fetch:disabled{opacity:.5;cursor:not-allowed}',
    ].join('\n');
  }


  // ── Build DOM ────────────────────────────────────────────────────────────────
  function build(cfg) {
    var c = cfg.primary_color || '#6366f1';
    var nm = cfg.bot_name || 'Support';
    var theme = cfg.widget_theme || 'dark';
    var fontFamily = cfg.font_family || 'Inter';
    var ini = nm.split(' ').map(function (w) { return w[0] || ''; }).join('').slice(0, 2).toUpperCase();

    // Inject Google Font for chosen font family
    var fontSlug = fontFamily.replace(/ /g, '+') + ':wght@400;500;600;700';
    var existingFont = document.querySelector('link[data-cvw-font]');
    if (existingFont) existingFont.remove();
    var fontLink = document.createElement('link');
    fontLink.rel = 'stylesheet';
    fontLink.setAttribute('data-cvw-font', '1');
    fontLink.href = 'https://fonts.googleapis.com/css2?family=' + fontSlug + '&display=swap';
    document.head.appendChild(fontLink);

    // Use logo_url from config (set by Auto-Scan), or try merchant's own page favicon
    function getSiteLogo() {
      if (cfg.logo_url) return cfg.logo_url;
      if (cfg.bot_avatar_url) return cfg.bot_avatar_url;
      var selectors = [
        'link[rel="apple-touch-icon"]',
        'link[rel="icon"][sizes="32x32"]',
        'link[rel="icon"][sizes="64x64"]',
        'link[rel="shortcut icon"]',
        'link[rel="icon"]',
      ];
      for (var i = 0; i < selectors.length; i++) {
        var el = document.querySelector(selectors[i]);
        if (el && el.href) return el.href;
      }
      return '';
    }
    var avatarUrl = getSiteLogo();

    S.botName = nm;
    S.botIni = ini;
    S.botAvatar = avatarUrl;

    var style = document.createElement('style');
    style.textContent = buildCSS(c, theme, fontFamily);
    document.head.appendChild(style);

    var root = document.createElement('div');
    root.id = 'cvw';
    root.innerHTML = [
      // Launch bubble
      '<button id="cvw-btn" aria-label="Open chat">',
      '  <div id="cvw-badge">1</div>',
      '  <svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>',
      '</button>',
      // Chat window
      '<div id="cvw-win" role="dialog" aria-label="Chat support">',
      '  <div id="cvw-head">',
      '    <div id="cvw-av">' + (avatarUrl ? '<img src="' + avatarUrl + '" style="width:100%;height:100%;object-fit:cover;border-radius:inherit" onerror="this.style.display=\'none\';this.parentNode.textContent=\'' + ini + '\'">' : esc(ini)) + '</div>',
      '    <div id="cvw-hi">',
      '      <div id="cvw-hn">' + esc(nm) + '</div>',
      '      <div id="cvw-hs"><span class="cvw-dot"></span>&nbsp;Online &amp; Ready</div>',
      '    </div>',
      '    <button id="cvw-x" aria-label="Close"><svg viewBox="0 0 24 24" width="15" height="15" fill="white"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg></button>',
      '  </div>',
      '  <div id="cvw-body"></div>',
      '  <div id="cvw-cbb"><button id="cvw-cbb-btn">',
      '    <svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1-9.4 0-17-7.6-17-17 0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1L6.6 10.8z"/></svg>',
      '    Request a Callback',
      '  </button></div>',
      '  <div id="cvw-foot">',
      '    <textarea id="cvw-inp" rows="1" placeholder="Type a message..." maxlength="2000"></textarea>',
      '    <button id="cvw-snd" aria-label="Send"><svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg></button>',
      '  </div>',
      '  <div id="cvw-brd">',
      '    <span>Powered by</span>',
      '    <a href="https://codverify.tech" target="_blank" rel="noopener">⚡ CODVerify</a>',
      '  </div>',
      '</div>',
    ].join('');
    document.body.appendChild(root);

    // Events — identical to original
    q('#cvw-btn').addEventListener('click', toggle);
    q('#cvw-x').addEventListener('click', function () { setOpen(false); });
    q('#cvw-snd').addEventListener('click', onSend);
    q('#cvw-cbb-btn').addEventListener('click', startCallbackFlow);
    q('#cvw-inp').addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); onSend(); }
      autoH(this);
    });
    q('#cvw-inp').addEventListener('input', function () { autoH(this); });
  }

  // ── Helpers ──────────────────────────────────────────────────────────────────
  function q(s) { return document.querySelector(s); }
  function esc(s) { return (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function tr(v) { return (v || '').trim(); }
  function autoH(e) { e.style.height = 'auto'; e.style.height = Math.min(e.scrollHeight, 80) + 'px'; }
  function scrl() { var b = q('#cvw-body'); if (b) setTimeout(function () { b.scrollTop = b.scrollHeight; }, 30); }
  function now() { return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }

  // ── Working Hours Check (IST = UTC+5:30, 8AM–8PM) ────────────────────────────
  function isWithinWorkingHours() {
    var now = new Date();
    var istOffset = 5.5 * 60;
    var utcMs = now.getTime() + now.getTimezoneOffset() * 60000;
    var istDate = new Date(utcMs + istOffset * 60000);
    var h = istDate.getHours();
    return h >= 8 && h < 20;
  }

  function showOffHoursMessage() {
    sys('⏰ Outside Service Hours');
    addBubble('b', 'Our support team is available Mon–Sat, 8AM–8PM IST. Right now we are outside service hours. You can request a callback and our team will contact you during working hours! 📞');
    var body = q('#cvw-body');
    if (body) {
      var cbBtn = document.createElement('button');
      cbBtn.className = 'cqb';
      cbBtn.style.cssText = 'margin:6px 0;padding:10px 20px;font-size:13px;font-weight:600;background:linear-gradient(135deg,#6366f1,#7c3aed);color:#fff;border:none;border-radius:22px;cursor:pointer;width:auto;transition:all .2s;box-shadow:0 4px 14px rgba(99,102,241,.4)';
      cbBtn.innerHTML = '📞 Request a Callback';
      cbBtn.addEventListener('click', function () {
        cbBtn.remove();
        startCallbackFlow();
      });
      body.appendChild(cbBtn);
      scrl();
    }
  }

  // ── Open / Close ─────────────────────────────────────────────────────────────
  function toggle() { setOpen(!S.open); }
  function setOpen(v) {
    S.open = v;
    var win = q('#cvw-win');
    var btn = q('#cvw-btn');
    if (v) {
      win.classList.add('on');
      q('#cvw-badge').style.display = 'none';
      if (btn) {
        btn.style.display = 'none';
        btn.style.opacity = '0';
        btn.style.pointerEvents = 'none';
        btn.style.transform = 'scale(.85) translateY(6px)';
        btn.setAttribute('aria-hidden', 'true');
      }
      if (!S.inited) init();
      setTimeout(function () { var i = q('#cvw-inp'); if (i && !S.cb.active) i.focus(); }, 280);
    } else {
      win.classList.remove('on');
      if (btn) {
        btn.style.display = 'flex';
        btn.style.opacity = '1';
        btn.style.pointerEvents = '';
        btn.style.transform = '';
        btn.removeAttribute('aria-hidden');
      }
    }
  }

  // ── Init ─────────────────────────────────────────────────────────────────────
  // ── init ─────────────────────────────────────────────────────────────────────
  function init() {
    S.inited = true;
    var cfg = S.config;
    S.tier = cfg.chatbot_tier || 'chatbot_basic';

    addBubble('b', cfg.welcome_message || 'Hi! 👋 How can I help you today?');

    var opts = cfg.menu_options || [];
    if (opts.length) {
      var body = q('#cvw-body');
      var wrap = document.createElement('div');
      wrap.id = 'cvw-opts';
      wrap.style.cssText = 'display:flex;flex-wrap:wrap;gap:4px;padding:4px 0 8px';
      opts.forEach(function (o) {
        var btn = document.createElement('button');
        btn.className = 'cqb';
        btn.textContent = o.label;
        btn.addEventListener('click', function () {
          wrap.remove();
          addBubble('v', o.label);
          setTimeout(function () {
            addBubble('b', o.answer);
          }, 600);
          if (!S.sessionId) startSession(o.label, true);
        });
        wrap.appendChild(btn);
      });
      body.appendChild(wrap);
      scrl();
    }

    if (S.tier === 'chatbot_basic') {
      get('/api/v1/merchant-chat/workers-status?api_key=' + encodeURIComponent(API_KEY), function (err, res) {
        if (!err && res && res.data && !res.data.workers_online) {
          updStatus('away');
        }
      });
    }

    // Logged-in customer: load recent orders
    if (S.loggedIn && S.customerEmail) {
      setTimeout(loadRecentOrders, 800);
    }
  }

  // ── Status helpers ───────────────────────────────────────────────────────────
  function updStatus(k) {
    var hs = q('#cvw-hs');
    if (!hs) return;
    if (k === 'away') {
      hs.innerHTML = '<span style="width:7px;height:7px;border-radius:50%;background:#f59e0b;display:inline-block;flex-shrink:0;box-shadow:0 0 0 2px rgba(245,158,11,.2)"></span>&nbsp;Away';
    } else if (k === 'agent') {
      hs.innerHTML = '<span class="cvw-dot"></span>&nbsp;Agent connected';
    } else if (k === 'offline') {
      hs.innerHTML = '<span style="width:7px;height:7px;border-radius:50%;background:#ef4444;display:inline-block;flex-shrink:0"></span>&nbsp;No agents online';
    }
  }

  // ── Message bubble ───────────────────────────────────────────────────────────
  function addBubble(type, text, label) {
    var body = q('#cvw-body');
    if (!body) return;

    var isUser = (type === 'v');
    var wrap = document.createElement('div');
    wrap.className = 'cw' + (isUser ? ' r' : '');

    if (label) {
      var sl = document.createElement('div');
      sl.className = 'cs';
      sl.textContent = label;
      wrap.appendChild(sl);
    }

    var row = document.createElement('div');
    row.className = 'cw-row';

    if (!isUser) {
      var av = document.createElement('div');
      av.className = 'cmav';
      if (type !== 'w' && S.botAvatar) {
        av.style.cssText = 'padding:0;overflow:hidden;background:transparent;border:none';
        var avImg = document.createElement('img');
        avImg.src = S.botAvatar;
        avImg.style.cssText = 'width:100%;height:100%;object-fit:cover;border-radius:inherit';
        avImg.onerror = function () { av.style.cssText = ''; av.textContent = S.botIni; };
        av.appendChild(avImg);
      } else {
        av.textContent = (type === 'w') ? (label ? label[0].toUpperCase() : 'A') : S.botIni;
      }
      row.appendChild(av);
    }

    var bbl = document.createElement('div');
    bbl.className = 'cm ' + type;
    bbl.textContent = text;
    row.appendChild(bbl);

    wrap.appendChild(row);

    var ts = document.createElement('div');
    ts.className = 'cts';
    var tick = isUser
      ? ' <span class="cvw-tick"><svg viewBox="0 0 16 10" width="13" height="13" fill="currentColor" style="opacity:.7"><path d="M1 5l4 4L15 1M6 9L5 8"/><path d="M5 9l4-4"/></svg></span>'
      : '';
    ts.innerHTML = now() + tick;
    wrap.appendChild(ts);

    body.appendChild(wrap);
    scrl();
  }

  function sys(text) {
    var body = q('#cvw-body');
    if (!body) return;
    var el = document.createElement('div');
    el.className = 'cm s';
    el.textContent = text;
    body.appendChild(el);
    scrl();
  }

  function showTyping() {
    var body = q('#cvw-body');
    if (!body || q('#cvw-typ')) return;
    var wrap = document.createElement('div');
    wrap.className = 'cw';
    var row = document.createElement('div');
    row.className = 'cw-row';
    var av = document.createElement('div');
    av.className = 'cmav';
    if (S.botAvatar) {
      av.style.cssText = 'padding:0;overflow:hidden;background:transparent;border:none';
      var tImg = document.createElement('img');
      tImg.src = S.botAvatar;
      tImg.style.cssText = 'width:100%;height:100%;object-fit:cover;border-radius:inherit';
      tImg.onerror = function () { av.style.cssText = ''; av.textContent = S.botIni; };
      av.appendChild(tImg);
    } else {
      av.textContent = S.botIni;
    }
    row.appendChild(av);
    var el = document.createElement('div');
    el.id = 'cvw-typ'; el.className = 'ctyp';
    el.innerHTML = '<span></span><span></span><span></span>';
    row.appendChild(el);
    wrap.appendChild(row);
    body.appendChild(wrap);
    scrl();
  }

  function removeTyping() {
    var e = q('#cvw-typ');
    if (e) { var p = e.closest('.cw') || e.parentElement.closest('.cw') || e.parentElement; p.remove(); }
  }

  // ── Quick inline buttons (callback flow choices) ──────────────────────────────
  function addChoiceButtons(choices) {
    var body = q('#cvw-body');
    if (!body) return;
    var wrap = document.createElement('div');
    wrap.id = 'cvw-choices';
    wrap.className = 'cw';
    wrap.style.cssText = 'display:flex;flex-wrap:wrap;gap:6px;padding:4px 0 6px';
    choices.forEach(function (ch) {
      var btn = document.createElement('button');
      btn.className = ch.skip ? 'cvw-skip' : (ch.cancel ? 'cvw-cbcancel' : 'cqb');
      btn.textContent = ch.label;
      btn.addEventListener('click', function () {
        wrap.remove();
        ch.action();
      });
      wrap.appendChild(btn);
    });
    body.appendChild(wrap);
    scrl();
  }

  function removeChoices() {
    var c = q('#cvw-choices');
    if (c) c.remove();
  }

  // ── Conversational Callback Flow ─────────────────────────────────────────────
  function startCallbackFlow() {
    if (S.cb.active) return;
    S.cb = { active: true, step: 0, data: {} };
    var inp = q('#cvw-inp');
    if (inp) { inp.placeholder = 'Reply here...'; }

    sys('📞 Callback Request');
    setTimeout(function () {
      botSay('Sure! Let me collect a few details. What\'s your **name**?', cbStep0Choices);
    }, 400);
  }

  function botSay(text, choicesFn, delay) {
    showTyping();
    setTimeout(function () {
      removeTyping();
      addBubble('b', text.replace(/\*\*/g, ''));
      if (choicesFn) choicesFn();
      var inp = q('#cvw-inp');
      if (inp) { inp.focus(); }
    }, delay || 700);
  }

  function cbStep0Choices() {
    addChoiceButtons([
      { label: '❌ Cancel', cancel: true, action: cancelCallback }
    ]);
    S.cb.step = 0;
  }

  function cbStep1() {
    botSay('Got it, ' + S.cb.data.name + '! 👍 What\'s your **phone number** so we can call you?', function () {
      addChoiceButtons([
        { label: '❌ Cancel', cancel: true, action: cancelCallback }
      ]);
      S.cb.step = 1;
    });
  }

  function cbStep2() {
    botSay('Perfect! Your **email address**? (optional)', function () {
      addChoiceButtons([
        { label: '⭐ Skip', skip: true, action: function () { S.cb.data.email = ''; cbStep3(); } },
        { label: '❌ Cancel', cancel: true, action: cancelCallback }
      ]);
      S.cb.step = 2;
    });
  }

  function cbStep3() {
    botSay('Almost done! Briefly, what\'s the **reason** for the callback? (optional)', function () {
      addChoiceButtons([
        { label: '⭐ Skip', skip: true, action: function () { S.cb.data.reason = ''; doSubmitCallback(); } },
        { label: '❌ Cancel', cancel: true, action: cancelCallback }
      ]);
      S.cb.step = 3;
    });
  }

  function handleCallbackInput(msg) {
    removeChoices();
    addBubble('v', msg);
    var step = S.cb.step;

    if (step === 0) {
      if (!msg || msg.length < 2) {
        botSay('Please enter a valid name (at least 2 characters).', cbStep0Choices);
        return;
      }
      S.cb.data.name = msg;
      cbStep1();
    } else if (step === 1) {
      var digits = msg.replace(/\D/g, '');
      if (digits.length < 7) {
        botSay('Please enter a valid phone number.', function () {
          addChoiceButtons([{ label: '❌ Cancel', cancel: true, action: cancelCallback }]);
          S.cb.step = 1;
        });
        return;
      }
      S.cb.data.phone = msg;
      cbStep2();
    } else if (step === 2) {
      S.cb.data.email = msg;
      cbStep3();
    } else if (step === 3) {
      S.cb.data.reason = msg;
      doSubmitCallback();
    }
  }

  function doSubmitCallback() {
    removeChoices();
    showTyping();
    var ep = (S.status === 'offline')
      ? '/api/v1/merchant-chat/offline-callback'
      : '/api/v1/merchant-chat/callback-request';

    post(ep, {
      api_key: API_KEY,
      visitor_name: S.cb.data.name,
      visitor_phone: S.cb.data.phone,
      visitor_email: S.cb.data.email || null,
      reason: S.cb.data.reason || 'Callback request via chat widget',
    }, function (err, res) {
      removeTyping();
      S.cb.active = false;
      S.status = 'callback_sent';
      var msg = (res && res.data && res.data.message)
        ? res.data.message
        : 'Your callback request has been submitted!';
      addBubble('b', '✅ ' + msg + ' Our team will call you shortly at ' + S.cb.data.phone + '.');
      var inp = q('#cvw-inp');
      if (inp) inp.placeholder = 'Type a message...';
    });
  }

  function cancelCallback() {
    S.cb.active = false;
    S.cb = { active: false, step: 0, data: {} };
    removeChoices();
    addBubble('b', 'No problem! Callback request cancelled. Feel free to ask me anything. 😊');
    var inp = q('#cvw-inp');
    if (inp) { inp.placeholder = 'Type a message...'; inp.focus(); }
  }

  // ── onSend — routes to callback flow or normal chat ───────────────────────────
  function onSend() {
    var inp = q('#cvw-inp');
    var msg = tr(inp && inp.value);
    if (!msg) return;
    inp.value = '';
    inp.style.height = 'auto';

    if (S.cb.active) {
      handleCallbackInput(msg);
      return;
    }

    sendMsg(msg);
  }

  // ── Normal chat ──────────────────────────────────────────────────────────────

  // ── Product carousel helpers ─────────────────────────────────────────────────
  function showProductCarousel(products, introText) {
    if (introText) addBubble('a', introText);
    var body = q('#cvw-body');
    if (!body || !products.length) return;

    // Section header
    var hdr = document.createElement('div');
    hdr.className = 'cvw-pc-header';
    hdr.innerHTML = '<span></span>🛍️ Products <span></span>';
    body.appendChild(hdr);

    var wrap = document.createElement('div');
    wrap.className = 'cvw-pcwrap';
    var rail = document.createElement('div');
    rail.className = 'cvw-pc';

    products.forEach(function (p, idx) {
      var card = document.createElement('a');
      card.className = 'cvw-pcard';

      // Set link — always open in new tab
      var hasUrl = p.url && p.url !== '#' && p.url.length > 4;
      if (hasUrl) {
        card.href = p.url;
        card.target = '_blank';
        card.rel = 'noopener noreferrer';
      } else {
        card.href = '#';
        card.addEventListener('click', function (e) { e.preventDefault(); });
      }

      // Stagger entry animation
      card.style.animationDelay = (idx * 50) + 'ms';

      // Image section
      var imgWrap = document.createElement('div');
      imgWrap.className = 'cvw-pimg-wrap';

      if (p.image) {
        var img = document.createElement('img');
        img.className = 'cvw-pimg';
        img.src = p.image;
        img.alt = p.title || 'Product';
        img.loading = 'lazy';
        img.onerror = function () {
          imgWrap.innerHTML = '<div class="cvw-pno-img">🛍️</div>';
          if (badgeEl) imgWrap.appendChild(badgeEl);
          if (priceEl) imgWrap.appendChild(priceEl);
        };
        imgWrap.appendChild(img);
      } else {
        var noimg = document.createElement('div');
        noimg.className = 'cvw-pno-img';
        noimg.textContent = '🛍️';
        imgWrap.appendChild(noimg);
      }

      // Category badge (top-right, frosted)
      var badgeEl = null;
      if (p.type) {
        badgeEl = document.createElement('span');
        badgeEl.className = 'cvw-pbadge';
        badgeEl.textContent = p.type.length > 12 ? p.type.slice(0, 12) + '..' : p.type;
        imgWrap.appendChild(badgeEl);
      }

      // Price overlaid on gradient (bottom-left of image)
      var priceEl = null;
      if (p.price) {
        priceEl = document.createElement('div');
        priceEl.className = 'cvw-pprice-img';
        priceEl.textContent = p.price;
        imgWrap.appendChild(priceEl);
      }

      card.appendChild(imgWrap);

      // Card body
      var body2 = document.createElement('div');
      body2.className = 'cvw-pbody';

      var nameEl = document.createElement('div');
      nameEl.className = 'cvw-pname';
      nameEl.textContent = p.title || '';
      body2.appendChild(nameEl);

      var shopBtn = document.createElement('div');
      shopBtn.className = 'cvw-pshop';
      shopBtn.style.pointerEvents = 'none'; // let parent <a> handle click
      shopBtn.innerHTML = hasUrl ? '🛒 View Product' : '🛍️ View Details';
      body2.appendChild(shopBtn);

      card.appendChild(body2);
      rail.appendChild(card);
    });

    wrap.appendChild(rail);
    body.appendChild(wrap);
    scrl();
  }

  function showCategoryChips(cats, introText) {
    if (introText) addBubble('a', introText);
    var body = q('#cvw-body');
    if (!body || !cats.length) return;
    var row = document.createElement('div');
    row.className = 'cvw-catrow';
    cats.forEach(function (cat) {
      var chip = document.createElement('button');
      chip.className = 'cvw-cat';
      chip.textContent = cat;
      chip.addEventListener('click', function () {
        row.remove();
        addBubble('v', cat);
        fetchProductsByCategory(cat);
      });
      row.appendChild(chip);
    });
    body.appendChild(row);
    scrl();
  }

  // ── Order Support (Flipkart-style) ──────────────────────────────────────────

  var ORDER_STATUS_LABELS = {
    delivered: 'Delivered ✓',
    shipped: 'Shipped',
    in_transit: 'In Transit',
    out_for_delivery: 'Out for Delivery',
    pending: 'Processing',
    cancelled: 'Cancelled',
    returned: 'Returned',
  };

  function loadRecentOrders() {
    var url = '/api/v1/merchant-chat/recent-orders?api_key=' + encodeURIComponent(API_KEY)
      + '&email=' + encodeURIComponent(S.customerEmail);
    showTyping();
    get(url, function (err, res) {
      removeTyping();
      if (err || !res || !res.success || !res.data.orders.length) return;
      var orders = res.data.orders;
      addBubble('b', 'Hi! 👋 I can see your recent orders below. Click on any order to get help with returns, refunds, or delivery queries.');
      showOrderList(orders);
    });
  }

  function showOrderList(orders) {
    var body = q('#cvw-body');
    if (!body || !orders.length) return;

    var hdr = document.createElement('div');
    hdr.className = 'cvw-orders-hdr';
    hdr.innerHTML = '<span></span>📦 Your Recent Orders <span></span>';
    body.appendChild(hdr);

    orders.forEach(function (o, idx) {
      var card = document.createElement('div');
      card.className = 'cvw-ocard';
      card.style.animationDelay = (idx * 60) + 'ms';

      // Image
      var imgDiv = document.createElement('div');
      imgDiv.className = 'cvw-oimg';
      if (o.item_image) {
        var im = document.createElement('img');
        im.src = o.item_image;
        im.alt = o.item_name || 'Item';
        im.onerror = function () { imgDiv.textContent = '📦'; };
        imgDiv.appendChild(im);
      } else {
        imgDiv.textContent = '📦';
      }
      card.appendChild(imgDiv);

      // Info
      var info = document.createElement('div');
      info.className = 'cvw-oinfo';

      var nameEl = document.createElement('div');
      nameEl.className = 'cvw-oname';
      nameEl.textContent = o.item_name || ('Order #' + o.order_number);
      info.appendChild(nameEl);

      var metaEl = document.createElement('div');
      metaEl.className = 'cvw-ometa';
      metaEl.textContent = 'Order #' + o.order_number;
      info.appendChild(metaEl);

      if (o.order_amount) {
        var priceEl = document.createElement('div');
        priceEl.className = 'cvw-oprice';
        priceEl.textContent = (o.currency || '₹') + ' ' + o.order_amount;
        info.appendChild(priceEl);
      }

      var ds = (o.delivery_status || 'pending').toLowerCase().replace(/ /g, '_');
      var badge = document.createElement('div');
      badge.className = 'cvw-obadge ' + ds;
      badge.textContent = ORDER_STATUS_LABELS[ds] || ds.replace(/_/g, ' ');
      info.appendChild(badge);

      card.appendChild(info);

      // Chevron
      var arr = document.createElement('div');
      arr.style.cssText = 'font-size:18px;opacity:.4;flex-shrink:0';
      arr.textContent = '›';
      card.appendChild(arr);

      card.addEventListener('click', function () {
        showOrderActions(o);
      });

      body.appendChild(card);
    });
    scrl();
  }

  function showOrderActions(order) {
    var body = q('#cvw-body');
    if (!body) return;

    // Remove any existing action panel
    var existing = q('#cvw-oactions-panel');
    if (existing) existing.remove();

    addBubble('v', 'Order #' + order.order_number);
    addBubble('b', 'What do you need help with for Order #' + order.order_number + '?');

    var panel = document.createElement('div');
    panel.id = 'cvw-oactions-panel';
    panel.className = 'cvw-oactions';

    // Return button
    if (order.within_return_window) {
      var retBtn = document.createElement('button');
      retBtn.className = 'cvw-oact-btn danger';
      retBtn.innerHTML = '<span class="cvw-oact-icon">↩️</span><div class="cvw-oact-text"><h4>Return This Item</h4><p>Send back your order for a return</p></div>';
      retBtn.addEventListener('click', function () {
        panel.remove();
        startReturnFlow(order, 'return');
      });
      panel.appendChild(retBtn);
    }

    // Exchange button (replaces Refund)
    if (order.within_return_window) {
      var exBtn = document.createElement('button');
      exBtn.className = 'cvw-oact-btn danger';
      exBtn.innerHTML = '<span class="cvw-oact-icon">🔄</span><div class="cvw-oact-text"><h4>Exchange This Item</h4><p>Get a different size or variant</p></div>';
      exBtn.addEventListener('click', function () {
        panel.remove();
        startExchangeFlow(order);
      });
      panel.appendChild(exBtn);
    }

    // Policy expired message
    if (!order.within_return_window) {
      var policyMsg = document.createElement('div');
      policyMsg.className = 'cvw-policy-msg';
      policyMsg.innerHTML = '⏰ <strong>Return/Exchange window has ended.</strong><br>As per our policy, returns and exchanges are accepted within ' + (order.return_policy_days || 7) + ' days of order placement. Your order was placed ' + (order.days_since_order || '?') + ' days ago. For special cases, please contact our support team.';
      panel.appendChild(policyMsg);
    }

    // Track delivery button
    if (order.tracking_url) {
      var trackBtn = document.createElement('a');
      trackBtn.className = 'cvw-oact-btn neutral';
      trackBtn.href = order.tracking_url;
      trackBtn.target = '_blank';
      trackBtn.rel = 'noopener';
      trackBtn.style.textDecoration = 'none';
      trackBtn.innerHTML = '<span class="cvw-oact-icon">🚚</span><div class="cvw-oact-text"><h4>Track Delivery</h4><p>' + (order.tracking_number || 'Check shipment status') + '</p></div>';
      panel.appendChild(trackBtn);
    }

    // Talk to support button
    var suppBtn = document.createElement('button');
    suppBtn.className = 'cvw-oact-btn primary';
    suppBtn.innerHTML = '<span class="cvw-oact-icon">💬</span><div class="cvw-oact-text"><h4>Talk to Support Agent</h4><p>Connect with our team for help</p></div>';
    suppBtn.addEventListener('click', function () {
      panel.remove();
      // Mark as loggedIn so return-intent check is skipped
      var wasLoggedIn = S.loggedIn;
      S.loggedIn = true;
      var msg = 'I need help with Order #' + order.order_number;
      sendMsg(msg);
      S.loggedIn = wasLoggedIn;
    });
    panel.appendChild(suppBtn);

    body.appendChild(panel);
    scrl();
  }

  var COMMON_SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'Free Size'];

  function startExchangeFlow(order) {
    var body = q('#cvw-body');
    if (!body) return;

    addBubble('a', 'Sure! Let me confirm the item you want to exchange and select a new size.');

    var box = document.createElement('div');
    box.className = 'cvw-exbox';

    // Product display
    var prod = document.createElement('div');
    prod.className = 'cvw-exproduct';
    var imgDiv = document.createElement('div');
    imgDiv.className = 'cvw-eximg';
    if (order.item_image) {
      var img = document.createElement('img');
      img.src = order.item_image;
      img.alt = order.item_name || 'Item';
      img.onerror = function () { imgDiv.textContent = '🛍️'; };
      imgDiv.appendChild(img);
    } else {
      imgDiv.textContent = '🛍️';
    }
    prod.appendChild(imgDiv);
    var info = document.createElement('div');
    info.className = 'cvw-exinfo';
    info.innerHTML = '<p>' + (order.item_name || ('Order #' + order.order_number)) + '</p><span>Order #' + order.order_number + '</span>';
    prod.appendChild(info);
    box.appendChild(prod);

    // Size label
    var lbl = document.createElement('div');
    lbl.className = 'cvw-exlabel';
    lbl.textContent = 'Select New Size:';
    box.appendChild(lbl);

    // Size buttons
    var sizeRow = document.createElement('div');
    sizeRow.className = 'cvw-sizes';
    var selectedSize = null;
    var submitBtn;
    COMMON_SIZES.forEach(function (sz) {
      var sBtn = document.createElement('button');
      sBtn.className = 'cvw-size';
      sBtn.textContent = sz;
      sBtn.addEventListener('click', function () {
        sizeRow.querySelectorAll('.cvw-size').forEach(function (b) { b.classList.remove('sel'); });
        sBtn.classList.add('sel');
        selectedSize = sz;
        if (submitBtn) { submitBtn.className = 'cvw-exsubmit rdy'; }
      });
      sizeRow.appendChild(sBtn);
    });
    box.appendChild(sizeRow);

    // Submit button
    submitBtn = document.createElement('button');
    submitBtn.className = 'cvw-exsubmit';
    submitBtn.textContent = '🔄 Request Exchange';
    submitBtn.addEventListener('click', function () {
      if (!selectedSize) return;
      box.remove();
      addBubble('v', 'Exchange to size: ' + selectedSize);
      submitReturnRequest({
        order: order,
        type: 'exchange',
        reason: 'Exchange request — new size: ' + selectedSize,
        exchangeSize: selectedSize,
      });
    });
    box.appendChild(submitBtn);

    body.appendChild(box);
    scrl();
  }

  function startReturnFlow(order, type) {
    S.returnFlow = { active: true, step: 0, order: order, type: type, reason: '' };
    var label = type === 'return' ? 'Return' : 'Refund';
    addBubble('b', 'I\'ll help you with a ' + label + ' for Order #' + order.order_number + '. Could you briefly tell us the reason?');
    var inp = q('#cvw-inp');
    if (inp) { inp.placeholder = 'Reason for ' + label.toLowerCase() + '...'; inp.focus(); }
  }

  function handleReturnInput(msg) {
    var rf = S.returnFlow;
    if (!rf.active) return false;
    if (rf.step === 0) {
      rf.reason = msg;
      rf.step = 1;
      addBubble('v', msg);
      // Confirm
      addBubble('b', 'Got it! To confirm — you want to ' + rf.type + ' Order #' + rf.order.order_number + '. Reason: "' + msg + '". Shall I submit this request?');
      var body = q('#cvw-body');
      var confirmWrap = document.createElement('div');
      confirmWrap.style.cssText = 'display:flex;gap:8px;padding:4px 0 8px;flex-wrap:wrap';
      var yes = document.createElement('button');
      yes.className = 'cqb';
      yes.textContent = '✅ Yes, Submit';
      yes.addEventListener('click', function () {
        confirmWrap.remove();
        submitReturnRequest(rf);
      });
      var no = document.createElement('button');
      no.className = 'cvw-skip';
      no.textContent = '❌ Cancel';
      no.addEventListener('click', function () {
        confirmWrap.remove();
        S.returnFlow = { active: false, step: 0, order: null, type: null, reason: '' };
        addBubble('b', 'No problem! Your ' + rf.type + ' request has been cancelled.');
        var i = q('#cvw-inp'); if (i) i.placeholder = 'Type a message...';
      });
      confirmWrap.appendChild(yes);
      confirmWrap.appendChild(no);
      if (body) body.appendChild(confirmWrap);
      scrl();
      return true;
    }
    return true;
  }

  function submitReturnRequest(rf) {
    showTyping();
    post('/api/v1/merchant-chat/submit-return', {
      api_key: API_KEY,
      session_id: S.sessionId || null,
      order_number: rf.order.order_number,
      request_type: rf.type,
      reason: rf.reason,
      exchange_size: rf.exchangeSize || null,
      customer_email: S.customerEmail || null,
      customer_name: rf.order.customer_name || null,
    }, function (err, res) {
      removeTyping();
      S.returnFlow = { active: false, step: 0, order: null, type: null, reason: '' };
      var i = q('#cvw-inp'); if (i) i.placeholder = 'Type a message...';
      if (err || !res || !res.success) {
        addBubble('b', '❌ Something went wrong. Please try again or contact support.');
        return;
      }
      var msg = (res.data && res.data.message) ? res.data.message : 'Your request has been submitted!';
      addBubble('b', '✅ ' + msg);
      addBubble('b', 'Your request has been logged. Our team will review and respond within 1–2 business days.');
    });
  }

  function fetchProductsByCategory(cat) {
    // Prevent double-fetch
    if (S.productFetching) return;
    S.productFetching = true;

    // Show shimmer loading cards
    var body = q('#cvw-body');
    // Section header shimmer
    var hdrShim = document.createElement('div');
    hdrShim.className = 'cvw-pc-header';
    hdrShim.innerHTML = '<span></span>⏳ Loading... <span></span>';
    if (body) body.appendChild(hdrShim);

    var shimWrap = document.createElement('div');
    shimWrap.className = 'cvw-pcwrap';
    var shimRail = document.createElement('div');
    shimRail.className = 'cvw-pc';
    for (var i = 0; i < 4; i++) {
      var sc = document.createElement('div');
      sc.className = 'cvw-pcard-shimmer';
      sc.innerHTML = '<div class="cvw-pshim-img"></div><div class="cvw-pshim-body"><div class="cvw-pshim-line"></div><div class="cvw-pshim-line s"></div><div class="cvw-pshim-btn"></div></div>';
      shimRail.appendChild(sc);
    }
    shimWrap.appendChild(shimRail);
    if (body) body.appendChild(shimWrap);
    scrl();

    var url = API_BASE + '/api/v1/merchant-chat/products?api_key=' + encodeURIComponent(API_KEY);
    if (cat) url += '&category=' + encodeURIComponent(cat);
    fetch(url).then(function (r) { return r.json(); }).then(function (res) {
      hdrShim.remove();
      shimWrap.remove();
      S.productFetching = false;
      if (res && res.success && res.data && res.data.products && res.data.products.length) {
        showProductCarousel(res.data.products, null);
      } else {
        var storeUrl = res && res.data && res.data.store_url;
        if (storeUrl) {
          addBubble('a', 'Our product catalog is still being set up. You can browse our full collection here:');
          var link = document.createElement('a');
          link.href = storeUrl;
          link.target = '_blank';
          link.rel = 'noopener';
          link.className = 'cqb';
          link.style.cssText = 'display:inline-block;margin:6px 0;text-decoration:none';
          link.textContent = '🛍️ Visit Our Store';
          var body2 = q('#cvw-body');
          if (body2) { body2.appendChild(link); scrl(); }
        } else {
          addBubble('a', 'Sorry, no products found right now. Please check back later or contact us!');
        }
      }
    }).catch(function () {
      hdrShim.remove();
      shimWrap.remove();
      S.productFetching = false;
      addBubble('a', 'Could not load products right now. Please try again.');
    });

  }

  function handleProductSignal(aiText) {
    if (!aiText) return false;

    var hasShow = aiText.indexOf('[SHOW_PRODUCTS]') !== -1;
    var catMatch = aiText.match(/\[ASK_CATEGORY:([^\]]*)\]/);

    if (!hasShow && !catMatch) return false;

    // ── Dedup guard: ignore if we fired in the last 5 seconds ──
    var now = Date.now();
    if (now - S.lastProductSignal < 5000) return true; // swallow signal, don't show carousel again
    S.lastProductSignal = now;

    if (hasShow) {
      var cleanText = aiText.replace(/\[SHOW_PRODUCTS\]/, '').replace(/\[CATS:[^\]]*\]/, '').trim();
      if (cleanText) addBubble('a', cleanText);
      fetchProductsByCategory(null);
      return true;
    }

    if (catMatch) {
      var introText = aiText.replace(/\[ASK_CATEGORY:[^\]]*\]/, '').trim();
      var cats = catMatch[1].split(',').map(function (c) { return c.trim(); }).filter(Boolean);
      showCategoryChips(cats, introText);
      return true;
    }

    return false;
  }

  // ── Anonymous Return/Refund flow ────────────────────────────────────────────
  var RETURN_KEYWORDS = [
    'return', 'refund', 'wapas', 'vapas', 'cancel', 'exchange', 'replace',
    'return karna', 'refund chahiye', 'wapas karo', 'order wapas',
    'return request', 'refund request', 'paise wapas', 'money back',
  ];

  function _isReturnIntent(msg) {
    var m = msg.toLowerCase();
    return RETURN_KEYWORDS.some(function (kw) { return m.indexOf(kw) !== -1; });
  }

  function showReturnEmailBox() {
    var body = q('#cvw-body');
    if (!body) return;

    addBubble('a', 'Sure! To find your orders, I need your registered email address.');

    var box = document.createElement('div');
    box.className = 'cvw-email-box';
    box.id = 'cvw-retbox';

    var hint = document.createElement('p');
    hint.textContent = 'Enter the email address you used when placing the order:';
    box.appendChild(hint);

    var inp = document.createElement('input');
    inp.type = 'email';
    inp.className = 'cvw-email-inp';
    inp.placeholder = 'yourname@example.com';
    inp.autocomplete = 'email';
    box.appendChild(inp);

    var btn = document.createElement('button');
    btn.className = 'cvw-email-fetch';
    btn.textContent = '🔍 Find My Orders';
    btn.addEventListener('click', function () {
      var email = (inp.value || '').trim().toLowerCase();
      if (!email || email.indexOf('@') === -1) {
        inp.style.borderColor = '#ef4444';
        inp.placeholder = 'Please enter a valid email';
        return;
      }
      btn.disabled = true;
      btn.textContent = 'Searching...';
      box.remove();
      addBubble('v', email);
      S.customerEmail = email;
      loadOrdersByEmail(email);
    });
    // Also allow Enter key
    inp.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { btn.click(); }
    });
    box.appendChild(btn);

    body.appendChild(box);
    scrl();
    setTimeout(function () { inp.focus(); }, 100);
  }

  function loadOrdersByEmail(email) {
    showTyping();
    var url = API_BASE + '/api/v1/merchant-chat/recent-orders?api_key='
      + encodeURIComponent(API_KEY) + '&email=' + encodeURIComponent(email);
    fetch(url)
      .then(function (r) { return r.json(); })
      .then(function (res) {
        removeTyping();
        if (!res || !res.success || !res.data || !res.data.orders || !res.data.orders.length) {
          addBubble('a', 'I couldn\'t find any orders linked to ' + email + '. Please double-check your email or contact support.');
          return;
        }
        addBubble('a', 'Found ' + res.data.orders.length + ' order(s) for your account. Select an order below to proceed:');
        showOrderList(res.data.orders);
      })
      .catch(function () {
        removeTyping();
        addBubble('a', 'Something went wrong. Please try again or contact support.');
      });
  }

  function sendMsg(msg) {
    addBubble('v', msg);

    // ── Anonymous return/refund intent — show email box instead of AI ──
    if (!S.loggedIn && _isReturnIntent(msg)) {
      setTimeout(showReturnEmailBox, 500);
      // Still start a session silently so session_id is available
      if (!S.sessionId) startSession(msg, true);
      return;
    }

    if (!S.sessionId) {
      startSession(msg, false);
      return;
    }

    showTyping();
    post('/api/v1/merchant-chat/message/' + S.sessionId, {
      api_key: API_KEY,
      message: msg,
    }, function (err, res) {
      removeTyping();
      if (err || !res || !res.success) return;
      var d = res.data;
      if (d.ai_response) {
        if (!handleProductSignal(d.ai_response)) {
          addBubble('a', d.ai_response);
        }
      }
      if (d.handoff_requested || d.status === 'waiting_human') {
        if (!isWithinWorkingHours()) {
          showOffHoursMessage();
          return;
        }
        sys('🔔 Connecting you with a support agent...');
        S.status = 'waiting_human';
        S.waitingSince = Date.now();
        S.timeoutFired = false;
        startPoll();
      }
    });
  }

  // ── Start session ────────────────────────────────────────────────────────────
  function startSession(msg, silent) {
    if (S.tier === 'chatbot_basic' && !isWithinWorkingHours()) {
      removeTyping();
      S.status = 'offline';
      updStatus('away');
      showOffHoursMessage();
      return;
    }

    showTyping();
    post('/api/v1/merchant-chat/start', {
      api_key: API_KEY,
      visitor_name: 'Visitor',
      visitor_email: null,
      message: msg,
      page_url: window.location.href,
      page_title: document.title || '',
    }, function (err, res) {
      removeTyping();

      if (err || !res) {
        if (!silent) sys('Connection error. Please try again.');
        return;
      }

      if (!res.success) {
        var d = res.data || {};
        if (d.no_workers_available) {
          S.status = 'offline';
          updStatus('offline');
          sys(d.offline_message || 'Our team is currently unavailable.');
          setTimeout(function () { startCallbackFlow(); }, 600);
        } else {
          if (!silent) sys(res.detail || 'Unable to connect. Please try again.');
        }
        return;
      }

      var data = res.data;

      if (data.no_workers_available) {
        S.status = 'offline';
        updStatus('offline');
        sys(data.offline_message || 'Our team is not available right now.');
        setTimeout(function () { startCallbackFlow(); }, 600);
        return;
      }

      S.sessionId = data.session_id;
      S.status = data.status || 'ai_active';

      if (data.ai_response) {
        if (!handleProductSignal(data.ai_response)) {
          addBubble('a', data.ai_response);
        }
      }

      if (data.handoff_requested || data.status === 'waiting_human') {
        sys('🔔 Connecting you with a support agent...');
        S.waitingSince = Date.now();
        S.timeoutFired = false;
        startPoll();
      }
    });
  }

  // ── Polling ──────────────────────────────────────────────────────────────────
  function startPoll() {
    if (S.pollTimer) return;
    S.pollTimer = setInterval(poll, 3000);
  }
  function stopPoll() {
    if (S.pollTimer) clearInterval(S.pollTimer);
    S.pollTimer = null;
  }
  function poll() {
    if (!S.sessionId) return;

    if (S.status === 'waiting_human' && !S.timeoutFired && S.waitingSince) {
      var elapsed = (Date.now() - S.waitingSince) / 1000;
      if (elapsed >= 50) {
        S.timeoutFired = true;
        stopPoll();
        sys('⏳ No agent joined in time.');
        addBubble('b', 'It seems all our support agents are currently busy. You can request a callback and our team will contact you shortly! 📞');
        var body = q('#cvw-body');
        if (body) {
          var cbBtn = document.createElement('button');
          cbBtn.className = 'cqb';
          cbBtn.style.cssText = 'margin:6px 0;padding:10px 20px;font-size:13px;font-weight:600;background:linear-gradient(135deg,#6366f1,#7c3aed);color:#fff;border:none;border-radius:22px;cursor:pointer;width:auto;transition:all .2s;box-shadow:0 4px 14px rgba(99,102,241,.4)';
          cbBtn.innerHTML = '📞 Request a Callback';
          cbBtn.addEventListener('click', function () {
            cbBtn.remove();
            startCallbackFlow();
          });
          body.appendChild(cbBtn);
          scrl();
        }
        return;
      }
    }

    get('/api/v1/merchant-chat/messages/' + S.sessionId + '?api_key=' + encodeURIComponent(API_KEY), function (err, res) {
      if (err || !res || !res.success) return;
      var d = res.data;
      var msgs = d.messages || [];

      if (msgs.length > S.msgCount) {
        msgs.slice(S.msgCount).forEach(function (m) {
          if (m.sender_type === 'worker') addBubble('w', m.message, d.worker_name || 'Agent');
          else if (m.sender_type === 'system') sys(m.message);
        });
        S.msgCount = msgs.length;
        if (!S.open) { q('#cvw-badge').style.display = 'flex'; }
      }

      if (d.session_status === 'human_active') {
        S.status = 'human_active';
        S.waitingSince = null;
        S.timeoutFired = false;
        updStatus('agent');
        stopPoll();
        startPoll();
      } else if (d.session_status === 'closed') {
        sys('👋 Chat ended. Thank you for reaching out!');
        stopPoll();
        S.sessionId = null;
      }
    });
  }

  // ── Bootstrap ────────────────────────────────────────────────────────────────
  function bootstrap() {
    get('/api/v1/merchant-chat/config/' + encodeURIComponent(API_KEY), function (err, res) {
      if (err || !res || !res.success) {
        console.warn('[CODVerify] Failed to load chatbot config:', err);
        return;
      }
      S.config = res.data;
      build(res.data);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootstrap);
  } else {
    bootstrap();
  }

})();