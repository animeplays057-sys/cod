/**
 * CODVerify Chatbot Widget v5.1 â€” Bug Fixes
 * Conversational callback flow + premium message design.
 *
 * Usage:
 *   <script src="https://api.codverify.tech/static/chatbot-widget.js?v=5"
 *           data-codverify-key="ck_YOUR_KEY"
 *           data-codverify-api="https://api.codverify.tech"></script>
 */
(function () {
  'use strict';

  var script = document.currentScript || (function () {
    var s = document.getElementsByTagName('script');
    return s[s.length - 1];
  })();
  var API_KEY  = (script.getAttribute('data-codverify-key')  || '').trim();
  var API_BASE = (script.getAttribute('data-codverify-api')  || 'https://api.codverify.tech').replace(/\/$/, '');

  if (!API_KEY) { console.warn('[CODVerify] data-codverify-key is required'); return; }

  // â”€â”€ State â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  var S = {
    open:      false,
    inited:    false,
    sessionId: null,
    status:    'idle',
    tier:      'chatbot_basic',
    config:    null,
    pollTimer: null,
    msgCount:  0,
    waitingSince: null,
    timeoutFired: false,
    cb: {
      active: false,
      step:   0,
      data:   {},
    },
    botName:   'Support',
    botIni:    'SB',
    botAvatar: '',
  };

  // â”€â”€ Network â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function get(path, cb) {
    fetch(API_BASE + path, { headers: { 'Content-Type': 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (d) { cb(null, d); })
      .catch(function (e) { cb(e, null); });
  }
  function post(path, body, cb) {
    fetch(API_BASE + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).then(function (r) { return r.json(); })
      .then(function (d) { cb(null, d); })
      .catch(function (e) { cb(e, null); });
  }

  // â”€â”€ CSS â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function buildCSS(c, theme, fontFamily) {
    var grad    = 'linear-gradient(135deg,' + c + ' 0%,#7c3aed 100%)';
    var isDark  = (theme !== 'light');
    var font    = fontFamily || 'Inter';

    // ── Window
    var winBg   = isDark ? '#060b18'        : '#ffffff';
    var winBor  = isDark ? 'rgba(255,255,255,.08)' : 'rgba(99,102,241,.12)';
    var winShad = isDark
      ? '0 40px 120px rgba(0,0,0,.95),0 0 0 1px rgba(255,255,255,.07),0 0 60px -10px ' + c
      : '0 32px 80px rgba(99,102,241,.18),0 8px 32px rgba(0,0,0,.08),0 0 0 1px rgba(99,102,241,.08)';

    // ── Body bg
    var bodyBg  = isDark
      ? 'radial-gradient(ellipse 80% 60% at 50% 0%,#0d1a3a 0%,#060b18 60%)'
      : 'radial-gradient(ellipse 80% 60% at 50% 0%,#ede9ff 0%,#f5f3ff 40%,#ffffff 100%)';
    var scrollT = isDark ? 'rgba(255,255,255,.1)'  : 'rgba(99,102,241,.2)';
    var sLblClr = isDark ? 'rgba(255,255,255,.35)' : 'rgba(80,80,120,.5)';
    var tsClr   = isDark ? 'rgba(255,255,255,.25)' : 'rgba(99,102,241,.4)';

    // ── Bot / AI bubbles
    var bBubBg  = isDark
      ? 'linear-gradient(150deg,#131d3a 0%,#0d1529 100%)'
      : 'linear-gradient(150deg,#ffffff 0%,#f8f7ff 100%)';
    var bBubClr = isDark ? 'rgba(255,255,255,.92)' : '#1e1b4b';
    var bBubBor = isDark
      ? '1px solid rgba(255,255,255,.09)'
      : '1px solid rgba(139,92,246,.18)';
    var bBubShd = isDark
      ? '0 4px 28px rgba(0,0,0,.6),inset 0 1px 0 rgba(255,255,255,.06)'
      : '0 4px 24px rgba(99,102,241,.12),0 1px 4px rgba(0,0,0,.04)';
    var aBubBg  = bBubBg;
    var aBubBor = bBubBor;

    // ── Worker bubbles
    var wBubBg  = isDark ? 'linear-gradient(150deg,#0f2820,#08180f)' : '#f0fdf4';
    var wBubClr = isDark ? '#34d399' : '#166534';
    var wBubBor = isDark ? '1px solid rgba(52,211,153,.25)' : '1px solid #86efac';

    // ── Visitor bubble shadow
    var vBubShd = '0 6px 30px rgba(99,102,241,.5),0 2px 10px rgba(0,0,0,.15)';

    // ── System msgs
    var sysClr  = isDark ? 'rgba(255,255,255,.3)' : 'rgba(99,102,241,.55)';
    var sysBg   = isDark ? 'rgba(255,255,255,.05)' : 'rgba(99,102,241,.06)';

    // ── Typing indicator
    var typBg   = isDark ? 'linear-gradient(150deg,#131d3a,#0d1529)' : '#ffffff';
    var typBor  = isDark ? '1px solid rgba(255,255,255,.09)' : '1px solid rgba(139,92,246,.18)';
    var typDot  = c;

    // ── Quick buttons
    var qBg     = isDark ? 'rgba(255,255,255,.07)' : 'rgba(255,255,255,.9)';
    var qBor    = isDark ? '1.5px solid rgba(255,255,255,.13)' : '1.5px solid rgba(139,92,246,.25)';
    var qClr    = isDark ? 'rgba(255,255,255,.82)'  : '#4c1d95';

    // ── Input
    var footBg  = isDark ? '#060b18' : '#faf9ff';
    var footBor = isDark ? '1px solid rgba(255,255,255,.07)' : '1px solid rgba(99,102,241,.12)';
    var inpBg   = isDark ? '#0d1529' : '#ffffff';
    var inpBor  = isDark ? '1.5px solid rgba(255,255,255,.1)' : '1.5px solid rgba(99,102,241,.2)';
    var inpClr  = isDark ? 'rgba(255,255,255,.92)' : '#1e1b4b';
    var inpPh   = isDark ? 'rgba(255,255,255,.28)' : 'rgba(99,102,241,.4)';

    // ── Callback strip
    var cbbGrad = grad;
    var cbbClr  = '#ffffff';

    // ── Branding
    var brdBg   = isDark ? 'rgba(255,255,255,.02)' : 'rgba(99,102,241,.04)';
    var brdBor  = isDark ? '1px solid rgba(255,255,255,.05)' : '1px solid rgba(99,102,241,.1)';
    var brdClr  = isDark ? 'rgba(255,255,255,.22)'  : 'rgba(99,102,241,.45)';
    var brdLink = isDark ? 'rgba(255,255,255,.6)'   : c;

    // ── Message avatar
    var avMsgBg = isDark ? 'rgba(255,255,255,.1)' : 'rgba(99,102,241,.12)';
    var avMsgCl = isDark ? '#fff' : c;

    // ── Premium computed values ───────────────────────────────────────────────
    var cRgb = c;  // primary color hex
    // Extract approximate RGB for rgba() usage — use the primary color as glow source
    var glowA = c + '55';   // 33% alpha
    var glowB = c + '33';   // 20% alpha
    var glowC = c + '18';   // ~10% alpha
    var glowD = c + 'aa';   // 67% alpha

    // Window
    var winBg   = isDark
      ? 'linear-gradient(160deg,#0b0f1e 0%,#080b17 50%,#07091a 100%)'
      : 'linear-gradient(160deg,#fafbff 0%,#f4f3ff 50%,#ffffff 100%)';
    var winBor  = isDark ? 'rgba(255,255,255,.06)' : 'rgba(139,92,246,.14)';
    var winShad = isDark
      ? '0 32px 100px rgba(0,0,0,.9),0 0 0 1px rgba(255,255,255,.055),0 0 80px -20px ' + c + ',0 0 40px -30px ' + c
      : '0 32px 80px rgba(99,102,241,.14),0 0 0 1px rgba(139,92,246,.12),0 8px 32px rgba(0,0,0,.06)';

    // Body
    var bodyBg  = isDark
      ? 'radial-gradient(ellipse 90% 70% at 50% -10%,' + glowC + ' 0%,transparent 55%),linear-gradient(180deg,#0b0f1e 0%,#080b17 100%)'
      : 'radial-gradient(ellipse 90% 70% at 50% -10%,rgba(139,92,246,.08) 0%,transparent 60%),linear-gradient(180deg,#f9f8ff 0%,#ffffff 100%)';
    var scrollT = isDark ? glowA : 'rgba(139,92,246,.3)';
    var sLblClr = isDark ? 'rgba(255,255,255,.3)' : 'rgba(80,60,140,.45)';
    var tsClr   = isDark ? 'rgba(255,255,255,.2)' : 'rgba(99,102,241,.35)';

    // Bot bubbles — glassmorphism with colored left accent bar
    var bBubBg  = isDark
      ? 'linear-gradient(140deg,rgba(255,255,255,.045) 0%,rgba(255,255,255,.02) 100%)'
      : 'linear-gradient(140deg,rgba(255,255,255,.98) 0%,rgba(248,246,255,.95) 100%)';
    var bBubClr = isDark ? 'rgba(255,255,255,.9)' : '#1a133d';
    var bBubBor = isDark ? '1px solid rgba(255,255,255,.07)' : '1px solid rgba(139,92,246,.12)';
    var bBubShd = isDark
      ? '0 4px 32px rgba(0,0,0,.55),inset 0 1px 0 rgba(255,255,255,.07),0 0 0 1.5px ' + glowC
      : '0 4px 24px rgba(139,92,246,.1),0 1px 4px rgba(0,0,0,.04),inset 0 1px 0 rgba(255,255,255,.9)';

    // Worker bubbles
    var wBubBg  = isDark ? 'linear-gradient(140deg,rgba(52,211,153,.08),rgba(16,185,129,.04))' : '#f0fdf6';
    var wBubClr = isDark ? '#4ade80' : '#166534';
    var wBubBor = isDark ? '1px solid rgba(74,222,128,.18)' : '1px solid #86efac';

    // User bubble — rich gradient
    var vBubShd = '0 8px 32px ' + glowA + ',0 2px 12px rgba(0,0,0,.18)';

    // System
    var sysClr  = isDark ? 'rgba(255,255,255,.28)' : 'rgba(99,102,241,.5)';
    var sysBg   = isDark ? 'rgba(255,255,255,.04)' : 'rgba(99,102,241,.05)';

    // Typing
    var typBg   = isDark ? 'linear-gradient(140deg,rgba(255,255,255,.045),rgba(255,255,255,.02))' : 'rgba(255,255,255,.95)';
    var typBor  = isDark ? '1px solid rgba(255,255,255,.07)' : '1px solid rgba(139,92,246,.12)';

    // Quick buttons
    var qBg     = isDark ? 'rgba(255,255,255,.055)' : 'rgba(255,255,255,.92)';
    var qBor    = isDark ? '1.5px solid rgba(255,255,255,.1)' : '1.5px solid rgba(139,92,246,.22)';
    var qClr    = isDark ? 'rgba(255,255,255,.85)' : '#4c1d95';

    // Input bar
    var footBg  = isDark ? 'rgba(7,9,26,.98)' : 'rgba(249,248,255,.98)';
    var footBor = isDark ? '1px solid rgba(255,255,255,.055)' : '1px solid rgba(139,92,246,.1)';
    var inpBg   = isDark ? 'rgba(255,255,255,.04)' : '#ffffff';
    var inpBor  = isDark ? '1.5px solid rgba(255,255,255,.08)' : '1.5px solid rgba(139,92,246,.18)';
    var inpClr  = isDark ? 'rgba(255,255,255,.9)' : '#1a133d';
    var inpPh   = isDark ? 'rgba(255,255,255,.22)' : 'rgba(99,102,241,.35)';

    // Branding
    var brdBg   = isDark ? 'rgba(255,255,255,.015)' : 'rgba(99,102,241,.03)';
    var brdBor  = isDark ? '1px solid rgba(255,255,255,.04)' : '1px solid rgba(99,102,241,.08)';
    var brdClr  = isDark ? 'rgba(255,255,255,.18)' : 'rgba(99,102,241,.4)';
    var brdLink = isDark ? 'rgba(255,255,255,.55)' : c;

    // Message avatar
    var avMsgBg = isDark ? 'rgba(255,255,255,.06)' : 'rgba(139,92,246,.1)';
    var avMsgCl = isDark ? 'rgba(255,255,255,.9)' : c;

    return [
      '#cvw *{box-sizing:border-box;font-family:"' + font + '",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;margin:0;padding:0;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility}',

      // ── Launcher button ─────────────────────────────────────────────────────
      '#cvw-btn{position:fixed;bottom:28px;right:28px;z-index:2147483646;width:64px;height:64px;border-radius:50%;background:' + grad + ';box-shadow:0 8px 32px ' + glowD + ',0 3px 10px rgba(0,0,0,.35),inset 0 1px 0 rgba(255,255,255,.3);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:transform .28s cubic-bezier(.34,1.56,.64,1),box-shadow .28s}',
      '#cvw-btn::after{content:"";position:absolute;inset:-4px;border-radius:50%;background:' + grad + ';opacity:.18;filter:blur(10px);z-index:-1;animation:cvwglow 3s ease-in-out infinite}',
      '@keyframes cvwglow{0%,100%{opacity:.18;transform:scale(1)}50%{opacity:.35;transform:scale(1.12)}}',
      '#cvw-btn:hover{transform:scale(1.1) translateY(-3px);box-shadow:0 16px 48px ' + glowD + ',0 4px 14px rgba(0,0,0,.35)}',
      '#cvw-btn svg{width:28px;height:28px;fill:#fff;position:relative;z-index:1;filter:drop-shadow(0 2px 4px rgba(0,0,0,.3))}',
      '#cvw-badge{position:absolute;top:-3px;right:-3px;background:linear-gradient(135deg,#f43f5e,#e11d48);color:#fff;font-size:10px;font-weight:700;min-width:20px;height:20px;border-radius:10px;padding:0 5px;display:none;align-items:center;justify-content:center;pointer-events:none;box-shadow:0 2px 10px rgba(244,63,94,.55);border:2px solid rgba(0,0,0,.15)}',
      // Pulsing ring around button
      '#cvw-btn::before{content:"";position:absolute;inset:-8px;border-radius:50%;border:1.5px solid ' + c + ';opacity:.3;animation:cvwring 3s ease-out infinite}',
      '@keyframes cvwring{0%{transform:scale(1);opacity:.4}80%{transform:scale(1.5);opacity:0}100%{transform:scale(1.5);opacity:0}}',

      // ── Chat window ─────────────────────────────────────────────────────────
      '#cvw-win{position:fixed;bottom:110px;right:28px;z-index:2147483645;width:392px;height:640px;border-radius:28px;background:' + winBg + ';border:1px solid ' + winBor + ';box-shadow:' + winShad + ';display:flex;flex-direction:column;overflow:hidden;transform:translateY(36px) scale(.86);transform-origin:bottom right;opacity:0;pointer-events:none;transition:transform .42s cubic-bezier(.34,1.44,.64,1),opacity .32s ease;backdrop-filter:blur(2px)}',
      '#cvw-win.on{transform:translateY(0) scale(1);opacity:1;pointer-events:all}',
      // Animated glow border accent at top
      '#cvw-win::before{content:"";position:absolute;top:0;left:0;right:0;height:2px;background:' + grad + ';z-index:10;border-radius:28px 28px 0 0}',

      // ── Header ──────────────────────────────────────────────────────────────
      '#cvw-head{background:' + grad + ';padding:16px 18px 14px;display:flex;align-items:center;gap:14px;flex-shrink:0;position:relative;overflow:hidden}',
      // Shimmer sweep animation
      '#cvw-head::before{content:"";position:absolute;top:0;left:-100%;width:60%;height:100%;background:linear-gradient(90deg,transparent,rgba(255,255,255,.18),transparent);animation:cvwshimmer 4s ease-in-out infinite;pointer-events:none}',
      '@keyframes cvwshimmer{0%{left:-100%}60%,100%{left:150%}}',
      // Subtle noise/texture overlay
      '#cvw-head::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(255,255,255,.12) 0%,rgba(255,255,255,.03) 60%,transparent 100%);pointer-events:none}',

      // Avatar — circular with glow ring
      '#cvw-av{width:46px;height:46px;border-radius:50%;background:rgba(255,255,255,.2);backdrop-filter:blur(16px);border:2px solid rgba(255,255,255,.4);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:14px;color:#fff;flex-shrink:0;box-shadow:0 0 0 3px rgba(255,255,255,.15),0 6px 20px rgba(0,0,0,.3);position:relative;z-index:1;overflow:hidden}',
      '#cvw-hi{flex:1;min-width:0;position:relative;z-index:1}',
      '#cvw-hn{font-size:15px;font-weight:700;color:#fff;letter-spacing:-.02em;line-height:1.2;text-shadow:0 1px 4px rgba(0,0,0,.2)}',
      '#cvw-hs{font-size:11px;color:rgba(255,255,255,.85);display:flex;align-items:center;gap:5px;margin-top:3px;font-weight:500;letter-spacing:.01em}',
      '.cvw-dot{width:6px;height:6px;border-radius:50%;background:#4ade80;flex-shrink:0;box-shadow:0 0 0 3px rgba(74,222,128,.3);animation:cvwpulse 2.5s ease-in-out infinite}',
      '@keyframes cvwpulse{0%,100%{box-shadow:0 0 0 3px rgba(74,222,128,.25)}50%{box-shadow:0 0 0 7px rgba(74,222,128,.06)}}',
      '#cvw-x{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);backdrop-filter:blur(8px);cursor:pointer;padding:8px;border-radius:12px;display:flex;flex-shrink:0;transition:background .2s,transform .22s;margin-left:auto;position:relative;z-index:1}',
      '#cvw-x:hover{background:rgba(255,255,255,.26);transform:scale(1.08) rotate(90deg)}',

      // ── Message body ─────────────────────────────────────────────────────────
      '#cvw-body{flex:1;overflow-y:auto;padding:20px 14px 12px;display:flex;flex-direction:column;gap:2px;scroll-behavior:smooth;background:' + bodyBg + '}',
      '#cvw-body::-webkit-scrollbar{width:3px}',
      '#cvw-body::-webkit-scrollbar-track{background:transparent}',
      '#cvw-body::-webkit-scrollbar-thumb{background:' + scrollT + ';border-radius:6px}',

      // Message row animation
      '.cw{display:flex;flex-direction:column;align-items:flex-start;margin-bottom:10px;width:100%;animation:cvwfade .38s cubic-bezier(.22,1,.36,1)}',
      '@keyframes cvwfade{from{opacity:0;transform:translateY(20px) scale(.95)}to{opacity:1;transform:translateY(0) scale(1)}}',
      '.cw.r{align-items:flex-end}',
      '.cw-row{display:inline-flex;align-items:flex-end;gap:9px;max-width:80%;vertical-align:bottom}',
      '.cw.r .cw-row{flex-direction:row-reverse}',

      // Mini avatar icon beside bubbles
      '.cmav{width:28px;height:28px;border-radius:50%;background:' + avMsgBg + ';border:1px solid ' + (isDark ? 'rgba(255,255,255,.08)' : 'rgba(139,92,246,.15)') + ';display:flex;align-items:center;justify-content:center;font-weight:700;font-size:9px;color:' + avMsgCl + ';flex-shrink:0;margin-bottom:2px;box-shadow:0 2px 10px rgba(0,0,0,.12);overflow:hidden}',
      '.cw.r .cmav{display:none}',

      '.cs{font-size:10px;color:' + sLblClr + ';padding:0 4px;font-weight:600;margin-bottom:4px;letter-spacing:.06em;text-transform:uppercase}',
      '.cw.r .cs{text-align:right}',

      // ── Bubble base
      '.cm{display:block;max-width:100%;padding:11px 15px;border-radius:20px;font-size:13.5px;line-height:1.7;word-break:break-word;overflow-wrap:break-word;white-space:normal;font-weight:400;position:relative;min-width:44px}',

      // Bot bubble — glassmorphism + colored left accent bar
      '.cm.b{background:' + bBubBg + ';color:' + bBubClr + ';border:' + bBubBor + ';border-left:3px solid ' + c + ';border-bottom-left-radius:6px;box-shadow:' + bBubShd + ';backdrop-filter:blur(12px)}',

      // AI bubble same as bot
      '.cm.a{background:' + bBubBg + ';color:' + bBubClr + ';border:' + bBubBor + ';border-left:3px solid ' + c + ';border-bottom-left-radius:6px;box-shadow:' + bBubShd + ';backdrop-filter:blur(12px)}',

      // Worker bubble
      '.cm.w{background:' + wBubBg + ';color:' + wBubClr + ';border:' + wBubBor + ';border-left:3px solid #4ade80;border-bottom-left-radius:6px;backdrop-filter:blur(8px)}',

      // User bubble — vivid gradient
      '.cm.v{background:' + grad + ';color:#fff;border-bottom-right-radius:6px;box-shadow:' + vBubShd + ';font-weight:500;letter-spacing:.01em}',

      // System message
      '.cm.s{background:' + sysBg + ';color:' + sysClr + ';font-size:11px;font-weight:500;align-self:center;text-align:center;padding:5px 18px;max-width:88%;border:none;border-radius:99px;margin:10px 0;letter-spacing:.03em;backdrop-filter:blur(8px)}',

      // Timestamp
      '.cts{font-size:10px;color:' + tsClr + ';padding:4px 5px 0;display:flex;align-items:center;gap:4px;font-weight:500}',
      '.cw.r .cts{justify-content:flex-end}',
      '.cvw-tick{display:inline-flex;align-items:center;opacity:.5}',

      // ── Typing indicator ─────────────────────────────────────────────────────
      '.ctyp{display:flex;gap:5px;align-items:center;padding:14px 18px;background:' + typBg + ';border-radius:20px;border-bottom-left-radius:6px;border-left:3px solid ' + c + ';width:max-content;border-top:' + typBor + ';border-right:' + typBor + ';border-bottom:' + typBor + ';box-shadow:' + bBubShd + ';backdrop-filter:blur(12px)}',
      '.ctyp span{width:7px;height:7px;background:' + c + ';border-radius:50%;animation:ctb 1.2s infinite ease-in-out;opacity:.4}',
      '.ctyp span:nth-child(2){animation-delay:.2s}.ctyp span:nth-child(3){animation-delay:.4s}',
      '@keyframes ctb{0%,60%,100%{transform:translateY(0);opacity:.35}30%{transform:translateY(-8px);opacity:1}}',

      // ── Quick reply buttons ───────────────────────────────────────────────────
      '.cqb{display:inline-block;margin:3px 4px 3px 0;padding:8px 16px;background:' + qBg + ';border:' + qBor + ';color:' + qClr + ';border-radius:24px;font-size:12.5px;cursor:pointer;transition:all .22s cubic-bezier(.34,1.56,.64,1);white-space:nowrap;font-weight:600;letter-spacing:.01em;backdrop-filter:blur(8px)}',
      '.cqb:hover{background:' + c + ';border-color:transparent;color:#fff;transform:translateY(-2px) scale(1.03);box-shadow:0 8px 24px ' + glowA + '}',

      // ── Footer / input bar ───────────────────────────────────────────────────
      '#cvw-foot{padding:10px 14px 14px;border-top:' + footBor + ';display:flex;gap:9px;align-items:flex-end;flex-shrink:0;background:' + footBg + ';backdrop-filter:blur(24px)}',
      '#cvw-inp{flex:1;padding:11px 16px;background:' + inpBg + ';border:' + inpBor + ';border-radius:18px;font-size:13.5px;outline:none;resize:none;max-height:80px;min-height:44px;line-height:1.6;color:' + inpClr + ';transition:border-color .22s,box-shadow .22s,background .22s;font-family:inherit;font-weight:500;backdrop-filter:blur(12px)}',
      '#cvw-inp::placeholder{color:' + inpPh + ';font-weight:400}',
      '#cvw-inp:focus{border-color:' + c + ';box-shadow:0 0 0 4px ' + glowC + ';background:' + (isDark ? 'rgba(255,255,255,.06)' : '#fff') + '}',

      // Send button
      '#cvw-snd{background:' + grad + ';border:none;border-radius:14px;width:44px;height:44px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:transform .24s cubic-bezier(.34,1.56,.64,1),box-shadow .2s;box-shadow:0 4px 20px ' + glowA + ',inset 0 1px 0 rgba(255,255,255,.25);position:relative;overflow:hidden}',
      '#cvw-snd::before{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(255,255,255,.22),transparent);border-radius:inherit}',
      '#cvw-snd:hover{transform:scale(1.1) translateY(-2px);box-shadow:0 10px 30px ' + glowD + '}',
      '#cvw-snd:active{transform:scale(.94)}',
      '#cvw-snd svg{width:19px;height:19px;fill:#fff;position:relative;filter:drop-shadow(0 1px 4px rgba(0,0,0,.3))}',

      // ── Callback strip ───────────────────────────────────────────────────────
      '#cvw-cbb{padding:0 14px 12px;flex-shrink:0;background:' + footBg + '}',
      '#cvw-cbb button{width:100%;padding:12px 18px;background:' + grad + ';border:none;border-radius:16px;font-size:13px;color:#fff;cursor:pointer;transition:transform .22s cubic-bezier(.34,1.56,.64,1),box-shadow .2s;display:flex;align-items:center;justify-content:center;gap:8px;font-family:inherit;font-weight:700;letter-spacing:.02em;box-shadow:0 6px 24px ' + glowA + ',inset 0 1px 0 rgba(255,255,255,.25)}',
      '#cvw-cbb button:hover{transform:translateY(-2px);box-shadow:0 10px 32px ' + glowD + '}',
      '#cvw-cbb button:active{transform:scale(.97)}',

      // Skip / cancel buttons
      '.cvw-skip{display:inline-block;margin:4px 5px 4px 0;padding:8px 18px;background:transparent;border:1.5px solid ' + (isDark ? 'rgba(255,255,255,.1)' : '#e2e8f0') + ';color:' + (isDark ? 'rgba(255,255,255,.45)' : '#94a3b8') + ';border-radius:22px;font-size:12.5px;cursor:pointer;transition:all .2s;font-family:inherit;font-weight:600}',
      '.cvw-skip:hover{border-color:' + c + ';color:' + c + '}',
      '.cvw-cbcancel{display:inline-block;margin:4px 5px 4px 0;padding:8px 18px;background:rgba(239,68,68,.06);border:1.5px solid rgba(239,68,68,.2);color:#f87171;border-radius:22px;font-size:12.5px;cursor:pointer;transition:all .2s;font-family:inherit;font-weight:600}',
      '.cvw-cbcancel:hover{background:rgba(239,68,68,.14)}',

      // ── Branding ─────────────────────────────────────────────────────────────
      '#cvw-brd{padding:7px 18px 8px;border-top:' + brdBor + ';background:' + brdBg + ';display:flex;align-items:center;justify-content:center;gap:5px;flex-shrink:0}',
      '#cvw-brd span{font-size:10px;color:' + brdClr + ';font-weight:500}',
      '#cvw-brd a{font-size:10px;font-weight:700;color:' + brdLink + ';text-decoration:none;transition:opacity .15s}',
      '#cvw-brd a:hover{opacity:.7}',

      '@media(max-width:420px){#cvw-win{width:calc(100vw - 12px);right:6px;border-radius:28px 28px 0 0;bottom:0;height:92dvh}#cvw-btn{bottom:24px;right:20px}}',
    ].join('\n');
  }

  // â”€â”€ Build DOM â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function build(cfg) {
    var c          = cfg.primary_color || '#6366f1';
    var nm         = cfg.bot_name      || 'Support';
    var theme      = cfg.widget_theme  || 'dark';
    var fontFamily = cfg.font_family   || 'Inter';
    var ini        = nm.split(' ').map(function (w) { return w[0] || ''; }).join('').slice(0, 2).toUpperCase();

    // Inject Google Font for chosen font family
    var fontSlug = fontFamily.replace(/ /g, '+') + ':wght@400;500;600;700';
    var existingFont = document.querySelector('link[data-cvw-font]');
    if (existingFont) existingFont.remove();
    var fontLink = document.createElement('link');
    fontLink.rel = 'stylesheet';
    fontLink.setAttribute('data-cvw-font', '1');
    fontLink.href = 'https://fonts.googleapis.com/css2?family=' + fontSlug + '&display=swap';
    document.head.appendChild(fontLink);

    // Use logo_url from config (set by Auto-Scan), or try merchant's own page favicon
    function getSiteLogo() {
      // Primary: logo saved in config via Auto-Scan
      if (cfg.logo_url) return cfg.logo_url;
      // Fallback: bot_avatar_url (legacy field name)
      if (cfg.bot_avatar_url) return cfg.bot_avatar_url;
      // Last resort: read favicon from the merchant page's own DOM
      var selectors = [
        'link[rel="apple-touch-icon"]',
        'link[rel="icon"][sizes="32x32"]',
        'link[rel="icon"][sizes="64x64"]',
        'link[rel="shortcut icon"]',
        'link[rel="icon"]',
      ];
      for (var i = 0; i < selectors.length; i++) {
        var el = document.querySelector(selectors[i]);
        if (el && el.href) return el.href;
      }
      return '';
    }
    var avatarUrl = getSiteLogo();

    S.botName = nm;
    S.botIni  = ini;
    S.botAvatar = avatarUrl;

    var style = document.createElement('style');
    style.textContent = buildCSS(c, theme, fontFamily);
    document.head.appendChild(style);

    var root = document.createElement('div');
    root.id = 'cvw';
    root.innerHTML = [
      // Launch bubble
      '<button id="cvw-btn" aria-label="Open chat">',
      '  <div id="cvw-badge">1</div>',
      '  <svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>',
      '</button>',
      // Chat window
      '<div id="cvw-win" role="dialog" aria-label="Chat support">',
      '  <div id="cvw-head">',
      '    <div id="cvw-av">' + (avatarUrl ? '<img src="' + avatarUrl + '" style="width:100%;height:100%;object-fit:cover;border-radius:inherit" onerror="this.style.display=\'none\';this.parentNode.textContent=\'' + ini + '\'">' : esc(ini)) + '</div>',
      '    <div id="cvw-hi">',
      '      <div id="cvw-hn">' + esc(nm) + '</div>',
      '      <div id="cvw-hs"><span class="cvw-dot"></span>&nbsp;Online &amp; Ready</div>',
      '    </div>',
      '    <button id="cvw-x" aria-label="Close"><svg viewBox="0 0 24 24" width="15" height="15" fill="white"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg></button>',
      '  </div>',
      '  <div id="cvw-body"></div>',
      '  <div id="cvw-cbb"><button id="cvw-cbb-btn">',
      '    <svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1-9.4 0-17-7.6-17-17 0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1L6.6 10.8z"/></svg>',
      '    Request a Callback',
      '  </button></div>',
      '  <div id="cvw-foot">',
      '    <textarea id="cvw-inp" rows="1" placeholder="Type a message..." maxlength="2000"></textarea>',
      '    <button id="cvw-snd" aria-label="Send"><svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg></button>',
      '  </div>',
      '  <div id="cvw-brd">',
      '    <span>Powered by</span>',
      '    <a href="https://codverify.tech" target="_blank" rel="noopener">âš¡ CODVerify</a>',
      '  </div>',
      '</div>',
    ].join('');
    document.body.appendChild(root);

    // Events
    q('#cvw-btn').addEventListener('click', toggle);
    q('#cvw-x').addEventListener('click', function () { setOpen(false); });
    q('#cvw-snd').addEventListener('click', onSend);
    q('#cvw-cbb-btn').addEventListener('click', startCallbackFlow);
    q('#cvw-inp').addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); onSend(); }
      autoH(this);
    });
    q('#cvw-inp').addEventListener('input', function () { autoH(this); });
  }

  // â”€â”€ Helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function q(s)     { return document.querySelector(s); }
  function esc(s)   { return (s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
  function tr(v)    { return (v || '').trim(); }
  function autoH(e) { e.style.height = 'auto'; e.style.height = Math.min(e.scrollHeight, 80) + 'px'; }
  function scrl()   { var b = q('#cvw-body'); if (b) setTimeout(function () { b.scrollTop = b.scrollHeight; }, 30); }
  function now()    { return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }

  // â”€â”€ Working Hours Check (IST = UTC+5:30, 8AMâ€“8PM) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function isWithinWorkingHours() {
    var now = new Date();
    var istOffset = 5.5 * 60; // IST is UTC+5:30 in minutes
    var utcMs = now.getTime() + now.getTimezoneOffset() * 60000;
    var istDate = new Date(utcMs + istOffset * 60000);
    var h = istDate.getHours();
    return h >= 8 && h < 20; // 8AM to 8PM IST
  }

  function showOffHoursMessage() {
    sys('â° Outside Service Hours');
    addBubble('b', 'Our support team is available Monâ€“Sat, 8AMâ€“8PM IST. Right now we are outside service hours. You can request a callback and our team will contact you during working hours! ðŸ“ž');
    var body = q('#cvw-body');
    if (body) {
      var cbBtn = document.createElement('button');
      cbBtn.className = 'cqb';
      cbBtn.style.cssText = 'margin:6px 0;padding:10px 20px;font-size:13px;font-weight:600;background:linear-gradient(135deg,#6366f1,#7c3aed);color:#fff;border:none;border-radius:22px;cursor:pointer;width:auto;transition:all .2s;box-shadow:0 4px 14px rgba(99,102,241,.4)';
      cbBtn.innerHTML = 'ðŸ“ž Request a Callback';
      cbBtn.addEventListener('click', function() {
        cbBtn.remove();
        startCallbackFlow();
      });
      body.appendChild(cbBtn);
      scrl();
    }
  }

  // â”€â”€ Open / Close â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function toggle() { setOpen(!S.open); }
  function setOpen(v) {
    S.open = v;
    var win = q('#cvw-win');
    var btn = q('#cvw-btn');
    if (v) {
      win.classList.add('on');
      q('#cvw-badge').style.display = 'none';
      if (btn) { btn.style.opacity = '0'; btn.style.pointerEvents = 'none'; btn.style.transform = 'scale(.85)'; }
      if (!S.inited) init();
      setTimeout(function () { var i = q('#cvw-inp'); if (i && !S.cb.active) i.focus(); }, 280);
    } else {
      win.classList.remove('on');
      if (btn) { btn.style.opacity = '1'; btn.style.pointerEvents = ''; btn.style.transform = ''; }
    }
  }

  // â”€â”€ Init â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function init() {
    S.inited = true;
    var cfg  = S.config;
    S.tier   = cfg.chatbot_tier || 'chatbot_basic';

    addBubble('b', cfg.welcome_message || 'Hi! ðŸ‘‹ How can I help you today?');

    // Quick-option buttons
    var opts = cfg.menu_options || [];
    if (opts.length) {
      var body = q('#cvw-body');
      var wrap = document.createElement('div');
      wrap.id = 'cvw-opts';
      wrap.style.cssText = 'display:flex;flex-wrap:wrap;gap:4px;padding:4px 0 8px';
      opts.forEach(function (o) {
        var btn = document.createElement('button');
        btn.className = 'cqb';
        btn.textContent = o.label;
        btn.addEventListener('click', function () {
          wrap.remove();
          addBubble('v', o.label);
          setTimeout(function () {
            addBubble('b', o.answer);
          }, 600);
          if (!S.sessionId) startSession(o.label, true);
        });
        wrap.appendChild(btn);
      });
      body.appendChild(wrap);
      scrl();
    }

    // Basic tier â€” check worker availability
    if (S.tier === 'chatbot_basic') {
      get('/api/v1/merchant-chat/workers-status?api_key=' + encodeURIComponent(API_KEY), function (err, res) {
        if (!err && res && res.data && !res.data.workers_online) {
          updStatus('away');
        }
      });
    }
  }

  // â”€â”€ Status helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function updStatus(k) {
    var hs = q('#cvw-hs');
    if (!hs) return;
    if (k === 'away') {
      hs.innerHTML = '<span style="width:7px;height:7px;border-radius:50%;background:#f59e0b;display:inline-block;flex-shrink:0;box-shadow:0 0 0 2px rgba(245,158,11,.2)"></span>&nbsp;Away';
    } else if (k === 'agent') {
      hs.innerHTML = '<span class="cvw-dot"></span>&nbsp;Agent connected';
    } else if (k === 'offline') {
      hs.innerHTML = '<span style="width:7px;height:7px;border-radius:50%;background:#ef4444;display:inline-block;flex-shrink:0"></span>&nbsp;No agents online';
    }
  }

  // â”€â”€ Message bubble â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function addBubble(type, text, label) {
    var body = q('#cvw-body');
    if (!body) return;

    var isUser = (type === 'v');
    var wrap   = document.createElement('div');
    wrap.className = 'cw' + (isUser ? ' r' : '');

    // Sender label (only for worker)
    if (label) {
      var sl = document.createElement('div');
      sl.className = 'cs';
      sl.textContent = label;
      wrap.appendChild(sl);
    }

    // Row: avatar + bubble
    var row = document.createElement('div');
    row.className = 'cw-row';

    // Mini avatar for bot/worker/ai (not user)
    if (!isUser) {
      var av = document.createElement('div');
      av.className = 'cmav';
      if (type !== 'w' && S.botAvatar) {
        av.style.cssText = 'padding:0;overflow:hidden;background:transparent;border:none';
        var avImg = document.createElement('img');
        avImg.src = S.botAvatar;
        avImg.style.cssText = 'width:100%;height:100%;object-fit:cover;border-radius:inherit';
        avImg.onerror = function() { av.style.cssText = ''; av.textContent = S.botIni; };
        av.appendChild(avImg);
      } else {
        av.textContent = (type === 'w') ? (label ? label[0].toUpperCase() : 'A') : S.botIni;
      }
      row.appendChild(av);
    }

    // Bubble
    var bbl = document.createElement('div');
    bbl.className = 'cm ' + type;
    bbl.textContent = text;
    row.appendChild(bbl);

    wrap.appendChild(row);

    // Timestamp + ticks
    var ts = document.createElement('div');
    ts.className = 'cts';
    var tick = isUser
      ? ' <span class="cvw-tick"><svg viewBox="0 0 16 10" width="13" height="13" fill="currentColor" style="opacity:.7"><path d="M1 5l4 4L15 1M6 9L5 8"/><path d="M5 9l4-4"/></svg></span>'
      : '';
    ts.innerHTML = now() + tick;
    wrap.appendChild(ts);

    body.appendChild(wrap);
    scrl();
  }

  function sys(text) {
    var body = q('#cvw-body');
    if (!body) return;
    var el = document.createElement('div');
    el.className = 'cm s';
    el.textContent = text;
    body.appendChild(el);
    scrl();
  }

  function showTyping() {
    var body = q('#cvw-body');
    if (!body || q('#cvw-typ')) return;
    var wrap = document.createElement('div');
    wrap.className = 'cw';
    // mini avatar beside typing
    var row = document.createElement('div');
    row.className = 'cw-row';
    var av = document.createElement('div');
    av.className = 'cmav';
    if (S.botAvatar) {
      av.style.cssText = 'padding:0;overflow:hidden;background:transparent;border:none';
      var tImg = document.createElement('img');
      tImg.src = S.botAvatar;
      tImg.style.cssText = 'width:100%;height:100%;object-fit:cover;border-radius:inherit';
      tImg.onerror = function() { av.style.cssText = ''; av.textContent = S.botIni; };
      av.appendChild(tImg);
    } else {
      av.textContent = S.botIni;
    }
    row.appendChild(av);
    var el = document.createElement('div');
    el.id = 'cvw-typ'; el.className = 'ctyp';
    el.innerHTML = '<span></span><span></span><span></span>';
    row.appendChild(el);
    wrap.appendChild(row);
    body.appendChild(wrap);
    scrl();
  }
  function removeTyping() {
    var e = q('#cvw-typ');
    if (e) { var p = e.closest('.cw') || e.parentElement.closest('.cw') || e.parentElement; p.remove(); }
  }

  // â”€â”€ Quick inline buttons (for callback flow choices) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function addChoiceButtons(choices) {
    var body = q('#cvw-body');
    if (!body) return;
    var wrap = document.createElement('div');
    wrap.id = 'cvw-choices';
    wrap.className = 'cw';
    wrap.style.cssText = 'display:flex;flex-wrap:wrap;gap:6px;padding:4px 0 6px';
    choices.forEach(function (ch) {
      var btn = document.createElement('button');
      btn.className = ch.skip ? 'cvw-skip' : (ch.cancel ? 'cvw-cbcancel' : 'cqb');
      btn.textContent = ch.label;
      btn.addEventListener('click', function () {
        wrap.remove();
        ch.action();
      });
      wrap.appendChild(btn);
    });
    body.appendChild(wrap);
    scrl();
  }
  function removeChoices() {
    var c = q('#cvw-choices');
    if (c) c.remove();
  }

  // â”€â”€ Conversational Callback Flow â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function startCallbackFlow() {
    if (S.cb.active) return;
    S.cb = { active: true, step: 0, data: {} };
    // Disable normal input area during callback flow
    var inp = q('#cvw-inp');
    if (inp) { inp.placeholder = 'Reply here...'; }

    sys('ðŸ“ž Callback Request');
    setTimeout(function () {
      botSay('Sure! Let me collect a few details. What\'s your **name**?', cbStep0Choices);
    }, 400);
  }

  // Helper: bot says something then optionally shows choice buttons
  function botSay(text, choicesFn, delay) {
    showTyping();
    setTimeout(function () {
      removeTyping();
      // strip markdown bold for display
      addBubble('b', text.replace(/\*\*/g, ''));
      if (choicesFn) choicesFn();
      var inp = q('#cvw-inp');
      if (inp) { inp.focus(); }
    }, delay || 700);
  }

  // Step 0 â€” ask for name
  function cbStep0Choices() {
    addChoiceButtons([
      { label: 'âŒ Cancel', cancel: true, action: cancelCallback }
    ]);
    // Override send to intercept callback input
    S.cb.step = 0;
  }

  // Step 1 â€” ask for phone
  function cbStep1() {
    botSay('Got it, ' + S.cb.data.name + '! ðŸ‘ What\'s your **phone number** so we can call you?', function () {
      addChoiceButtons([
        { label: 'âŒ Cancel', cancel: true, action: cancelCallback }
      ]);
      S.cb.step = 1;
    });
  }

  // Step 2 â€” ask for email (optional)
  function cbStep2() {
    botSay('Perfect! Your **email address**? (optional)', function () {
      addChoiceButtons([
        { label: 'â­ï¸ Skip', skip: true, action: function () { S.cb.data.email = ''; cbStep3(); } },
        { label: 'âŒ Cancel', cancel: true, action: cancelCallback }
      ]);
      S.cb.step = 2;
    });
  }

  // Step 3 â€” ask reason (optional)
  function cbStep3() {
    botSay('Almost done! Briefly, what\'s the **reason** for the callback? (optional)', function () {
      addChoiceButtons([
        { label: 'â­ï¸ Skip', skip: true, action: function () { S.cb.data.reason = ''; doSubmitCallback(); } },
        { label: 'âŒ Cancel', cancel: true, action: cancelCallback }
      ]);
      S.cb.step = 3;
    });
  }

  // Handle user text input during callback flow
  function handleCallbackInput(msg) {
    removeChoices();
    addBubble('v', msg);
    var step = S.cb.step;

    if (step === 0) {
      // Name
      if (!msg || msg.length < 2) {
        botSay('Please enter a valid name (at least 2 characters).', cbStep0Choices);
        return;
      }
      S.cb.data.name = msg;
      cbStep1();
    } else if (step === 1) {
      // Phone â€” basic validation
      var digits = msg.replace(/\D/g, '');
      if (digits.length < 7) {
        botSay('Please enter a valid phone number.', function () {
          addChoiceButtons([{ label: 'âŒ Cancel', cancel: true, action: cancelCallback }]);
          S.cb.step = 1;
        });
        return;
      }
      S.cb.data.phone = msg;
      cbStep2();
    } else if (step === 2) {
      // Email
      S.cb.data.email = msg;
      cbStep3();
    } else if (step === 3) {
      // Reason
      S.cb.data.reason = msg;
      doSubmitCallback();
    }
  }

  function doSubmitCallback() {
    removeChoices();
    showTyping();
    var ep = (S.status === 'offline')
      ? '/api/v1/merchant-chat/offline-callback'
      : '/api/v1/merchant-chat/callback-request';

    post(ep, {
      api_key:       API_KEY,
      visitor_name:  S.cb.data.name,
      visitor_phone: S.cb.data.phone,
      visitor_email: S.cb.data.email  || null,
      reason:        S.cb.data.reason || 'Callback request via chat widget',
    }, function (err, res) {
      removeTyping();
      S.cb.active = false;
      S.status = 'callback_sent';
      var msg = (res && res.data && res.data.message)
        ? res.data.message
        : 'Your callback request has been submitted!';
      addBubble('b', 'âœ… ' + msg + ' Our team will call you shortly at ' + S.cb.data.phone + '.');
      // Reset input placeholder
      var inp = q('#cvw-inp');
      if (inp) inp.placeholder = 'Type a message...';
    });
  }

  function cancelCallback() {
    S.cb.active = false;
    S.cb = { active: false, step: 0, data: {} };
    removeChoices();
    addBubble('b', 'No problem! Callback request cancelled. Feel free to ask me anything. ðŸ˜Š');
    var inp = q('#cvw-inp');
    if (inp) { inp.placeholder = 'Type a message...'; inp.focus(); }
  }

  // â”€â”€ onSend â€” routes to callback flow or normal chat â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function onSend() {
    var inp = q('#cvw-inp');
    var msg = tr(inp && inp.value);
    if (!msg) return;
    inp.value = '';
    inp.style.height = 'auto';

    // If in callback flow, intercept
    if (S.cb.active) {
      handleCallbackInput(msg);
      return;
    }

    // Normal chat flow
    sendMsg(msg);
  }

  // â”€â”€ Normal chat â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function sendMsg(msg) {
    addBubble('v', msg);

    if (!S.sessionId) {
      startSession(msg, false);
      return;
    }

    showTyping();
    post('/api/v1/merchant-chat/message/' + S.sessionId, {
      api_key: API_KEY,
      message: msg,
    }, function (err, res) {
      removeTyping();
      if (err || !res || !res.success) return;
      var d = res.data;
      if (d.ai_response) addBubble('a', d.ai_response);
      if (d.handoff_requested || d.status === 'waiting_human') {
        // Check working hours before connecting to human agent
        if (!isWithinWorkingHours()) {
          showOffHoursMessage();
          return;
        }
        sys('ðŸ”” Connecting you with a support agent...');
        S.status = 'waiting_human';
        S.waitingSince = Date.now();
        S.timeoutFired = false;
        startPoll();
      }
    });
  }

  // â”€â”€ Start session â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function startSession(msg, silent) {
    // For basic tier (direct worker forward), check working hours first
    if (S.tier === 'chatbot_basic' && !isWithinWorkingHours()) {
      removeTyping();
      S.status = 'offline';
      updStatus('away');
      showOffHoursMessage();
      return;
    }

    showTyping();
    post('/api/v1/merchant-chat/start', {
      api_key:       API_KEY,
      visitor_name:  'Visitor',
      visitor_email: null,
      message:       msg,
      page_url:      window.location.href,
      page_title:    document.title || '',
    }, function (err, res) {
      removeTyping();

      if (err || !res) {
        if (!silent) sys('Connection error. Please try again.');
        return;
      }

      if (!res.success) {
        var d = res.data || {};
        if (d.no_workers_available) {
          S.status = 'offline';
          updStatus('offline');
          sys(d.offline_message || 'Our team is currently unavailable.');
          // Auto-start callback flow
          setTimeout(function () { startCallbackFlow(); }, 600);
        } else {
          if (!silent) sys(res.detail || 'Unable to connect. Please try again.');
        }
        return;
      }

      var data = res.data;

      if (data.no_workers_available) {
        S.status = 'offline';
        updStatus('offline');
        sys(data.offline_message || 'Our team is not available right now.');
        setTimeout(function () { startCallbackFlow(); }, 600);
        return;
      }

      S.sessionId = data.session_id;
      S.status    = data.status || 'ai_active';

      if (data.ai_response) addBubble('a', data.ai_response);

      if (data.handoff_requested || data.status === 'waiting_human') {
        sys('ðŸ”” Connecting you with a support agent...');
        S.waitingSince = Date.now();
        S.timeoutFired = false;
        startPoll();
      }
    });
  }

  // â”€â”€ Polling â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function startPoll() {
    if (S.pollTimer) return;
    S.pollTimer = setInterval(poll, 3000);
  }
  function stopPoll() {
    if (S.pollTimer) clearInterval(S.pollTimer);
    S.pollTimer = null;
  }
  function poll() {
    if (!S.sessionId) return;

    // â”€â”€ 50-second worker join timeout â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    if (S.status === 'waiting_human' && !S.timeoutFired && S.waitingSince) {
      var elapsed = (Date.now() - S.waitingSince) / 1000;
      if (elapsed >= 50) {
        S.timeoutFired = true;
        stopPoll();
        // Show timeout message + prominent callback button
        sys('â³ No agent joined in time.');
        addBubble('b', 'It seems all our support agents are currently busy. You can request a callback and our team will contact you shortly! ðŸ“ž');
        // Show inline callback button
        var body = q('#cvw-body');
        if (body) {
          var cbBtn = document.createElement('button');
          cbBtn.className = 'cqb';
          cbBtn.style.cssText = 'margin:6px 0;padding:10px 20px;font-size:13px;font-weight:600;background:linear-gradient(135deg,#6366f1,#7c3aed);color:#fff;border:none;border-radius:22px;cursor:pointer;width:auto;transition:all .2s;box-shadow:0 4px 14px rgba(99,102,241,.4)';
          cbBtn.innerHTML = 'ðŸ“ž Request a Callback';
          cbBtn.addEventListener('click', function() {
            cbBtn.remove();
            startCallbackFlow();
          });
          body.appendChild(cbBtn);
          scrl();
        }
        return;
      }
    }

    get('/api/v1/merchant-chat/messages/' + S.sessionId + '?api_key=' + encodeURIComponent(API_KEY), function (err, res) {
      if (err || !res || !res.success) return;
      var d    = res.data;
      var msgs = d.messages || [];

      if (msgs.length > S.msgCount) {
        msgs.slice(S.msgCount).forEach(function (m) {
          if (m.sender_type === 'worker') addBubble('w', m.message, d.worker_name || 'Agent');
          else if (m.sender_type === 'system') sys(m.message);
        });
        S.msgCount = msgs.length;
        if (!S.open) { q('#cvw-badge').style.display = 'flex'; }
      }

      if (d.session_status === 'human_active') {
        // Worker joined â€” reset timeout state
        S.status = 'human_active';
        S.waitingSince = null;
        S.timeoutFired = false;
        updStatus('agent');
        stopPoll();
        startPoll();
      } else if (d.session_status === 'closed') {
        sys('ðŸ‘‹ Chat ended. Thank you for reaching out!');
        stopPoll();
        S.sessionId = null;
      }
    });
  }

  // â”€â”€ Bootstrap â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  function bootstrap() {
    get('/api/v1/merchant-chat/config/' + encodeURIComponent(API_KEY), function (err, res) {
      if (err || !res || !res.success) {
        console.warn('[CODVerify] Failed to load chatbot config:', err);
        return;
      }
      S.config = res.data;
      build(res.data);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootstrap);
  } else {
    bootstrap();
  }

})();
