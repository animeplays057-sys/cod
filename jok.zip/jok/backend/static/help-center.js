/**
 * CODVerify Help Center Widget — Premium v4
 * Usage: <div id="codverify-help-center"></div>
 *        <script src="...help-center.js" data-key="YOUR_API_KEY"></script>
 */
(function () {
  'use strict';
  
  if (window.__CVHC_LOADED__) return;
  window.__CVHC_LOADED__ = true;

  var sc = document.currentScript || (function () { var s = document.getElementsByTagName('script'); return s[s.length - 1]; })();
  var API_KEY = sc.getAttribute('data-key') || sc.getAttribute('data-codverify-key') || '';
  var HC_BASE = (sc.getAttribute('data-api') || 'https://api.codverify.tech') + '/api/v1/help-center';
  var root = document.getElementById('codverify-help-center');
  if (!root) { console.warn('[CODVerify HC] No #codverify-help-center element found'); return; }

  var API_THEME = sc.getAttribute('data-theme') || 'modern';
  var cfg = {
    primary: '#2563eb', name: 'Support', logo: '', faq: '', shipping: '', return_policy: '',
    contact: '', return_days: 7, refund_days: 7, theme: API_THEME,
    return_enabled: true,
    exchange_enabled: true,
    exchange_options: [],  // [{label, type, choices[]}] — fetched from merchant config
    sections: {
      track_order: true, return_exchange: true, call_me_back: true,
      chat_with_us: true, faqs: true, our_policies: true, raise_complaint: true
    },
    custom_sections: []
  };

  // Google Font — DM Sans
  if (!document.querySelector('[data-cvhc-font]')) {
    var lk = document.createElement('link');
    lk.rel = 'stylesheet';
    lk.href = 'https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;0,9..40,800;1,9..40,400&display=swap';
    lk.setAttribute('data-cvhc-font', '1'); document.head.appendChild(lk);
  }

  // ── CSS ──────────────────────────────────────────────────────────────
  var CSS = `
/* ─── RESET & BASE ─────────────────────────────────────────── */
#codverify-help-center,
#codverify-help-center *{
  box-sizing:border-box;margin:0;padding:0;
  font-family:'DM Sans',sans-serif;
  -webkit-font-smoothing:antialiased;
}
#codverify-help-center{
  --cv-p:#2563eb;
  --cv-p-dark:#1d4ed8;
  --cv-p-light:#dbeafe;
  --cv-p-subtle:#eff6ff;
  --cv-surface:#ffffff;
  --cv-bg:#f0f4fb;
  --cv-border:#dde3ec;
  --cv-border-strong:#bac4d3;
  --cv-text:#0d1117;
  --cv-text-2:#4a5568;
  --cv-text-3:#8899aa;
  --cv-radius:28px;
  --cv-radius-sm:16px;
  --cv-shadow:0 4px 24px rgba(0,0,0,.07),0 1px 4px rgba(0,0,0,.04);
  --cv-shadow-lg:0 20px 60px rgba(0,0,0,.14),0 4px 16px rgba(0,0,0,.07);
  --cv-shadow-card:0 2px 12px rgba(0,0,0,.06),0 1px 3px rgba(0,0,0,.04);

  width:100%;
  max-width:640px;
  margin:0 auto;
  background:var(--cv-bg);
  border-radius:var(--cv-radius);
  box-shadow:var(--cv-shadow-lg);
  overflow:clip;
  position:relative;
  min-height:780px;
}
@media(min-width:480px){#codverify-help-center{min-height:860px;}}

/* ── FLOATING BUBBLES ───────────────────────────────────────── */
.cvhc-bubble{
  position:absolute;border-radius:50%;pointer-events:none;z-index:0;
  animation:cv-float linear infinite;
  opacity:0;
}
@keyframes cv-float{
  0%  {transform:translateY(100%) scale(0);opacity:0;}
  10% {opacity:.7;}
  90% {opacity:.4;}
  100%{transform:translateY(-120vh) scale(1.1);opacity:0;}
}

/* ─── HERO ─────────────────────────────────────────────────── */
.cvhc-hero{
  background:linear-gradient(135deg,#1e3a8a 0%,#1d4ed8 40%,#2563eb 70%,#3b82f6 100%);
  padding:72px 36px 88px;
  text-align:center;
  position:relative;
  overflow:hidden;
}
/* Mesh orbs */
.cvhc-hero-orb{
  position:absolute;border-radius:50%;pointer-events:none;filter:blur(60px);
  opacity:.9;
}
.cvhc-hero-orb:nth-child(1){width:340px;height:340px;top:-100px;right:-60px;background:rgba(99,102,241,.55);}
.cvhc-hero-orb:nth-child(2){width:260px;height:260px;bottom:-80px;left:-60px;background:rgba(14,165,233,.5);}
.cvhc-hero-orb:nth-child(3){width:180px;height:180px;top:30px;left:20%;background:rgba(255,255,255,.14);}
.cvhc-hero-glow{
  position:absolute;inset:0;pointer-events:none;
  background:radial-gradient(ellipse 80% 60% at 50% 0%,rgba(255,255,255,.22),transparent 70%);
}
/* grid overlay */
.cvhc-hero::before{
  content:'';position:absolute;inset:0;pointer-events:none;z-index:0;
  background-image:linear-gradient(rgba(255,255,255,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.05) 1px,transparent 1px);
  background-size:36px 36px;
}
.cvhc-hero-logo{
  width:80px;height:80px;border-radius:24px;object-fit:cover;
  border:3px solid rgba(255,255,255,.4);
  box-shadow:0 12px 40px rgba(0,0,0,.3),0 0 0 8px rgba(255,255,255,.1);
  margin:0 auto 22px;display:block;position:relative;z-index:1;
}
.cvhc-badge{
  display:inline-flex;align-items:center;gap:8px;
  background:rgba(255,255,255,.15);
  border:1px solid rgba(255,255,255,.3);
  border-radius:100px;padding:10px 22px;
  font-size:11px;font-weight:700;color:#fff;
  letter-spacing:.8px;text-transform:uppercase;
  margin-bottom:22px;position:relative;z-index:2;
  backdrop-filter:blur(16px);
  box-shadow:0 4px 16px rgba(0,0,0,.15);
}
.cvhc-badge-dot{
  width:8px;height:8px;border-radius:50%;background:#34d399;
  box-shadow:0 0 10px rgba(52,211,153,1);flex-shrink:0;
  animation:cv-pulse-dot 2s infinite;
}
@keyframes cv-pulse-dot{0%,100%{box-shadow:0 0 8px rgba(52,211,153,.9);}50%{box-shadow:0 0 20px rgba(52,211,153,1),0 0 40px rgba(52,211,153,.4);}}
.cvhc-hero-title{
  font-size:clamp(32px,5vw,48px);font-weight:900;color:#fff;
  line-height:1.05;letter-spacing:-1.5px;
  position:relative;z-index:2;
  text-shadow:0 4px 32px rgba(0,0,0,.3);
  margin-bottom:4px;
}
.cvhc-hero-sub{
  font-size:15px;color:rgba(255,255,255,.75);
  margin-top:14px;font-weight:500;
  position:relative;z-index:2;letter-spacing:.2px;
}

/* ─── HOME BODY ─────────────────────────────────────────────── */
.cvhc-body{
  padding:28px 22px 40px;
  background:var(--cv-bg);
  display:flex;flex-direction:column;align-items:stretch;
}
@media(min-width:480px){.cvhc-body{padding:32px 32px 44px;}}

/* ─── SECTION LABEL ─────────────────────────────────────────── */
.cvhc-section-label{
  font-size:10.5px;font-weight:800;color:var(--cv-text-3);
  letter-spacing:1px;text-transform:uppercase;
  margin-bottom:14px;padding-left:2px;
  display:flex;align-items:center;gap:8px;
}
.cvhc-section-label::before{
  content:'';display:inline-block;width:18px;height:2px;
  background:var(--cv-p);border-radius:2px;
}

/* ─── ACTION GRID ────────────────────────────────────────────── */
.cvhc-grid{
  display:grid;
  grid-template-columns:repeat(2,1fr);
  gap:14px;margin-bottom:14px;
}
@media(min-width:560px){.cvhc-grid{grid-template-columns:repeat(4,1fr);}}
.cvhc-grid-2{
  display:grid;grid-template-columns:repeat(2,1fr);
  gap:14px;margin-bottom:24px;
}

/* ─── ACTION CARD ────────────────────────────────────────────── */
.cvhc-card{
  background:var(--cv-surface);
  border-radius:22px;
  padding:28px 16px 24px;
  text-align:center;cursor:pointer;
  border:1.5px solid var(--cv-border);
  box-shadow:0 4px 16px rgba(0,0,0,.07),0 1px 3px rgba(0,0,0,.04);
  transition:transform .28s cubic-bezier(.34,1.56,.64,1),
             box-shadow .28s ease,border-color .2s;
  position:relative;overflow:hidden;
}
.cvhc-card::before{
  content:'';position:absolute;inset:0;
  background:linear-gradient(135deg,rgba(255,255,255,0) 50%,rgba(255,255,255,.7));
  pointer-events:none;
}
.cvhc-card::after{
  content:'';position:absolute;bottom:-30px;right:-30px;
  width:80px;height:80px;border-radius:50%;
  background:radial-gradient(circle,rgba(37,99,235,.06),transparent 70%);
  pointer-events:none;transition:opacity .3s;
}
.cvhc-card:hover{
  transform:translateY(-8px) scale(1.02);
  box-shadow:0 20px 48px rgba(37,99,235,.18),0 6px 16px rgba(0,0,0,.07);
  border-color:var(--cv-p);
}
.cvhc-card:hover::after{opacity:2;}
.cvhc-card:active{transform:scale(.96) translateY(-2px);}

.cvhc-card-icon{
  width:54px;height:54px;border-radius:16px;
  display:flex;align-items:center;justify-content:center;
  margin:0 auto 14px;
  transition:transform .28s cubic-bezier(.34,1.56,.64,1),box-shadow .28s;
  box-shadow:0 4px 12px rgba(0,0,0,.08);
}
.cvhc-card:hover .cvhc-card-icon{
  transform:scale(1.12) rotate(-6deg);
  box-shadow:0 8px 20px rgba(0,0,0,.14);
}
.cvhc-card-icon svg{width:24px;height:24px;stroke-width:1.8;}

.cvhc-card-label{font-size:13.5px;font-weight:700;color:var(--cv-text);line-height:1.3;}
.cvhc-card-desc{font-size:11.5px;color:var(--cv-text-3);margin-top:5px;font-weight:500;}

/* icon palettes */
.icon-blue{background:#eff6ff;}.icon-blue svg{color:#2563eb;}
.icon-amber{background:#fffbeb;}.icon-amber svg{color:#d97706;}
.icon-emerald{background:#f0fdf4;}.icon-emerald svg{color:#059669;}
.icon-violet{background:#f5f3ff;}.icon-violet svg{color:#7c3aed;}
.icon-sky{background:#f0f9ff;}.icon-sky svg{color:#0284c7;}
.icon-slate{background:#f8fafc;}.icon-slate svg{color:#475569;}
.icon-red{background:#fef2f2;}.icon-red svg{color:#dc2626;}

/* ─── CONTACT STRIP ──────────────────────────────────────────── */
.cvhc-contact{
  background:var(--cv-surface);border-radius:16px;
  padding:16px 20px;margin-bottom:16px;
  box-shadow:var(--cv-shadow-card);
  border:1.5px solid var(--cv-border);
  display:flex;gap:14px;align-items:flex-start;
}
.cvhc-contact-icon{
  width:36px;height:36px;border-radius:10px;background:#eff6ff;
  display:flex;align-items:center;justify-content:center;flex-shrink:0;
}
.cvhc-contact-icon svg{width:17px;height:17px;color:#2563eb;stroke-width:2;}
.cvhc-contact-title{font-size:13px;font-weight:700;color:var(--cv-text);margin-bottom:4px;}
.cvhc-contact-text{font-size:12.5px;color:var(--cv-text-2);line-height:1.7;}

/* ─── POWERED BY ─────────────────────────────────────────────── */
.cvhc-pow{
  position:absolute;bottom:0;left:0;right:0;height:42px;
  display:flex;align-items:center;justify-content:center;
  font-size:11.5px;color:var(--cv-text-3);
  border-top:1px solid var(--cv-border);background:var(--cv-bg);
  letter-spacing:.1px;z-index:30;
}
.cvhc-pow a{color:var(--cv-p);text-decoration:none;font-weight:700;}

/* ─── PANEL ──────────────────────────────────────────────────── */
.cvhc-panel{
  position:absolute;inset:0;bottom:42px;z-index:20;
  background:var(--cv-bg);
  transform:translateX(103%);
  transition:transform .36s cubic-bezier(.4,0,.2,1);
  overflow-y:auto;display:flex;flex-direction:column;
}
.cvhc-panel.open{transform:translateX(0);}

/* Panel hero header */
.cvhc-panel-hero{
  padding:22px 24px 30px;
  position:relative;overflow:hidden;flex-shrink:0;
}
.cvhc-panel-hero::after{
  content:'';position:absolute;
  width:260px;height:260px;border-radius:50%;
  top:-100px;right:-80px;
  background:rgba(255,255,255,.08);pointer-events:none;
}
.cvhc-panel-back{
  display:inline-flex;align-items:center;gap:5px;
  background:rgba(255,255,255,.18);
  border:1px solid rgba(255,255,255,.26);
  border-radius:10px;padding:7px 14px;
  color:#fff;font-size:13px;font-weight:600;cursor:pointer;
  margin-bottom:20px;transition:background .15s;
  position:relative;z-index:1;font-family:'DM Sans',sans-serif;
}
.cvhc-panel-back:hover{background:rgba(255,255,255,.3);}
.cvhc-panel-back svg{width:15px;height:15px;stroke-width:2.5;}
.cvhc-panel-icon{
  width:48px;height:48px;border-radius:14px;
  background:rgba(255,255,255,.18);
  border:1.5px solid rgba(255,255,255,.28);
  display:flex;align-items:center;justify-content:center;
  margin-bottom:10px;position:relative;z-index:1;
}
.cvhc-panel-icon svg{width:22px;height:22px;color:#fff;stroke-width:2;}
.cvhc-panel-title{font-size:22px;font-weight:800;color:#fff;position:relative;z-index:1;letter-spacing:-.3px;}
.cvhc-panel-subtitle{font-size:13px;color:rgba(255,255,255,.68);margin-top:5px;position:relative;z-index:1;}

/* Panel body */
.cvhc-panel-body{padding:22px 20px 32px;flex:1;}
@media(min-width:480px){.cvhc-panel-body{padding:26px 26px 36px;}}

/* ─── FORM CARD ──────────────────────────────────────────────── */
.cvhc-form-card{
  background:var(--cv-surface);
  border-radius:24px;padding:28px 24px;
  box-shadow:0 8px 32px rgba(0,0,0,.09),0 1px 4px rgba(0,0,0,.04);
  border:1.5px solid var(--cv-border);
  margin-bottom:16px;
  position:relative;overflow:hidden;
}
.cvhc-form-card::before{
  content:'';position:absolute;top:-60px;right:-60px;
  width:180px;height:180px;border-radius:50%;
  background:radial-gradient(circle,rgba(37,99,235,.06),transparent 70%);
  pointer-events:none;
}

/* ─── FORM ELEMENTS ──────────────────────────────────────────── */
.cvhc-fg{margin-bottom:20px;position:relative;}

/* ── Premium label ── */
.cvhc-label{
  display:block;font-size:11px;font-weight:800;
  color:var(--cv-text-3);margin-bottom:8px;
  letter-spacing:.9px;text-transform:uppercase;
  transition:color .2s;
  display:flex;align-items:center;gap:6px;
}
.cvhc-fg:focus-within .cvhc-label{
  color:var(--cv-p);
}
.cvhc-label-dot{
  width:5px;height:5px;border-radius:50%;
  background:var(--cv-p);display:inline-block;
  opacity:0;transform:scale(0);
  transition:opacity .2s,transform .2s;
}
.cvhc-fg:focus-within .cvhc-label-dot{
  opacity:1;transform:scale(1);
}

/* ── Premium inputs ── */
.cvhc-input-wrap{
  position:relative;
}
.cvhc-input-accent{
  position:absolute;left:0;top:8px;bottom:8px;
  width:3px;border-radius:0 3px 3px 0;
  background:var(--cv-p);
  opacity:0;transform:scaleY(0);
  transition:opacity .25s,transform .3s cubic-bezier(.34,1.56,.64,1);
  pointer-events:none;
}
.cvhc-fg:focus-within .cvhc-input-accent{
  opacity:1;transform:scaleY(1);
}
.cvhc-input{
  width:100%;padding:13px 16px 13px 20px;
  border:1.5px solid var(--cv-border);
  border-radius:14px;font-size:14px;
  color:var(--cv-text);
  background:linear-gradient(135deg,rgba(255,255,255,.95),rgba(248,250,255,.9));
  outline:none;
  transition:border-color .22s,box-shadow .22s,background .22s,transform .15s;
  font-family:'DM Sans',sans-serif;
  box-shadow:0 2px 8px rgba(0,0,0,.04),inset 0 1px 2px rgba(0,0,0,.03);
}
.cvhc-input:hover{
  border-color:var(--cv-border-strong);
  box-shadow:0 4px 12px rgba(0,0,0,.07),inset 0 1px 2px rgba(0,0,0,.03);
}
.cvhc-input:focus{
  border-color:var(--cv-p);
  background:#fff;
  box-shadow:0 0 0 3px rgba(37,99,235,.14),0 4px 16px rgba(37,99,235,.1);
  transform:translateY(-1px);
}
.cvhc-input::placeholder{color:var(--cv-text-3);font-weight:400;}

/* ── Premium select ── */
.cvhc-select-wrap{
  position:relative;
}
.cvhc-select-arrow{
  position:absolute;right:14px;top:50%;transform:translateY(-50%);
  pointer-events:none;
  width:16px;height:16px;color:var(--cv-text-3);
  transition:color .2s,transform .25s;
}
.cvhc-fg:focus-within .cvhc-select-arrow{color:var(--cv-p);transform:translateY(-50%) rotate(180deg);}
.cvhc-select{
  width:100%;padding:13px 42px 13px 16px;
  border:1.5px solid var(--cv-border);
  border-radius:14px;font-size:14px;
  color:var(--cv-text);
  background:linear-gradient(135deg,rgba(255,255,255,.95),rgba(248,250,255,.9));
  outline:none;cursor:pointer;
  font-family:'DM Sans',sans-serif;
  appearance:none;
  box-shadow:0 2px 8px rgba(0,0,0,.04),inset 0 1px 2px rgba(0,0,0,.03);
  transition:border-color .22s,box-shadow .22s,transform .15s;
}
.cvhc-select:hover{
  border-color:var(--cv-border-strong);
}
.cvhc-select:focus{
  border-color:var(--cv-p);
  background:#fff;
  box-shadow:0 0 0 3px rgba(37,99,235,.14),0 4px 16px rgba(37,99,235,.1);
  transform:translateY(-1px);
}

/* ── Premium textarea ── */
.cvhc-textarea{
  width:100%;padding:13px 16px 13px 20px;
  border:1.5px solid var(--cv-border);
  border-radius:14px;font-size:14px;
  color:var(--cv-text);
  background:linear-gradient(135deg,rgba(255,255,255,.95),rgba(248,250,255,.9));
  outline:none;resize:vertical;min-height:100px;
  transition:border-color .22s,box-shadow .22s,background .22s,transform .15s;
  font-family:'DM Sans',sans-serif;line-height:1.7;
  box-shadow:0 2px 8px rgba(0,0,0,.04),inset 0 1px 2px rgba(0,0,0,.03);
}
.cvhc-textarea:hover{border-color:var(--cv-border-strong);}
.cvhc-textarea:focus{
  border-color:var(--cv-p);background:#fff;
  box-shadow:0 0 0 3px rgba(37,99,235,.14),0 4px 16px rgba(37,99,235,.1);
  transform:translateY(-1px);
}
.cvhc-textarea::placeholder{color:var(--cv-text-3);font-weight:400;}

/* ─── BUTTON ─────────────────────────────────────────────────── */
@keyframes cv-btn-shine{
  0%{background-position:200% center;}
  100%{background-position:-200% center;}
}
.cvhc-btn{
  display:flex;align-items:center;justify-content:center;gap:9px;
  width:100%;padding:16px 28px;
  font-size:14.5px;font-weight:800;color:#fff;
  border:none;border-radius:16px;cursor:pointer;
  transition:transform .25s cubic-bezier(.34,1.56,.64,1),box-shadow .25s,filter .2s;
  letter-spacing:.3px;margin-top:10px;
  font-family:'DM Sans',sans-serif;
  position:relative;overflow:hidden;
  background-size:300% auto;
}
.cvhc-btn::before{
  content:'';position:absolute;inset:0;
  background:linear-gradient(90deg,transparent 0%,rgba(255,255,255,.22) 50%,transparent 100%);
  background-size:200% 100%;
  transform:translateX(-100%);
  transition:transform .5s ease;
  pointer-events:none;
}
.cvhc-btn:hover::before{transform:translateX(100%);}
.cvhc-btn svg{width:18px;height:18px;stroke-width:2.2;flex-shrink:0;position:relative;z-index:1;}
.cvhc-btn span{position:relative;z-index:1;}
.cvhc-btn:hover{transform:translateY(-3px);filter:brightness(1.08);}
.cvhc-btn:active{transform:scale(.97) translateY(-1px);}
.cvhc-btn:disabled{opacity:.5;cursor:not-allowed;transform:none;filter:none;}

/* ── Ripple on click ── */
.cvhc-btn-ripple{
  position:absolute;border-radius:50%;
  background:rgba(255,255,255,.35);
  transform:scale(0);animation:cv-ripple .55s linear;
  pointer-events:none;
}
@keyframes cv-ripple{
  to{transform:scale(4);opacity:0;}
}

.btn-blue{
  background:linear-gradient(135deg,#60a5fa 0%,#2563eb 50%,#1d4ed8 100%);
  box-shadow:0 6px 20px rgba(37,99,235,.4),0 2px 6px rgba(37,99,235,.2);
}
.btn-blue:hover{box-shadow:0 12px 32px rgba(37,99,235,.55),0 4px 10px rgba(37,99,235,.25);}

.btn-amber{
  background:linear-gradient(135deg,#fbbf24 0%,#f59e0b 50%,#d97706 100%);
  box-shadow:0 6px 20px rgba(217,119,6,.4),0 2px 6px rgba(217,119,6,.2);
}
.btn-amber:hover{box-shadow:0 12px 32px rgba(217,119,6,.55),0 4px 10px rgba(217,119,6,.25);}

.btn-emerald{
  background:linear-gradient(135deg,#34d399 0%,#10b981 50%,#059669 100%);
  box-shadow:0 6px 20px rgba(5,150,105,.4),0 2px 6px rgba(5,150,105,.2);
}
.btn-emerald:hover{box-shadow:0 12px 32px rgba(5,150,105,.55),0 4px 10px rgba(5,150,105,.25);}

/* ─── ALERTS ─────────────────────────────────────────────────── */
.cvhc-alert{
  padding:12px 15px;border-radius:12px;
  font-size:13px;margin-bottom:14px;
  display:flex;gap:10px;align-items:flex-start;
  line-height:1.55;font-weight:500;
}
.cvhc-alert svg{flex-shrink:0;margin-top:1px;width:16px;height:16px;stroke-width:2;}
.alert-err{background:#fef2f2;color:#b91c1c;border:1.5px solid #fecaca;}
.alert-ok{background:#f0fdf4;color:#15803d;border:1.5px solid #bbf7d0;}
.alert-info{background:#eff6ff;color:#1d4ed8;border:1.5px solid #bfdbfe;}
.alert-warn{background:#fffbeb;color:#b45309;border:1.5px solid #fde68a;}

/* ─── TRACKING MODAL ─────────────────────────────────────────── */
.cvhc-tmodal-wrap{
  position:absolute;inset:0;z-index:100;
  background:rgba(15,23,42,.4);backdrop-filter:blur(6px);
  -webkit-backdrop-filter:blur(6px);
  display:flex;align-items:center;justify-content:center;
  opacity:0;pointer-events:none;transition:opacity .3s;
  padding:24px 16px;overflow-y:auto;
}
@media(min-width:480px){.cvhc-tmodal-wrap{padding:32px 24px;}}
.cvhc-tmodal-wrap.open{opacity:1;pointer-events:auto;}

.cvhc-tmodal{
  background:var(--cv-surface);width:100%;max-width:440px;
  margin:auto;
  border-radius:24px;box-shadow:var(--cv-shadow-lg);
  transform:translateY(30px) scale(.95);transition:transform .4s cubic-bezier(.34,1.56,.64,1);
  position:relative;display:flex;flex-direction:column;
  overflow:hidden;
}
.cvhc-tmodal-wrap.open .cvhc-tmodal{transform:translateY(0) scale(1);}

.cvhc-tm-head{
  background:linear-gradient(135deg,var(--cv-p),var(--cv-p-dark));
  padding:26px 24px;color:#fff;position:relative;flex-shrink:0;
}
.cvhc-tm-close{
  position:absolute;top:16px;right:16px;width:32px;height:32px;
  border-radius:50%;background:rgba(255,255,255,.2);color:#fff;
  display:flex;align-items:center;justify-content:center;cursor:pointer;
  border:none;transition:background .2s;
}
.cvhc-tm-close:hover{background:rgba(255,255,255,.3);}
.cvhc-tm-close svg{width:18px;height:18px;stroke-width:2.5;}

.cvhc-tm-num{font-size:22px;font-weight:800;letter-spacing:-.4px;line-height:1.2;}
.cvhc-tm-name{font-size:14px;opacity:.9;margin-top:4px;}
.cvhc-tm-amt{
  position:absolute;bottom:-17px;right:24px;
  background:var(--cv-surface);color:var(--cv-text);
  padding:7px 16px;border-radius:20px;font-weight:800;font-size:15px;
  box-shadow:var(--cv-shadow-card);border:1.5px solid var(--cv-border);
}

.cvhc-tm-body{
  padding:32px 24px 24px;overflow-y:auto;flex:1;
}
.cvhc-tl{padding:0;}


/* Timeline steps */
.cvhc-step{display:flex;gap:14px;padding-bottom:22px;position:relative;}
.cvhc-step:last-child{padding-bottom:0;}
.cvhc-step-line{
  position:absolute;left:15px;top:34px;bottom:0;width:2px;
  background:linear-gradient(to bottom,#c7d2fe 0%,transparent 100%);
}
.cvhc-step:last-child .cvhc-step-line{display:none;}
.cvhc-dot{
  width:32px;height:32px;border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  flex-shrink:0;z-index:1;
}
.cvhc-dot svg{width:15px;height:15px;stroke-width:2.2;}
.dot-done{background:#dcfce7;color:#16a34a;}
.dot-done svg{color:#16a34a;}
.dot-active{
  background:var(--cv-p);color:#fff;
  box-shadow:0 0 0 5px rgba(37,99,235,.15);
}
.dot-active svg{color:#fff;}
.dot-pending{background:#f1f5f9;color:#94a3b8;}
.dot-pending svg{color:#94a3b8;}
.cvhc-step-body{flex:1;padding-top:5px;}
.cvhc-step-label{font-size:14px;font-weight:600;color:var(--cv-text);}
.cvhc-step-label.active{color:var(--cv-p);}
.cvhc-step-sub{font-size:12px;color:var(--cv-text-3);margin-top:2px;}

/* Tracking info box */
.cvhc-tbox{
  background:#f8faff;border:1.5px solid #e0e9ff;
  border-radius:13px;padding:14px 16px;margin-top:16px;
}
.cvhc-tbox-title{
  font-size:10.5px;font-weight:700;color:var(--cv-p);
  text-transform:uppercase;letter-spacing:.7px;margin-bottom:10px;
  display:flex;align-items:center;gap:6px;
}
.cvhc-tbox-title svg{width:14px;height:14px;stroke-width:2;}
.cvhc-trow{
  display:flex;justify-content:space-between;
  padding:7px 0;border-bottom:1px solid #e4ecf7;font-size:13px;
}
.cvhc-trow:last-child{border:none;}
.cvhc-tlabel{color:var(--cv-text-2);}
.cvhc-tval{font-weight:600;color:var(--cv-text);}

/* Return badge */
.cvhc-ret-badge{
  display:inline-flex;align-items:center;gap:8px;
  padding:10px 16px;border-radius:11px;font-size:13px;
  font-weight:600;margin-top:14px;cursor:pointer;
  border:none;transition:all .2s;font-family:'DM Sans',sans-serif;
}
.cvhc-ret-badge svg{width:15px;height:15px;stroke-width:2;}
.badge-ok{background:#dcfce7;color:#15803d;}
.badge-ok:hover{background:#bbf7d0;transform:translateY(-1px);}
.badge-exp{background:#fef2f2;color:#b91c1c;cursor:default;}

/* ─── FAQ ────────────────────────────────────────────────────── */
.cvhc-faq-item{
  background:var(--cv-surface);border:1.5px solid var(--cv-border);
  border-radius:14px;margin-bottom:10px;overflow:hidden;
  transition:border-color .2s,box-shadow .2s;
}
.cvhc-faq-item:hover{border-color:var(--cv-border-strong);box-shadow:0 4px 12px rgba(0,0,0,.06);}
.cvhc-faq-q{
  padding:16px 20px;
  display:flex;justify-content:space-between;align-items:center;
  cursor:pointer;font-size:14px;font-weight:600;color:var(--cv-text);
  transition:background .15s,color .15s;gap:12px;
}
.cvhc-faq-q:hover{background:#f0f5ff;}
.cvhc-faq-q.open{background:#eff6ff;color:var(--cv-p);}
.cvhc-faq-a{
  padding:0 20px;font-size:13.5px;color:var(--cv-text-2);
  line-height:1.85;max-height:0;overflow:hidden;
  transition:max-height .38s ease,padding .3s;
  background:linear-gradient(to bottom,#eff6ff,#f8faff);
  border-top:0px solid #bfdbfe;
}
.cvhc-faq-a.open{max-height:600px;padding:14px 20px 18px;border-top-width:1px;}
.cvhc-faq-chev{
  transition:transform .28s cubic-bezier(.34,1.56,.64,1);flex-shrink:0;
  width:18px;height:18px;color:var(--cv-text-3);
}
.cvhc-faq-chev.open{transform:rotate(180deg);color:var(--cv-p);}

/* ─── SPINNER / SKELETON ─────────────────────────────────────── */
.cvhc-spin{
  width:20px;height:20px;
  border:2.5px solid rgba(255,255,255,.3);
  border-top-color:#fff;border-radius:50%;
  animation:cv-spin .6s linear infinite;
}
@keyframes cv-spin{to{transform:rotate(360deg)}}
.cvhc-skel{
  background:linear-gradient(90deg,#e8edf5 25%,#d5dcec 50%,#e8edf5 75%);
  background-size:200% 100%;
  animation:cv-shim 1.4s infinite;border-radius:10px;
}
@keyframes cv-shim{to{background-position:-200% 0}}

/* ─── CARD ENTRANCE ANIMATION ────────────────────────────────── */
@keyframes cv-fadeup{
  from{opacity:0;transform:translateY(14px);}
  to{opacity:1;transform:translateY(0);}
}
.cvhc-card{
  animation:cv-fadeup .4s ease both;
}
.cvhc-card:nth-child(1){animation-delay:.04s;}
.cvhc-card:nth-child(2){animation-delay:.1s;}
.cvhc-card:nth-child(3){animation-delay:.16s;}
.cvhc-card:nth-child(4){animation-delay:.22s;}

/* ─── DIVIDER ─────────────────────────────────────────────────── */
.cvhc-divider{
  height:1px;background:var(--cv-border);margin:20px 0;
}
`;

  function injectCSS() {
    if (document.getElementById('cvhc-css')) return;
    var s = document.createElement('style'); s.id = 'cvhc-css'; s.textContent = CSS; document.head.appendChild(s);
  }

  // ── SVG ICON SET ──────────────────────────────────────────────────────
  var I = {
    /* nav / actions */
    truck: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><rect x="1" y="3" width="15" height="13" rx="2"/><path d="M16 8h4l3 5v3h-7V8z"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>',
    ret: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M3 9l4-4 4 4"/><path d="M7 5v11a4 4 0 004 4h6"/><path d="M21 15l-4 4-4-4"/></svg>',
    phone: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg>',
    chat: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>',
    faq: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
    doc: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
    mail: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
    back: '<svg fill="none" stroke="currentColor" stroke-linecap="round" viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"/></svg>',
    chev: '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg>',
    check: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
    warn: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
    err: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
    info: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
    search: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
    /* timeline step icons */
    clipboard: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M16 4h2a2 2 0 012 2v14a2 2 0 01-2 2H6a2 2 0 01-2-2V6a2 2 0 012-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/></svg>',
    mappin: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>',
    checkcircle: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
    /* misc */
    signal: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M5 12.55a11 11 0 0114.08 0"/><path d="M1.42 9a16 16 0 0121.16 0"/><path d="M8.53 16.11a6 6 0 016.95 0"/><line x1="12" y1="20" x2="12.01" y2="20"/></svg>',
    refresh: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>',
    wallet: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M21 12V7H5a2 2 0 010-4h14v4"/><path d="M3 5v14a2 2 0 002 2h16v-5"/><path d="M18 12a2 2 0 000 4h4v-4z"/></svg>',
    shield: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
    xCircle: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
    alert: '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
  };

  // ── HTTP ──────────────────────────────────────────────────────────────
  function get(url, cb) { fetch(url).then(r => r.json()).then(d => cb(null, d)).catch(e => cb(e, null)); }
  function post(url, body, cb) { fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then(r => r.json()).then(d => cb(null, d)).catch(e => cb(e, null)); }

  // ── Helpers ───────────────────────────────────────────────────────────
  function esc(s) { return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function val(id) { var e = document.getElementById(id); return e ? e.value.trim() : ''; }
  function alert2(el, type, msg) {
    var map = { err: 'alert-err', ok: 'alert-ok', info: 'alert-info', warn: 'alert-warn' };
    var ico = { err: I.err, ok: I.check, info: I.info, warn: I.warn };
    el.innerHTML = '<div class="cvhc-alert ' + map[type] + '">' + ico[type] + '<span>' + msg + '</span></div>';
  }
  function setBtn(btn, loading, original) {
    btn.disabled = loading;
    btn.innerHTML = loading ? '<div class="cvhc-spin"></div>' : original;
  }

  // ── Init ──────────────────────────────────────────────────────────────
  function init() {
    injectCSS();
    root.style.setProperty('--cv-p', cfg.primary);

    // Skeleton loading state
    root.innerHTML = `
    <div style="background:linear-gradient(145deg,#1d4ed8,#2563eb,#3b82f6);padding:44px 36px 52px;text-align:center">
      <div class="cvhc-skel" style="height:9px;width:110px;border-radius:100px;margin:0 auto 18px;background:rgba(255,255,255,.18)"></div>
      <div class="cvhc-skel" style="height:32px;width:55%;margin:0 auto 12px;background:rgba(255,255,255,.16)"></div>
      <div class="cvhc-skel" style="height:14px;width:38%;margin:0 auto;background:rgba(255,255,255,.1)"></div>
    </div>
    <div style="padding:24px 20px;background:#f4f7fb">
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px">
        <div class="cvhc-skel" style="height:120px;border-radius:18px"></div>
        <div class="cvhc-skel" style="height:120px;border-radius:18px"></div>
        <div class="cvhc-skel" style="height:120px;border-radius:18px"></div>
        <div class="cvhc-skel" style="height:120px;border-radius:18px"></div>
      </div>
    </div>`;

    get(HC_BASE + '/config?api_key=' + encodeURIComponent(API_KEY), function (err, res) {
      if (err || !res || !res.success) {
        root.innerHTML = '<div style="padding:24px"><div class="cvhc-alert alert-err">' + I.err + '<span>Could not load help center. Please check your API key.</span></div></div>';
        return;
      }
      var d = res.data;
      cfg.primary = d.primary_color || cfg.primary;
      cfg.name = d.business_name || 'Support';
      cfg.logo = d.logo_url || '';
      cfg.faq = d.help_center_faq || d.business_faq || '';
      cfg.shipping = d.help_center_shipping || d.shipping_info || '';
      cfg.return_policy = d.help_center_return || d.return_policy || '';
      cfg.contact = d.help_center_contact || d.contact_info || '';
      cfg.return_days = d.return_policy_days || 7;
      cfg.refund_days = d.refund_policy_days || 7;
      cfg.theme = d.help_center_theme || API_THEME || 'modern';
      cfg.return_enabled = d.return_enabled !== false;
      cfg.exchange_enabled = d.exchange_enabled !== false;
      cfg.exchange_options = Array.isArray(d.exchange_options) ? d.exchange_options : [];
      cfg.sections = Object.assign({
        track_order: true, return_exchange: true, call_me_back: true,
        chat_with_us: true, faqs: true, our_policies: true, raise_complaint: true
      }, d.help_center_sections || {});
      cfg.custom_sections = (d.help_center_custom_sections || []).filter(function(s){ return s.enabled !== false; });
      applyTheme();
      root.style.setProperty('--cv-p', cfg.primary);
      render();
    });
  }

  // ── Theme applier ─────────────────────────────────────────────────────
  function applyTheme() {
    var t = cfg.theme || 'modern';
    var themes = {
      modern: { '--cv-p': cfg.primary, '--cv-bg': '#f4f7fb', '--cv-surface': '#ffffff', '--cv-text': '#0d1117', '--cv-text-2': '#4a5568', '--cv-hero-bg': 'linear-gradient(135deg,#1e3a8a 0%,#1d4ed8 40%,#2563eb 70%,#3b82f6 100%)' },
      glass:  { '--cv-p': '#818cf8', '--cv-bg': '#0f172a', '--cv-surface': 'rgba(255,255,255,.06)', '--cv-text': '#f1f5f9', '--cv-text-2': '#94a3b8', '--cv-border': 'rgba(255,255,255,.1)', '--cv-hero-bg': 'linear-gradient(135deg,#0f172a 0%,#1e1b4b 50%,#312e81 100%)' },
      minimal:{ '--cv-p': '#2563eb', '--cv-bg': '#ffffff', '--cv-surface': '#f8fafc', '--cv-text': '#111827', '--cv-text-2': '#6b7280', '--cv-border': '#e5e7eb', '--cv-hero-bg': 'linear-gradient(135deg,#1e40af 0%,#3b82f6 100%)' },
      bold:   { '--cv-p': '#d4af37', '--cv-bg': '#0d1225', '--cv-surface': '#1a2744', '--cv-text': '#f1f5f9', '--cv-text-2': '#94a3b8', '--cv-border': 'rgba(212,175,55,.2)', '--cv-hero-bg': 'linear-gradient(135deg,#0d1225 0%,#1a2744 50%,#0d1225 100%)' },
    };
    var vars = themes[t] || themes.modern;
    Object.keys(vars).forEach(function(k) { root.style.setProperty(k, vars[k]); });
    // Hero override via attribute stored in hero element
    root.setAttribute('data-theme', t);
  }

  // ── Render home ───────────────────────────────────────────────────────
  function render() {
    root.innerHTML = '';
    var main = document.createElement('div');
    main.id = 'cvhc-main'; main.style.cssText = 'width:100%;padding-bottom:52px;overflow-y:auto;flex:1;';

    // ── Floating background bubbles ──────────────────────────────────────
    var bubbleColors = [
      'rgba(99,102,241,.18)', 'rgba(59,130,246,.15)',
      'rgba(14,165,233,.12)', 'rgba(167,139,250,.14)',
      'rgba(52,211,153,.10)'
    ];
    var _bubbleTimer = null;
    function spawnBubble() {
      var b = document.createElement('div');
      b.className = 'cvhc-bubble';
      var size = 18 + Math.random() * 48;
      var left = 5 + Math.random() * 90;
      var dur  = 6 + Math.random() * 10;
      var delay = Math.random() * 4;
      var color = bubbleColors[Math.floor(Math.random() * bubbleColors.length)];
      b.style.cssText = [
        'width:' + size + 'px',
        'height:' + size + 'px',
        'left:' + left + '%',
        'bottom:-' + size + 'px',
        'background:' + color,
        'animation-duration:' + dur + 's',
        'animation-delay:' + delay + 's',
        'backdrop-filter:blur(2px)',
        'border:1px solid rgba(255,255,255,.25)',
      ].join(';');
      root.appendChild(b);
      setTimeout(function() { if (b.parentNode) b.parentNode.removeChild(b); }, (dur + delay) * 1000 + 500);
    }
    // Spawn initial bubbles
    for (var _i = 0; _i < 6; _i++) { setTimeout(spawnBubble, _i * 600); }
    // Keep spawning every 1.5s
    _bubbleTimer = setInterval(spawnBubble, 1500);
    // Stop after widget is removed from DOM
    setTimeout(function() { if (_bubbleTimer) clearInterval(_bubbleTimer); }, 120000);



    var logoHtml = cfg.logo ? '<img class="cvhc-hero-logo" src="' + cfg.logo + '" onerror="this.style.display=\'none\'" />' : '';

    // Build quick-action cards based on enabled sections
    var quickCards = '';
    if (cfg.sections.track_order) quickCards += '<div class="cvhc-card" data-panel="track"><div class="cvhc-card-icon icon-blue">' + I.truck + '</div><div class="cvhc-card-label">Track Order</div><div class="cvhc-card-desc">Check delivery status</div></div>';
    if (cfg.sections.return_exchange) quickCards += '<div class="cvhc-card" data-panel="return"><div class="cvhc-card-icon icon-amber">' + I.ret + '</div><div class="cvhc-card-label">Return / Exchange</div><div class="cvhc-card-desc">Initiate a request</div></div>';
    if (cfg.sections.call_me_back) quickCards += '<div class="cvhc-card" data-panel="callback"><div class="cvhc-card-icon icon-emerald">' + I.phone + '</div><div class="cvhc-card-label">Call Me Back</div><div class="cvhc-card-desc">Get a callback</div></div>';
    if (cfg.sections.chat_with_us) quickCards += '<div class="cvhc-card" id="cvhc-chat-btn"><div class="cvhc-card-icon icon-violet">' + I.chat + '</div><div class="cvhc-card-label">Chat with Us</div><div class="cvhc-card-desc">AI &amp; Live Agent</div></div>';
    if (cfg.sections.raise_complaint) quickCards += '<div class="cvhc-card" data-panel="complaint"><div class="cvhc-card-icon icon-red">' + I.alert + '</div><div class="cvhc-card-label">Raise a Complaint</div><div class="cvhc-card-desc">Report an issue</div></div>';

    // Build resource cards
    var resCards = '';
    if (cfg.sections.faqs && cfg.faq) resCards += '<div class="cvhc-card" data-panel="faq"><div class="cvhc-card-icon icon-sky">' + I.faq + '</div><div class="cvhc-card-label">FAQs</div><div class="cvhc-card-desc">Common questions</div></div>';
    if (cfg.sections.our_policies && (cfg.shipping || cfg.return_policy)) resCards += '<div class="cvhc-card" data-panel="policy"><div class="cvhc-card-icon icon-slate">' + I.doc + '</div><div class="cvhc-card-label">Our Policies</div><div class="cvhc-card-desc">Shipping &amp; returns</div></div>';
    // Custom sections
    cfg.custom_sections.forEach(function(cs, idx) {
      resCards += '<div class="cvhc-card" data-panel="custom_' + idx + '"><div class="cvhc-card-icon icon-sky">' + I.faq + '</div><div class="cvhc-card-label">' + esc(cs.label) + '</div><div class="cvhc-card-desc">Tap to view</div></div>';
    });

    var heroGrad = root.style.getPropertyValue('--cv-hero-bg') || 'linear-gradient(135deg,#1e3a8a 0%,#1d4ed8 40%,#2563eb 70%,#3b82f6 100%)';

    main.innerHTML =
    '<div class="cvhc-hero" style="background:' + heroGrad + '">' +
      '<div class="cvhc-hero-orb"></div><div class="cvhc-hero-orb"></div><div class="cvhc-hero-orb"></div>' +
      '<div class="cvhc-hero-glow"></div>' +
      logoHtml +
      '<div class="cvhc-badge"><span class="cvhc-badge-dot"></span>We&rsquo;re here to help</div>' +
      '<div class="cvhc-hero-title">How can we help<br>you today?</div>' +
      '<div class="cvhc-hero-sub">' + esc(cfg.name) + ' &mdash; Support Center</div>' +
    '</div>' +
    '<div class="cvhc-body">' +
      (quickCards ? '<div class="cvhc-section-label">Quick Actions</div><div class="cvhc-grid">' + quickCards + '</div>' : '') +
      (resCards   ? '<div class="cvhc-section-label" style="margin-top:20px">Resources</div><div class="cvhc-grid-2">' + resCards + '</div>' : '') +
    '</div>';

    root.appendChild(main);

    // Powered by
    var pow = document.createElement('div');
    pow.className = 'cvhc-pow';
    pow.innerHTML = 'Powered by <a href="https://codverify.tech" target="_blank" rel="noopener">&nbsp;CODVerify</a>';
    root.appendChild(pow);

    // Panels
    addPanel('track',    'linear-gradient(145deg,#1d4ed8,#2563eb)',   I.truck, 'Track My Order',         'Enter your order details below',      trackBody());
    addPanel('return',   'linear-gradient(145deg,#b45309,#d97706)',   I.ret,   'Return / Exchange',       'Submit your return or exchange request', returnBody());
    addPanel('callback', 'linear-gradient(145deg,#047857,#10b981)',   I.phone, 'Request a Callback',      'We\'ll call you back as soon as possible', callbackBody());
    addPanel('faq',      'linear-gradient(145deg,#0369a1,#0ea5e9)',   I.faq,   'Frequently Asked Questions', 'Quick answers to common questions',   faqBody());
    addPanel('policy',   'linear-gradient(145deg,#3730a3,#6366f1)',   I.doc,   'Our Policies',            'Shipping, return and refund policies', policyBody());
    addPanel('complaint','linear-gradient(145deg,#b91c1c,#ef4444)',   I.alert, 'Raise a Complaint',       'Tell us about your issue',            complaintBody());

    // Custom section panels
    cfg.custom_sections.forEach(function(cs, idx) {
      addPanel('custom_' + idx, 'linear-gradient(145deg,#0369a1,#0ea5e9)', I.faq, esc(cs.label), 'Information', '<p style="line-height:1.8;color:var(--cv-text-2);font-size:14px;white-space:pre-wrap;">' + esc(cs.content || '') + '</p>');
    });

    attachEvents();
  }

  function addPanel(id, grad, icon, title, subtitle, bodyHtml) {
    var p = document.createElement('div');
    p.className = 'cvhc-panel'; p.id = 'cvhc-p-' + id;
    p.innerHTML = `
    <div class="cvhc-panel-hero" style="background:${grad}">
      <button class="cvhc-panel-back" id="cvhc-back-${id}">${I.back} Back</button>
      <div class="cvhc-panel-icon">${icon}</div>
      <div class="cvhc-panel-title">${title}</div>
      <div class="cvhc-panel-subtitle">${subtitle}</div>
    </div>
    <div class="cvhc-panel-body">
      <div class="cvhc-form-card">${bodyHtml}</div>
    </div>`;
    root.appendChild(p);
    document.getElementById('cvhc-back-' + id).onclick = function () { closePanel(id); };
  }

  function open2(id) { var p = document.getElementById('cvhc-p-' + id); if (p) setTimeout(function () { p.classList.add('open'); }, 10); }
  function closePanel(id) { var p = document.getElementById('cvhc-p-' + id); if (p) p.classList.remove('open'); }

  // ── Panel body templates ──────────────────────────────────────────────

  function complaintBody() {
    var chevSvg = '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" style="width:16px;height:16px"><polyline points="6 9 12 15 18 9"/></svg>';
    return `
  <div class="cvhc-fg">
    <label class="cvhc-label"><span class="cvhc-label-dot"></span>Your Name <span style="color:#ef4444">*</span></label>
    <div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div>
      <input class="cvhc-input" id="cv-cmp-name" placeholder="Full name" />
    </div>
  </div>
  <div class="cvhc-fg">
    <label class="cvhc-label"><span class="cvhc-label-dot"></span>Email Address</label>
    <div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div>
      <input class="cvhc-input" id="cv-cmp-email" type="email" placeholder="your@email.com" />
    </div>
  </div>
  <div class="cvhc-fg">
    <label class="cvhc-label"><span class="cvhc-label-dot"></span>Phone Number</label>
    <div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div>
      <input class="cvhc-input" id="cv-cmp-phone" type="tel" placeholder="+91 98765 43210" />
    </div>
  </div>
  <div class="cvhc-fg">
    <label class="cvhc-label"><span class="cvhc-label-dot"></span>Order Number <span style="font-weight:400;opacity:.6;text-transform:none;letter-spacing:0">(optional)</span></label>
    <div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div>
      <input class="cvhc-input" id="cv-cmp-order" placeholder="e.g. #1234 or ORD-5678" />
    </div>
  </div>
  <div class="cvhc-fg">
    <label class="cvhc-label"><span class="cvhc-label-dot"></span>Subject <span style="color:#ef4444">*</span></label>
    <div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div>
      <input class="cvhc-input" id="cv-cmp-subj" placeholder="Brief description of your complaint" />
    </div>
  </div>
  <div class="cvhc-fg">
    <label class="cvhc-label"><span class="cvhc-label-dot"></span>Details <span style="color:#ef4444">*</span></label>
    <div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div>
      <textarea class="cvhc-textarea" id="cv-cmp-desc" rows="4" placeholder="Please describe your issue in detail..."></textarea>
    </div>
  </div>
  <div id="cv-cmp-msg"></div>
  <button class="cvhc-btn" id="cv-cmp-btn" style="background:linear-gradient(135deg,#ef4444 0%,#b91c1c 100%);box-shadow:0 6px 20px rgba(185,28,28,.4);">
    ${I.alert}<span>Submit Complaint</span>
  </button>`;
  }

  function trackBody() {
    return `
  <div class="cvhc-fg">
    <label class="cvhc-label"><span class="cvhc-label-dot"></span>Order Number</label>
    <div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div>
      <input class="cvhc-input" id="cv-tor" placeholder="e.g. #1234 or ORD-5678" />
    </div>
  </div>
  <div class="cvhc-fg">
    <label class="cvhc-label"><span class="cvhc-label-dot"></span>Email or Phone Number</label>
    <div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div>
      <input class="cvhc-input" id="cv-tct" placeholder="Registered email or phone" />
    </div>
  </div>
  <div id="cv-tmsg"></div>
  <button class="cvhc-btn btn-blue" id="cv-tbtn">${I.search}<span>Track My Order</span></button>
  <div id="cv-tres"></div>`;
  }

  function returnBody() {
    // Build request type options — no refund, only return/exchange enabled by merchant
    var typeOptions = '';
    if (cfg.return_enabled) {
      typeOptions += '<option value="return">Return (send product back)</option>';
    }
    if (cfg.exchange_enabled) {
      typeOptions += '<option value="exchange">Exchange (swap product)</option>';
    }
    // If neither is enabled, show a message
    if (!typeOptions) {
      return '<div class="cvhc-alert alert-warn">' + I.warn + '<span>Returns &amp; exchanges are not available for this store at this time.</span></div>';
    }

    // Build dynamic exchange option fields
    var chevSvg = '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" class="cvhc-select-arrow"><polyline points="6 9 12 15 18 9"/></svg>';
    var exchangeFieldsHtml = '';
    if (cfg.exchange_enabled && cfg.exchange_options.length > 0) {
      cfg.exchange_options.forEach(function(opt, idx) {
        var fieldId = 'cv-rex-' + idx;
        var labelHtml = '<label class="cvhc-label"><span class="cvhc-label-dot"></span>' + esc(opt.label || 'Option') + ' <span style="font-weight:400;opacity:.6;text-transform:none;letter-spacing:0">(for exchange)</span></label>';
        var inputHtml = '';
        if (opt.type === 'select' && Array.isArray(opt.choices) && opt.choices.length > 0) {
          inputHtml = '<div class="cvhc-select-wrap">' + chevSvg + '<select class="cvhc-select cv-rex-field" id="' + fieldId + '">';
          inputHtml += '<option value="">-- Select ' + esc(opt.label) + ' --</option>';
          opt.choices.forEach(function(c) {
            inputHtml += '<option value="' + esc(c) + '">' + esc(c) + '</option>';
          });
          inputHtml += '</select></div>';
        } else {
          inputHtml = '<div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div><input class="cvhc-input cv-rex-field" id="' + fieldId + '" placeholder="Enter ' + esc(opt.label) + '" /></div>';
        }
        exchangeFieldsHtml += '<div class="cvhc-fg cv-exchange-row" style="display:none" data-opt-idx="' + idx + '">' + labelHtml + inputHtml + '</div>';
      });
    } else if (cfg.exchange_enabled) {
      exchangeFieldsHtml = '<div class="cvhc-fg cv-exchange-row" style="display:none"><label class="cvhc-label"><span class="cvhc-label-dot"></span>Preferred Replacement <span style="font-weight:400;opacity:.6;text-transform:none;letter-spacing:0">(for exchange)</span></label><div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div><input class="cvhc-input" id="cv-rex-0" placeholder="Describe what you want instead…" /></div></div>';
    }

    var chev = '<svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" class="cvhc-select-arrow"><polyline points="6 9 12 15 18 9"/></svg>';

    return `
  <div class="cvhc-alert alert-info" style="margin-bottom:18px">${I.info}<span>Returns accepted within <strong>${cfg.return_days} days</strong> of order date.</span></div>
  <div class="cvhc-fg">
    <label class="cvhc-label"><span class="cvhc-label-dot"></span>Order Number <span style="color:#ef4444">*</span></label>
    <div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div>
      <input class="cvhc-input" id="cv-ror" placeholder="#1234" />
    </div>
  </div>
  <div class="cvhc-fg">
    <label class="cvhc-label"><span class="cvhc-label-dot"></span>Email or Phone <span style="color:#ef4444">*</span></label>
    <div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div>
      <input class="cvhc-input" id="cv-rct" placeholder="Registered email or phone" />
    </div>
  </div>
  <div class="cvhc-fg">
    <label class="cvhc-label"><span class="cvhc-label-dot"></span>Request Type <span style="color:#ef4444">*</span></label>
    <div class="cvhc-select-wrap">${chev}
      <select class="cvhc-select" id="cv-rtype">${typeOptions}</select>
    </div>
  </div>
  ${exchangeFieldsHtml}
  <div class="cvhc-fg">
    <label class="cvhc-label"><span class="cvhc-label-dot"></span>Reason for Request <span style="color:#ef4444">*</span></label>
    <div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div>
      <textarea class="cvhc-textarea" id="cv-rrsn" placeholder="Describe the issue with your order…"></textarea>
    </div>
  </div>
  <div id="cv-rmsg"></div>
  <button class="cvhc-btn btn-amber" id="cv-rbtn">${I.ret}<span>Submit Request</span></button>`;
  }

  function callbackBody() {
    return `
  <div class="cvhc-fg">
    <label class="cvhc-label"><span class="cvhc-label-dot"></span>Your Name</label>
    <div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div>
      <input class="cvhc-input" id="cv-cnm" placeholder="Full name" />
    </div>
  </div>
  <div class="cvhc-fg">
    <label class="cvhc-label"><span class="cvhc-label-dot"></span>Phone Number</label>
    <div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div>
      <input class="cvhc-input" id="cv-cph" type="tel" placeholder="+91 98XXX XXXXX" />
    </div>
  </div>
  <div class="cvhc-fg">
    <label class="cvhc-label"><span class="cvhc-label-dot"></span>Email <span style="font-weight:400;text-transform:none;letter-spacing:0;opacity:.7">(optional)</span></label>
    <div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div>
      <input class="cvhc-input" id="cv-cem" type="email" placeholder="you@example.com" />
    </div>
  </div>
  <div class="cvhc-fg">
    <label class="cvhc-label"><span class="cvhc-label-dot"></span>What do you need help with?</label>
    <div class="cvhc-input-wrap"><div class="cvhc-input-accent"></div>
      <textarea class="cvhc-textarea" id="cv-crs" placeholder="Briefly describe your query…"></textarea>
    </div>
  </div>
  <div id="cv-cmsg"></div>
  <button class="cvhc-btn btn-emerald" id="cv-cbtn">${I.phone}<span>Request Callback</span></button>`;
  }

  function faqBody() {
    if (!cfg.faq) return '<div class="cvhc-alert alert-info">' + I.info + '<span>No FAQs configured yet. Add FAQs in your chatbot settings.</span></div>';

    var raw = cfg.faq.trim();
    var items = [];

    // Try Q:/A: format first (standard scraper output)
    var lines = raw.split('\n');
    var i = 0;
    while (i < lines.length) {
      var qm = /^Q:\s*(.+)/i.exec(lines[i]);
      if (qm) {
        // collect answer — may span multiple A: lines or next line without prefix
        var ans = '';
        if (i + 1 < lines.length) {
          var am = /^A:\s*([\s\S]+)/i.exec(lines[i + 1]);
          if (am) { ans = am[1]; i += 2; }
          else { i++; }
        } else { i++; }
        if (qm[1].trim()) items.push({ q: qm[1].trim(), a: ans.trim() });
        continue;
      }
      i++;
    }

    // If Q/A parsing yielded nothing, try numbered "1. Question\nAnswer" style
    if (!items.length) {
      var numbered = raw.match(/^\d+[.)]\s*.+/gm);
      if (numbered && numbered.length >= 2) {
        numbered.forEach(function(line) {
          items.push({ q: line.replace(/^\d+[.)]\s*/, '').trim(), a: '' });
        });
      }
    }

    // Render as accordion if we have structured items
    if (items.length) {
      return items.map(function(it, idx) {
        return '<div class="cvhc-faq-item">'
          + '<div class="cvhc-faq-q" data-faq="' + idx + '">'
          + '<span>' + esc(it.q) + '</span>'
          + '<svg class="cvhc-faq-chev" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg>'
          + '</div>'
          + (it.a ? '<div class="cvhc-faq-a" id="cv-fa-' + idx + '">' + esc(it.a) + '</div>' : '')
          + '</div>';
      }).join('');
    }

    // Fallback: render as readable pre-formatted block
    return '<div style="font-size:13.5px;color:var(--cv-text-2);line-height:1.9;white-space:pre-wrap;background:#f8faff;border-radius:12px;padding:14px 16px;border:1px solid #e4ecf7">' + esc(raw) + '</div>';
  }

  function policyBody() {
    var h = '';
    var iconStyle = 'style="width:16px;height:16px;display:inline-flex;align-items:center;flex-shrink:0" ';
    // Small icon helper — strips the opening <svg to inject size attrs
    function sIcon(svgStr) {
      return svgStr.replace('<svg ', '<svg width="16" height="16" style="flex-shrink:0" ');
    }
    if (cfg.shipping) h += `
    <div style="margin-bottom:24px">
      <div style="font-size:12px;font-weight:700;color:var(--cv-text-2);letter-spacing:.5px;text-transform:uppercase;margin-bottom:12px;display:flex;align-items:center;gap:8px">
        ` + sIcon(I.truck) + ` Shipping Policy
      </div>
      <div style="font-size:13.5px;color:var(--cv-text-2);line-height:1.9;white-space:pre-wrap;background:#f8faff;border-radius:12px;padding:14px 16px;border:1px solid #e4ecf7">` + esc(cfg.shipping) + `</div>
    </div>`;
    if (cfg.return_policy) h += `
    <div>
      <div style="font-size:12px;font-weight:700;color:var(--cv-text-2);letter-spacing:.5px;text-transform:uppercase;margin-bottom:12px;display:flex;align-items:center;gap:8px">
        ` + sIcon(I.ret) + ` Return &amp; Refund Policy
      </div>
      <div style="font-size:13.5px;color:var(--cv-text-2);line-height:1.9;white-space:pre-wrap;background:#f8faff;border-radius:12px;padding:14px 16px;border:1px solid #e4ecf7">` + esc(cfg.return_policy) + `</div>
    </div>`;
    return h || '<div class="cvhc-alert alert-info">' + I.info + '<span>No policies configured yet.</span></div>';
  }

  // ── Event bindings ────────────────────────────────────────────────────
  function attachEvents() {
    // ── Ripple effect on all buttons ──
    function addRipple(btn) {
      btn.addEventListener('click', function(e) {
        var r = document.createElement('span');
        r.className = 'cvhc-btn-ripple';
        var rect = btn.getBoundingClientRect();
        var size = Math.max(rect.width, rect.height);
        r.style.cssText = 'width:' + size + 'px;height:' + size + 'px;left:' + (e.clientX - rect.left - size/2) + 'px;top:' + (e.clientY - rect.top - size/2) + 'px;';
        btn.appendChild(r);
        setTimeout(function() { if (r.parentNode) r.parentNode.removeChild(r); }, 600);
      });
    }
    root.querySelectorAll('.cvhc-btn').forEach(addRipple);

    root.querySelectorAll('[data-panel]').forEach(function (el) {
      el.onclick = function () { open2(el.getAttribute('data-panel')); };
    });
    var chat = document.getElementById('cvhc-chat-btn');
    if (chat) chat.onclick = function () { var w = document.getElementById('cvw-btn'); w ? w.click() : open2('callback'); };

    // ── Track order ──
    var tbtn = document.getElementById('cv-tbtn');
    if (tbtn) {
      var torig = tbtn.innerHTML;
      tbtn.onclick = function () {
        var o = val('cv-tor'), c = val('cv-tct');
        var msg = document.getElementById('cv-tmsg'), res = document.getElementById('cv-tres');
        if (!o || !c) { alert2(msg, 'err', 'Please fill in both fields.'); return; }
        setBtn(tbtn, true, torig); msg.innerHTML = ''; res.innerHTML = '';
        post(HC_BASE + '/track', { api_key: API_KEY, order_number: o, contact: c }, function (err, r) {
          setBtn(tbtn, false, torig);
          if (err || !r) { alert2(msg, 'err', 'Network error. Please try again.'); return; }
          if (!r.success) { alert2(msg, r.error === 'verification_failed' ? 'warn' : 'err', r.message || 'Order not found.'); return; }
          renderTrack(r.data.order);
          alert2(msg, 'ok', 'Tracking details loaded successfully.');
        });
      };
    }

    // Exchange field toggle — show/hide per exchange_options when type = exchange
    var rtype = document.getElementById('cv-rtype');
    if (rtype) {
      rtype.onchange = function () {
        var isExchange = rtype.value === 'exchange';
        root.querySelectorAll('.cv-exchange-row').forEach(function(row) {
          row.style.display = isExchange ? 'block' : 'none';
        });
      };
    }

    // ── Return submit ──
    var rbtn = document.getElementById('cv-rbtn');
    if (rbtn) {
      var rorig = rbtn.innerHTML;
      rbtn.onclick = function () {
        var o = val('cv-ror'), c = val('cv-rct'), t = val('cv-rtype') || 'return', rsn = val('cv-rrsn');
        var msg = document.getElementById('cv-rmsg');
        if (!o || !c || !rsn) { alert2(msg, 'err', 'Please fill all required fields.'); return; }

        // Collect all exchange option values as a summary string
        var exchangeSummary = '';
        if (t === 'exchange') {
          var parts = [];
          cfg.exchange_options.forEach(function(opt, idx) {
            var el = document.getElementById('cv-rex-' + idx);
            var v = el ? el.value.trim() : '';
            if (v) parts.push(opt.label + ': ' + v);
          });
          // If no structured options, check the free-text field
          if (parts.length === 0) {
            var freeEl = document.getElementById('cv-rex-0');
            if (freeEl && freeEl.value.trim()) parts.push(freeEl.value.trim());
          }
          exchangeSummary = parts.join(' | ');
        }

        setBtn(rbtn, true, rorig); msg.innerHTML = '';
        post(HC_BASE + '/return', {
          api_key: API_KEY,
          order_number: o,
          contact: c,
          request_type: t,
          reason: rsn,
          exchange_size: exchangeSummary || null
        }, function (err, r) {
          setBtn(rbtn, false, rorig);
          if (err || !r) { alert2(msg, 'err', 'Network error. Please try again.'); return; }
          if (!r.success) { alert2(msg, r.error === 'window_expired' ? 'warn' : 'err', r.message || 'Error.'); return; }
          alert2(msg, 'ok', r.data.message || 'Request submitted successfully!'); rbtn.style.display = 'none';
        });
      };
    }

    // ── Callback submit ──
    var cbtn = document.getElementById('cv-cbtn');
    if (cbtn) {
      var corig = cbtn.innerHTML;
      cbtn.onclick = function () {
        var nm = val('cv-cnm'), ph = val('cv-cph'), em = val('cv-cem'), rs = val('cv-crs');
        var msg = document.getElementById('cv-cmsg');
        if (!nm || !ph) { alert2(msg, 'err', 'Name and phone are required.'); return; }
        setBtn(cbtn, true, corig); msg.innerHTML = '';
        post(HC_BASE + '/callback', { api_key: API_KEY, visitor_name: nm, visitor_phone: ph, visitor_email: em, reason: rs }, function (err, r) {
          setBtn(cbtn, false, corig);
          if (err || !r) { alert2(msg, 'err', 'Network error. Please try again.'); return; }
          if (!r.success) { alert2(msg, 'err', r.message || 'Error.'); return; }
          alert2(msg, 'ok', r.data.message || 'Callback requested!'); cbtn.style.display = 'none';
        });
      };
    }

    // FAQ accordion
    root.querySelectorAll('[data-faq]').forEach(function (el) {
      el.onclick = function () {
        var idx = el.getAttribute('data-faq');
        var a = document.getElementById('cv-fa-' + idx);
        var ch = el.querySelector('.cvhc-faq-chev');
        var isOpen = a && a.classList.contains('open');
        // Close all others first
        root.querySelectorAll('.cvhc-faq-q.open').forEach(function(oq) {
          if (oq !== el) {
            oq.classList.remove('open');
            var oi = oq.getAttribute('data-faq');
            var oa = document.getElementById('cv-fa-' + oi);
            var och = oq.querySelector('.cvhc-faq-chev');
            if (oa) oa.classList.remove('open');
            if (och) och.classList.remove('open');
          }
        });
        if (!isOpen) {
          el.classList.add('open');
          if (a) a.classList.add('open');
          if (ch) ch.classList.add('open');
        } else {
          el.classList.remove('open');
          if (a) a.classList.remove('open');
          if (ch) ch.classList.remove('open');
        }
      };
    });

    // ── Complaint submit ──
    var cmpBtn = document.getElementById('cv-cmp-btn');
    if (cmpBtn) {
      var cmpOrig = cmpBtn.innerHTML;
      cmpBtn.onclick = function () {
        var nm   = val('cv-cmp-name');
        var subj = val('cv-cmp-subj');
        var desc = val('cv-cmp-desc');
        var msg  = document.getElementById('cv-cmp-msg');
        if (!nm || !subj || !desc) { alert2(msg, 'err', 'Name, subject and details are required.'); return; }
        setBtn(cmpBtn, true, cmpOrig); msg.innerHTML = '';
        post(HC_BASE + '/complaint', {
          api_key: API_KEY,
          customer_name: nm,
          customer_email: val('cv-cmp-email') || null,
          customer_phone: val('cv-cmp-phone') || null,
          order_number:   val('cv-cmp-order') || null,
          subject:        subj,
          description:    desc,
        }, function (err, r) {
          setBtn(cmpBtn, false, cmpOrig);
          if (err || !r) { alert2(msg, 'err', 'Network error. Please try again.'); return; }
          if (!r.success) { alert2(msg, 'err', r.message || 'Error submitting complaint.'); return; }
          var ref = (r.data && r.data.reference) ? ' (Ref: ' + r.data.reference + ')' : '';
          alert2(msg, 'ok', 'Complaint submitted' + ref + '. We\'ll get back to you soon!');
          cmpBtn.style.display = 'none';
          ['cv-cmp-name','cv-cmp-email','cv-cmp-phone','cv-cmp-order','cv-cmp-subj','cv-cmp-desc'].forEach(function(id) {
            var el = document.getElementById(id); if (el) el.value = '';
          });
        });
      };
    }
  }

  // ── Tracking result render ────────────────────────────────────────────
  var STEPS = [
    { keys: ['pending', 'processing'], label: 'Order Placed', icon: I.clipboard },
    { keys: ['shipped', 'dispatched'], label: 'Shipped', icon: I.truck },
    { keys: ['out_for_delivery'], label: 'Out for Delivery', icon: I.mappin },
    { keys: ['delivered'], label: 'Delivered', icon: I.checkcircle },
  ];

  function renderTrack(order) {
    var raw = (order.delivery_status_raw || '').toLowerCase();
    var ai = -1;
    STEPS.forEach(function (s, i) { if (s.keys.some(function (k) { return raw.includes(k); })) ai = i; });
    if (raw === 'delivered') ai = 3;

    var tl = STEPS.map(function (s, i) {
      var done = i < ai, active = i === ai || (ai === -1 && i === 0);
      return '<div class="cvhc-step">'
        + '<div class="cvhc-step-line"></div>'
        + '<div class="cvhc-dot ' + (done ? 'dot-done' : active ? 'dot-active' : 'dot-pending') + '">' + s.icon + '</div>'
        + '<div class="cvhc-step-body">'
        + '<div class="cvhc-step-label' + (active ? ' active' : '') + '">' + s.label + '</div>'
        + (active ? '<div class="cvhc-step-sub">Current status</div>' : '')
        + '</div></div>';
    }).join('');

    var amt = order.order_amount ? (order.currency || 'INR') + ' ' + Number(order.order_amount).toLocaleString('en-IN') : '';

    var tbox = '';
    if (order.tracking_number) {
      var tv = order.tracking_url ? '<a href="' + esc(order.tracking_url) + '" target="_blank" style="color:var(--cv-p);font-weight:600">View Live Track</a>' : esc(order.tracking_number);
      tbox = '<div class="cvhc-tbox">'
        + '<div class="cvhc-tbox-title">' + I.signal + ' Tracking Details</div>'
        + '<div class="cvhc-trow"><span class="cvhc-tlabel">Courier</span><span class="cvhc-tval">' + esc(order.tracking_company || '-') + '</span></div>'
        + '<div class="cvhc-trow"><span class="cvhc-tlabel">AWB No.</span><span class="cvhc-tval">' + esc(order.tracking_number) + '</span></div>'
        + (order.tracking_url ? '<div class="cvhc-trow"><span class="cvhc-tlabel">Live Track</span><span class="cvhc-tval">' + tv + '</span></div>' : '')
        + '</div>';
    }

    var elig = order.within_return_window;
    var badge = '<button class="cvhc-ret-badge ' + (elig ? 'badge-ok' : 'badge-exp') + '" id="cv-retbadge">'
      + (elig ? I.check + ' Return / Exchange eligible' : I.xCircle + ' Return window expired (' + cfg.return_days + ' days)')
      + '</button>';

    var prevWrap = root.querySelector('.cvhc-tmodal-wrap');
    if (prevWrap) prevWrap.remove();

    var wrap = document.createElement('div');
    wrap.className = 'cvhc-tmodal-wrap';
    var closeIcon = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path></svg>';
    
    wrap.innerHTML = '<div class="cvhc-tmodal">'
      + '<div class="cvhc-tm-head">'
      + '<button class="cvhc-tm-close">' + closeIcon + '</button>'
      + '<div class="cvhc-tm-num">Order #' + esc(order.order_number) + '</div>'
      + '<div class="cvhc-tm-name">' + esc(order.customer_name || '') + '</div>'
      + (amt ? '<div class="cvhc-tm-amt">' + amt + '</div>' : '')
      + '</div>'
      + '<div class="cvhc-tm-body">'
      + '<div class="cvhc-tl">' + tl + tbox + '<div style="margin-top:20px">' + badge + '</div></div>'
      + '</div>'
      + '</div>';
    
    root.appendChild(wrap);
    wrap.offsetHeight; // trigger reflow
    wrap.classList.add('open');

    var clsBtn = wrap.querySelector('.cvhc-tm-close');
    clsBtn.onclick = function () {
      wrap.classList.remove('open');
      setTimeout(function () { wrap.remove(); }, 350);
    };

    var rb = wrap.querySelector('#cv-retbadge');
    if (rb && elig) rb.onclick = function () { 
      clsBtn.click();
      closePanel('track'); 
      setTimeout(function () { open2('return'); }, 340); 
    };
  }

  // ── Boot ──────────────────────────────────────────────────────────────
  document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', init) : init();

})();