from enum import Enum


class UserRole(str, Enum):
    MERCHANT = "merchant"
    ADMIN = "admin"


class UserStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"
    TRIAL = "trial"


class StorePlatform(str, Enum):
    SHOPIFY = "shopify"
    WOOCOMMERCE = "woocommerce"
    CUSTOM = "custom"


class PlanType(str, Enum):
    TRIAL = "trial"
    PLAN_1 = "plan_1"
    PLAN_2 = "plan_2"
    PLAN_3 = "plan_3"
    ENTERPRISE = "enterprise"


class ChatbotTier(str, Enum):
    NONE = "none"
    BASIC = "chatbot_basic"
    AI = "chatbot_ai"
    FULL = "chatbot_full"


CHATBOT_TIER_FEATURES = {
    ChatbotTier.NONE: {
        "name": "No Chatbot",
        "description": "No chatbot on your store.",
        "features": [],
    },
    ChatbotTier.BASIC: {
        "name": "Basic Chatbot",
        "description": "A chatbot widget on your store with menu options and a human handoff button. Visitors can browse FAQs and request a support agent.",
        "features": [
            "Chatbot widget on your store",
            "Customizable menu options & FAQs",
            "Welcome message & branding",
            "Human handoff request button",
            "Conversation history",
        ],
    },
    ChatbotTier.AI: {
        "name": "AI Chatbot",
        "description": "Everything in Basic plus Groq-powered AI that automatically answers customer questions 24/7 based on your business information.",
        "features": [
            "Everything in Basic Chatbot",
            "Groq AI auto-responses (24/7)",
            "Trained on your business info, products & FAQs",
            "Hindi + English language support",
            "Smart handoff when AI can't resolve",
        ],
    },
    ChatbotTier.FULL: {
        "name": "AI Chatbot + Live Support",
        "description": "Everything in AI Chatbot plus a real-time live agent (worker) takeover system. Your support team can jump in to resolve complex queries directly in the chat.",
        "features": [
            "Everything in AI Chatbot",
            "Live agent (worker) takeover",
            "Real-time worker dashboard for chat",
            "Agent assignment & routing",
            "Full conversation audit trail",
            "Priority support queue",
        ],
    },
}


class BillingCycle(str, Enum):
    MONTHLY = "monthly"
    YEARLY = "yearly"


class SubscriptionStatus(str, Enum):
    ACTIVE = "active"
    EXPIRED = "expired"
    CANCELLED = "cancelled"
    PAST_DUE = "past_due"


class VerificationStatus(str, Enum):
    PENDING = "pending"
    QUEUED = "queued"
    SENT = "sent"
    DELIVERED = "delivered"
    READ = "read"
    CONFIRMED = "confirmed"
    CANCELLED = "cancelled"
    NO_REPLY = "no_reply"
    FAILED = "failed"
    NOT_ON_WHATSAPP = "not_on_whatsapp"
    MANUAL_CONFIRMED = "manual_confirmed"
    MANUAL_CANCELLED = "manual_cancelled"


class DeliveryStatus(str, Enum):
    PENDING = "pending"
    SHIPPED = "shipped"
    IN_TRANSIT = "in_transit"
    OUT_FOR_DELIVERY = "out_for_delivery"
    DELIVERED = "delivered"
    RETURNED = "returned"
    RTO = "rto"


class MessageDirection(str, Enum):
    OUTBOUND = "outbound"
    INBOUND = "inbound"


class MessageType(str, Enum):
    TEMPLATE = "template"
    INTERACTIVE = "interactive"
    TEXT = "text"
    BUTTON_REPLY = "button_reply"


class MessageStatus(str, Enum):
    QUEUED = "queued"
    SENT = "sent"
    DELIVERED = "delivered"
    READ = "read"
    FAILED = "failed"


class TemplateType(str, Enum):
    ORDER_CONFIRMATION = "order_confirmation"
    DELIVERY_UPDATE = "delivery_update"
    FOLLOW_UP = "follow_up"
    CUSTOM = "custom"


class ApprovalStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class TransactionType(str, Enum):
    SUBSCRIPTION = "subscription"
    EXTRA_USAGE = "extra_usage"
    REFUND = "refund"
    CREDIT = "credit"
    WALLET_RECHARGE = "wallet_recharge"
    WALLET_DEBIT = "wallet_debit"
    WALLET_ADMIN_CREDIT = "wallet_admin_credit"


class TransactionStatus(str, Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"
    REFUNDED = "refunded"


class TicketStatus(str, Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    WAITING_ON_CUSTOMER = "waiting_on_customer"
    RESOLVED = "resolved"
    CLOSED = "closed"


class TicketPriority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"


class NotificationType(str, Enum):
    INFO = "info"
    SUCCESS = "success"
    WARNING = "warning"
    ERROR = "error"


PLAN_DETAILS = {
    PlanType.TRIAL: {
        "name": "Free Trial",
        "price_monthly": 0,
        "price_yearly": 0,
        "quota": 50,
        "stores": 1,
        "features": ["Order Confirmation", "Basic Dashboard", "Email Support"],
    },
    PlanType.PLAN_1: {
        "name": "Order Confirmation",
        "price_monthly": 999,
        "price_yearly": 9590,
        "quota": 500,
        "stores": 2,
        "features": ["WhatsApp Order Verification", "Basic Analytics", "2 Store Connections", "Email Support", "API Access"],
    },
    PlanType.PLAN_2: {
        "name": "Order Confirmation + Delivery Updates",
        "price_monthly": 1999,
        "price_yearly": 19190,
        "quota": 500,
        "stores": 5,
        "features": ["Everything in Plan 1", "Delivery Updates via WhatsApp", "Advanced Analytics", "Risk Scoring", "5 Store Connections", "Priority Support"],
    },
    PlanType.PLAN_3: {
        "name": "Growth",
        "price_monthly": 3499,
        "price_yearly": 33590,
        "quota": 2000,
        "stores": 10,
        "features": ["Everything in Plan 2", "2000 Orders/month", "10 Store Connections", "Custom Templates", "Dedicated Support", "Webhook Integration"],
    },
    PlanType.ENTERPRISE: {
        "name": "Enterprise",
        "price_monthly": None,
        "price_yearly": None,
        "quota": -1,
        "stores": -1,
        "features": ["Unlimited Orders", "Unlimited Stores", "Custom Integrations", "SLA", "Dedicated Account Manager", "Custom Pricing"],
    },
}

# Wallet System Constants
DEFAULT_PER_ORDER_RATE = 1.0  # ₹1 per order verification (admin can change)
WALLET_RECHARGE_OPTIONS = [
    {"amount": 100, "label": "₹100", "bonus": 0},
    {"amount": 500, "label": "₹500", "bonus": 25},
    {"amount": 1000, "label": "₹1,000", "bonus": 75},
    {"amount": 2500, "label": "₹2,500", "bonus": 250},
    {"amount": 5000, "label": "₹5,000", "bonus": 600},
    {"amount": 10000, "label": "₹10,000", "bonus": 1500},
]

POSITIVE_RESPONSES = [
    "yes", "haan", "ha", "haa", "confirm", "ok", "ship it", "bhej do",
    "ji", "ji ha", "confirmed", "sure", "done", "thik hai", "theek hai",
    "bilkul", "hnji", "han ji", "yes please", "ship karo"
]

NEGATIVE_RESPONSES = [
    "no", "nahi", "nhi", "cancel", "mat bhejo", "nope", "don't", "dont",
    "band karo", "cancel karo", "no thanks", "reject", "nope", "na",
    "mat karo", "ruko", "rok do", "cancel kar do"
]
