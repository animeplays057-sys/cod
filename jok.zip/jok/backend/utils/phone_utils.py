import re
import hashlib


def normalize_phone(phone: str) -> str:
    if not phone:
        return ""
    phone = phone.strip()
    # If looks like email — return empty (order will proceed without phone)
    if "@" in phone or re.match(r"^[^+\d]", phone):
        return ""
    phone = re.sub(r"[\s\-\(\)\.]", "", phone)
    if phone.startswith("0"):
        phone = phone[1:]
    if len(phone) == 10 and phone[0] in "6789":
        phone = "+91" + phone
    elif phone.startswith("91") and len(phone) == 12:
        phone = "+" + phone
    elif not phone.startswith("+"):
        phone = "+91" + phone
    # Final check — if still no digits after +, return empty
    if not re.search(r"\d{7,}", phone):
        return ""
    return phone


def validate_indian_phone(phone: str) -> bool:
    normalized = normalize_phone(phone)
    return bool(re.match(r"^\+91[6-9]\d{9}$", normalized))


def mask_phone(phone: str) -> str:
    if len(phone) >= 10:
        return phone[:4] + "****" + phone[-2:]
    return "****"


def phone_last_four(phone: str) -> str:
    digits = re.sub(r"\D", "", phone)
    return digits[-4:] if len(digits) >= 4 else digits


def hash_phone(phone: str) -> str:
    normalized = normalize_phone(phone)
    return hashlib.sha256(normalized.encode()).hexdigest()
