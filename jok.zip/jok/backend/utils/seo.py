import httpx
import os
import logging

logger = logging.getLogger(__name__)

async def ping_indexnow(url: str):
    """
    Pings the Bing / IndexNow API to notify search engines of a new or updated URL.
    Requires INDEXNOW_KEY to be set in the environment variables.
    """
    # Note: the user will add INDEXNOW_KEY to .env later.
    indexnow_key = os.getenv("INDEXNOW_KEY")
    if not indexnow_key:
        logger.warning("INDEXNOW_KEY not found in environment, skipping IndexNow ping for URL: %s", url)
        return False
        
    host = os.getenv("FRONTEND_URL", "https://codverify.tech").replace("https://", "").replace("http://", "").strip("/")
    
    payload = {
        "host": host,
        "key": indexnow_key,
        "keyLocation": f"https://{host}/{indexnow_key}.txt",
        "urlList": [url]
    }
    
    endpoint = "https://api.indexnow.org/IndexNow"
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(endpoint, json=payload, headers={"Content-Type": "application/json; charset=utf-8"}, timeout=10.0)
            if response.status_code in [200, 202]:
                logger.info("Successfully pinged IndexNow for URL: %s", url)
                return True
            else:
                logger.error("Failed to ping IndexNow. Status Code: %s, Response: %s", response.status_code, response.text)
                return False
    except Exception as e:
        logger.error("Exception occurred while pinging IndexNow: %s", str(e))
        return False
