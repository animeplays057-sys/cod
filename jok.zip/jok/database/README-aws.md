# CODVerify — Database Migration Guide (Supabase)

Supabase database stays **unchanged** when moving to AWS.
Only the backend compute (server) is changing — your data is safe.

## Migration Run Order

Run these SQL files **in order** in the Supabase SQL Editor
(Dashboard → SQL Editor → New Query → paste file content → Run):

```
1.  migration.sql                    ← Core tables (users, merchants, orders)
2.  migration_part2.sql              ← Additional columns and indexes
3.  countries_migration.sql          ← Countries/phone codes table
4.  shopify_migration.sql            ← Shopify OAuth & stores
5.  shopify_key_migration.sql        ← Shopify API key columns
6.  reviews_migration.sql            ← Product reviews table
7.  contracts_migration.sql          ← Merchant contracts
8.  contracts_payment_upgrade.sql    ← Payment fields on contracts
9.  chatbot_tier_migration.sql       ← Chatbot tier configuration
10. merchant_chatbot_migration.sql   ← Merchant chatbot settings
11. all_orders_callback_migration.sql ← Callback request tables
12. worker_migration.sql             ← Worker/agent tables
13. fix_verification_enum.sql        ← Fix verification status enum
14. fix_contracts_fk.sql             ← Fix foreign key constraints
15. fix_merchant_blacklist.sql       ← Merchant blacklist fixes
16. fix_callback_schema_cache.sql    ← Callback schema cache fix
17. remove_twilio_plivo.sql          ← Remove old SMS provider columns
18. seed_data.sql                    ← Default/seed data
19. seed_reviews.sql                 ← Sample reviews (optional)
```

## After AWS Migration — Only Update These

When you move the backend from HuggingFace to AWS, you only need to update:

1. **Meta (WhatsApp)** Webhook URL in Meta Business Dashboard:
   - Old: `https://smile2112-codverify.hf.space/api/v1/webhooks/whatsapp`
   - New: `https://api.codverify.tech/api/v1/webhooks/whatsapp`

2. **Shopify Partner Dashboard** → App URLs:
   - App URL: `https://api.codverify.tech/shopify/auth`
   - Redirect URLs: `https://api.codverify.tech/shopify/auth/callback`
   - Webhook endpoint: `https://api.codverify.tech/api/v1/webhooks/shopify/{shop}`

3. **Cloudflare Pages** → Environment Variables:
   - `VITE_API_URL` = `https://api.codverify.tech`

4. **backend/.env** on EC2:
   - `BACKEND_URL=https://api.codverify.tech`

> **Everything in Supabase (tables, RLS rules, functions) stays 100% unchanged.**
