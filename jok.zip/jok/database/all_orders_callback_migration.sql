-- ═══════════════════════════════════════════════════════════════
-- Migration: All Order Types Sync + Callback Requests + Tracking
-- ═══════════════════════════════════════════════════════════════

-- 1. Add new columns to orders table for all order types
ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_method VARCHAR(50) DEFAULT 'cod';
ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_status VARCHAR(50) DEFAULT 'pending';
ALTER TABLE orders ADD COLUMN IF NOT EXISTS order_type VARCHAR(50) DEFAULT 'cod'; -- cod, prepaid, manual
ALTER TABLE orders ADD COLUMN IF NOT EXISTS fulfillment_status VARCHAR(50) DEFAULT 'unfulfilled'; -- unfulfilled, partial, fulfilled
ALTER TABLE orders ADD COLUMN IF NOT EXISTS tracking_number VARCHAR(255);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS tracking_url TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS tracking_company VARCHAR(100);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivery_status VARCHAR(50) DEFAULT 'pending'; -- pending, shipped, in_transit, out_for_delivery, delivered, returned
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivery_updated_at TIMESTAMPTZ;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS source VARCHAR(50) DEFAULT 'shopify'; -- shopify, woocommerce, manual
ALTER TABLE orders ADD COLUMN IF NOT EXISTS customer_address TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS tags TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS notes TEXT;

-- 2. Callback requests table (permanent, works even when workers are online)
CREATE TABLE IF NOT EXISTS callback_requests (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    merchant_id UUID REFERENCES users(id),
    visitor_name VARCHAR(255) NOT NULL,
    visitor_phone VARCHAR(50) NOT NULL,
    visitor_email VARCHAR(255),
    reason TEXT,
    status VARCHAR(50) DEFAULT 'pending', -- pending, in_progress, resolved, cancelled
    assigned_worker_id UUID REFERENCES users(id),
    resolved_by_worker_id UUID REFERENCES users(id),
    resolution_notes TEXT,
    source VARCHAR(50) DEFAULT 'chatbot_widget', -- chatbot_widget, chatbot_offline
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    resolved_at TIMESTAMPTZ
);

-- 3. Add store_name to worker display (workers are linked to merchants via assigned orders/chats)
-- Add assigned_merchant_ids to track which merchants a worker serves
ALTER TABLE users ADD COLUMN IF NOT EXISTS assigned_store_names TEXT; -- comma-separated store names for display

-- 4. Indexes for performance
CREATE INDEX IF NOT EXISTS idx_orders_order_type ON orders(order_type);
CREATE INDEX IF NOT EXISTS idx_orders_payment_method ON orders(payment_method);
CREATE INDEX IF NOT EXISTS idx_orders_delivery_status ON orders(delivery_status);
CREATE INDEX IF NOT EXISTS idx_callback_requests_merchant ON callback_requests(merchant_id);
CREATE INDEX IF NOT EXISTS idx_callback_requests_worker ON callback_requests(assigned_worker_id);
CREATE INDEX IF NOT EXISTS idx_callback_requests_status ON callback_requests(status);
CREATE INDEX IF NOT EXISTS idx_orders_tracking ON orders(tracking_number);
