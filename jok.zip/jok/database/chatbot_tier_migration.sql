-- Add chatbot_tier column to contracts and merchant_chatbot_config tables.
-- These columns were referenced in backend code but never defined in the original migrations.
-- Run this migration once against your Supabase database.

-- 1. Add chatbot_tier to contracts
ALTER TABLE contracts
    ADD COLUMN IF NOT EXISTS chatbot_tier TEXT NOT NULL DEFAULT 'none'
    CHECK (chatbot_tier IN ('none', 'chatbot_basic', 'chatbot_ai', 'chatbot_full'));

-- 2. Add chatbot_tier to merchant_chatbot_config
ALTER TABLE merchant_chatbot_config
    ADD COLUMN IF NOT EXISTS chatbot_tier TEXT NOT NULL DEFAULT 'chatbot_basic'
    CHECK (chatbot_tier IN ('none', 'chatbot_basic', 'chatbot_ai', 'chatbot_full'));

-- 3. For any existing active contracts that had a chatbot tier implicitly assumed,
--    default them to 'chatbot_basic' (already done by the column default above).
--    If you want to retroactively set 'chatbot_ai' for specific contracts, run:
--    UPDATE contracts SET chatbot_tier = 'chatbot_ai' WHERE id IN ('<uuid1>', '<uuid2>');

-- 4. Sync chatbot_tier into merchant_chatbot_config for already-active contracts
--    so existing merchants get the right tier without needing manual intervention.
UPDATE merchant_chatbot_config mcc
SET chatbot_tier = c.chatbot_tier
FROM contracts c
WHERE c.user_id = mcc.merchant_id
  AND c.status = 'active'
  AND c.chatbot_tier != 'none';
