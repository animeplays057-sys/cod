-- ============================================================
-- CODVerify — Contract-Based Business Model Migration
-- Run this in Supabase SQL Editor
-- ============================================================

-- 1. Contracts table
CREATE TABLE IF NOT EXISTS contracts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    contract_number TEXT UNIQUE NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('contract', 'monthly')) DEFAULT 'contract',
    status TEXT NOT NULL CHECK (status IN ('pending', 'active', 'expired', 'cancelled', 'completed')) DEFAULT 'pending',

    -- Services included
    services JSONB NOT NULL DEFAULT '[]',
    -- e.g. [{"name":"SMS Verification","included":true},{"name":"Call Verification","included":true}, ...]

    -- Duration
    duration_months INTEGER NOT NULL DEFAULT 1,
    start_date TIMESTAMPTZ,
    end_date TIMESTAMPTZ,

    -- Financials
    total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
    advance_amount DECIMAL(12,2) NOT NULL DEFAULT 0,     -- pay now
    remaining_amount DECIMAL(12,2) NOT NULL DEFAULT 0,   -- after advance
    monthly_amount DECIMAL(12,2) NOT NULL DEFAULT 0,     -- for monthly plans
    currency TEXT NOT NULL DEFAULT 'INR',

    -- Admin notes
    notes TEXT,
    created_by UUID,  -- admin user id

    -- Timestamps
    accepted_at TIMESTAMPTZ,
    paid_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Invoices / Payment records
CREATE TABLE IF NOT EXISTS invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    contract_id UUID REFERENCES contracts(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    invoice_number TEXT UNIQUE NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('advance', 'monthly', 'one_time', 'refund')) DEFAULT 'monthly',
    status TEXT NOT NULL CHECK (status IN ('pending', 'paid', 'failed', 'refunded')) DEFAULT 'pending',

    amount DECIMAL(12,2) NOT NULL,
    currency TEXT NOT NULL DEFAULT 'INR',
    description TEXT,

    -- Razorpay
    razorpay_order_id TEXT,
    razorpay_payment_id TEXT,
    razorpay_signature TEXT,

    due_date TIMESTAMPTZ,
    paid_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Add contract reference to users
ALTER TABLE users ADD COLUMN IF NOT EXISTS account_status TEXT DEFAULT 'pending_activation'
    CHECK (account_status IN ('pending_activation', 'contract_pending', 'active', 'suspended', 'deactivated'));

-- 4. Indexes
CREATE INDEX IF NOT EXISTS idx_contracts_user_id ON contracts(user_id);
CREATE INDEX IF NOT EXISTS idx_contracts_status ON contracts(status);
CREATE INDEX IF NOT EXISTS idx_invoices_contract_id ON invoices(contract_id);
CREATE INDEX IF NOT EXISTS idx_invoices_user_id ON invoices(user_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);

-- 5. RLS Policies
ALTER TABLE contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own contracts" ON contracts
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all contracts" ON contracts
    FOR ALL USING (
        EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin')
    );

CREATE POLICY "Users can view own invoices" ON invoices
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all invoices" ON invoices
    FOR ALL USING (
        EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin')
    );
