-- ============================================================
-- CODVerify — Countries Table Migration
-- Run in Supabase SQL Editor (once)
-- ============================================================

CREATE TABLE IF NOT EXISTS countries (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    country_name    TEXT NOT NULL,
    country_code    TEXT NOT NULL,          -- E.164 prefix, e.g. '+91'
    country_iso     TEXT NOT NULL UNIQUE,   -- ISO-3166 alpha-2, e.g. 'IN'
    flag_emoji      TEXT,
    whatsapp_enabled BOOLEAN DEFAULT false,
    sms_enabled     BOOLEAN DEFAULT false,
    voice_enabled   BOOLEAN DEFAULT false,
    provider        TEXT NOT NULL,          -- 'facebook_whatsapp' | 'plivo'
    price_per_verification DECIMAL(10,4) NOT NULL,
    currency        TEXT NOT NULL DEFAULT 'USD',
    our_sms_cost    DECIMAL(10,4) DEFAULT 0,
    our_voice_cost  DECIMAL(10,4) DEFAULT 0,
    phone_format    TEXT,
    is_active       BOOLEAN DEFAULT true,
    restrictions    TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_countries_active ON countries (is_active);
CREATE INDEX IF NOT EXISTS idx_countries_iso    ON countries (country_iso);

-- ── Seed Data ─────────────────────────────────────────────

-- Clear existing rows to avoid duplicates (safe to re-run)
DELETE FROM countries WHERE country_iso IN ('IN', 'US', 'PH', 'MX', 'GB');

INSERT INTO countries (
    country_name, country_code, country_iso, flag_emoji,
    whatsapp_enabled, sms_enabled, voice_enabled,
    provider, price_per_verification, currency,
    our_sms_cost, our_voice_cost, phone_format,
    is_active, restrictions
) VALUES
-- India → WhatsApp only
(
    'India', '+91', 'IN', '🇮🇳',
    true, false, false,
    'facebook_whatsapp', 2.50, 'INR',
    0, 0, '+91XXXXXXXXXX',
    true, 'DLT required for SMS — WhatsApp only'
),
-- USA → Plivo SMS + Voice
(
    'USA', '+1', 'US', '🇺🇸',
    false, true, true,
    'plivo', 0.06, 'USD',
    0.005, 0.010, '+1XXXXXXXXXX',
    true, '10DLC registered'
),
-- Philippines → Plivo SMS + Voice
(
    'Philippines', '+63', 'PH', '🇵🇭',
    false, true, true,
    'plivo', 0.05, 'USD',
    0.020, 0.030, '+63XXXXXXXXXX',
    true, null
),
-- Mexico → Plivo SMS + Voice (Spanish)
(
    'Mexico', '+52', 'MX', '🇲🇽',
    false, true, true,
    'plivo', 0.04, 'USD',
    0.015, 0.015, '+52XXXXXXXXXX',
    true, null
),
-- United Kingdom → Plivo SMS + Voice
(
    'United Kingdom', '+44', 'GB', '🇬🇧',
    false, true, true,
    'plivo', 0.08, 'USD',
    0.040, 0.010, '+44XXXXXXXXXX',
    true, null
);

-- ============================================================
-- Verification Logs — ensure multi-country columns exist
-- ============================================================

-- Add country tracking to orders table (safe: IF NOT EXISTS)
ALTER TABLE orders
    ADD COLUMN IF NOT EXISTS country_iso TEXT,
    ADD COLUMN IF NOT EXISTS verification_channel TEXT,
    ADD COLUMN IF NOT EXISTS provider_used TEXT;

-- Update existing India orders
UPDATE orders
SET country_iso = 'IN', provider_used = 'facebook_whatsapp'
WHERE verification_channel = 'whatsapp'
  AND country_iso IS NULL;

-- Update existing USA Twilio orders → now Plivo
UPDATE orders
SET country_iso = 'US', provider_used = 'plivo'
WHERE verification_channel IN ('twilio_sms', 'plivo_sms')
  AND country_iso IS NULL;

-- Also rename old 'twilio_sms' channel values
UPDATE orders SET verification_channel = 'plivo_sms'
WHERE verification_channel = 'twilio_sms';

-- ============================================================
-- Usage Records — country-wise billing tracking
-- ============================================================

CREATE TABLE IF NOT EXISTS usage_records (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id        UUID,
    user_id         UUID,
    country_iso     TEXT NOT NULL,
    verification_method TEXT NOT NULL,  -- 'whatsapp', 'sms', 'voice'
    count           INTEGER DEFAULT 0,
    total_cost      DECIMAL(10,4) DEFAULT 0,
    total_charged   DECIMAL(10,4) DEFAULT 0,
    billing_period  TEXT NOT NULL,      -- 'YYYY-MM' e.g. '2025-01'
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (user_id, country_iso, verification_method, billing_period)
);

CREATE INDEX IF NOT EXISTS idx_usage_user_period
    ON usage_records (user_id, billing_period);
CREATE INDEX IF NOT EXISTS idx_usage_country
    ON usage_records (country_iso);
