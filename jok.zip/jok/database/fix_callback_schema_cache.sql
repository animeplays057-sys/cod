-- ═══════════════════════════════════════════════════════════════
-- Fix: callback_requests schema cache PGRST204 errors
-- Run this in Supabase SQL Editor
-- ═══════════════════════════════════════════════════════════════

-- 1. Add missing columns (IF NOT EXISTS prevents duplicate errors)
ALTER TABLE callback_requests ADD COLUMN IF NOT EXISTS resolved_by_worker_id UUID REFERENCES users(id);
ALTER TABLE callback_requests ADD COLUMN IF NOT EXISTS resolution_notes TEXT;
ALTER TABLE callback_requests ADD COLUMN IF NOT EXISTS resolved_at TIMESTAMPTZ;

-- 2. Force PostgREST to reload its schema cache immediately
-- (This is the key fix for PGRST204 "column not in schema cache" errors)
NOTIFY pgrst, 'reload schema';

-- 3. Verify the columns now exist
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'callback_requests'
ORDER BY ordinal_position;
