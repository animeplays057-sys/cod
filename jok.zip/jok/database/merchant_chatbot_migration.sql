-- ═══════════════════════════════════════════════════════════════════════
-- Merchant Chatbot System Migration
-- Adds: chatbot config per merchant, API usage tracking, rate limits
-- Run this in Supabase SQL Editor AFTER worker_migration.sql
-- ═══════════════════════════════════════════════════════════════════════

-- 1. Merchant Chatbot Configuration
CREATE TABLE IF NOT EXISTS merchant_chatbot_config (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    is_enabled boolean DEFAULT false,
    -- Business info for AI context
    business_name text NOT NULL DEFAULT '',
    business_description text DEFAULT '',
    business_services text DEFAULT '',
    business_website text DEFAULT '',
    business_faq text DEFAULT '',      -- Custom FAQs in text format
    welcome_message text DEFAULT 'Hi! 👋 How can I help you today?',
    -- Scripted menu options (JSON array)
    menu_options jsonb DEFAULT '[]',
    -- Branding
    primary_color text DEFAULT '#6366f1',
    bot_name text DEFAULT 'Support Bot',
    bot_avatar_url text,
    -- Rate limits
    monthly_request_limit int DEFAULT 100,
    current_month_usage int DEFAULT 0,
    usage_reset_date timestamptz DEFAULT (date_trunc('month', now()) + interval '1 month'),
    -- API key for embed widget
    api_key text UNIQUE DEFAULT encode(gen_random_bytes(24), 'hex'),
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    UNIQUE(merchant_id)
);

-- 2. Chatbot API Usage Tracking (per request log)
CREATE TABLE IF NOT EXISTS chatbot_api_usage (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id uuid NOT NULL REFERENCES users(id),
    session_id uuid REFERENCES chat_sessions(id),
    request_type text DEFAULT 'chat' CHECK (request_type IN ('chat', 'start', 'message')),
    visitor_ip text,
    created_at timestamptz DEFAULT now()
);

-- 3. Add source 'merchant_widget' to chat_sessions if not exists
ALTER TABLE chat_sessions DROP CONSTRAINT IF EXISTS chat_sessions_source_check;
ALTER TABLE chat_sessions ADD CONSTRAINT chat_sessions_source_check
    CHECK (source IN ('website', 'shopify', 'whatsapp', 'merchant_widget'));

-- 4. Add sender_type 'system' for join/leave notifications
ALTER TABLE chat_messages DROP CONSTRAINT IF EXISTS chat_messages_sender_type_check;
ALTER TABLE chat_messages ADD CONSTRAINT chat_messages_sender_type_check
    CHECK (sender_type IN ('visitor', 'ai', 'worker', 'system'));

-- 5. Indexes
CREATE INDEX IF NOT EXISTS idx_chatbot_config_merchant ON merchant_chatbot_config(merchant_id);
CREATE INDEX IF NOT EXISTS idx_chatbot_config_api_key ON merchant_chatbot_config(api_key);
CREATE INDEX IF NOT EXISTS idx_chatbot_usage_merchant ON chatbot_api_usage(merchant_id);
CREATE INDEX IF NOT EXISTS idx_chatbot_usage_date ON chatbot_api_usage(created_at);

-- 6. RLS
ALTER TABLE merchant_chatbot_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE chatbot_api_usage ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Service role full access" ON merchant_chatbot_config FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Service role full access" ON chatbot_api_usage FOR ALL USING (true) WITH CHECK (true);

-- 7. RPC function to increment chatbot usage counter atomically
CREATE OR REPLACE FUNCTION increment_chatbot_usage(p_merchant_id uuid)
RETURNS void AS $$
BEGIN
    UPDATE merchant_chatbot_config
    SET current_month_usage = current_month_usage + 1
    WHERE merchant_id = p_merchant_id;
END;
$$ LANGUAGE plpgsql;
