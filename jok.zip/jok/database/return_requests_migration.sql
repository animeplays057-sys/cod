-- ═══════════════════════════════════════════════════════════════════════
-- Return & Refund Requests Migration
-- Adds: return_requests table + return/refund policy days in chatbot config
-- Run this in Supabase SQL Editor AFTER merchant_chatbot_migration.sql
-- ═══════════════════════════════════════════════════════════════════════

-- 1. Return/Refund Requests Table
--    Stores full context: order info, customer info, merchant website info
CREATE TABLE IF NOT EXISTS return_requests (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),

    -- Merchant (owner of this request)
    merchant_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,

    -- Website / Store info (so worker & admin know which website it came from)
    store_name text,
    store_url  text,
    platform   text,   -- 'shopify' | 'woocommerce' | 'generic'

    -- Order details (denormalized for easy display without re-joining)
    order_number        text NOT NULL,
    order_amount        numeric,
    currency            text DEFAULT 'INR',
    order_placed_at     timestamptz,   -- when original order was placed
    delivery_status     text,
    fulfillment_status  text,

    -- Item info (first/main item from the order, or JSON list)
    item_name           text,
    item_image_url      text,
    item_price          text,
    items_json          jsonb,         -- full line items array if available

    -- Customer identification
    customer_name       text,
    customer_email      text,
    customer_phone      text,

    -- Request details
    request_type text NOT NULL CHECK (request_type IN ('return', 'refund')),
    reason       text,
    status text DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'completed')),

    -- Resolution tracking
    worker_notes  text,
    resolved_by   uuid REFERENCES users(id),
    resolved_at   timestamptz,

    -- Chat session link (optional — so worker can view the conversation)
    session_id uuid REFERENCES chat_sessions(id),

    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- 2. Add return/refund policy days to merchant chatbot config
ALTER TABLE merchant_chatbot_config
    ADD COLUMN IF NOT EXISTS return_policy_days   int DEFAULT 7,
    ADD COLUMN IF NOT EXISTS refund_policy_days   int DEFAULT 7;

-- 3. Indexes for fast queries
CREATE INDEX IF NOT EXISTS idx_return_requests_merchant    ON return_requests(merchant_id);
CREATE INDEX IF NOT EXISTS idx_return_requests_order       ON return_requests(order_number);
CREATE INDEX IF NOT EXISTS idx_return_requests_status      ON return_requests(status);
CREATE INDEX IF NOT EXISTS idx_return_requests_created     ON return_requests(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_return_requests_store_url   ON return_requests(store_url);

-- 4. RLS — service role has full access (same pattern as other tables)
ALTER TABLE return_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Service role full access" ON return_requests FOR ALL USING (true) WITH CHECK (true);

-- 5. Auto-update updated_at trigger
CREATE OR REPLACE FUNCTION update_return_requests_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_return_requests_updated_at ON return_requests;
CREATE TRIGGER trg_return_requests_updated_at
    BEFORE UPDATE ON return_requests
    FOR EACH ROW EXECUTE FUNCTION update_return_requests_updated_at();
