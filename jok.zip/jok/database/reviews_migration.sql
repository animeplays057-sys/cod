-- Reviews Table Migration
-- Run this in your Supabase SQL Editor

CREATE TABLE IF NOT EXISTS reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    author_name VARCHAR(255) NOT NULL,
    author_company VARCHAR(255),
    author_role VARCHAR(255),
    rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
    title VARCHAR(500),
    body TEXT NOT NULL,
    is_approved BOOLEAN DEFAULT false,
    is_featured BOOLEAN DEFAULT false,
    is_visible BOOLEAN DEFAULT true,
    admin_note TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast public queries (approved + visible)
CREATE INDEX IF NOT EXISTS idx_reviews_approved_visible
    ON reviews (is_approved, is_visible, created_at DESC);

-- Index for featured reviews
CREATE INDEX IF NOT EXISTS idx_reviews_featured
    ON reviews (is_featured, is_approved)
    WHERE is_featured = true AND is_approved = true;

-- Row Level Security (optional — admin panel uses service role key)
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- Allow public reads of approved reviews
CREATE POLICY "Public read approved reviews"
    ON reviews FOR SELECT
    USING (is_approved = true AND is_visible = true);

-- Allow insert from public (submission)
CREATE POLICY "Public insert reviews"
    ON reviews FOR INSERT
    WITH CHECK (true);

-- Seed some example reviews (optional — delete this block if not needed)
-- INSERT INTO reviews (author_name, author_company, author_role, rating, title, body, is_approved, is_featured) VALUES
-- ('Rahul Sharma', 'FashionMart India', 'Founder', 5, 'Reduced our RTO by 40%', 'CODVerify has been a game-changer. Our COD return rate dropped from 28% to under 18% within the first month.', true, true),
-- ('Priya Mehta', 'TechGadgets Store', 'Operations Head', 5, 'Seamless WhatsApp integration', 'The WhatsApp verification flow is incredibly smooth. Our customers love the instant confirmation.', true, true),
-- ('Vikram Patel', 'IndianCrafts Co', 'CEO', 4, 'Great platform, solid support', 'Very happy with the service. Support team is responsive and the dashboard gives us all the data we need.', true, false);
