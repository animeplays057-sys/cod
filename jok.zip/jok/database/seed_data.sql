"""
Database seed data for initial setup
"""

-- Insert sample admins
INSERT INTO admins (email, name, password_hash) VALUES
('admin@yoursmile.com', 'System Administrator', 'hashed_password_admin');

-- Insert sample merchants
INSERT INTO merchants (user_id, merchant_id, business_name, business_email, country_code) VALUES
(1, 'MERC_ABC123XYZ', 'Demo Store', 'demo@store.com', 'PK');

-- Insert sample stores
INSERT INTO stores (merchant_id, name, description, category) VALUES
(1, 'Demo Store', 'A demonstration store', 'General');

-- Insert sample products
INSERT INTO products (store_id, name, description, price, category, inventory_count) VALUES
(1, 'Sample Product 1', 'This is a sample product', 999.99, 'Electronics', 50),
(1, 'Sample Product 2', 'Another sample product', 499.99, 'Fashion', 100);

-- Insert sample customers
INSERT INTO customers (merchant_id, phone, name, country_code) VALUES
(1, '03001234567', 'Ahmed Hassan', 'PK'),
(1, '03009876543', 'Fatima Khan', 'PK');

-- Insert sample orders
INSERT INTO orders (customer_id, store_id, order_number, total_amount, status) VALUES
(1, 1, 'ORD_001', 2499.98, 'completed'),
(2, 1, 'ORD_002', 999.99, 'pending');

-- Insert order items
INSERT INTO order_items (order_id, product_id, quantity, unit_price, subtotal) VALUES
(1, 1, 1, 999.99, 999.99),
(1, 2, 2, 499.99, 999.98),
(2, 1, 1, 999.99, 999.99);

-- Insert sample payments
INSERT INTO payments (order_id, amount, payment_method, status) VALUES
(1, 2499.98, 'card', 'completed'),
(2, 999.99, 'card', 'pending');
