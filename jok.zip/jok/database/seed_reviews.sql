-- =====================================================
-- CODVerify — Seed 20 Demo Reviews
-- Run this in Supabase SQL Editor AFTER reviews_migration.sql
-- All reviews are pre-approved and visible immediately
-- =====================================================

INSERT INTO reviews (author_name, author_company, author_role, rating, title, body, is_approved, is_featured, is_visible, created_at) VALUES

-- 1. Rahul Sharma
('Rahul Sharma', 'TrendyKart', 'Founder', 5,
 'RTO dropped 45% in first month',
 'CODVerify completely transformed our COD operations. We were losing ₹2L/month on fake orders. Within 30 days, our RTO dropped from 38% to 21%. The WhatsApp verification is seamless — customers love it.',
 true, true, true, NOW() - INTERVAL '45 days'),

-- 2. Priya Patel
('Priya Patel', 'GlamBox India', 'Operations Head', 5,
 'Best investment for our D2C brand',
 'We tried 3 different COD verification services before CODVerify. None came close. The AI chatbot handles 80% of customer queries automatically. Our team now focuses on growth instead of chasing fake orders.',
 true, false, true, NOW() - INTERVAL '42 days'),

-- 3. Michael Chen
('Michael Chen', 'UrbanEdge US', 'CEO', 5,
 'SMS verification works flawlessly for US market',
 'Been using CODVerify for our US store. The SMS + Voice call fallback is incredibly effective. 99% of genuine customers confirm within 2 minutes. Fraudulent orders get filtered out automatically.',
 true, false, true, NOW() - INTERVAL '40 days'),

-- 4. Ankit Verma
('Ankit Verma', 'FitGear Pro', 'Co-Founder', 5,
 'Saved us from ₹5L loss in first quarter',
 'We sell fitness equipment via COD. High-ticket items = high RTO risk. CODVerify''s verification caught 200+ fake orders in Q1 alone. The ROI is insane — literally 50x return on investment.',
 true, true, true, NOW() - INTERVAL '38 days'),

-- 5. Sarah Johnson
('Sarah Johnson', 'PureGlow Cosmetics', 'E-commerce Manager', 4,
 'Great tool, amazing support team',
 'The verification rates are excellent and the dashboard gives us real-time insights. What impressed me most is their support team — they helped us customize everything during onboarding.',
 true, false, true, NOW() - INTERVAL '35 days'),

-- 6. Deepak Kumar
('Deepak Kumar', 'ElectroMart', 'Owner', 5,
 'WhatsApp verification = game changer for India',
 'Indian customers respond to WhatsApp like nothing else. Our confirmation rate went from 60% to 94% after switching to CODVerify. The button-based verification is so simple even non-tech-savvy customers can use it.',
 true, true, true, NOW() - INTERVAL '33 days'),

-- 7. Neha Agarwal
('Neha Agarwal', 'StyleNest', 'Founder', 5,
 'Reduced RTO from 42% to 18%',
 'Fashion D2C brand here. Our RTO was killing our margins. CODVerify brought it down dramatically. The personalized contract plan they offered us was very reasonable and the results speak for themselves.',
 true, false, true, NOW() - INTERVAL '30 days'),

-- 8. James Wilson
('James Wilson', 'GadgetStop', 'Operations Director', 5,
 'Voice call verification is brilliant',
 'Many of our older customers don''t check SMS quickly. The auto voice call fallback is genius — it rings them if they don''t respond to SMS within 5 minutes. Our confirmation rate is now 97%.',
 true, false, true, NOW() - INTERVAL '28 days'),

-- 9. Kavita Desai
('Kavita Desai', 'BabyBliss India', 'Co-Founder', 5,
 'Zero fake orders since we started',
 'We sell baby products online. Before CODVerify, we''d get 15-20 fake orders daily. Now? Zero. The behavioral analysis catches suspicious patterns before orders even reach verification.',
 true, true, true, NOW() - INTERVAL '25 days'),

-- 10. Arjun Mehta
('Arjun Mehta', 'SpiceRoute', 'Tech Lead', 4,
 'API integration was smooth',
 'We have a custom e-commerce setup. The API documentation was thorough and integration took us only 2 hours. The webhook callbacks are reliable and event tracking is comprehensive.',
 true, false, true, NOW() - INTERVAL '23 days'),

-- 11. Ritu Singh
('Ritu Singh', 'HomeCraft Store', 'Founder', 5,
 'Customer support is exceptional',
 'What sets CODVerify apart is their dedicated support. Our account manager responds within minutes and helped us optimize our verification flow. It feels like having an in-house team.',
 true, false, true, NOW() - INTERVAL '20 days'),

-- 12. Chris Anderson
('Chris Anderson', 'Peak Athletics', 'COO', 5,
 'ROI was visible within the first week',
 'We were skeptical about yet another verification tool. But the results were immediate — within 7 days we saw a 35% drop in failed deliveries. The analytics dashboard makes it easy to track everything.',
 true, true, true, NOW() - INTERVAL '18 days'),

-- 13. Pooja Reddy
('Pooja Reddy', 'NaturalGlow', 'Marketing Head', 5,
 'Our delivery success rate is now 96%',
 'Organic skincare brand. COD is 70% of our revenue. CODVerify made sure almost every COD order is genuine. 96% delivery success rate — our logistics partner is amazed.',
 true, false, true, NOW() - INTERVAL '15 days'),

-- 14. Vikram Joshi
('Vikram Joshi', 'TechBazaar', 'Founder', 5,
 'Shopify integration is seamless',
 'Installed the Shopify plugin, connected our store, and it just works. Every COD order gets verified automatically. No manual intervention needed. This is how SaaS should work.',
 true, false, true, NOW() - INTERVAL '13 days'),

-- 15. Meera Kapoor
('Meera Kapoor', 'FashionHub', 'CEO', 4,
 'Great for scaling COD business',
 'When we scaled from 100 to 1000 orders/day, CODVerify scaled with us effortlessly. The system handles peak loads during sale events without breaking a sweat.',
 true, false, true, NOW() - INTERVAL '10 days'),

-- 16. Rajesh Nair
('Rajesh Nair', 'KeralaSpice', 'Owner', 5,
 'Hindi + English templates work perfectly',
 'Our customers speak Hindi and English. The multi-language verification templates are perfect. Customers get messages in their preferred language which increases confirmation rates significantly.',
 true, false, true, NOW() - INTERVAL '8 days'),

-- 17. Lisa Park
('Lisa Park', 'ZenHome USA', 'VP Operations', 5,
 'Best COD verification for US market',
 'Finding a COD verification service that works well in the US was challenging. CODVerify''s SMS + voice combo is the only solution that gave us over 95% confirmation rates.',
 true, false, true, NOW() - INTERVAL '6 days'),

-- 18. Suresh Gupta
('Suresh Gupta', 'MediQuick', 'Director', 5,
 'AI chatbot handles everything',
 'The AI chatbot on our website handles customer queries about their orders 24/7. It even processes address changes and quantity updates. Our support ticket volume dropped by 60%.',
 true, true, true, NOW() - INTERVAL '4 days'),

-- 19. Amanda Foster
('Amanda Foster', 'PetPlanet', 'E-commerce Head', 5,
 'Fraud detection saved us thousands',
 'CODVerify''s blacklist system and risk scoring identified a fraud ring that was placing fake orders. Saved us at least $5,000 in the first month. The fraud pattern alerts are invaluable.',
 true, false, true, NOW() - INTERVAL '2 days'),

-- 20. Karan Malhotra
('Karan Malhotra', 'UrbanWear', 'Founder', 5,
 'From 30% RTO to 12% — unbelievable',
 'Streetwear brand. COD orders were a nightmare with 30% returns. After CODVerify, we''re at 12%. The personalized contract plan gave us unlimited verifications at a fraction of what we were losing.',
 true, false, true, NOW() - INTERVAL '1 day');

-- Verify the insert
SELECT COUNT(*) AS total_reviews, 
       SUM(CASE WHEN is_featured THEN 1 ELSE 0 END) AS featured_count
FROM reviews WHERE is_approved = true;
