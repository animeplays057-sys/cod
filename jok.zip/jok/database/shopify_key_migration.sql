-- ============================================================
-- Shopify Secret Key Based Connection Flow
-- ============================================================
-- When a merchant installs the Shopify app, a secret key is 
-- generated. The merchant then creates an account on the website 
-- and enters this key to link their Shopify store.
-- ============================================================

-- Table to store pending Shopify installations with secret keys
CREATE TABLE IF NOT EXISTS shopify_install_keys (
    id              UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    shop_domain     TEXT NOT NULL,
    shop_name       TEXT,
    shop_email      TEXT,
    shopify_shop_id TEXT,
    access_token_encrypted TEXT,
    secret_key      VARCHAR(20) NOT NULL UNIQUE,
    is_used         BOOLEAN DEFAULT FALSE,
    linked_user_id  UUID REFERENCES users(id) ON DELETE SET NULL,
    linked_at       TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT now(),
    expires_at      TIMESTAMPTZ DEFAULT (now() + INTERVAL '30 days')
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_shopify_install_keys_secret ON shopify_install_keys(secret_key);
CREATE INDEX IF NOT EXISTS idx_shopify_install_keys_shop ON shopify_install_keys(shop_domain);
CREATE INDEX IF NOT EXISTS idx_shopify_install_keys_used ON shopify_install_keys(is_used);

-- Add connection_status column to stores table
ALTER TABLE stores ADD COLUMN IF NOT EXISTS shopify_install_key_id UUID REFERENCES shopify_install_keys(id);
