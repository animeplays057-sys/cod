-- ================================================================
-- CODVerify Full System Migration
-- Run this in Supabase SQL Editor
-- ================================================================

-- 1. Shopify shop-user binding columns
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS shopify_shop_domain   TEXT,
  ADD COLUMN IF NOT EXISTS shopify_shop_id        TEXT,
  ADD COLUMN IF NOT EXISTS onboarding_completed   BOOLEAN DEFAULT FALSE;

CREATE INDEX IF NOT EXISTS idx_users_shopify_shop
  ON users (shopify_shop_domain);

-- 2. Country & currency columns
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS country                VARCHAR(5) DEFAULT 'IN';

ALTER TABLE billing_transactions
  ADD COLUMN IF NOT EXISTS currency               VARCHAR(5) DEFAULT 'INR';

-- 3. Wallet recharge plans table (replaces hardcoded constants)
CREATE TABLE IF NOT EXISTS wallet_recharge_plans (
  id          UUID              DEFAULT gen_random_uuid() PRIMARY KEY,
  label       VARCHAR(50)       NOT NULL,       -- e.g. "₹500" or "$10"
  amount      DECIMAL(10,2)     NOT NULL,       -- actual amount (50 = ₹50 or $50)
  bonus       DECIMAL(10,2)     DEFAULT 0,      -- bonus on top of deposit
  currency    VARCHAR(5)        NOT NULL,       -- "INR" or "USD"
  is_active   BOOLEAN           DEFAULT TRUE,
  sort_order  INT               DEFAULT 0,
  created_at  TIMESTAMPTZ       DEFAULT now()
);

-- Seed default INR plans
INSERT INTO wallet_recharge_plans (label, amount, bonus, currency, sort_order) VALUES
  ('₹100',    100,    0,    'INR', 1),
  ('₹500',    500,    25,   'INR', 2),
  ('₹1,000',  1000,   75,   'INR', 3),
  ('₹2,500',  2500,   250,  'INR', 4),
  ('₹5,000',  5000,   600,  'INR', 5),
  ('₹10,000', 10000,  1500, 'INR', 6)
ON CONFLICT DO NOTHING;

-- Seed default USD plans
INSERT INTO wallet_recharge_plans (label, amount, bonus, currency, sort_order) VALUES
  ('$5',   5,   0,   'USD', 1),
  ('$10',  10,  1,   'USD', 2),
  ('$25',  25,  3,   'USD', 3),
  ('$50',  50,  8,   'USD', 4),
  ('$100', 100, 20,  'USD', 5)
ON CONFLICT DO NOTHING;

-- 4. Admin settings — add payment gateway columns
ALTER TABLE admin_settings
  ADD COLUMN IF NOT EXISTS razorpay_key_id          TEXT,
  ADD COLUMN IF NOT EXISTS razorpay_key_secret       TEXT,    -- encrypted
  ADD COLUMN IF NOT EXISTS razorpay_enabled          BOOLEAN  DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS stripe_secret_key         TEXT,    -- encrypted
  ADD COLUMN IF NOT EXISTS stripe_publishable_key    TEXT,
  ADD COLUMN IF NOT EXISTS stripe_webhook_secret     TEXT,    -- encrypted
  ADD COLUMN IF NOT EXISTS stripe_enabled            BOOLEAN  DEFAULT FALSE;

-- 5. Per-order rates by currency (upsert)
INSERT INTO admin_settings (setting_key, setting_value, setting_label, setting_group)
  VALUES ('per_order_rate_inr', '1.0', 'Per Order Rate (₹ INR)', 'billing')
  ON CONFLICT (setting_key) DO NOTHING;

INSERT INTO admin_settings (setting_key, setting_value, setting_label, setting_group)
  VALUES ('per_order_rate_usd', '0.012', 'Per Order Rate ($ USD)', 'billing')
  ON CONFLICT (setting_key) DO NOTHING;

-- Done!
SELECT 'Migration completed successfully' AS result;
