-- ═══════════════════════════════════════════════════════════════════════
-- Smart Scraper Migration — adds new columns to merchant_chatbot_config
-- Run this in Supabase SQL Editor
-- ═══════════════════════════════════════════════════════════════════════

-- Add new columns from smart website scraper
ALTER TABLE merchant_chatbot_config
    ADD COLUMN IF NOT EXISTS contact_info text DEFAULT '',    -- email, phone, WhatsApp, social links
    ADD COLUMN IF NOT EXISTS shipping_info text DEFAULT '',   -- shipping policy extracted from site
    ADD COLUMN IF NOT EXISTS return_policy text DEFAULT '',   -- return/refund policy from site
    ADD COLUMN IF NOT EXISTS platform text DEFAULT '';        -- 'shopify' | 'woocommerce' | 'generic'
