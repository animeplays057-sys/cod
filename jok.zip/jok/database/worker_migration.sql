-- ═══════════════════════════════════════════════════════════════════════
-- Worker System Migration
-- Adds: worker fields, chat system, order verification tracking
-- Run this in Supabase SQL Editor
-- ═══════════════════════════════════════════════════════════════════════

-- 1. Add worker-related columns to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS duty_status text DEFAULT 'off_duty' CHECK (duty_status IN ('on_duty', 'off_duty', 'break'));
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_duty_change timestamptz;
ALTER TABLE users ADD COLUMN IF NOT EXISTS total_duty_seconds bigint DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS current_duty_start timestamptz;

-- 2. Chat Sessions table
CREATE TABLE IF NOT EXISTS chat_sessions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    visitor_name text DEFAULT 'Visitor',
    visitor_email text,
    visitor_phone text,
    merchant_id uuid REFERENCES users(id),
    assigned_worker_id uuid REFERENCES users(id),
    status text DEFAULT 'ai_active' CHECK (status IN ('ai_active', 'waiting_human', 'human_active', 'resolved', 'abandoned')),
    source text DEFAULT 'website' CHECK (source IN ('website', 'shopify', 'whatsapp')),
    metadata jsonb DEFAULT '{}',
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    resolved_at timestamptz
);

-- 3. Chat Messages table
CREATE TABLE IF NOT EXISTS chat_messages (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id uuid NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE,
    sender_type text NOT NULL CHECK (sender_type IN ('visitor', 'ai', 'worker')),
    sender_id uuid REFERENCES users(id),
    message text NOT NULL,
    metadata jsonb DEFAULT '{}',
    created_at timestamptz DEFAULT now()
);

-- 4. Order Verifications table (worker call tracking)
CREATE TABLE IF NOT EXISTS order_verifications (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id uuid NOT NULL,
    worker_id uuid NOT NULL REFERENCES users(id),
    merchant_id uuid,
    customer_name text,
    customer_phone text,
    customer_address text,
    order_amount decimal(12,2),
    call_status text DEFAULT 'pending' CHECK (call_status IN ('pending', 'answered', 'not_picked', 'cancel', 'callback')),
    call_notes text,
    call_duration_seconds int DEFAULT 0,
    attempts int DEFAULT 1,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- 5. Worker Duty Logs (track on/off duty history)
CREATE TABLE IF NOT EXISTS worker_duty_logs (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    worker_id uuid NOT NULL REFERENCES users(id),
    action text NOT NULL CHECK (action IN ('clock_in', 'clock_out', 'break_start', 'break_end')),
    created_at timestamptz DEFAULT now()
);

-- 6. Indexes for performance
CREATE INDEX IF NOT EXISTS idx_chat_sessions_worker ON chat_sessions(assigned_worker_id);
CREATE INDEX IF NOT EXISTS idx_chat_sessions_status ON chat_sessions(status);
CREATE INDEX IF NOT EXISTS idx_chat_messages_session ON chat_messages(session_id);
CREATE INDEX IF NOT EXISTS idx_order_verifications_worker ON order_verifications(worker_id);
CREATE INDEX IF NOT EXISTS idx_order_verifications_status ON order_verifications(call_status);
CREATE INDEX IF NOT EXISTS idx_worker_duty_logs_worker ON worker_duty_logs(worker_id);

-- 7. Enable RLS
ALTER TABLE chat_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE worker_duty_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies (allow service role full access)
CREATE POLICY "Service role full access" ON chat_sessions FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Service role full access" ON chat_messages FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Service role full access" ON order_verifications FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Service role full access" ON worker_duty_logs FOR ALL USING (true) WITH CHECK (true);
