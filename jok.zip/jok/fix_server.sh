#!/bin/bash
# Run this on server: bash /tmp/fix_missing_files.sh
# Creates all missing backend Python modules + rebuilds backend container

set -e
BACKEND="/home/ubuntu/cod/jok/backend"
echo "==> Creating missing route files..."

# ── 1. routes/merchant/returns.py ────────────────────────────────────────────
cat > "$BACKEND/routes/merchant/returns.py" << 'PYEOF'
"""
Return & Refund Requests — Merchant API
Merchants see ONLY their own store's return requests.
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone
from config.database import get_db
from middleware.auth import get_current_merchant
from utils.helpers import success_response, paginate_params, pagination_meta

router = APIRouter(prefix="/api/v1/merchant/returns", tags=["Merchant Returns"])


class UpdateReturnRequest(BaseModel):
    status: str               # 'approved' | 'rejected' | 'completed'
    worker_notes: Optional[str] = None


@router.get("")
async def list_merchant_returns(
    page: int = 1,
    limit: int = 20,
    status: Optional[str] = None,
    request_type: Optional[str] = None,
    search: Optional[str] = None,
    user: dict = Depends(get_current_merchant),
):
    """List all return/refund requests for THIS merchant only."""
    db = get_db()
    offset, limit = paginate_params(page, limit)

    query = (
        db.table("return_requests")
        .select("*", count="exact")
        .eq("merchant_id", user["id"])
    )

    if status:
        query = query.eq("status", status)
    if request_type:
        query = query.eq("request_type", request_type)
    if search:
        query = query.or_(
            f"order_number.ilike.%{search}%,"
            f"customer_name.ilike.%{search}%,"
            f"customer_email.ilike.%{search}%,"
            f"customer_phone.ilike.%{search}%"
        )

    result = (
        query.order("created_at", desc=True)
        .range(offset, offset + limit - 1)
        .execute()
    )

    return success_response({
        "returns": result.data or [],
        "pagination": pagination_meta(result.count or 0, page, limit),
    })


@router.get("/stats")
async def get_return_stats(user: dict = Depends(get_current_merchant)):
    """Quick stats: counts by status for dashboard badge."""
    db = get_db()
    all_res = (
        db.table("return_requests")
        .select("status")
        .eq("merchant_id", user["id"])
        .execute()
    )
    rows = all_res.data or []
    stats = {"pending": 0, "approved": 0, "rejected": 0, "completed": 0, "total": len(rows)}
    for r in rows:
        s = r.get("status", "pending")
        if s in stats:
            stats[s] += 1
    return success_response(stats)


@router.get("/{return_id}")
async def get_return_detail(return_id: str, user: dict = Depends(get_current_merchant)):
    """Get full detail of a single return request (merchant's own only)."""
    db = get_db()
    result = (
        db.table("return_requests")
        .select("*")
        .eq("id", return_id)
        .eq("merchant_id", user["id"])
        .execute()
    )
    if not result.data:
        raise HTTPException(404, "Return request not found")
    return success_response({"return": result.data[0]})


@router.put("/{return_id}")
async def update_return_status(
    return_id: str,
    body: UpdateReturnRequest,
    user: dict = Depends(get_current_merchant),
):
    """Approve / reject / complete a return request."""
    valid_statuses = {"approved", "rejected", "completed"}
    if body.status not in valid_statuses:
        raise HTTPException(400, f"Invalid status. Must be one of: {valid_statuses}")

    db = get_db()
    existing = (
        db.table("return_requests")
        .select("id, merchant_id, status")
        .eq("id", return_id)
        .eq("merchant_id", user["id"])
        .execute()
    )
    if not existing.data:
        raise HTTPException(404, "Return request not found")

    updates = {
        "status": body.status,
        "resolved_by": user["id"],
        "resolved_at": datetime.now(timezone.utc).isoformat(),
    }
    if body.worker_notes is not None:
        updates["worker_notes"] = body.worker_notes

    db.table("return_requests").update(updates).eq("id", return_id).execute()
    return success_response(message=f"Return request {body.status} successfully")
PYEOF
echo "  [OK] routes/merchant/returns.py"

# ── 2. routes/admin/returns.py ───────────────────────────────────────────────
cat > "$BACKEND/routes/admin/returns.py" << 'PYEOF'
"""
Return & Refund Requests — Admin API
Admins see ALL return requests across ALL merchants.
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone
from config.database import get_db
from middleware.auth import get_current_admin
from utils.helpers import success_response, paginate_params, pagination_meta

router = APIRouter(prefix="/api/v1/admin/returns", tags=["Admin Returns"])


class AdminUpdateReturn(BaseModel):
    status: str
    worker_notes: Optional[str] = None


@router.get("")
async def list_all_returns(
    page: int = 1,
    limit: int = 30,
    status: Optional[str] = None,
    request_type: Optional[str] = None,
    merchant_id: Optional[str] = None,
    search: Optional[str] = None,
    admin: dict = Depends(get_current_admin),
):
    db = get_db()
    offset, limit = paginate_params(page, limit)
    query = db.table("return_requests").select("*", count="exact")
    if merchant_id:
        query = query.eq("merchant_id", merchant_id)
    if status:
        query = query.eq("status", status)
    if request_type:
        query = query.eq("request_type", request_type)
    if search:
        query = query.or_(
            f"order_number.ilike.%{search}%,"
            f"customer_name.ilike.%{search}%,"
            f"customer_email.ilike.%{search}%"
        )
    result = query.order("created_at", desc=True).range(offset, offset + limit - 1).execute()
    rows = result.data or []
    if rows:
        merchant_ids = list({r["merchant_id"] for r in rows if r.get("merchant_id")})
        users_res = db.table("users").select("id, email, company_name").in_("id", merchant_ids).execute()
        users_map = {str(u["id"]): u for u in (users_res.data or [])}
        for r in rows:
            mid = str(r.get("merchant_id", ""))
            r["merchant_email"] = users_map.get(mid, {}).get("email", "")
            r["merchant_company"] = users_map.get(mid, {}).get("company_name", "")
    return success_response({"returns": rows, "pagination": pagination_meta(result.count or 0, page, limit)})


@router.get("/stats")
async def get_admin_return_stats(admin: dict = Depends(get_current_admin)):
    db = get_db()
    rows = db.table("return_requests").select("status, request_type").execute().data or []
    stats = {"total": len(rows), "pending": 0, "approved": 0, "rejected": 0, "completed": 0, "returns": 0, "refunds": 0}
    for r in rows:
        s = r.get("status", "pending")
        if s in stats:
            stats[s] += 1
        if r.get("request_type") == "return":
            stats["returns"] += 1
        elif r.get("request_type") == "refund":
            stats["refunds"] += 1
    return success_response(stats)


@router.get("/{return_id}")
async def get_return_detail(return_id: str, admin: dict = Depends(get_current_admin)):
    db = get_db()
    result = db.table("return_requests").select("*").eq("id", return_id).execute()
    if not result.data:
        raise HTTPException(404, "Return request not found")
    return success_response({"return": result.data[0]})


@router.put("/{return_id}")
async def admin_update_return(return_id: str, body: AdminUpdateReturn, admin: dict = Depends(get_current_admin)):
    valid_statuses = {"pending", "approved", "rejected", "completed"}
    if body.status not in valid_statuses:
        raise HTTPException(400, f"Invalid status. Must be one of: {valid_statuses}")
    db = get_db()
    existing = db.table("return_requests").select("id").eq("id", return_id).execute()
    if not existing.data:
        raise HTTPException(404, "Return request not found")
    updates = {"status": body.status, "resolved_by": admin["id"], "resolved_at": datetime.now(timezone.utc).isoformat()}
    if body.worker_notes is not None:
        updates["worker_notes"] = body.worker_notes
    db.table("return_requests").update(updates).eq("id", return_id).execute()
    return success_response(message=f"Return request updated to '{body.status}'")
PYEOF
echo "  [OK] routes/admin/returns.py"

# ── 3. routes/worker/returns.py ──────────────────────────────────────────────
cat > "$BACKEND/routes/worker/returns.py" << 'PYEOF'
"""
Return & Refund Requests — Worker API
Workers see ALL return requests so they can process them.
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone
from config.database import get_db
from middleware.auth import get_current_worker
from utils.helpers import success_response, paginate_params, pagination_meta

router = APIRouter(prefix="/api/v1/worker/returns", tags=["Worker Returns"])


class WorkerUpdateReturn(BaseModel):
    status: str
    worker_notes: Optional[str] = None


@router.get("")
async def list_all_returns_worker(
    page: int = 1,
    limit: int = 20,
    status: Optional[str] = None,
    request_type: Optional[str] = None,
    search: Optional[str] = None,
    worker: dict = Depends(get_current_worker),
):
    db = get_db()
    offset, limit = paginate_params(page, limit)
    query = db.table("return_requests").select("*", count="exact")
    if status:
        query = query.eq("status", status)
    if request_type:
        query = query.eq("request_type", request_type)
    if search:
        query = query.or_(
            f"order_number.ilike.%{search}%,"
            f"customer_name.ilike.%{search}%,"
            f"customer_email.ilike.%{search}%"
        )
    result = query.order("created_at", desc=True).range(offset, offset + limit - 1).execute()
    return success_response({"returns": result.data or [], "pagination": pagination_meta(result.count or 0, page, limit)})


@router.get("/stats")
async def worker_return_stats(worker: dict = Depends(get_current_worker)):
    db = get_db()
    rows = db.table("return_requests").select("status, request_type").execute().data or []
    stats = {"total": len(rows), "pending": 0, "approved": 0, "rejected": 0, "completed": 0, "returns": 0, "refunds": 0}
    for r in rows:
        s = r.get("status", "pending")
        if s in stats:
            stats[s] += 1
        if r.get("request_type") == "return":
            stats["returns"] += 1
        elif r.get("request_type") == "refund":
            stats["refunds"] += 1
    return success_response(stats)


@router.get("/{return_id}")
async def get_return_detail_worker(return_id: str, worker: dict = Depends(get_current_worker)):
    db = get_db()
    result = db.table("return_requests").select("*").eq("id", return_id).execute()
    if not result.data:
        raise HTTPException(404, "Return request not found")
    return success_response({"return": result.data[0]})


@router.put("/{return_id}")
async def worker_update_return(return_id: str, body: WorkerUpdateReturn, worker: dict = Depends(get_current_worker)):
    valid_statuses = {"approved", "rejected", "completed"}
    if body.status not in valid_statuses:
        raise HTTPException(400, f"Invalid status.")
    db = get_db()
    existing = db.table("return_requests").select("id").eq("id", return_id).execute()
    if not existing.data:
        raise HTTPException(404, "Return request not found")
    updates = {"status": body.status, "resolved_by": worker["id"], "resolved_at": datetime.now(timezone.utc).isoformat()}
    if body.worker_notes is not None:
        updates["worker_notes"] = body.worker_notes
    db.table("return_requests").update(updates).eq("id", return_id).execute()
    return success_response(message=f"Return request updated to '{body.status}'")
PYEOF
echo "  [OK] routes/worker/returns.py"

# ── 4. routes/admin/reviews.py ───────────────────────────────────────────────
cat > "$BACKEND/routes/admin/reviews.py" << 'PYEOF'
"""Admin Reviews — manage customer reviews."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from config.database import get_db
from middleware.auth import get_current_admin
from utils.helpers import success_response, paginate_params, pagination_meta

router = APIRouter(prefix="/api/v1/admin/reviews", tags=["Admin Reviews"])


class UpdateReviewBody(BaseModel):
    is_featured: Optional[bool] = None
    is_approved: Optional[bool] = None
    admin_note: Optional[str] = None


@router.get("")
async def list_reviews(page: int = 1, limit: int = 20, featured_only: bool = False, user: dict = Depends(get_current_admin)):
    db = get_db()
    offset, limit = paginate_params(page, limit)
    query = db.table("reviews").select("*", count="exact")
    if featured_only:
        query = query.eq("is_featured", True)
    result = query.order("created_at", desc=True).range(offset, offset + limit - 1).execute()
    return success_response({"reviews": result.data or [], "pagination": pagination_meta(result.count or 0, page, limit)})


@router.put("/{review_id}")
async def update_review(review_id: str, body: UpdateReviewBody, user: dict = Depends(get_current_admin)):
    db = get_db()
    existing = db.table("reviews").select("id").eq("id", review_id).execute()
    if not existing.data:
        raise HTTPException(404, "Review not found")
    updates = {}
    if body.is_featured is not None:
        updates["is_featured"] = body.is_featured
    if body.is_approved is not None:
        updates["is_approved"] = body.is_approved
    if body.admin_note is not None:
        updates["admin_note"] = body.admin_note
    if not updates:
        raise HTTPException(400, "No fields to update")
    db.table("reviews").update(updates).eq("id", review_id).execute()
    return success_response(message="Review updated successfully")


@router.delete("/{review_id}")
async def delete_review(review_id: str, user: dict = Depends(get_current_admin)):
    db = get_db()
    existing = db.table("reviews").select("id").eq("id", review_id).execute()
    if not existing.data:
        raise HTTPException(404, "Review not found")
    db.table("reviews").delete().eq("id", review_id).execute()
    return success_response(message="Review deleted successfully")
PYEOF
echo "  [OK] routes/admin/reviews.py"

# ── Done — rebuild backend ────────────────────────────────────────────────────
echo ""
echo "==> All files created. Rebuilding backend..."
cd /home/ubuntu/cod/jok
docker compose up -d --build backend
echo ""
echo "==> Waiting 15s for backend to start..."
sleep 15
docker logs codverify-backend --tail 20
echo ""
echo "==> DONE! Check logs above — should show 'Application startup complete'"
