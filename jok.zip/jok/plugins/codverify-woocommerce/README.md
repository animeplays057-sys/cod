# CODVerify for WooCommerce

> **WhatsApp COD Verification & RTO Prevention for WooCommerce stores.**

This plugin integrates your WooCommerce store with the [CODVerify](https://codverify.tech) platform. When a customer places a Cash on Delivery order, CODVerify automatically sends a WhatsApp confirmation message to verify the order — reducing RTO (Return to Origin) losses significantly.

---

## ✨ Features

- **Automatic COD Verification** — WhatsApp message sent on every new COD order
- **Smart COD Detection** — Detects standard WooCommerce COD + custom payment methods
- **Idempotent Sending** — Each order is sent only once (tracked via order meta)
- **Delivery Updates** — Notifies CODVerify when an order is marked as Completed or Cancelled
- **Re-send Button** — Force re-send any order directly from the WooCommerce order edit page
- **Test Connection** — Verify your API credentials with one click in the settings page
- **HPOS Compatible** — Supports WooCommerce High Performance Order Storage
- **Debug Logging** — Optional PHP error log output for troubleshooting

---

## 📋 Requirements

| Requirement         | Version   |
|---------------------|-----------|
| WordPress           | 5.8+      |
| WooCommerce         | 6.0+      |
| PHP                 | 7.4+      |
| CODVerify Account   | Active    |

---

## 🚀 Installation

### Step 1 — Install the Plugin

**Option A: Manual Upload**
1. Download / zip the `codverify-woocommerce` folder
2. Go to **WordPress Admin → Plugins → Add New → Upload Plugin**
3. Upload the zip file and click **Install Now**
4. Click **Activate**

**Option B: FTP / cPanel**
1. Copy the `codverify-woocommerce` folder to `/wp-content/plugins/`
2. Go to **WordPress Admin → Plugins** and activate **CODVerify for WooCommerce**

---

### Step 2 — Get Your API Keys

1. Register/Login at [codverify.tech](https://codverify.tech)
2. Go to **Dashboard → API Keys**
3. Click **Generate New Key**
4. Copy both the **API Key** (`cv_...`) and **Secret Key**

> ⚠️ Save the Secret Key immediately — it is shown only once!

---

### Step 3 — Configure the Plugin

1. In WordPress Admin, go to **WooCommerce → CODVerify**
2. Paste your **API Key** and **Secret Key**
3. Click **Test Connection** to verify
4. Click **Save Settings**

---

### Step 4 — Add Your Store in CODVerify Dashboard

1. Go to [CODVerify Dashboard → Stores](https://codverify.tech/dashboard/stores)
2. Click **Add Store → WooCommerce**
3. Enter your store URL (e.g., `yourstore.com`)
4. Your API key will be automatically linked

---

## ⚙️ Settings Reference

| Setting                | Default              | Description                                                |
|------------------------|----------------------|------------------------------------------------------------|
| **API Key**            | _(empty)_            | Your CODVerify API Key                                     |
| **Secret Key**         | _(empty)_            | Your CODVerify Secret Key                                  |
| **Backend URL**        | `https://codverify.tech/api/v1` | API base URL (do not change unless self-hosted) |
| **Send Prepaid Orders**| No                   | Also forward non-COD orders to CODVerify                    |
| **Extra COD Methods**  | _(empty)_            | Comma-separated extra payment method IDs to treat as COD   |
| **Min Order Amount**   | 0                    | Skip orders below this amount (₹)                          |
| **Debug Logging**      | No                   | Log all API calls to PHP error log                         |

---

## 🔌 Order Lifecycle Hooks

The plugin hooks into these WooCommerce events:

| WooCommerce Event             | CODVerify Action                  |
|-------------------------------|-----------------------------------|
| Order Created (checkout)      | Send COD order for verification   |
| Status → Processing           | Send order (if not sent yet)      |
| Status → On-Hold              | Send order (if not sent yet)      |
| Status → Completed            | Send delivery update (delivered)  |
| Status → Cancelled / Refunded | Cancel order in CODVerify         |

---

## 🗂️ File Structure

```
codverify-woocommerce/
├── codverify-woocommerce.php     # Main plugin entry point
├── uninstall.php                 # Cleanup on plugin deletion
├── assets/
│   └── admin.css                 # Admin settings page styles
└── includes/
    ├── class-codverify-api.php   # HTTP client for CODVerify backend
    ├── class-codverify-admin.php # WP Admin settings page
    └── class-codverify-hooks.php # WooCommerce order hooks & meta box
```

---

## 🔑 API Payload Reference

When a new COD order is placed, the plugin sends:

```json
{
  "store_order_id":     "1234",
  "order_number":       "1234",
  "customer_name":      "Rahul Sharma",
  "customer_phone":     "+919876543210",
  "customer_email":     "rahul@example.com",
  "order_amount":       999.0,
  "currency":           "INR",
  "payment_method":     "cod",
  "order_type":         "cod",
  "fulfillment_status": "unfulfilled",
  "products": [
    { "name": "Product A", "quantity": 2, "price": 499.5, "image_url": "..." }
  ],
  "shipping_address": {
    "line1": "123 Main St",
    "line2": "",
    "city": "Mumbai",
    "state": "MH",
    "pincode": "400001",
    "country": "IN"
  },
  "source":          "woocommerce",
  "shop_domain":     "mystore.com",
  "tags":            "",
  "notes":           "",
  "tracking_number": "",
  "tracking_url":    "",
  "tracking_company":""
}
```

**Auth Headers sent with every request:**
```
X-API-Key:     cv_xxxxxxxxxxxxxxxx
X-Secret-Key:  your_secret_key
X-Source:      woocommerce
X-Plugin-Ver:  1.0.0
```

---

## 🛠️ Troubleshooting

### Orders not being sent?
- Enable **Debug Logging** in settings and check PHP error log
- Make sure API Key and Secret Key are correct (use Test Connection)
- Check if order payment method is detected as COD (add it to "Extra COD Methods" if needed)

### Test Connection fails?
- Verify your API Key and Secret Key in [CODVerify Dashboard](https://codverify.tech/dashboard/api-keys)
- Ensure your server can reach `https://codverify.tech` (check firewall/curl)

### How to manually re-send an order?
- Open the order in **WooCommerce → Orders**
- Find the **CODVerify** metabox in the right sidebar
- Click **Re-send to CODVerify**

---

## 📄 License

GPL v2 or later — see [LICENSE](https://www.gnu.org/licenses/gpl-2.0.html)

---

## 🌐 Links

- 🌍 Website: [codverify.tech](https://codverify.tech)
- 📊 Dashboard: [codverify.tech/dashboard](https://codverify.tech/dashboard)
- 📧 Support: support@codverify.tech
