<?php
/**
 * CODVerify Admin Settings Page
 * Renders and manages the WooCommerce settings page for CODVerify.
 */

if (!defined('ABSPATH'))
  exit;

class CODVerify_Admin
{

  public function init(): void
  {
    add_action('admin_menu', array($this, 'register_menu'));
    add_action('admin_init', array($this, 'register_settings'));
    add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
    add_action('wp_ajax_codverify_test_connection', array($this, 'ajax_test_connection'));
    add_action('wp_ajax_codverify_generate_connect_key', array($this, 'ajax_generate_connect_key'));
  }

  // ── Menu ─────────────────────────────────────────────────────────────────

  public function register_menu(): void
  {
    add_submenu_page(
      'woocommerce',
      __('CODVerify Settings', 'codverify-woocommerce'),
      __('CODVerify', 'codverify-woocommerce'),
      'manage_woocommerce',
      'codverify-settings',
      array($this, 'render_settings_page')
    );
  }

  // ── Settings Registration ─────────────────────────────────────────────────

  public function register_settings(): void
  {
    $options = array(
      'codverify_api_key' => '',
      'codverify_secret_key' => '',
      'codverify_backend_url' => CODVERIFY_API_BASE,
      'codverify_enable_logging' => 'no',
      'codverify_send_prepaid' => 'no',
      'codverify_extra_cod_methods' => '',
      'codverify_min_order_amount' => '0',
    );

    foreach ($options as $option => $default) {
      register_setting('codverify_settings_group', $option, array(
        'sanitize_callback' => 'sanitize_text_field',
        'default' => $default,
      ));
    }
  }

  // ── Assets ───────────────────────────────────────────────────────────────

  public function enqueue_assets(string $hook): void
  {
    if (strpos($hook, 'codverify-settings') === false)
      return;

    wp_enqueue_style('codverify-admin', CODVERIFY_PLUGIN_URL . 'assets/admin.css', array(), CODVERIFY_VERSION);
  }

  // ── Settings Page Render ──────────────────────────────────────────────────

  public function render_settings_page(): void
  {
    if (!current_user_can('manage_woocommerce')) {
      wp_die(esc_html__('You do not have permission to access this page.', 'codverify-woocommerce'));
    }

    $api_key = get_option('codverify_api_key', '');
    $secret_key = get_option('codverify_secret_key', '');
    $backend = get_option('codverify_backend_url', CODVERIFY_API_BASE);
    $logging = get_option('codverify_enable_logging', 'no');
    $send_pre = get_option('codverify_send_prepaid', 'no');
    $extra_cod = get_option('codverify_extra_cod_methods', '');
    $min_amount = get_option('codverify_min_order_amount', '0');
    $is_conf = (!empty($api_key) && !empty($secret_key));
?>
        <div class="wrap codverify-settings-wrap">

          <!-- Header -->
          <div class="codverify-header">
            <div class="codverify-logo">
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none"><circle cx="16" cy="16" r="16" fill="#4f46e5"/><path d="M8 16.5l5 5 11-11" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
              <span>CODVerify</span>
            </div>
            <p><?php esc_html_e('WhatsApp COD Verification &amp; RTO Prevention for WooCommerce', 'codverify-woocommerce'); ?></p>
          </div>

          <!-- Connection Status Banner -->
          <div class="codverify-status-banner <?php echo $is_conf ? 'configured' : 'not-configured'; ?>">
            <?php if ($is_conf): ?>
              <span class="status-dot"></span>
              <?php esc_html_e('Plugin is configured. Orders will be sent to CODVerify automatically.', 'codverify-woocommerce'); ?>
            <?php
    else: ?>
              <span class="status-dot"></span>
              <?php esc_html_e('Plugin not configured. Please enter your API Key and Secret Key below.', 'codverify-woocommerce'); ?>
            <?php
    endif; ?>
          </div>

          <form method="post" action="options.php" id="codverify-settings-form">
            <?php settings_fields('codverify_settings_group'); ?>

            <div class="codverify-cards-grid">

              <!-- API Credentials Card -->
              <div class="codverify-card">
                <h2 class="codverify-card-title">
                  🔑 <?php esc_html_e('API Credentials', 'codverify-woocommerce'); ?>
                </h2>
                <p class="codverify-card-desc">
                  <?php
    printf(
      wp_kses(
      /* translators: %s: URL link */
      __('Get your API Key from the <a href="%s" target="_blank">CODVerify Dashboard → API Keys</a>.', 'codverify-woocommerce'),
      array('a' => array('href' => array(), 'target' => array()))
    ),
      'https://codverify.tech/dashboard/api-keys'
    );
?>
                </p>

                <table class="codverify-table">
                  <tr>
                    <th><label for="codverify_api_key"><?php esc_html_e('API Key', 'codverify-woocommerce'); ?></label></th>
                    <td>
                      <input type="text" id="codverify_api_key" name="codverify_api_key"
                             value="<?php echo esc_attr($api_key); ?>"
                             class="regular-text" placeholder="cv_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" autocomplete="off" />
                      <p class="description"><?php esc_html_e('Your CODVerify API Key (starts with cv_).', 'codverify-woocommerce'); ?></p>
                    </td>
                  </tr>
                  <tr>
                    <th><label for="codverify_secret_key"><?php esc_html_e('Secret Key', 'codverify-woocommerce'); ?></label></th>
                    <td>
                      <input type="password" id="codverify_secret_key" name="codverify_secret_key"
                             value="<?php echo esc_attr($secret_key); ?>"
                             class="regular-text" autocomplete="new-password" />
                      <p class="description"><?php esc_html_e('Your CODVerify Secret Key.', 'codverify-woocommerce'); ?></p>
                    </td>
                  </tr>
                  <tr>
                    <th><label for="codverify_backend_url"><?php esc_html_e('Backend URL', 'codverify-woocommerce'); ?></label></th>
                    <td>
                      <input type="url" id="codverify_backend_url" name="codverify_backend_url"
                             value="<?php echo esc_attr($backend); ?>"
                             class="regular-text" />
                      <p class="description"><?php esc_html_e('Leave as default unless you have a self-hosted backend.', 'codverify-woocommerce'); ?></p>
                    </td>
                  </tr>
                </table>

                <div class="codverify-test-connection">
                  <button type="button" id="codverify-test-btn" class="button button-secondary">
                    🔗 <?php esc_html_e('Test Connection', 'codverify-woocommerce'); ?>
                  </button>
                  <span id="codverify-test-result" style="margin-left:12px;font-size:13px;"></span>
                </div>
              </div>

              <!-- Order Settings Card -->
              <div class="codverify-card">
                <h2 class="codverify-card-title">
                  📦 <?php esc_html_e('Order Settings', 'codverify-woocommerce'); ?>
                </h2>

                <table class="codverify-table">
                  <tr>
                    <th><label for="codverify_send_prepaid"><?php esc_html_e('Send Prepaid Orders', 'codverify-woocommerce'); ?></label></th>
                    <td>
                      <label>
                        <input type="checkbox" id="codverify_send_prepaid" name="codverify_send_prepaid"
                               value="yes" <?php checked($send_pre, 'yes'); ?> />
                        <?php esc_html_e('Also send prepaid/online payment orders to CODVerify', 'codverify-woocommerce'); ?>
                      </label>
                      <p class="description"><?php esc_html_e('By default only COD orders are sent. Enable this to send all orders.', 'codverify-woocommerce'); ?></p>
                    </td>
                  </tr>
                  <tr>
                    <th><label for="codverify_extra_cod_methods"><?php esc_html_e('Extra COD Methods', 'codverify-woocommerce'); ?></label></th>
                    <td>
                      <input type="text" id="codverify_extra_cod_methods" name="codverify_extra_cod_methods"
                             value="<?php echo esc_attr($extra_cod); ?>"
                             class="regular-text" placeholder="e.g. bacs, cheque" />
                      <p class="description"><?php esc_html_e('Comma-separated additional payment method IDs to treat as COD.', 'codverify-woocommerce'); ?></p>
                    </td>
                  </tr>
                  <tr>
                    <th><label for="codverify_min_order_amount"><?php esc_html_e('Minimum Order Amount (₹)', 'codverify-woocommerce'); ?></label></th>
                    <td>
                      <input type="number" id="codverify_min_order_amount" name="codverify_min_order_amount"
                             value="<?php echo esc_attr($min_amount); ?>"
                             min="0" step="1" class="small-text" />
                      <p class="description"><?php esc_html_e('Orders below this amount will not be sent to CODVerify. Set 0 to send all.', 'codverify-woocommerce'); ?></p>
                    </td>
                  </tr>
                </table>
              </div>

              <!-- Advanced Settings Card -->
              <div class="codverify-card">
                <h2 class="codverify-card-title">
                  ⚙️ <?php esc_html_e('Advanced', 'codverify-woocommerce'); ?>
                </h2>

                <table class="codverify-table">
                  <tr>
                    <th><label for="codverify_enable_logging"><?php esc_html_e('Enable Debug Logging', 'codverify-woocommerce'); ?></label></th>
                    <td>
                      <label>
                        <input type="checkbox" id="codverify_enable_logging" name="codverify_enable_logging"
                               value="yes" <?php checked($logging, 'yes'); ?> />
                        <?php esc_html_e('Log CODVerify API requests/responses to PHP error log', 'codverify-woocommerce'); ?>
                      </label>
                      <p class="description"><?php esc_html_e('Enable only for debugging. Disable in production.', 'codverify-woocommerce'); ?></p>
                    </td>
                  </tr>
                </table>
              </div>

              <!-- Connect Store Card -->
              <div class="codverify-card codverify-card-connect" style="border-left:4px solid #4f46e5;">
                <h2 class="codverify-card-title">
                  🔗 <?php esc_html_e('Connect to CODVerify Dashboard', 'codverify-woocommerce'); ?>
                </h2>
                <p class="codverify-card-desc">
                  <?php esc_html_e('After saving your API Keys above, click the button below to generate your Connect Key. Then go to your CODVerify Dashboard → Stores → Connect Store and enter this key to link your WooCommerce store.', 'codverify-woocommerce'); ?>
                </p>

                <?php
    $connect_key = get_option('codverify_wc_connect_key', '');
    if ($connect_key):
?>
                  <div id="codverify-connect-key-wrap" style="margin:16px 0;padding:16px;background:#f0fdf4;border:1px solid #86efac;border-radius:8px;">
                    <p style="margin:0 0 8px;font-weight:600;color:#166534;"><?php esc_html_e('Your Connect Key:', 'codverify-woocommerce'); ?></p>
                    <div style="display:flex;align-items:center;gap:10px;">
                      <code id="codverify-key-display" style="font-size:16px;font-weight:700;letter-spacing:2px;color:#4f46e5;background:#fff;padding:8px 16px;border-radius:6px;border:1px solid #c7d2fe;"><?php echo esc_html($connect_key); ?></code>
                      <button type="button" id="codverify-copy-key" class="button button-secondary" onclick="navigator.clipboard.writeText('<?php echo esc_js($connect_key); ?>').then(function(){document.getElementById('codverify-copy-key').textContent='✅ Copied!'})">
                        📋 <?php esc_html_e('Copy Key', 'codverify-woocommerce'); ?>
                      </button>
                    </div>
                    <p style="margin:10px 0 0;font-size:12px;color:#6b7280;"><?php esc_html_e('Go to CODVerify Dashboard → Stores → Connect Store and paste this key.', 'codverify-woocommerce'); ?></p>
                  </div>
                <?php
    else: ?>
                  <div id="codverify-connect-key-wrap" style="margin:16px 0;"></div>
                <?php
    endif; ?>

                <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
                  <button type="button" id="codverify-gen-key-btn" class="button button-primary">
                    🗝️ <?php esc_html_e('Generate Connect Key', 'codverify-woocommerce'); ?>
                  </button>
                  <a href="https://codverify.tech/dashboard/stores" target="_blank" class="button button-secondary">
                    🏪 <?php esc_html_e('Open Dashboard Stores →', 'codverify-woocommerce'); ?>
                  </a>
                  <span id="codverify-gen-result" style="font-size:13px;"></span>
                </div>
              </div>

              <!-- How It Works Card -->
              <div class="codverify-card codverify-card-howto">
                <h2 class="codverify-card-title">📋 <?php esc_html_e('How It Works', 'codverify-woocommerce'); ?></h2>
                <ol class="codverify-steps">
                  <li>
                    <strong><?php esc_html_e('Create CODVerify Account', 'codverify-woocommerce'); ?></strong><br/>
                    <?php esc_html_e('Register at codverify.tech and log in to your dashboard.', 'codverify-woocommerce'); ?>
                  </li>
                  <li>
                    <strong><?php esc_html_e('Get API Keys', 'codverify-woocommerce'); ?></strong><br/>
                    <?php esc_html_e('Go to Dashboard → API Keys → Generate Key. Copy both the API Key and Secret Key.', 'codverify-woocommerce'); ?>
                  </li>
                  <li>
                    <strong><?php esc_html_e('Enter Keys Here & Generate Connect Key', 'codverify-woocommerce'); ?></strong><br/>
                    <?php esc_html_e('Paste your API Key + Secret Key above, save, then click "Generate Connect Key".', 'codverify-woocommerce'); ?>
                  </li>
                  <li>
                    <strong><?php esc_html_e('Connect Store in Dashboard', 'codverify-woocommerce'); ?></strong><br/>
                    <?php esc_html_e('Go to CODVerify Dashboard → Stores → Connect Store → paste your Connect Key.', 'codverify-woocommerce'); ?>
                  </li>
                  <li>
                    <strong><?php esc_html_e('Done!', 'codverify-woocommerce'); ?></strong><br/>
                    <?php esc_html_e('All COD orders will automatically be sent to CODVerify for WhatsApp verification. Your chatbot will appear on your storefront.', 'codverify-woocommerce'); ?>
                  </li>
                </ol>
                <a href="https://codverify.tech/register" target="_blank" class="codverify-btn-primary">
                  <?php esc_html_e('Create Free Account ↗', 'codverify-woocommerce'); ?>
                </a>
              </div>

            </div><!-- .codverify-cards-grid -->

            <?php submit_button(__('Save Settings', 'codverify-woocommerce'), 'primary', 'submit', true); ?>
          </form>
        </div><!-- .wrap -->

        <script>
        (function($) {
            // Test connection AJAX
            $('#codverify-test-btn').on('click', function() {
                var btn = $(this);
                var result = $('#codverify-test-result');
                btn.prop('disabled', true).text('⏳ Testing...');
                result.html('');
                $.post(ajaxurl, {
                    action: 'codverify_test_connection',
                    nonce: '<?php echo wp_create_nonce('codverify_test'); ?>',
                    api_key: $('#codverify_api_key').val(),
                    secret_key: $('#codverify_secret_key').val(),
                    backend_url: $('#codverify_backend_url').val()
                }, function(response) {
                    btn.prop('disabled', false).text('🔗 Test Connection');
                    if (response.success) {
                        result.html('<span style="color:#22c55e;font-weight:600;">✅ ' + response.data.message + '</span>');
                    } else {
                        result.html('<span style="color:#ef4444;font-weight:600;">❌ ' + response.data.message + '</span>');
                    }
                }).fail(function() {
                    btn.prop('disabled', false).text('🔗 Test Connection');
                    result.html('<span style="color:#ef4444;">❌ Network error. Please try again.</span>');
                });
            });

            // Generate Connect Key AJAX
            $('#codverify-gen-key-btn').on('click', function() {
                var btn = $(this);
                var result = $('#codverify-gen-result');
                btn.prop('disabled', true).text('⏳ Generating...');
                result.html('');
                $.post(ajaxurl, {
                    action: 'codverify_generate_connect_key',
                    nonce: '<?php echo wp_create_nonce('codverify_gen_key'); ?>',
                    api_key: $('#codverify_api_key').val(),
                    secret_key: $('#codverify_secret_key').val(),
                    backend_url: $('#codverify_backend_url').val()
                }, function(response) {
                    btn.prop('disabled', false).text('🗝️ Generate Connect Key');
                    if (response.success) {
                        var key = response.data.secret_key;
                        var wrap = $('#codverify-connect-key-wrap');
                        wrap.html(
                            '<div style="padding:16px;background:#f0fdf4;border:1px solid #86efac;border-radius:8px;">'
                            + '<p style="margin:0 0 8px;font-weight:600;color:#166534;">Your Connect Key:</p>'
                            + '<div style="display:flex;align-items:center;gap:10px;">'
                            + '<code id="codverify-key-display" style="font-size:16px;font-weight:700;letter-spacing:2px;color:#4f46e5;background:#fff;padding:8px 16px;border-radius:6px;border:1px solid #c7d2fe;">' + key + '</code>'
                            + '<button type="button" class="button button-secondary" onclick="navigator.clipboard.writeText(\'' + key + '\').then(function(){this.textContent=\'✅ Copied!\'}.bind(this))">📋 Copy Key</button>'
                            + '</div>'
                            + '<p style="margin:10px 0 0;font-size:12px;color:#6b7280;">Go to CODVerify Dashboard → Stores → Connect Store and paste this key.</p>'
                            + '</div>'
                        );
                        result.html('<span style="color:#22c55e;font-weight:600;">✅ Key generated!</span>');
                    } else {
                        result.html('<span style="color:#ef4444;font-weight:600;">❌ ' + response.data.message + '</span>');
                    }
                }).fail(function() {
                    btn.prop('disabled', false).text('🗝️ Generate Connect Key');
                    result.html('<span style="color:#ef4444;">❌ Network error. Please try again.</span>');
                });
            });

            // Toggle checkbox value for WP settings
            $('input[type="checkbox"]').each(function() {
                var name = $(this).attr('name');
                if (!$('input[type="hidden"][name="' + name + '"]').length) {
                    $(this).before('<input type="hidden" name="' + name + '" value="no" />');
                }
            });
        })(jQuery);
        </script>
        <?php
  }

  // ── AJAX: Test Connection ─────────────────────────────────────────────────

  public function ajax_test_connection(): void
  {
    check_ajax_referer('codverify_test', 'nonce');

    if (!current_user_can('manage_woocommerce')) {
      wp_send_json_error(array('message' => 'Permission denied.'));
    }

    // Temporarily use the submitted values for testing (don't save yet)
    $api_key = sanitize_text_field($_POST['api_key'] ?? '');
    $secret_key = sanitize_text_field($_POST['secret_key'] ?? '');
    $backend = esc_url_raw($_POST['backend_url'] ?? CODVERIFY_API_BASE);

    if (empty($api_key) || empty($secret_key)) {
      wp_send_json_error(array('message' => 'Please enter both API Key and Secret Key before testing.'));
    }

    // Temporarily override options for this test
    update_option('codverify_api_key', $api_key);
    update_option('codverify_secret_key', $secret_key);
    update_option('codverify_backend_url', $backend);

    $api = new CODVerify_API();
    $result = $api->test_connection();

    if ($result['success']) {
      wp_send_json_success(array('message' => $result['message']));
    }
    else {
      wp_send_json_error(array('message' => $result['message']));
    }
  }

  // ── AJAX: Generate WooCommerce Connect Key ────────────────────────────────

  public function ajax_generate_connect_key(): void
  {
    check_ajax_referer('codverify_gen_key', 'nonce');

    if (!current_user_can('manage_woocommerce')) {
      wp_send_json_error(array('message' => 'Permission denied.'));
    }

    $api_key = sanitize_text_field($_POST['api_key'] ?? '');
    $secret_key = sanitize_text_field($_POST['secret_key'] ?? '');
    $backend = esc_url_raw($_POST['backend_url'] ?? CODVERIFY_API_BASE);

    if (empty($api_key) || empty($secret_key)) {
      wp_send_json_error(array('message' => 'Please enter and save your API Key + Secret Key first.'));
    }

    // Save options so the API client can read them
    update_option('codverify_api_key', $api_key);
    update_option('codverify_secret_key', $secret_key);
    update_option('codverify_backend_url', $backend);

    $store_domain = wp_parse_url(get_site_url(), PHP_URL_HOST);
    $store_name = get_bloginfo('name');
    $store_url = get_site_url();

    $api = new CODVerify_API();
    $response = $api->request(
      'POST',
      '/api/v1/auth/woocommerce-generate-key',
      array(
      'store_domain' => $store_domain,
      'store_name' => $store_name,
      'store_url' => $store_url,
    )
    );

    if (!isset($response['success']) || !$response['success']) {
      $msg = isset($response['message']) ? $response['message'] : 'Failed to generate connect key. Check your API credentials.';
      wp_send_json_error(array('message' => $msg));
    }

    $connect_key = $response['data']['secret_key'] ?? '';

    if (empty($connect_key) && !empty($response['data']['is_already_connected'])) {
      wp_send_json_success(array(
        'secret_key' => 'already_connected',
        'message' => 'Store is already connected to a CODVerify account.',
      ));
    }

    if (empty($connect_key)) {
      wp_send_json_error(array('message' => 'No key returned from server. Try again.'));
    }

    // Persist the connect key so it survives page reloads
    update_option('codverify_wc_connect_key', $connect_key);

    wp_send_json_success(array('secret_key' => $connect_key));
  }
}
