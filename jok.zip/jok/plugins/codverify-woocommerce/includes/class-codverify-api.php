<?php
/**
 * CODVerify API Client
 * Handles communication with the CODVerify backend.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class CODVerify_API {

    /** @var string */
    private $api_key;

    /** @var string */
    private $secret_key;

    /** @var string */
    private $base_url;

    public function __construct() {
        $this->api_key    = get_option( 'codverify_api_key', '' );
        $this->secret_key = get_option( 'codverify_secret_key', '' );
        $this->base_url   = rtrim( get_option( 'codverify_backend_url', CODVERIFY_API_BASE ), '/' );
    }

    /**
     * Check if plugin is properly configured.
     */
    public function is_configured(): bool {
        return ! empty( $this->api_key ) && ! empty( $this->secret_key );
    }

    /**
     * Build auth headers for API requests.
     */
    private function get_headers(): array {
        return array(
            'Content-Type'  => 'application/json',
            'X-API-Key'     => $this->api_key,
            'X-Secret-Key'  => $this->secret_key,
            'X-Source'      => 'woocommerce',
            'X-Plugin-Ver'  => CODVERIFY_VERSION,
        );
    }

    /**
     * Send a new order to CODVerify backend.
     *
     * @param array $order_data Order payload
     * @return array{success: bool, message: string, data: array}
     */
    public function send_order( array $order_data ): array {
        if ( ! $this->is_configured() ) {
            return array( 'success' => false, 'message' => 'CODVerify not configured (missing API key)', 'data' => array() );
        }

        $response = wp_remote_post(
            $this->base_url . '/webhook/order/new',
            array(
                'method'    => 'POST',
                'headers'   => $this->get_headers(),
                'body'      => wp_json_encode( $order_data ),
                'timeout'   => 15,
                'sslverify' => true,
            )
        );

        return $this->parse_response( $response );
    }

    /**
     * Send delivery status update to CODVerify backend.
     *
     * @param array $update_data Update payload
     * @return array
     */
    public function send_delivery_update( array $update_data ): array {
        if ( ! $this->is_configured() ) {
            return array( 'success' => false, 'message' => 'CODVerify not configured', 'data' => array() );
        }

        $response = wp_remote_post(
            $this->base_url . '/webhook/order/delivery-update',
            array(
                'method'  => 'POST',
                'headers' => $this->get_headers(),
                'body'    => wp_json_encode( $update_data ),
                'timeout' => 15,
            )
        );

        return $this->parse_response( $response );
    }

    /**
     * Cancel an order in CODVerify.
     *
     * @param string $store_order_id WooCommerce order ID (as string)
     * @return array
     */
    public function cancel_order( string $store_order_id ): array {
        if ( ! $this->is_configured() ) {
            return array( 'success' => false, 'message' => 'CODVerify not configured', 'data' => array() );
        }

        $response = wp_remote_post(
            $this->base_url . '/webhook/order/cancel',
            array(
                'method'  => 'POST',
                'headers' => $this->get_headers(),
                'body'    => wp_json_encode( array( 'store_order_id' => $store_order_id ) ),
                'timeout' => 15,
            )
        );

        return $this->parse_response( $response );
    }

    /**
     * Test the connection with the CODVerify backend.
     *
     * @return array{success: bool, message: string}
     */
    public function test_connection(): array {
        if ( ! $this->is_configured() ) {
            return array( 'success' => false, 'message' => 'API Key or Secret Key is missing.' );
        }

        $response = wp_remote_get(
            $this->base_url . '/merchant/dashboard',
            array(
                'headers' => $this->get_headers(),
                'timeout' => 10,
            )
        );

        if ( is_wp_error( $response ) ) {
            return array( 'success' => false, 'message' => 'Connection error: ' . $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );

        if ( $code === 200 ) {
            return array( 'success' => true, 'message' => 'Connection successful! CODVerify is properly configured.' );
        } elseif ( $code === 401 || $code === 403 ) {
            return array( 'success' => false, 'message' => 'Authentication failed. Please check your API Key and Secret Key.' );
        } else {
            $body = wp_remote_retrieve_body( $response );
            $json = json_decode( $body, true );
            $msg  = $json['detail'] ?? $json['message'] ?? "Unexpected response (HTTP $code). Please check your settings.";
            return array( 'success' => false, 'message' => $msg );
        }
    }

    /**
     * Parse a WP_HTTP response into a standard result array.
     */
    private function parse_response( $response ): array {
        if ( is_wp_error( $response ) ) {
            codverify_log( 'API WP_Error: ' . $response->get_error_message() );
            return array( 'success' => false, 'message' => $response->get_error_message(), 'data' => array() );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        $json = json_decode( $body, true );

        codverify_log( "API Response [$code]: " . $body );

        $success = ( $code >= 200 && $code < 300 );
        $message = $json['message'] ?? ( $success ? 'OK' : "HTTP error $code" );
        $data    = $json['data'] ?? array();

        return compact( 'success', 'message', 'data' );
    }
    /**
     * General-purpose request method for calling arbitrary CODVerify endpoints.
     *
     * @param string $method HTTP method (GET, POST, DELETE, etc.)
     * @param string $path   Endpoint path, e.g. '/api/v1/auth/woocommerce-generate-key'
     * @param array  $body   Request body (will be JSON-encoded for non-GET requests)
     * @return array{success: bool, message: string, data: array}
     */
    public function request( string $method, string $path, array $body = array() ): array {
        $method = strtoupper( $method );
        $url    = $this->base_url . $path;

        $args = array(
            'method'    => $method,
            'headers'   => $this->get_headers(),
            'timeout'   => 15,
            'sslverify' => true,
        );

        if ( ! empty( $body ) && $method !== 'GET' ) {
            $args['body'] = wp_json_encode( $body );
        }

        $response = wp_remote_request( $url, $args );

        return $this->parse_response( $response );
    }

    /**
     * Fetch the chatbot/widget API key from the backend.
     * Returns the chatbot_api_key string or empty string on failure.
     */
    public function get_chatbot_api_key(): string {
        if ( ! $this->is_configured() ) return '';

        $result = $this->request( 'GET', '/api/v1/merchant/dashboard' );

        if ( ! $result['success'] ) return '';

        // Try common paths where the chatbot_api_key may be nested
        return $result['data']['chatbot_api_key']
            ?? $result['data']['data']['chatbot_api_key']
            ?? '';
    }
}

// ── Global logging helper ────────────────────────────────────────────────────
function codverify_log( string $message ): void {
    if ( get_option( 'codverify_enable_logging', 'no' ) === 'yes' ) {
        error_log( '[CODVerify] ' . $message );
    }
}
