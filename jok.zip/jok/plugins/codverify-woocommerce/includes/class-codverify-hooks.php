<?php
/**
 * CODVerify WooCommerce Order Hooks
 * Hooks into WooCommerce order lifecycle events and forwards data to CODVerify.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class CODVerify_Hooks {

    /** @var CODVerify_API */
    private $api;

    public function __construct() {
        $this->api = new CODVerify_API();
    }

    public function init(): void {
        // Trigger on new order creation
        add_action( 'woocommerce_checkout_order_created',    array( $this, 'on_order_created' ),    10, 1 );

        // Trigger when order status changes to processing (payment received / COD accepted)
        add_action( 'woocommerce_order_status_processing',   array( $this, 'on_order_processing' ), 10, 2 );

        // Trigger when order status changes to on-hold (common COD initial state)
        add_action( 'woocommerce_order_status_on-hold',      array( $this, 'on_order_on_hold' ),    10, 2 );

        // Trigger when order is marked as completed (delivered)
        add_action( 'woocommerce_order_status_completed',    array( $this, 'on_order_completed' ),  10, 2 );

        // Trigger when order is cancelled
        add_action( 'woocommerce_order_status_cancelled',    array( $this, 'on_order_cancelled' ),  10, 2 );

        // Trigger when order is refunded / failed
        add_action( 'woocommerce_order_status_refunded',     array( $this, 'on_order_cancelled' ),  10, 2 );

        // Manual "Send to CODVerify" button in order meta box
        add_action( 'add_meta_boxes',                         array( $this, 'add_order_metabox' ) );
        add_action( 'wp_ajax_codverify_resend_order',         array( $this, 'ajax_resend_order' ) );

        // Chatbot widget injection on storefront
        add_action( 'wp_enqueue_scripts',                    array( $this, 'inject_chatbot' ) );

    }

    // ── Chatbot Injection ─────────────────────────────────────────────

    /**
     * Inject the CODVerify chatbot widget script on the WooCommerce storefront.
     */
    public function inject_chatbot(): void {
        if ( is_admin() ) return;
        if ( ! $this->api->is_configured() ) return;

        $chatbot_key = get_transient( 'codverify_chatbot_api_key' );
        if ( false === $chatbot_key ) {
            $chatbot_key = $this->api->get_chatbot_api_key();
            set_transient( 'codverify_chatbot_api_key', (string) $chatbot_key, 12 * HOUR_IN_SECONDS );
        }
        if ( empty( $chatbot_key ) ) return;

        $backend = rtrim( get_option( 'codverify_backend_url', CODVERIFY_API_BASE ), '/' );
        wp_enqueue_script( 'codverify-chatbot', $backend . '/chatbot/script.js', array(), null, true );
        wp_add_inline_script( 'codverify-chatbot', '', 'before' );
        add_filter( 'script_loader_tag', function( $tag, $handle ) use ( $chatbot_key ) {
            if ( 'codverify-chatbot' !== $handle ) return $tag;
            return str_replace( ' src=', ' data-chatbot-key="' . esc_attr( $chatbot_key ) . '" src=', $tag );
        }, 10, 2 );
    }



    // ── Event Handlers ──────────────────────────────────────────────────────

    /**
     * Called immediately when a WooCommerce order is created.
     */
    public function on_order_created( WC_Order $order ): void {
        // Only process COD orders at creation time
        if ( ! $this->is_cod_order( $order ) ) {
            return;
        }
        $this->send_order_to_codverify( $order, 'pending' );
    }

    /**
     * Called when order moves to processing (payment confirmed / COD accepted).
     */
    public function on_order_processing( int $order_id, WC_Order $order ): void {
        $this->maybe_send_order( $order );
    }

    /**
     * Called when order moves to on-hold (common for COD orders).
     */
    public function on_order_on_hold( int $order_id, WC_Order $order ): void {
        $this->maybe_send_order( $order );
    }

    /**
     * Called when order is marked completed (delivered).
     */
    public function on_order_completed( int $order_id, WC_Order $order ): void {
        $this->send_delivery_update( $order, 'delivered' );
    }

    /**
     * Called when order is cancelled or refunded.
     */
    public function on_order_cancelled( int $order_id, WC_Order $order ): void {
        if ( $order->get_meta( '_codverify_sent' ) !== 'yes' ) {
            return;
        }
        $result = $this->api->cancel_order( (string) $order->get_id() );
        codverify_log( "Cancel order #{$order->get_id()}: " . ( $result['success'] ? 'OK' : $result['message'] ) );
    }

    // ── Core Logic ──────────────────────────────────────────────────────────

    /**
     * Only send an order if it hasn't been sent yet (idempotency).
     */
    private function maybe_send_order( WC_Order $order ): void {
        if ( $order->get_meta( '_codverify_sent' ) === 'yes' ) {
            codverify_log( "Order #{$order->get_id()} already sent to CODVerify — skipping." );
            return;
        }
        $this->send_order_to_codverify( $order );
    }

    /**
     * Build payload and send the order to CODVerify.
     *
     * @param WC_Order $order          WooCommerce order object
     * @param string   $force_status   Optional override for fulfillment_status
     */
    public function send_order_to_codverify( WC_Order $order, string $force_status = '' ): array {
        if ( ! $this->api->is_configured() ) {
            codverify_log( 'Plugin not configured — skipping order #' . $order->get_id() );
            return array( 'success' => false, 'message' => 'Plugin not configured' );
        }

        $payload = $this->build_order_payload( $order, $force_status );
        $result  = $this->api->send_order( $payload );

        // Record result as order meta
        if ( $result['success'] ) {
            $order->update_meta_data( '_codverify_sent', 'yes' );
            $order->update_meta_data( '_codverify_sent_at', current_time( 'mysql' ) );
            $order->update_meta_data( '_codverify_order_id', $result['data']['order_id'] ?? '' );
            $order->add_order_note( __( '✅ CODVerify: Order sent for WhatsApp verification.', 'codverify-woocommerce' ) );
            $order->save();
            codverify_log( "Order #{$order->get_id()} sent successfully to CODVerify." );
        } else {
            $order->add_order_note( '⚠️ CODVerify: ' . esc_html( $result['message'] ) );
            $order->save();
            codverify_log( "Order #{$order->get_id()} FAILED: " . $result['message'] );
        }

        return $result;
    }

    /**
     * Send a delivery status update to CODVerify.
     */
    private function send_delivery_update( WC_Order $order, string $delivery_status ): void {
        if ( $order->get_meta( '_codverify_sent' ) !== 'yes' ) {
            return;
        }

        $tracking = $this->extract_tracking( $order );

        $payload = array(
            'store_order_id'  => (string) $order->get_id(),
            'delivery_status' => $delivery_status,
            'tracking_number' => $tracking['number'],
            'tracking_url'    => $tracking['url'],
            'tracking_company'=> $tracking['company'],
        );

        $result = $this->api->send_delivery_update( $payload );
        codverify_log( "Delivery update [{$delivery_status}] for #{$order->get_id()}: " . ( $result['success'] ? 'OK' : $result['message'] ) );
    }

    // ── Payload Builder ─────────────────────────────────────────────────────

    /**
     * Build the full order payload expected by `POST /api/v1/webhook/order/new`.
     */
    private function build_order_payload( WC_Order $order, string $force_status = '' ): array {
        $store_domain = parse_url( get_site_url(), PHP_URL_HOST );
        $is_cod       = $this->is_cod_order( $order );
        $payment_method = $order->get_payment_method_title();

        // Items
        $products = array();
        foreach ( $order->get_items() as $item ) {
            /** @var WC_Order_Item_Product $item */
            $product   = $item->get_product();
            $image_url = '';
            if ( $product && $product->get_image_id() ) {
                $image_url = wp_get_attachment_url( $product->get_image_id() ) ?: '';
            }
            $products[] = array(
                'name'      => $item->get_name(),
                'quantity'  => $item->get_quantity(),
                'price'     => (float) $order->get_item_subtotal( $item, false ),
                'image_url' => $image_url ?: null,
            );
        }

        // Shipping address
        $shipping_addr = null;
        if ( $order->has_shipping_address() || $order->get_shipping_address_1() ) {
            $shipping_addr = array(
                'line1'   => $order->get_shipping_address_1(),
                'line2'   => $order->get_shipping_address_2(),
                'city'    => $order->get_shipping_city(),
                'state'   => $order->get_shipping_state(),
                'pincode' => $order->get_shipping_postcode(),
                'country' => $order->get_shipping_country(),
            );
        }

        // Phone — prefer shipping, fallback to billing
        $phone = $order->get_shipping_phone()
            ?: $order->get_billing_phone()
            ?: '';

        // Normalize phone
        $phone = $this->normalize_phone( $phone );

        // Tracking info
        $tracking = $this->extract_tracking( $order );

        // Fulfillment status
        $fulfillment_status = $force_status ?: 'unfulfilled';
        if ( $order->get_status() === 'completed' ) {
            $fulfillment_status = 'fulfilled';
        }

        // WooCommerce order note (first customer note if any)
        $customer_note = $order->get_customer_note() ?: '';

        // Tags
        $tags = implode( ',', wc_get_order_item_meta( $order->get_id(), 'codverify_tags', false ) ?: array() );

        return array(
            'store_order_id'     => (string) $order->get_id(),
            'order_number'       => ltrim( $order->get_order_number(), '#' ),
            'customer_name'      => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ) ?: 'Customer',
            'customer_phone'     => $phone,
            'customer_email'     => $order->get_billing_email(),
            'order_amount'       => (float) $order->get_total(),
            'currency'           => $order->get_currency(),
            'payment_method'     => $is_cod ? 'cod' : ( $payment_method ?: 'prepaid' ),
            'order_type'         => $is_cod ? 'cod' : 'prepaid',
            'fulfillment_status' => $fulfillment_status,
            'products'           => $products,
            'shipping_address'   => $shipping_addr,
            'source'             => 'woocommerce',
            'shop_domain'        => $store_domain,
            'tags'               => $tags,
            'notes'              => $customer_note,
            'tracking_number'    => $tracking['number'],
            'tracking_url'       => $tracking['url'],
            'tracking_company'   => $tracking['company'],
        );
    }

    // ── Helpers ─────────────────────────────────────────────────────────────

    /**
     * Check if a WooCommerce order is a Cash on Delivery order.
     */
    private function is_cod_order( WC_Order $order ): bool {
        $payment_method = strtolower( $order->get_payment_method() );
        $method_title   = strtolower( $order->get_payment_method_title() );

        $cod_keywords = array( 'cod', 'cash_on_delivery', 'cash-on-delivery', 'cashondelivery', 'cash' );
        foreach ( $cod_keywords as $keyword ) {
            if ( strpos( $payment_method, $keyword ) !== false || strpos( $method_title, $keyword ) !== false ) {
                return true;
            }
        }

        // Allow extra payment method IDs via settings
        $extra_cod = get_option( 'codverify_extra_cod_methods', '' );
        if ( $extra_cod ) {
            $extra_list = array_map( 'trim', explode( ',', $extra_cod ) );
            foreach ( $extra_list as $extra ) {
                if ( ! empty( $extra ) && strpos( $payment_method, strtolower( $extra ) ) !== false ) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Normalize a phone number to E.164 format.
     * Defaults to Indian (+91) prefix if no country code detected.
     */
    private function normalize_phone( string $phone ): string {
        // Strip non-numeric except leading +
        $cleaned = preg_replace( '/[^\d+]/', '', $phone );
        if ( empty( $cleaned ) ) return '';

        // Already has country code
        if ( substr( $cleaned, 0, 1 ) === '+' ) return $cleaned;

        // 10-digit Indian number
        if ( strlen( $cleaned ) === 10 ) return '+91' . $cleaned;

        // 11 digits starting with 0 (Indian landlines / mobiles written as 0XXXXXXXXXX)
        if ( strlen( $cleaned ) === 11 && $cleaned[0] === '0' ) return '+91' . substr( $cleaned, 1 );

        // 12 digits starting with 91 (91XXXXXXXXXX → +91XXXXXXXXXX)
        if ( strlen( $cleaned ) === 12 && substr( $cleaned, 0, 2 ) === '91' ) return '+' . $cleaned;

        return '+' . $cleaned;
    }

    /**
     * Try to extract tracking info from common plugins (Shipment Tracking, etc).
     */
    private function extract_tracking( WC_Order $order ): array {
        $result = array( 'number' => '', 'url' => '', 'company' => '' );

        // WooCommerce Shipment Tracking (official plugin)
        if ( function_exists( 'wc_st_add_tracking_number' ) ) {
            $tracking_items = wc_st_get_tracking_items( $order->get_id() );
            if ( ! empty( $tracking_items ) ) {
                $latest = end( $tracking_items );
                $result['number']  = $latest['tracking_number']      ?? '';
                $result['url']     = $latest['formatted_tracking_link'] ?? '';
                $result['company'] = $latest['tracking_provider']    ?? '';
            }
        }

        // Fallback: check order meta for common keys
        if ( empty( $result['number'] ) ) {
            $meta_keys = array( '_tracking_number', 'tracking_number', '_shipment_tracking_number' );
            foreach ( $meta_keys as $key ) {
                $val = $order->get_meta( $key );
                if ( $val ) { $result['number'] = $val; break; }
            }
        }

        return $result;
    }

    // ── Admin Meta Box ──────────────────────────────────────────────────────

    public function add_order_metabox(): void {
        $screen = wc_get_container()->get( \Automattic\WooCommerce\Internal\Admin\Orders\PageController::class )->get_edit_page_screen_id() ?? 'shop_order';
        add_meta_box(
            'codverify-order-box',
            __( 'CODVerify', 'codverify-woocommerce' ),
            array( $this, 'render_order_metabox' ),
            array( 'shop_order', 'woocommerce_page_wc-orders' ),
            'side',
            'high'
        );
    }

    public function render_order_metabox( $post_or_order ): void {
        $order = ( $post_or_order instanceof WC_Order )
            ? $post_or_order
            : wc_get_order( $post_or_order->ID );

        if ( ! $order ) return;

        $sent    = $order->get_meta( '_codverify_sent' );
        $sent_at = $order->get_meta( '_codverify_sent_at' );
        $cv_id   = $order->get_meta( '_codverify_order_id' );

        echo '<div id="codverify-metabox" style="font-size:13px;">';

        if ( $sent === 'yes' ) {
            echo '<p style="color:#22c55e;font-weight:600;">✅ ' . esc_html__( 'Sent to CODVerify', 'codverify-woocommerce' ) . '</p>';
            if ( $sent_at ) {
                echo '<p style="color:#64748b;font-size:11px;">' . esc_html( $sent_at ) . '</p>';
            }
        } else {
            echo '<p style="color:#f59e0b;font-weight:600;">⏳ ' . esc_html__( 'Not Sent Yet', 'codverify-woocommerce' ) . '</p>';
        }

        echo '<button type="button" id="codverify-resend-btn" class="button button-secondary" style="margin-top:8px;width:100%;" data-order-id="' . esc_attr( $order->get_id() ) . '">';
        echo esc_html__( $sent === 'yes' ? '↻ Re-send to CODVerify' : '📤 Send to CODVerify', 'codverify-woocommerce' );
        echo '</button>';

        echo '<div id="codverify-resend-result" style="margin-top:6px;font-size:12px;"></div>';
        echo '</div>';

        // Inline JS for the AJAX button
        ?>
        <script>
        (function($) {
            $('#codverify-resend-btn').on('click', function() {
                var btn = $(this);
                var orderId = btn.data('order-id');
                btn.prop('disabled', true).text('⏳ Sending...');
                $.post(ajaxurl, {
                    action: 'codverify_resend_order',
                    order_id: orderId,
                    nonce: '<?php echo wp_create_nonce( 'codverify_resend' ); ?>'
                }, function(response) {
                    var result = $('#codverify-resend-result');
                    if (response.success) {
                        result.html('<span style="color:#22c55e;">✅ ' + response.data.message + '</span>');
                        btn.text('↻ Re-send to CODVerify');
                    } else {
                        result.html('<span style="color:#ef4444;">❌ ' + response.data.message + '</span>');
                        btn.text('↻ Re-send to CODVerify');
                    }
                    btn.prop('disabled', false);
                });
            });
        })(jQuery);
        </script>
        <?php
    }

    public function ajax_resend_order(): void {
        check_ajax_referer( 'codverify_resend', 'nonce' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied.' ) );
        }

        $order_id = absint( $_POST['order_id'] ?? 0 );
        $order    = wc_get_order( $order_id );

        if ( ! $order ) {
            wp_send_json_error( array( 'message' => "Order #$order_id not found." ) );
        }

        // Force resend by clearing the sent flag
        $order->delete_meta_data( '_codverify_sent' );
        $order->save();

        $result = $this->send_order_to_codverify( $order );

        if ( $result['success'] ) {
            wp_send_json_success( array( 'message' => 'Order sent to CODVerify successfully!' ) );
        } else {
            wp_send_json_error( array( 'message' => $result['message'] ) );
        }
    }
}
